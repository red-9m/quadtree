
# candidate unordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, false>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-unordered-empty.OwlJhL/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000d3190 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   d3190:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   d3197:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d319b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   d31a3:	48 8b 2a             	mov    (%rdx),%rbp
   d31a6:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   d31ae:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   d31b2:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   d31ba:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   d31c2:	49 89 ff             	mov    %rdi,%r15
   d31c5:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   d31cd:	89 4c 24 58          	mov    %ecx,0x58(%rsp)
   d31d1:	4c 89 44 24 48       	mov    %r8,0x48(%rsp)
   d31d6:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   d31df:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   d31e7:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   d31eb:	0f 11 07             	movups %xmm0,(%rdi)
   d31ee:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   d31f2:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   d31f6:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   d31fa:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   d31fe:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   d3202:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   d3206:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   d320a:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   d320f:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   d3213:	e8 e8 35 07 00       	call   146800 <_ZN5bench6memory11allocationsEv>
   d3218:	80 3d 59 30 09 00 00 	cmpb   $0x0,0x93059(%rip)        # 166278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   d321f:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
   d3224:	49 89 c6             	mov    %rax,%r14
   d3227:	0f 84 94 0e 00 00    	je     d40c1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf31>
   d322d:	0f 31                	rdtsc
   d322f:	48 c1 e2 20          	shl    $0x20,%rdx
   d3233:	48 09 d0             	or     %rdx,%rax
   d3236:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   d323b:	49 8b 13             	mov    (%r11),%rdx
   d323e:	49 39 53 08          	cmp    %rdx,0x8(%r11)
   d3242:	0f 84 17 09 00 00    	je     d3b5f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9cf>
   d3248:	49 29 ec             	sub    %rbp,%r12
   d324b:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   d3250:	83 7c 24 58 01       	cmpl   $0x1,0x58(%rsp)
   d3255:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   d325a:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   d3262:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   d3267:	4d 89 fe             	mov    %r15,%r14
   d326a:	0f 94 44 24 5f       	sete   0x5f(%rsp)
   d326f:	45 31 ed             	xor    %r13d,%r13d
   d3272:	0f 1f 00             	nopl   (%rax)
   d3275:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3280:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   d3285:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d3289:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   d328d:	0f 29 84 24 80 00 00 00 	movaps %xmm0,0x80(%rsp)
   d3295:	48 8b 28             	mov    (%rax),%rbp
   d3298:	4c 8b 60 08          	mov    0x8(%rax),%r12
   d329c:	49 29 ec             	sub    %rbp,%r12
   d329f:	4d 89 e7             	mov    %r12,%r15
   d32a2:	49 c1 ff 04          	sar    $0x4,%r15
   d32a6:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   d32ad:	74 10                	je     d32bf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x12f>
   d32af:	8b 44 24 58          	mov    0x58(%rsp),%eax
   d32b3:	3b 83 b8 02 00 00    	cmp    0x2b8(%rbx),%eax
   d32b9:	0f 84 b2 05 00 00    	je     d3871 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x6e1>
   d32bf:	0f b6 44 24 5f       	movzbl 0x5f(%rsp),%eax
   d32c4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d32c8:	31 f6                	xor    %esi,%esi
   d32ca:	ba 88 01 00 00       	mov    $0x188,%edx
   d32cf:	66 0f 6f 35 d9 c5 07 00 	movdqa 0x7c5d9(%rip),%xmm6        # 14f8b0 <C.66.5+0x290>
   d32d7:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   d32df:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   d32e7:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   d32ee:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   d32f3:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   d32fb:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   d3303:	66 48 0f 6e c0       	movq   %rax,%xmm0
   d3308:	0f 11 b4 24 0c 01 00 00 	movups %xmm6,0x10c(%rsp)
   d3310:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   d3314:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   d331d:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   d3325:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   d332e:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   d3336:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   d333f:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   d3347:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   d334f:	0f 29 64 24 30       	movaps %xmm4,0x30(%rsp)
   d3354:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   d335c:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   d3361:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   d3369:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
   d336e:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   d3376:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   d3382:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   d338e:	e8 7d 3d f3 ff       	call   7110 <memset@plt>
   d3393:	66 0f 6f 64 24 30    	movdqa 0x30(%rsp),%xmm4
   d3399:	66 0f ef c9          	pxor   %xmm1,%xmm1
   d339d:	66 0f 6f 05 1b c5 07 00 	movdqa 0x7c51b(%rip),%xmm0        # 14f8c0 <C.66.5+0x2a0>
   d33a5:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
   d33ab:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
   d33b1:	66 0f ef ed          	pxor   %xmm5,%xmm5
   d33b5:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   d33bc:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   d33c4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   d33c9:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   d33d1:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   d33d9:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   d33e1:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   d33ed:	48 89 9c 24 d8 01 00 00 	mov    %rbx,0x1d8(%rsp)
   d33f5:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   d3401:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   d340d:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   d3419:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   d3425:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   d3431:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   d343c:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   d3444:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   d344f:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   d345b:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   d3463:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   d346f:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   d347a:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   d3482:	48 89 9c 24 78 02 00 00 	mov    %rbx,0x278(%rsp)
   d348a:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   d3496:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   d34a2:	48 89 9c 24 90 02 00 00 	mov    %rbx,0x290(%rsp)
   d34aa:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   d34b6:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   d34be:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   d34c6:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   d34ce:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   d34d6:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   d34de:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   d34ea:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   d34f2:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   d34fb:	0f 29 8c 24 90 00 00 00 	movaps %xmm1,0x90(%rsp)
   d3503:	0f 29 84 24 a0 00 00 00 	movaps %xmm0,0xa0(%rsp)
   d350b:	f3 0f 6f 84 24 99 00 00 00 	movdqu 0x99(%rsp),%xmm0
   d3514:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   d351c:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   d3524:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   d352d:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   d3535:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   d353c:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   d3544:	48 89 9c 24 a8 02 00 00 	mov    %rbx,0x2a8(%rsp)
   d354c:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   d3558:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   d3564:	48 89 9c 24 c0 02 00 00 	mov    %rbx,0x2c0(%rsp)
   d356c:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   d3578:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   d3584:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   d3590:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   d359b:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   d35a7:	48 89 9c 24 60 03 00 00 	mov    %rbx,0x360(%rsp)
   d35af:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   d35ba:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   d35c5:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   d35d1:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   d35d9:	48 89 9c 24 00 04 00 00 	mov    %rbx,0x400(%rsp)
   d35e1:	48 89 9c 24 18 04 00 00 	mov    %rbx,0x418(%rsp)
   d35e9:	48 89 9c 24 30 04 00 00 	mov    %rbx,0x430(%rsp)
   d35f1:	48 89 9c 24 48 04 00 00 	mov    %rbx,0x448(%rsp)
   d35f9:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   d3601:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   d3609:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   d3611:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   d3619:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   d3621:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   d3628:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   d3631:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   d363c:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   d3643:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   d364a:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   d3655:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   d365c:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   d3664:	e8 17 52 02 00       	call   f8880 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   d3669:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   d3670:	0f 85 1a 07 00 00    	jne    d3d90 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc00>
   d3676:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   d367f:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   d3687:	48 89 5b 50          	mov    %rbx,0x50(%rbx)
   d368b:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   d3693:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   d369c:	c6 83 ec 00 00 00 00 	movb   $0x0,0xec(%rbx)
   d36a3:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
   d36a7:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   d36b0:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   d36b8:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   d36bc:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   d36c5:	48 89 43 48          	mov    %rax,0x48(%rbx)
   d36c9:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   d36d0:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
   d36d4:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   d36dd:	48 89 83 98 00 00 00 	mov    %rax,0x98(%rbx)
   d36e4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   d36e9:	0f 11 43 38          	movups %xmm0,0x38(%rbx)
   d36ed:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d36f1:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
   d36f8:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   d3701:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
   d3708:	0f 11 83 a8 00 00 00 	movups %xmm0,0xa8(%rbx)
   d370f:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   d3717:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   d3720:	48 c7 43 58 00 00 00 00 	movq   $0x0,0x58(%rbx)
   d3728:	0f 11 83 b1 00 00 00 	movups %xmm0,0xb1(%rbx)
   d372f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d3733:	0f 11 83 d0 00 00 00 	movups %xmm0,0xd0(%rbx)
   d373a:	48 c7 43 60 00 00 00 00 	movq   $0x0,0x60(%rbx)
   d3742:	48 c7 43 68 00 00 00 00 	movq   $0x0,0x68(%rbx)
   d374a:	48 c7 43 70 00 00 00 00 	movq   $0x0,0x70(%rbx)
   d3752:	48 c7 43 78 00 00 00 00 	movq   $0x0,0x78(%rbx)
   d375a:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   d3764:	c6 83 94 00 00 00 00 	movb   $0x0,0x94(%rbx)
   d376b:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   d3775:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   d3780:	c7 83 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%rbx)
   d378a:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   d3791:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   d379a:	48 89 9b f0 00 00 00 	mov    %rbx,0xf0(%rbx)
   d37a1:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
   d37a7:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   d37ae:	48 c7 83 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rbx)
   d37b9:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   d37c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   d37c5:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   d37cc:	8b 44 24 58          	mov    0x58(%rsp),%eax
   d37d0:	48 c7 83 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rbx)
   d37db:	48 89 9b 08 01 00 00 	mov    %rbx,0x108(%rbx)
   d37e2:	48 c7 83 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rbx)
   d37ed:	48 c7 83 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rbx)
   d37f8:	48 89 9b 20 01 00 00 	mov    %rbx,0x120(%rbx)
   d37ff:	48 c7 83 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rbx)
   d380a:	48 c7 83 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rbx)
   d3815:	48 89 9b 38 01 00 00 	mov    %rbx,0x138(%rbx)
   d381c:	48 c7 83 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rbx)
   d3827:	48 c7 83 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rbx)
   d3832:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   d383d:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   d3847:	c6 83 80 01 00 00 01 	movb   $0x1,0x180(%rbx)
   d384e:	89 83 b8 02 00 00    	mov    %eax,0x2b8(%rbx)
   d3854:	0f 11 83 50 01 00 00 	movups %xmm0,0x150(%rbx)
   d385b:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   d3864:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   d386c:	e8 0f 50 02 00       	call   f8880 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   d3871:	4c 39 bb c0 02 00 00 	cmp    %r15,0x2c0(%rbx)
   d3878:	0f 82 d2 04 00 00    	jb     d3d50 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbc0>
   d387e:	48 8b 93 78 02 00 00 	mov    0x278(%rbx),%rdx
   d3885:	4c 8b 8b 70 02 00 00 	mov    0x270(%rbx),%r9
   d388c:	48 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rcx
   d3896:	49 89 d0             	mov    %rdx,%r8
   d3899:	4d 29 c8             	sub    %r9,%r8
   d389c:	4c 89 c0             	mov    %r8,%rax
   d389f:	48 c1 f8 03          	sar    $0x3,%rax
   d38a3:	48 0f af c1          	imul   %rcx,%rax
   d38a7:	4c 39 f8             	cmp    %r15,%rax
   d38aa:	0f 82 20 04 00 00    	jb     d3cd0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb40>
   d38b0:	49 39 c7             	cmp    %rax,%r15
   d38b3:	73 16                	jae    d38cb <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x73b>
   d38b5:	49 6b c7 38          	imul   $0x38,%r15,%rax
   d38b9:	49 01 c1             	add    %rax,%r9
   d38bc:	4c 39 ca             	cmp    %r9,%rdx
   d38bf:	74 07                	je     d38c8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x738>
   d38c1:	4c 89 8b 78 02 00 00 	mov    %r9,0x278(%rbx)
   d38c8:	4c 89 ca             	mov    %r9,%rdx
   d38cb:	48 8b bb 70 02 00 00 	mov    0x270(%rbx),%rdi
   d38d2:	4d 85 e4             	test   %r12,%r12
   d38d5:	74 5a                	je     d3931 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7a1>
   d38d7:	48 89 f8             	mov    %rdi,%rax
   d38da:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d38de:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   d38e2:	31 f6                	xor    %esi,%esi
   d38e4:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   d38ea:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d38f5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3900:	f3 0f 6f 4d 00       	movdqu 0x0(%rbp),%xmm1
   d3905:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   d3909:	48 83 c5 10          	add    $0x10,%rbp
   d390d:	48 83 c0 38          	add    $0x38,%rax
   d3911:	89 70 d8             	mov    %esi,-0x28(%rax)
   d3914:	48 83 c6 01          	add    $0x1,%rsi
   d3918:	0f 11 40 e8          	movups %xmm0,-0x18(%rax)
   d391c:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   d3924:	0f 11 48 c8          	movups %xmm1,-0x38(%rax)
   d3928:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
   d392c:	4c 39 fe             	cmp    %r15,%rsi
   d392f:	72 cf                	jb     d3900 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x770>
   d3931:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d3935:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
   d3939:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   d3945:	4c 8d bb 88 01 00 00 	lea    0x188(%rbx),%r15
   d394c:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   d3954:	48 39 fa             	cmp    %rdi,%rdx
   d3957:	0f 84 4b 04 00 00    	je     d3da8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc18>
   d395d:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   d3967:	48 29 fa             	sub    %rdi,%rdx
   d396a:	48 c1 fa 03          	sar    $0x3,%rdx
   d396e:	48 0f af d0          	imul   %rax,%rdx
   d3972:	48 39 53 38          	cmp    %rdx,0x38(%rbx)
   d3976:	0f 82 b4 04 00 00    	jb     d3e30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xca0>
   d397c:	48 83 ec 20          	sub    $0x20,%rsp
   d3980:	48 8d b3 70 02 00 00 	lea    0x270(%rbx),%rsi
   d3987:	4c 89 f9             	mov    %r15,%rcx
   d398a:	48 89 ef             	mov    %rbp,%rdi
   d398d:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   d3996:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   d399f:	0f 11 04 24          	movups %xmm0,(%rsp)
   d39a3:	e8 a8 d1 ff ff       	call   d0b50 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   d39a8:	48 83 c4 20          	add    $0x20,%rsp
   d39ac:	84 c0                	test   %al,%al
   d39ae:	0f 85 84 02 00 00    	jne    d3c38 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa8>
   d39b4:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
   d39b9:	48 83 7c 24 08 18    	cmpq   $0x18,0x8(%rsp)
   d39bf:	0f 84 eb 02 00 00    	je     d3cb0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb20>
   d39c5:	48 8d 84 24 80 00 00 00 	lea    0x80(%rsp),%rax
   d39cd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d39d1:	4c 89 bc 24 b8 00 00 00 	mov    %r15,0xb8(%rsp)
   d39d9:	44 8b bb d0 00 00 00 	mov    0xd0(%rbx),%r15d
   d39e0:	48 89 84 24 40 01 00 00 	mov    %rax,0x140(%rsp)
   d39e8:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   d39ed:	c6 84 24 b0 00 00 00 00 	movb   $0x0,0xb0(%rsp)
   d39f5:	66 0f 6f 8c 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm1
   d39fe:	48 89 84 24 c0 00 00 00 	mov    %rax,0xc0(%rsp)
   d3a06:	48 c7 84 24 c8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xc8(%rsp)
   d3a12:	0f 29 8c 24 10 03 00 00 	movaps %xmm1,0x310(%rsp)
   d3a1a:	66 0f 6f 8c 24 c0 00 00 00 	movdqa 0xc0(%rsp),%xmm1
   d3a23:	0f 29 84 24 d0 00 00 00 	movaps %xmm0,0xd0(%rsp)
   d3a2b:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   d3a33:	0f 29 8c 24 20 03 00 00 	movaps %xmm1,0x320(%rsp)
   d3a3b:	0f 29 84 24 30 03 00 00 	movaps %xmm0,0x330(%rsp)
   d3a43:	0f 29 84 24 40 03 00 00 	movaps %xmm0,0x340(%rsp)
   d3a4b:	45 85 ff             	test   %r15d,%r15d
   d3a4e:	0f 85 9c 01 00 00    	jne    d3bf0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa60>
   d3a54:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d3a58:	31 c0                	xor    %eax,%eax
   d3a5a:	0f 11 84 24 98 01 00 00 	movups %xmm0,0x198(%rsp)
   d3a62:	f3 0f 6f 84 24 98 01 00 00 	movdqu 0x198(%rsp),%xmm0
   d3a6b:	45 85 ff             	test   %r15d,%r15d
   d3a6e:	44 89 f9             	mov    %r15d,%ecx
   d3a71:	41 0f 95 c7          	setne  %r15b
   d3a75:	3c 0b                	cmp    $0xb,%al
   d3a77:	45 0f b6 ff          	movzbl %r15b,%r15d
   d3a7b:	40 0f 94 c5          	sete   %bpl
   d3a7f:	66 0f c6 c0 01       	shufpd $0x1,%xmm0,%xmm0
   d3a84:	48 83 7c 24 08 18    	cmpq   $0x18,0x8(%rsp)
   d3a8a:	0f 84 b0 01 00 00    	je     d3c40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab0>
   d3a90:	41 8b 46 38          	mov    0x38(%r14),%eax
   d3a94:	49 01 4e 30          	add    %rcx,0x30(%r14)
   d3a98:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   d3aa2:	48 8b 94 24 88 00 00 00 	mov    0x88(%rsp),%rdx
   d3aaa:	f3 41 0f 6f 76 18    	movdqu 0x18(%r14),%xmm6
   d3ab0:	44 39 f8             	cmp    %r15d,%eax
   d3ab3:	f3 41 0f 6f 6e 48    	movdqu 0x48(%r14),%xmm5
   d3ab9:	41 0f 42 c7          	cmovb  %r15d,%eax
   d3abd:	4c 01 ea             	add    %r13,%rdx
   d3ac0:	66 0f d4 c6          	paddq  %xmm6,%xmm0
   d3ac4:	49 83 c5 01          	add    $0x1,%r13
   d3ac8:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   d3acd:	f3 0f 7e 84 24 80 00 00 00 	movq   0x80(%rsp),%xmm0
   d3ad6:	41 89 46 38          	mov    %eax,0x38(%r14)
   d3ada:	48 89 d0             	mov    %rdx,%rax
   d3add:	48 c1 e8 1e          	shr    $0x1e,%rax
   d3ae1:	41 08 6e 68          	or     %bpl,0x68(%r14)
   d3ae5:	48 31 d0             	xor    %rdx,%rax
   d3ae8:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   d3af2:	48 0f af c2          	imul   %rdx,%rax
   d3af6:	48 89 c2             	mov    %rax,%rdx
   d3af9:	48 c1 ea 1b          	shr    $0x1b,%rdx
   d3afd:	48 31 d0             	xor    %rdx,%rax
   d3b00:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   d3b0a:	48 0f af c2          	imul   %rdx,%rax
   d3b0e:	48 89 c2             	mov    %rax,%rdx
   d3b11:	48 c1 ea 1f          	shr    $0x1f,%rdx
   d3b15:	48 31 d0             	xor    %rdx,%rax
   d3b18:	66 48 0f 6e f8       	movq   %rax,%xmm7
   d3b1d:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   d3b22:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
   d3b26:	48 8b 10             	mov    (%rax),%rdx
   d3b29:	48 8b 40 08          	mov    0x8(%rax),%rax
   d3b2d:	66 0f d4 c5          	paddq  %xmm5,%xmm0
   d3b31:	41 0f 11 46 48       	movups %xmm0,0x48(%r14)
   d3b36:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   d3b3b:	48 29 d0             	sub    %rdx,%rax
   d3b3e:	48 c1 f8 03          	sar    $0x3,%rax
   d3b42:	48 0f af c1          	imul   %rcx,%rax
   d3b46:	49 39 c5             	cmp    %rax,%r13
   d3b49:	0f 82 31 f7 ff ff    	jb     d3280 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf0>
   d3b4f:	4d 89 f7             	mov    %r14,%r15
   d3b52:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   d3b5a:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
   d3b5f:	80 3d 12 27 09 00 00 	cmpb   $0x0,0x92712(%rip)        # 166278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   d3b66:	0f 84 6e 05 00 00    	je     d40da <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf4a>
   d3b6c:	0f 31                	rdtsc
   d3b6e:	48 c1 e2 20          	shl    $0x20,%rdx
   d3b72:	48 09 d0             	or     %rdx,%rax
   d3b75:	48 2b 44 24 40       	sub    0x40(%rsp),%rax
   d3b7a:	0f 88 23 05 00 00    	js     d40a3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf13>
   d3b80:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d3b84:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   d3b89:	f2 0f 59 05 9f 26 09 00 	mulsd  0x9269f(%rip),%xmm0        # 166230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   d3b91:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   d3b96:	49 89 07             	mov    %rax,(%r15)
   d3b99:	e8 62 2c 07 00       	call   146800 <_ZN5bench6memory11allocationsEv>
   d3b9e:	4c 29 f0             	sub    %r14,%rax
   d3ba1:	49 89 47 58          	mov    %rax,0x58(%r15)
   d3ba5:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   d3bad:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   d3bb6:	0f 85 42 05 00 00    	jne    d40fe <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf6e>
   d3bbc:	4c 89 f8             	mov    %r15,%rax
   d3bbf:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   d3bc7:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   d3bcf:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   d3bd7:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   d3bdf:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   d3be7:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   d3bee:	c3                   	ret
   d3bef:	90                   	nop
   d3bf0:	48 8b 8c 24 20 03 00 00 	mov    0x320(%rsp),%rcx
   d3bf8:	4c 8b 84 24 28 03 00 00 	mov    0x328(%rsp),%r8
   d3c00:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   d3c08:	48 8d 94 24 40 01 00 00 	lea    0x140(%rsp),%rdx
   d3c10:	4c 8d 8c 24 f0 00 00 00 	lea    0xf0(%rsp),%r9
   d3c18:	48 89 ee             	mov    %rbp,%rsi
   d3c1b:	e8 b0 42 ff ff       	call   c7ed0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_>
   d3c20:	0f b6 84 24 90 01 00 00 	movzbl 0x190(%rsp),%eax
   d3c28:	3c 0b                	cmp    $0xb,%al
   d3c2a:	0f 84 32 fe ff ff    	je     d3a62 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8d2>
   d3c30:	84 c0                	test   %al,%al
   d3c32:	0f 84 2a fe ff ff    	je     d3a62 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8d2>
   d3c38:	0f b6 d0             	movzbl %al,%edx
   d3c3b:	e9 f5 01 00 00       	jmp    d3e35 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xca5>
   d3c40:	f2 0f 10 15 e8 25 09 00 	movsd  0x925e8(%rip),%xmm2        # 166230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   d3c48:	4c 89 e0             	mov    %r12,%rax
   d3c4b:	48 2b 44 24 40       	sub    0x40(%rsp),%rax
   d3c50:	0f 88 8a 03 00 00    	js     d3fe0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe50>
   d3c56:	66 0f ef c9          	pxor   %xmm1,%xmm1
   d3c5a:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
   d3c5f:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
   d3c63:	80 3d 0e 26 09 00 00 	cmpb   $0x0,0x9260e(%rip)        # 166278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   d3c6a:	f2 48 0f 2c c1       	cvttsd2si %xmm1,%rax
   d3c6f:	49 89 46 08          	mov    %rax,0x8(%r14)
   d3c73:	0f 84 97 03 00 00    	je     d4010 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe80>
   d3c79:	0f 31                	rdtsc
   d3c7b:	48 c1 e2 20          	shl    $0x20,%rdx
   d3c7f:	48 09 d0             	or     %rdx,%rax
   d3c82:	4c 29 e0             	sub    %r12,%rax
   d3c85:	0f 88 2d 03 00 00    	js     d3fb8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe28>
   d3c8b:	66 0f ef c9          	pxor   %xmm1,%xmm1
   d3c8f:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
   d3c94:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
   d3c98:	f2 48 0f 2c c1       	cvttsd2si %xmm1,%rax
   d3c9d:	49 89 46 10          	mov    %rax,0x10(%r14)
   d3ca1:	e9 ea fd ff ff       	jmp    d3a90 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x900>
   d3ca6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   d3cb0:	80 3d c1 25 09 00 00 	cmpb   $0x0,0x925c1(%rip)        # 166278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   d3cb7:	0f 84 43 03 00 00    	je     d4000 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   d3cbd:	0f 31                	rdtsc
   d3cbf:	48 c1 e2 20          	shl    $0x20,%rdx
   d3cc3:	48 09 d0             	or     %rdx,%rax
   d3cc6:	49 89 c4             	mov    %rax,%r12
   d3cc9:	e9 f7 fc ff ff       	jmp    d39c5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x835>
   d3cce:	66 90                	xchg   %ax,%ax
   d3cd0:	48 8b b3 80 02 00 00 	mov    0x280(%rbx),%rsi
   d3cd7:	4d 89 fb             	mov    %r15,%r11
   d3cda:	49 29 c3             	sub    %rax,%r11
   d3cdd:	48 89 f7             	mov    %rsi,%rdi
   d3ce0:	48 29 d7             	sub    %rdx,%rdi
   d3ce3:	48 c1 ff 03          	sar    $0x3,%rdi
   d3ce7:	48 0f af f9          	imul   %rcx,%rdi
   d3ceb:	4c 39 df             	cmp    %r11,%rdi
   d3cee:	0f 82 5c 01 00 00    	jb     d3e50 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc0>
   d3cf4:	4c 89 de             	mov    %r11,%rsi
   d3cf7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d3cfb:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   d3cff:	48 89 d0             	mov    %rdx,%rax
   d3d02:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   d3d0a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3d15:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3d20:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   d3d24:	48 83 c0 38          	add    $0x38,%rax
   d3d28:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   d3d2c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   d3d30:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   d3d34:	48 83 ee 01          	sub    $0x1,%rsi
   d3d38:	75 e6                	jne    d3d20 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb90>
   d3d3a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   d3d3e:	4c 01 da             	add    %r11,%rdx
   d3d41:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   d3d48:	e9 7e fb ff ff       	jmp    d38cb <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x73b>
   d3d4d:	0f 1f 00             	nopl   (%rax)
   d3d50:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d3d54:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   d3d5c:	48 8d bb 88 01 00 00 	lea    0x188(%rbx),%rdi
   d3d63:	4c 89 bc 24 20 03 00 00 	mov    %r15,0x320(%rsp)
   d3d6b:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   d3d73:	e8 c8 79 03 00       	call   10b740 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   d3d78:	84 c0                	test   %al,%al
   d3d7a:	0f 85 b8 fe ff ff    	jne    d3c38 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa8>
   d3d80:	4c 89 bb c0 02 00 00 	mov    %r15,0x2c0(%rbx)
   d3d87:	e9 f2 fa ff ff       	jmp    d387e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x6ee>
   d3d8c:	0f 1f 40 00          	nopl   0x0(%rax)
   d3d90:	c6 83 80 01 00 00 00 	movb   $0x0,0x180(%rbx)
   d3d97:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   d3d9b:	e8 e0 4a 02 00       	call   f8880 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   d3da0:	e9 d1 f8 ff ff       	jmp    d3676 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x4e6>
   d3da5:	0f 1f 00             	nopl   (%rax)
   d3da8:	48 83 bb c8 00 00 00 00 	cmpq   $0x0,0xc8(%rbx)
   d3db0:	74 55                	je     d3e07 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc77>
   d3db2:	48 8b 93 80 00 00 00 	mov    0x80(%rbx),%rdx
   d3db9:	48 85 d2             	test   %rdx,%rdx
   d3dbc:	0f 85 75 02 00 00    	jne    d4037 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xea7>
   d3dc2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   d3dc7:	66 0f 6f 05 b1 ba 07 00 	movdqa 0x7bab1(%rip),%xmm0        # 14f880 <C.66.5+0x260>
   d3dcf:	c7 83 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%rbx)
   d3dd9:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   d3de4:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   d3deb:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   d3df6:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   d3e00:	0f 11 83 dc 00 00 00 	movups %xmm0,0xdc(%rbx)
   d3e07:	80 7b 08 00          	cmpb   $0x0,0x8(%rbx)
   d3e0b:	0f 84 a3 fb ff ff    	je     d39b4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x824>
   d3e11:	80 bb 60 01 00 00 00 	cmpb   $0x0,0x160(%rbx)
   d3e18:	0f 84 96 fb ff ff    	je     d39b4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x824>
   d3e1e:	c6 83 60 01 00 00 00 	movb   $0x0,0x160(%rbx)
   d3e25:	e9 8a fb ff ff       	jmp    d39b4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x824>
   d3e2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   d3e30:	ba 10 00 00 00       	mov    $0x10,%edx
   d3e35:	48 8b 3d 24 24 09 00 	mov    0x92424(%rip),%rdi        # 166260 <stderr@GLIBC_2.2.5>
   d3e3c:	48 8d 35 5d 9b 07 00 	lea    0x79b5d(%rip),%rsi        # 14d9a0 <_IO_stdin_used+0x19a0>
   d3e43:	31 c0                	xor    %eax,%eax
   d3e45:	e8 f6 34 f3 ff       	call   7340 <fprintf@plt>
   d3e4a:	e8 d1 32 f3 ff       	call   7120 <abort@plt>
   d3e4f:	90                   	nop
   d3e50:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   d3e5a:	48 29 c7             	sub    %rax,%rdi
   d3e5d:	4c 39 df             	cmp    %r11,%rdi
   d3e60:	0f 82 b2 89 f3 ff    	jb     c818 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   d3e66:	4c 39 d8             	cmp    %r11,%rax
   d3e69:	4c 89 d9             	mov    %r11,%rcx
   d3e6c:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
   d3e71:	48 0f 43 c8          	cmovae %rax,%rcx
   d3e75:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
   d3e7a:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   d3e7f:	48 01 c1             	add    %rax,%rcx
   d3e82:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   d3e87:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   d3e91:	48 39 c1             	cmp    %rax,%rcx
   d3e94:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
   d3e99:	48 0f 47 c8          	cmova  %rax,%rcx
   d3e9d:	48 6b c1 38          	imul   $0x38,%rcx,%rax
   d3ea1:	48 89 c7             	mov    %rax,%rdi
   d3ea4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   d3ea9:	e8 32 2a 07 00       	call   1468e0 <_Znwm>
   d3eae:	4c 6b 5c 24 20 38    	imul   $0x38,0x20(%rsp),%r11
   d3eb4:	4c 8b 44 24 68       	mov    0x68(%rsp),%r8
   d3eb9:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d3ebd:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   d3ec2:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
   d3ec7:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   d3ecb:	49 01 c0             	add    %rax,%r8
   d3ece:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   d3ed3:	4d 01 c3             	add    %r8,%r11
   d3ed6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   d3ee0:	41 0f 11 40 10       	movups %xmm0,0x10(%r8)
   d3ee5:	49 83 c0 38          	add    $0x38,%r8
   d3ee9:	41 0f 11 40 c8       	movups %xmm0,-0x38(%r8)
   d3eee:	41 0f 11 48 e0       	movups %xmm1,-0x20(%r8)
   d3ef3:	41 0f 11 40 f0       	movups %xmm0,-0x10(%r8)
   d3ef8:	4d 39 d8             	cmp    %r11,%r8
   d3efb:	75 e3                	jne    d3ee0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd50>
   d3efd:	4c 39 ca             	cmp    %r9,%rdx
   d3f00:	74 70                	je     d3f72 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xde2>
   d3f02:	4c 89 cf             	mov    %r9,%rdi
   d3f05:	49 89 c0             	mov    %rax,%r8
   d3f08:	90                   	nop
   d3f09:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3f14:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3f1f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3f2a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3f35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   d3f40:	f3 0f 6f 07          	movdqu (%rdi),%xmm0
   d3f44:	48 8b 4f 30          	mov    0x30(%rdi),%rcx
   d3f48:	48 83 c7 38          	add    $0x38,%rdi
   d3f4c:	49 83 c0 38          	add    $0x38,%r8
   d3f50:	41 0f 11 40 c8       	movups %xmm0,-0x38(%r8)
   d3f55:	f3 0f 6f 47 d8       	movdqu -0x28(%rdi),%xmm0
   d3f5a:	49 89 48 f8          	mov    %rcx,-0x8(%r8)
   d3f5e:	41 0f 11 40 d8       	movups %xmm0,-0x28(%r8)
   d3f63:	f3 0f 6f 47 e8       	movdqu -0x18(%rdi),%xmm0
   d3f68:	41 0f 11 40 e8       	movups %xmm0,-0x18(%r8)
   d3f6d:	48 39 fa             	cmp    %rdi,%rdx
   d3f70:	75 ce                	jne    d3f40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdb0>
   d3f72:	4d 85 c9             	test   %r9,%r9
   d3f75:	74 15                	je     d3f8c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdfc>
   d3f77:	4c 29 ce             	sub    %r9,%rsi
   d3f7a:	4c 89 cf             	mov    %r9,%rdi
   d3f7d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   d3f82:	e8 59 2a 07 00       	call   1469e0 <_ZdlPvm>
   d3f87:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   d3f8c:	49 6b d7 38          	imul   $0x38,%r15,%rdx
   d3f90:	48 89 83 70 02 00 00 	mov    %rax,0x270(%rbx)
   d3f97:	48 01 c2             	add    %rax,%rdx
   d3f9a:	48 03 44 24 10       	add    0x10(%rsp),%rax
   d3f9f:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   d3fa6:	48 89 83 80 02 00 00 	mov    %rax,0x280(%rbx)
   d3fad:	e9 19 f9 ff ff       	jmp    d38cb <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x73b>
   d3fb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   d3fb8:	48 89 c2             	mov    %rax,%rdx
   d3fbb:	83 e0 01             	and    $0x1,%eax
   d3fbe:	66 0f ef c9          	pxor   %xmm1,%xmm1
   d3fc2:	48 d1 ea             	shr    $1,%rdx
   d3fc5:	48 09 c2             	or     %rax,%rdx
   d3fc8:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
   d3fcd:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
   d3fd1:	e9 be fc ff ff       	jmp    d3c94 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb04>
   d3fd6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   d3fe0:	48 89 c2             	mov    %rax,%rdx
   d3fe3:	83 e0 01             	and    $0x1,%eax
   d3fe6:	66 0f ef c9          	pxor   %xmm1,%xmm1
   d3fea:	48 d1 ea             	shr    $1,%rdx
   d3fed:	48 09 c2             	or     %rax,%rdx
   d3ff0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
   d3ff5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
   d3ff9:	e9 61 fc ff ff       	jmp    d3c5f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xacf>
   d3ffe:	66 90                	xchg   %ax,%ax
   d4000:	e8 cb 32 f3 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   d4005:	49 89 c4             	mov    %rax,%r12
   d4008:	e9 b8 f9 ff ff       	jmp    d39c5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x835>
   d400d:	0f 1f 00             	nopl   (%rax)
   d4010:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   d4015:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   d401a:	e8 b1 32 f3 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   d401f:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
   d4025:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   d402a:	f2 0f 10 15 fe 21 09 00 	movsd  0x921fe(%rip),%xmm2        # 166230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   d4032:	e9 4b fc ff ff       	jmp    d3c82 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf2>
   d4037:	48 c7 83 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%rbx)
   d4042:	80 bb 94 00 00 00 00 	cmpb   $0x0,0x94(%rbx)
   d4049:	0f 85 95 00 00 00    	jne    d40e4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf54>
   d404f:	8b 83 90 00 00 00    	mov    0x90(%rbx),%eax
   d4055:	83 c0 01             	add    $0x1,%eax
   d4058:	89 83 90 00 00 00    	mov    %eax,0x90(%rbx)
   d405e:	83 f8 ff             	cmp    $0xffffffff,%eax
   d4061:	0f 85 5b fd ff ff    	jne    d3dc2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc32>
   d4067:	48 8b 43 78          	mov    0x78(%rbx),%rax
   d406b:	48 89 d1             	mov    %rdx,%rcx
   d406e:	48 c1 e1 04          	shl    $0x4,%rcx
   d4072:	48 01 c1             	add    %rax,%rcx
   d4075:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   d407c:	48 83 c0 10          	add    $0x10,%rax
   d4080:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   d4088:	48 39 c1             	cmp    %rax,%rcx
   d408b:	75 e8                	jne    d4075 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xee5>
   d408d:	48 01 93 b0 00 00 00 	add    %rdx,0xb0(%rbx)
   d4094:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   d409e:	e9 1f fd ff ff       	jmp    d3dc2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc32>
   d40a3:	48 89 c2             	mov    %rax,%rdx
   d40a6:	83 e0 01             	and    $0x1,%eax
   d40a9:	66 0f ef c0          	pxor   %xmm0,%xmm0
   d40ad:	48 d1 ea             	shr    $1,%rdx
   d40b0:	48 09 c2             	or     %rax,%rdx
   d40b3:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   d40b8:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   d40bc:	e9 c8 fa ff ff       	jmp    d3b89 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9f9>
   d40c1:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
   d40c6:	e8 d5 cf f3 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   d40cb:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
   d40d0:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   d40d5:	e9 61 f1 ff ff       	jmp    d323b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab>
   d40da:	e8 c1 cf f3 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   d40df:	e9 91 fa ff ff       	jmp    d3b75 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9e5>
   d40e4:	48 c7 83 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rbx)
   d40ef:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   d40f9:	e9 c4 fc ff ff       	jmp    d3dc2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc32>
   d40fe:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   d4106:	e8 55 31 f3 ff       	call   7260 <__stack_chk_fail@plt>

# candidate ordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, true>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-unordered-empty.OwlJhL/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000ebee0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   ebee0:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   ebee7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ebeeb:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   ebef3:	48 8b 2a             	mov    (%rdx),%rbp
   ebef6:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   ebefe:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   ebf02:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   ebf0a:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   ebf12:	49 89 ff             	mov    %rdi,%r15
   ebf15:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   ebf1d:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   ebf24:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   ebf29:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   ebf32:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   ebf3a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   ebf3e:	0f 11 07             	movups %xmm0,(%rdi)
   ebf41:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   ebf45:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   ebf49:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   ebf4d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   ebf51:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   ebf55:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   ebf59:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   ebf5d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   ebf62:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   ebf66:	e8 95 a8 05 00       	call   146800 <_ZN5bench6memory11allocationsEv>
   ebf6b:	80 3d 06 a3 07 00 00 	cmpb   $0x0,0x7a306(%rip)        # 166278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ebf72:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   ebf77:	49 89 c6             	mov    %rax,%r14
   ebf7a:	0f 84 a3 0e 00 00    	je     ece23 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf43>
   ebf80:	0f 31                	rdtsc
   ebf82:	48 c1 e2 20          	shl    $0x20,%rdx
   ebf86:	48 09 d0             	or     %rdx,%rax
   ebf89:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   ebf91:	49 8b 11             	mov    (%r9),%rdx
   ebf94:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   ebf98:	0f 84 4b 09 00 00    	je     ec8e9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa09>
   ebf9e:	49 29 ec             	sub    %rbp,%r12
   ebfa1:	c6 44 24 77 00       	movb   $0x0,0x77(%rsp)
   ebfa6:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   ebfae:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ebfb2:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   ebfba:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   ebfc3:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   ebfcc:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   ebfd5:	c7 44 24 70 00 00 00 00 	movl   $0x0,0x70(%rsp)
   ebfdd:	4c 89 8c 24 88 00 00 00 	mov    %r9,0x88(%rsp)
   ebfe5:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   ebfed:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   ebff5:	49 89 de             	mov    %rbx,%r14
   ebff8:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   ec000:	45 31 ed             	xor    %r13d,%r13d
   ec003:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   ec008:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   ec00d:	0f 1f 00             	nopl   (%rax)
   ec010:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   ec015:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   ec019:	48 8b 28             	mov    (%rax),%rbp
   ec01c:	48 8b 58 08          	mov    0x8(%rax),%rbx
   ec020:	48 29 eb             	sub    %rbp,%rbx
   ec023:	49 89 dc             	mov    %rbx,%r12
   ec026:	49 c1 fc 04          	sar    $0x4,%r12
   ec02a:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   ec032:	74 14                	je     ec048 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x168>
   ec034:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ec03b:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   ec042:	0f 84 cb 05 00 00    	je     ec613 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x733>
   ec048:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   ec050:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec054:	31 f6                	xor    %esi,%esi
   ec056:	66 0f 6f 3d 52 38 06 00 	movdqa 0x63852(%rip),%xmm7        # 14f8b0 <C.66.5+0x290>
   ec05e:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   ec066:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ec06e:	ba 88 01 00 00       	mov    $0x188,%edx
   ec073:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   ec07a:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   ec07f:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   ec087:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   ec08f:	66 48 0f 6e c0       	movq   %rax,%xmm0
   ec094:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   ec09c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   ec0a0:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   ec0a9:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   ec0b1:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   ec0ba:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   ec0c2:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   ec0cb:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   ec0d3:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   ec0db:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   ec0e0:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   ec0e8:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   ec0ed:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   ec0f5:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   ec0fa:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   ec102:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   ec10e:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   ec11a:	e8 f1 af f1 ff       	call   7110 <memset@plt>
   ec11f:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   ec125:	66 0f ef c9          	pxor   %xmm1,%xmm1
   ec129:	66 0f 6f 05 8f 37 06 00 	movdqa 0x6378f(%rip),%xmm0        # 14f8c0 <C.66.5+0x2a0>
   ec131:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   ec137:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   ec13d:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ec141:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ec148:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   ec150:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ec155:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   ec15d:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   ec165:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   ec16d:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   ec179:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   ec181:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   ec18d:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   ec199:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   ec1a5:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   ec1b1:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   ec1bd:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   ec1c8:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   ec1d0:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   ec1db:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   ec1e7:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   ec1ef:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   ec1fb:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   ec206:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   ec20e:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   ec216:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   ec222:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   ec22e:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   ec236:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   ec242:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   ec24a:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   ec252:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   ec25a:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   ec262:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   ec26a:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   ec276:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   ec27e:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   ec287:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   ec28f:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   ec297:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   ec2a0:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   ec2a8:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   ec2b0:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   ec2b9:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   ec2c1:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ec2c8:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   ec2d0:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   ec2d8:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   ec2e4:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   ec2f0:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   ec2f8:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   ec304:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   ec310:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   ec31c:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   ec327:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   ec333:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   ec33b:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   ec346:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   ec351:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   ec35d:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   ec365:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   ec36d:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   ec375:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   ec37d:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   ec385:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   ec38d:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   ec395:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   ec39d:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   ec3a5:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ec3ad:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   ec3b4:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   ec3bd:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   ec3c8:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   ec3cf:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   ec3d6:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   ec3e1:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   ec3e8:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   ec3f0:	e8 8b c4 00 00       	call   f8880 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ec3f5:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   ec3fd:	0f 85 f5 06 00 00    	jne    ecaf8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc18>
   ec403:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   ec40c:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   ec414:	4d 89 76 50          	mov    %r14,0x50(%r14)
   ec418:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   ec420:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   ec429:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   ec431:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   ec436:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   ec43f:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   ec447:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   ec44c:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   ec455:	49 89 46 48          	mov    %rax,0x48(%r14)
   ec459:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ec460:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   ec465:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   ec46e:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   ec475:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ec47a:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   ec47f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec483:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   ec48b:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   ec494:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   ec49b:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   ec4a3:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   ec4ab:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   ec4b4:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   ec4bc:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   ec4c4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec4c8:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   ec4d0:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   ec4d8:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   ec4e0:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   ec4e8:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   ec4f0:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   ec4fb:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   ec503:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   ec50e:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   ec519:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   ec524:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   ec52b:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   ec534:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   ec53b:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   ec542:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   ec549:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   ec554:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   ec55b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ec560:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   ec567:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ec56e:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   ec579:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   ec580:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   ec58b:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   ec596:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   ec59d:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   ec5a8:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   ec5b3:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   ec5ba:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   ec5c5:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   ec5d0:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   ec5db:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   ec5e6:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   ec5ee:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   ec5f5:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   ec5fd:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   ec606:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ec60e:	e8 6d c2 00 00       	call   f8880 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ec613:	4d 39 a6 c0 02 00 00 	cmp    %r12,0x2c0(%r14)
   ec61a:	0f 82 90 04 00 00    	jb     ecab0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd0>
   ec620:	49 8b 96 78 02 00 00 	mov    0x278(%r14),%rdx
   ec627:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   ec62e:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   ec638:	48 89 d1             	mov    %rdx,%rcx
   ec63b:	4c 29 d1             	sub    %r10,%rcx
   ec63e:	48 89 c8             	mov    %rcx,%rax
   ec641:	48 c1 f8 03          	sar    $0x3,%rax
   ec645:	48 0f af c7          	imul   %rdi,%rax
   ec649:	4c 39 e0             	cmp    %r12,%rax
   ec64c:	0f 82 ee 03 00 00    	jb     eca40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb60>
   ec652:	49 39 c4             	cmp    %rax,%r12
   ec655:	73 16                	jae    ec66d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   ec657:	49 6b c4 38          	imul   $0x38,%r12,%rax
   ec65b:	49 01 c2             	add    %rax,%r10
   ec65e:	4c 39 d2             	cmp    %r10,%rdx
   ec661:	74 07                	je     ec66a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   ec663:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   ec66a:	4c 89 d2             	mov    %r10,%rdx
   ec66d:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   ec674:	48 85 db             	test   %rbx,%rbx
   ec677:	0f 84 7c 00 00 00    	je     ec6f9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x819>
   ec67d:	4c 89 d1             	mov    %r10,%rcx
   ec680:	31 f6                	xor    %esi,%esi
   ec682:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   ec686:	49 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%r11
   ec690:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   ec69a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ec6a0:	41 89 f0             	mov    %esi,%r8d
   ec6a3:	f3 0f 6f 45 00       	movdqu 0x0(%rbp),%xmm0
   ec6a8:	89 71 10             	mov    %esi,0x10(%rcx)
   ec6ab:	48 83 c6 01          	add    $0x1,%rsi
   ec6af:	41 81 f0 6b 6e 61 72 	xor    $0x72616e6b,%r8d
   ec6b6:	c6 41 30 01          	movb   $0x1,0x30(%rcx)
   ec6ba:	48 83 c5 10          	add    $0x10,%rbp
   ec6be:	48 83 c1 38          	add    $0x38,%rcx
   ec6c2:	4c 89 c0             	mov    %r8,%rax
   ec6c5:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   ec6c9:	48 c1 e8 1e          	shr    $0x1e,%rax
   ec6cd:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   ec6d1:	4c 31 c0             	xor    %r8,%rax
   ec6d4:	49 0f af c3          	imul   %r11,%rax
   ec6d8:	49 89 c0             	mov    %rax,%r8
   ec6db:	49 c1 e8 1b          	shr    $0x1b,%r8
   ec6df:	4c 31 c0             	xor    %r8,%rax
   ec6e2:	48 0f af c7          	imul   %rdi,%rax
   ec6e6:	49 89 c0             	mov    %rax,%r8
   ec6e9:	49 c1 e8 1f          	shr    $0x1f,%r8
   ec6ed:	4c 31 c0             	xor    %r8,%rax
   ec6f0:	48 89 41 f0          	mov    %rax,-0x10(%rcx)
   ec6f4:	4c 39 e6             	cmp    %r12,%rsi
   ec6f7:	72 a7                	jb     ec6a0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   ec6f9:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   ec705:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec709:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   ec711:	4c 39 d2             	cmp    %r10,%rdx
   ec714:	0f 84 f6 03 00 00    	je     ecb10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc30>
   ec71a:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   ec724:	4c 29 d2             	sub    %r10,%rdx
   ec727:	48 c1 fa 03          	sar    $0x3,%rdx
   ec72b:	48 0f af d0          	imul   %rax,%rdx
   ec72f:	49 39 56 38          	cmp    %rdx,0x38(%r14)
   ec733:	0f 82 67 04 00 00    	jb     ecba0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc0>
   ec739:	48 83 ec 20          	sub    $0x20,%rsp
   ec73d:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   ec744:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   ec74b:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   ec754:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   ec758:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   ec761:	0f 11 04 24          	movups %xmm0,(%rsp)
   ec765:	e8 e6 43 fe ff       	call   d0b50 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   ec76a:	48 83 c4 20          	add    $0x20,%rsp
   ec76e:	84 c0                	test   %al,%al
   ec770:	0f 85 fb 06 00 00    	jne    ece71 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf91>
   ec776:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   ec77f:	0f 84 fb 01 00 00    	je     ec980 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa0>
   ec785:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   ec78a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec78e:	4c 89 f6             	mov    %r14,%rsi
   ec791:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ec799:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   ec7a1:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   ec7a9:	e8 52 ec ff ff       	call   eb400 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   ec7ae:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   ec7b6:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   ec7be:	8b 7c 24 70          	mov    0x70(%rsp),%edi
   ec7c2:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   ec7c9:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   ec7cd:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   ec7d7:	48 8b b4 24 38 03 00 00 	mov    0x338(%rsp),%rsi
   ec7df:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   ec7e5:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   ec7ee:	39 c7                	cmp    %eax,%edi
   ec7f0:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   ec7f9:	0f 43 c7             	cmovae %edi,%eax
   ec7fc:	48 01 74 24 08       	add    %rsi,0x8(%rsp)
   ec801:	4c 01 64 24 10       	add    %r12,0x10(%rsp)
   ec806:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   ec80a:	89 44 24 70          	mov    %eax,0x70(%rsp)
   ec80e:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   ec812:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   ec81b:	41 89 47 38          	mov    %eax,0x38(%r15)
   ec81f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ec824:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   ec82a:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   ec82f:	49 89 47 40          	mov    %rax,0x40(%r15)
   ec833:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   ec838:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   ec83d:	49 89 47 48          	mov    %rax,0x48(%r15)
   ec841:	48 89 d0             	mov    %rdx,%rax
   ec844:	48 c1 e8 1e          	shr    $0x1e,%rax
   ec848:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   ec84d:	48 31 d0             	xor    %rdx,%rax
   ec850:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   ec855:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   ec85f:	48 0f af c2          	imul   %rdx,%rax
   ec863:	48 89 c2             	mov    %rax,%rdx
   ec866:	48 c1 ea 1b          	shr    $0x1b,%rdx
   ec86a:	48 31 d0             	xor    %rdx,%rax
   ec86d:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   ec877:	48 0f af c2          	imul   %rdx,%rax
   ec87b:	48 89 c2             	mov    %rax,%rdx
   ec87e:	48 c1 ea 1f          	shr    $0x1f,%rdx
   ec882:	48 31 d0             	xor    %rdx,%rax
   ec885:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   ec88a:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   ec88f:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   ec897:	49 89 5f 50          	mov    %rbx,0x50(%r15)
   ec89b:	0f b6 5c 24 77       	movzbl 0x77(%rsp),%ebx
   ec8a0:	84 db                	test   %bl,%bl
   ec8a2:	0f 44 d8             	cmove  %eax,%ebx
   ec8a5:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   ec8ad:	49 83 c5 01          	add    $0x1,%r13
   ec8b1:	48 8b 10             	mov    (%rax),%rdx
   ec8b4:	88 5c 24 77          	mov    %bl,0x77(%rsp)
   ec8b8:	41 88 5f 68          	mov    %bl,0x68(%r15)
   ec8bc:	48 8b 40 08          	mov    0x8(%rax),%rax
   ec8c0:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   ec8c5:	48 29 d0             	sub    %rdx,%rax
   ec8c8:	48 c1 f8 03          	sar    $0x3,%rax
   ec8cc:	48 0f af c1          	imul   %rcx,%rax
   ec8d0:	49 39 c5             	cmp    %rax,%r13
   ec8d3:	0f 82 37 f7 ff ff    	jb     ec010 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   ec8d9:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   ec8e1:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   ec8e9:	80 3d 88 99 07 00 00 	cmpb   $0x0,0x79988(%rip)        # 166278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ec8f0:	0f 84 49 05 00 00    	je     ece3f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf5f>
   ec8f6:	0f 31                	rdtsc
   ec8f8:	48 c1 e2 20          	shl    $0x20,%rdx
   ec8fc:	48 09 d0             	or     %rdx,%rax
   ec8ff:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   ec907:	0f 88 f8 04 00 00    	js     ece05 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf25>
   ec90d:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec911:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ec916:	f2 0f 59 05 12 99 07 00 	mulsd  0x79912(%rip),%xmm0        # 166230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ec91e:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ec923:	49 89 07             	mov    %rax,(%r15)
   ec926:	e8 d5 9e 05 00       	call   146800 <_ZN5bench6memory11allocationsEv>
   ec92b:	4c 29 f0             	sub    %r14,%rax
   ec92e:	49 89 47 58          	mov    %rax,0x58(%r15)
   ec932:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   ec93a:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   ec943:	0f 85 1b 05 00 00    	jne    ece64 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf84>
   ec949:	4c 89 f8             	mov    %r15,%rax
   ec94c:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   ec954:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   ec95c:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   ec964:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   ec96c:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   ec974:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   ec97b:	c3                   	ret
   ec97c:	0f 1f 40 00          	nopl   0x0(%rax)
   ec980:	80 3d f1 98 07 00 00 	cmpb   $0x0,0x798f1(%rip)        # 166278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ec987:	0f 84 fb 03 00 00    	je     ecd88 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xea8>
   ec98d:	0f 31                	rdtsc
   ec98f:	48 c1 e2 20          	shl    $0x20,%rdx
   ec993:	48 09 d0             	or     %rdx,%rax
   ec996:	48 89 c5             	mov    %rax,%rbp
   ec999:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   ec99e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec9a2:	4c 89 f6             	mov    %r14,%rsi
   ec9a5:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ec9ad:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   ec9b5:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   ec9bd:	e8 3e ea ff ff       	call   eb400 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   ec9c2:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   ec9ca:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   ec9d2:	48 89 e8             	mov    %rbp,%rax
   ec9d5:	f2 0f 10 0d 53 98 07 00 	movsd  0x79853(%rip),%xmm1        # 166230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ec9dd:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   ec9e5:	0f 88 65 03 00 00    	js     ecd50 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   ec9eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec9ef:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ec9f4:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   ec9f8:	80 3d 79 98 07 00 00 	cmpb   $0x0,0x79879(%rip)        # 166278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ec9ff:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   eca04:	49 89 47 08          	mov    %rax,0x8(%r15)
   eca08:	0f 84 62 03 00 00    	je     ecd70 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe90>
   eca0e:	0f 31                	rdtsc
   eca10:	48 c1 e2 20          	shl    $0x20,%rdx
   eca14:	48 09 d0             	or     %rdx,%rax
   eca17:	48 29 e8             	sub    %rbp,%rax
   eca1a:	0f 88 10 03 00 00    	js     ecd30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe50>
   eca20:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eca24:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   eca29:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   eca2d:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   eca32:	49 89 47 10          	mov    %rax,0x10(%r15)
   eca36:	e9 83 fd ff ff       	jmp    ec7be <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8de>
   eca3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   eca40:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   eca47:	4d 89 e3             	mov    %r12,%r11
   eca4a:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   eca54:	49 29 c3             	sub    %rax,%r11
   eca57:	48 89 f7             	mov    %rsi,%rdi
   eca5a:	48 29 d7             	sub    %rdx,%rdi
   eca5d:	48 c1 ff 03          	sar    $0x3,%rdi
   eca61:	49 0f af f9          	imul   %r9,%rdi
   eca65:	4c 39 df             	cmp    %r11,%rdi
   eca68:	0f 82 52 01 00 00    	jb     ecbc0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xce0>
   eca6e:	4c 89 d9             	mov    %r11,%rcx
   eca71:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eca75:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   eca79:	48 89 d0             	mov    %rdx,%rax
   eca7c:	0f 1f 40 00          	nopl   0x0(%rax)
   eca80:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   eca84:	48 83 c0 38          	add    $0x38,%rax
   eca88:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   eca8c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   eca90:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   eca94:	48 83 e9 01          	sub    $0x1,%rcx
   eca98:	75 e6                	jne    eca80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   eca9a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   eca9e:	4c 01 da             	add    %r11,%rdx
   ecaa1:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   ecaa8:	e9 c0 fb ff ff       	jmp    ec66d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   ecaad:	0f 1f 00             	nopl   (%rax)
   ecab0:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   ecab8:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   ecabf:	4c 89 a4 24 10 03 00 00 	mov    %r12,0x310(%rsp)
   ecac7:	48 c7 84 24 18 03 00 00 00 00 00 00 	movq   $0x0,0x318(%rsp)
   ecad3:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   ecadb:	e8 60 ec 01 00       	call   10b740 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   ecae0:	84 c0                	test   %al,%al
   ecae2:	0f 85 89 03 00 00    	jne    ece71 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf91>
   ecae8:	4d 89 a6 c0 02 00 00 	mov    %r12,0x2c0(%r14)
   ecaef:	e9 2c fb ff ff       	jmp    ec620 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x740>
   ecaf4:	0f 1f 40 00          	nopl   0x0(%rax)
   ecaf8:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   ecb00:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   ecb04:	e8 77 bd 00 00       	call   f8880 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ecb09:	e9 f5 f8 ff ff       	jmp    ec403 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x523>
   ecb0e:	66 90                	xchg   %ax,%ax
   ecb10:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   ecb18:	74 58                	je     ecb72 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   ecb1a:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   ecb21:	48 85 d2             	test   %rdx,%rdx
   ecb24:	0f 85 6b 02 00 00    	jne    ecd95 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xeb5>
   ecb2a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ecb2f:	66 0f 6f 05 49 2d 06 00 	movdqa 0x62d49(%rip),%xmm0        # 14f880 <C.66.5+0x260>
   ecb37:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   ecb42:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   ecb4d:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   ecb54:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   ecb5f:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   ecb6a:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   ecb72:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   ecb77:	0f 84 f9 fb ff ff    	je     ec776 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   ecb7d:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   ecb85:	0f 84 eb fb ff ff    	je     ec776 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   ecb8b:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   ecb93:	e9 de fb ff ff       	jmp    ec776 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   ecb98:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   ecba0:	ba 10 00 00 00       	mov    $0x10,%edx
   ecba5:	48 8b 3d b4 96 07 00 	mov    0x796b4(%rip),%rdi        # 166260 <stderr@GLIBC_2.2.5>
   ecbac:	48 8d 35 ed 0d 06 00 	lea    0x60ded(%rip),%rsi        # 14d9a0 <_IO_stdin_used+0x19a0>
   ecbb3:	31 c0                	xor    %eax,%eax
   ecbb5:	e8 86 a7 f1 ff       	call   7340 <fprintf@plt>
   ecbba:	e8 61 a5 f1 ff       	call   7120 <abort@plt>
   ecbbf:	90                   	nop
   ecbc0:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   ecbca:	48 29 c7             	sub    %rax,%rdi
   ecbcd:	4c 39 df             	cmp    %r11,%rdi
   ecbd0:	0f 82 48 02 f2 ff    	jb     ce1e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   ecbd6:	4c 39 d8             	cmp    %r11,%rax
   ecbd9:	4c 89 df             	mov    %r11,%rdi
   ecbdc:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   ecbe4:	48 0f 43 f8          	cmovae %rax,%rdi
   ecbe8:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   ecbf0:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   ecbf8:	48 01 c7             	add    %rax,%rdi
   ecbfb:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   ecc00:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   ecc0a:	48 39 c7             	cmp    %rax,%rdi
   ecc0d:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   ecc12:	48 0f 47 f8          	cmova  %rax,%rdi
   ecc16:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   ecc1a:	48 89 c7             	mov    %rax,%rdi
   ecc1d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   ecc22:	e8 b9 9c 05 00       	call   1468e0 <_Znwm>
   ecc27:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   ecc2d:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   ecc35:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ecc39:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   ecc3e:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   ecc46:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   ecc4a:	48 01 c1             	add    %rax,%rcx
   ecc4d:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   ecc55:	49 01 cb             	add    %rcx,%r11
   ecc58:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   ecc60:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   ecc64:	48 83 c1 38          	add    $0x38,%rcx
   ecc68:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   ecc6c:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   ecc70:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   ecc74:	4c 39 d9             	cmp    %r11,%rcx
   ecc77:	75 e7                	jne    ecc60 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   ecc79:	4c 39 d2             	cmp    %r10,%rdx
   ecc7c:	74 71                	je     eccef <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe0f>
   ecc7e:	4c 89 d1             	mov    %r10,%rcx
   ecc81:	48 89 c7             	mov    %rax,%rdi
   ecc84:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   ecc89:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ecc94:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ecc9f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eccaa:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eccb5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eccc0:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   eccc4:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   eccc8:	48 83 c1 38          	add    $0x38,%rcx
   ecccc:	48 83 c7 38          	add    $0x38,%rdi
   eccd0:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   eccd4:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   eccd9:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   eccdd:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   ecce1:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   ecce6:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   eccea:	48 39 ca             	cmp    %rcx,%rdx
   ecced:	75 d1                	jne    eccc0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xde0>
   eccef:	4d 85 d2             	test   %r10,%r10
   eccf2:	74 15                	je     ecd09 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe29>
   eccf4:	4c 29 d6             	sub    %r10,%rsi
   eccf7:	4c 89 d7             	mov    %r10,%rdi
   eccfa:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   eccff:	e8 dc 9c 05 00       	call   1469e0 <_ZdlPvm>
   ecd04:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   ecd09:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   ecd0d:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   ecd14:	48 01 c2             	add    %rax,%rdx
   ecd17:	48 03 44 24 40       	add    0x40(%rsp),%rax
   ecd1c:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   ecd23:	49 89 86 80 02 00 00 	mov    %rax,0x280(%r14)
   ecd2a:	e9 3e f9 ff ff       	jmp    ec66d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   ecd2f:	90                   	nop
   ecd30:	48 89 c2             	mov    %rax,%rdx
   ecd33:	83 e0 01             	and    $0x1,%eax
   ecd36:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ecd3a:	48 d1 ea             	shr    $1,%rdx
   ecd3d:	48 09 c2             	or     %rax,%rdx
   ecd40:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   ecd45:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   ecd49:	e9 db fc ff ff       	jmp    eca29 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb49>
   ecd4e:	66 90                	xchg   %ax,%ax
   ecd50:	48 89 c2             	mov    %rax,%rdx
   ecd53:	83 e0 01             	and    $0x1,%eax
   ecd56:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ecd5a:	48 d1 ea             	shr    $1,%rdx
   ecd5d:	48 09 c2             	or     %rax,%rdx
   ecd60:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   ecd65:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   ecd69:	e9 86 fc ff ff       	jmp    ec9f4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb14>
   ecd6e:	66 90                	xchg   %ax,%ax
   ecd70:	e8 5b a5 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   ecd75:	f2 0f 10 0d b3 94 07 00 	movsd  0x794b3(%rip),%xmm1        # 166230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ecd7d:	e9 95 fc ff ff       	jmp    eca17 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb37>
   ecd82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ecd88:	e8 43 a5 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   ecd8d:	48 89 c5             	mov    %rax,%rbp
   ecd90:	e9 04 fc ff ff       	jmp    ec999 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab9>
   ecd95:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   ecda0:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   ecda8:	0f 85 9b 00 00 00    	jne    ece49 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf69>
   ecdae:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   ecdb5:	83 c0 01             	add    $0x1,%eax
   ecdb8:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   ecdbf:	83 f8 ff             	cmp    $0xffffffff,%eax
   ecdc2:	0f 85 62 fd ff ff    	jne    ecb2a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   ecdc8:	49 8b 46 78          	mov    0x78(%r14),%rax
   ecdcc:	48 89 d1             	mov    %rdx,%rcx
   ecdcf:	48 c1 e1 04          	shl    $0x4,%rcx
   ecdd3:	48 01 c1             	add    %rax,%rcx
   ecdd6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   ecddd:	48 83 c0 10          	add    $0x10,%rax
   ecde1:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   ecde9:	48 39 c8             	cmp    %rcx,%rax
   ecdec:	75 e8                	jne    ecdd6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef6>
   ecdee:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   ecdf5:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   ece00:	e9 25 fd ff ff       	jmp    ecb2a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   ece05:	48 89 c2             	mov    %rax,%rdx
   ece08:	83 e0 01             	and    $0x1,%eax
   ece0b:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ece0f:	48 d1 ea             	shr    $1,%rdx
   ece12:	48 09 c2             	or     %rax,%rdx
   ece15:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   ece1a:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   ece1e:	e9 f3 fa ff ff       	jmp    ec916 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa36>
   ece23:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   ece28:	e8 73 42 f2 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   ece2d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   ece32:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   ece3a:	e9 52 f1 ff ff       	jmp    ebf91 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb1>
   ece3f:	e8 5c 42 f2 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   ece44:	e9 b6 fa ff ff       	jmp    ec8ff <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa1f>
   ece49:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   ece54:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   ece5f:	e9 c6 fc ff ff       	jmp    ecb2a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   ece64:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   ece6c:	e8 ef a3 f1 ff       	call   7260 <__stack_chk_fail@plt>
   ece71:	0f b6 d0             	movzbl %al,%edx
   ece74:	e9 2c fd ff ff       	jmp    ecba5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc5>

# candidate ordered_pairs bench::Counters bench::LibraryIndex<int, true>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-unordered-empty.OwlJhL/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000eb400 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   eb400:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
   eb407:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eb40b:	48 89 9c 24 68 02 00 00 	mov    %rbx,0x268(%rsp)
   eb413:	48 89 fb             	mov    %rdi,%rbx
   eb416:	48 89 ac 24 70 02 00 00 	mov    %rbp,0x270(%rsp)
   eb41e:	48 89 f5             	mov    %rsi,%rbp
   eb421:	4c 89 b4 24 88 02 00 00 	mov    %r14,0x288(%rsp)
   eb429:	49 89 d6             	mov    %rdx,%r14
   eb42c:	8b 96 d0 00 00 00    	mov    0xd0(%rsi),%edx
   eb432:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
   eb439:	64 48 8b 3c 25 28 00 00 00 	mov    %fs:0x28,%rdi
   eb442:	48 89 bc 24 58 02 00 00 	mov    %rdi,0x258(%rsp)
   eb44a:	31 ff                	xor    %edi,%edi
   eb44c:	83 fa 01             	cmp    $0x1,%edx
   eb44f:	76 47                	jbe    eb498 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x98>
   eb451:	48 39 f2             	cmp    %rsi,%rdx
   eb454:	0f 84 d6 00 00 00    	je     eb530 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x130>
   eb45a:	4c 89 bc 24 90 02 00 00 	mov    %r15,0x290(%rsp)
   eb462:	ba 07 00 00 00       	mov    $0x7,%edx
   eb467:	48 8b 3d f2 ad 07 00 	mov    0x7adf2(%rip),%rdi        # 166260 <stderr@GLIBC_2.2.5>
   eb46e:	48 8d 35 2b 25 06 00 	lea    0x6252b(%rip),%rsi        # 14d9a0 <_IO_stdin_used+0x19a0>
   eb475:	31 c0                	xor    %eax,%eax
   eb477:	4c 89 a4 24 78 02 00 00 	mov    %r12,0x278(%rsp)
   eb47f:	4c 89 ac 24 80 02 00 00 	mov    %r13,0x280(%rsp)
   eb487:	e8 b4 be f1 ff       	call   7340 <fprintf@plt>
   eb48c:	e8 8f bc f1 ff       	call   7120 <abort@plt>
   eb491:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   eb498:	48 39 f2             	cmp    %rsi,%rdx
   eb49b:	75 bd                	jne    eb45a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5a>
   eb49d:	48 89 d0             	mov    %rdx,%rax
   eb4a0:	0f 11 84 24 78 01 00 00 	movups %xmm0,0x178(%rsp)
   eb4a8:	31 d2                	xor    %edx,%edx
   eb4aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   eb4b0:	48 8b 8c 24 80 01 00 00 	mov    0x180(%rsp),%rcx
   eb4b8:	85 c0                	test   %eax,%eax
   eb4ba:	89 c7                	mov    %eax,%edi
   eb4bc:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   eb4c4:	0f 95 c0             	setne  %al
   eb4c7:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   eb4cf:	80 fa 0b             	cmp    $0xb,%dl
   eb4d2:	48 89 0b             	mov    %rcx,(%rbx)
   eb4d5:	48 8b 8c 24 78 01 00 00 	mov    0x178(%rsp),%rcx
   eb4dd:	0f b6 c0             	movzbl %al,%eax
   eb4e0:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
   eb4e4:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   eb4e8:	89 43 20             	mov    %eax,0x20(%rbx)
   eb4eb:	0f 94 43 30          	sete   0x30(%rbx)
   eb4ef:	48 8b 84 24 58 02 00 00 	mov    0x258(%rsp),%rax
   eb4f7:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   eb500:	0f 85 91 09 00 00    	jne    ebe97 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa97>
   eb506:	48 89 d8             	mov    %rbx,%rax
   eb509:	48 8b ac 24 70 02 00 00 	mov    0x270(%rsp),%rbp
   eb511:	48 8b 9c 24 68 02 00 00 	mov    0x268(%rsp),%rbx
   eb519:	4c 8b b4 24 88 02 00 00 	mov    0x288(%rsp),%r14
   eb521:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
   eb528:	c3                   	ret
   eb529:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   eb530:	49 89 c8             	mov    %rcx,%r8
   eb533:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   eb53b:	48 8b 45 50          	mov    0x50(%rbp),%rax
   eb53f:	89 d1                	mov    %edx,%ecx
   eb541:	0f 11 84 24 c8 00 00 00 	movups %xmm0,0xc8(%rsp)
   eb549:	66 49 0f 6e d8       	movq   %r8,%xmm3
   eb54e:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   eb553:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
   eb557:	c6 84 24 b0 00 00 00 00 	movb   $0x0,0xb0(%rsp)
   eb55f:	48 c7 84 24 e8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xe8(%rsp)
   eb56b:	0f 11 84 24 d8 00 00 00 	movups %xmm0,0xd8(%rsp)
   eb573:	48 85 c0             	test   %rax,%rax
   eb576:	0f 84 8b 06 00 00    	je     ebc07 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x807>
   eb57c:	48 89 84 24 70 01 00 00 	mov    %rax,0x170(%rsp)
   eb584:	48 89 84 24 78 01 00 00 	mov    %rax,0x178(%rsp)
   eb58c:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   eb598:	48 c7 84 24 88 01 00 00 00 00 00 00 	movq   $0x0,0x188(%rsp)
   eb5a4:	48 89 84 24 90 01 00 00 	mov    %rax,0x190(%rsp)
   eb5ac:	48 c7 84 24 98 01 00 00 00 00 00 00 	movq   $0x0,0x198(%rsp)
   eb5b8:	48 c7 84 24 a0 01 00 00 00 00 00 00 	movq   $0x0,0x1a0(%rsp)
   eb5c4:	48 89 84 24 a8 01 00 00 	mov    %rax,0x1a8(%rsp)
   eb5cc:	48 c7 84 24 b0 01 00 00 00 00 00 00 	movq   $0x0,0x1b0(%rsp)
   eb5d8:	48 c7 84 24 b8 01 00 00 00 00 00 00 	movq   $0x0,0x1b8(%rsp)
   eb5e4:	48 89 84 24 c0 01 00 00 	mov    %rax,0x1c0(%rsp)
   eb5ec:	48 c7 84 24 c8 01 00 00 00 00 00 00 	movq   $0x0,0x1c8(%rsp)
   eb5f8:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   eb604:	48 89 84 24 d8 01 00 00 	mov    %rax,0x1d8(%rsp)
   eb60c:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   eb618:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   eb624:	48 89 84 24 f0 01 00 00 	mov    %rax,0x1f0(%rsp)
   eb62c:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   eb638:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   eb644:	48 89 84 24 08 02 00 00 	mov    %rax,0x208(%rsp)
   eb64c:	48 c7 84 24 10 02 00 00 00 00 00 00 	movq   $0x0,0x210(%rsp)
   eb658:	48 c7 84 24 18 02 00 00 00 00 00 00 	movq   $0x0,0x218(%rsp)
   eb664:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   eb66c:	48 c7 84 24 28 02 00 00 00 00 00 00 	movq   $0x0,0x228(%rsp)
   eb678:	48 c7 84 24 30 02 00 00 00 00 00 00 	movq   $0x0,0x230(%rsp)
   eb684:	48 89 84 24 38 02 00 00 	mov    %rax,0x238(%rsp)
   eb68c:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   eb698:	48 c7 84 24 48 02 00 00 00 00 00 00 	movq   $0x0,0x248(%rsp)
   eb6a4:	c7 84 24 50 02 00 00 00 00 00 00 	movl   $0x0,0x250(%rsp)
   eb6af:	c6 84 24 54 02 00 00 00 	movb   $0x0,0x254(%rsp)
   eb6b7:	48 39 b5 a0 01 00 00 	cmp    %rsi,0x1a0(%rbp)
   eb6be:	0f 82 24 05 00 00    	jb     ebbe8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e8>
   eb6c4:	48 39 b5 b8 01 00 00 	cmp    %rsi,0x1b8(%rbp)
   eb6cb:	0f 82 17 05 00 00    	jb     ebbe8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e8>
   eb6d1:	80 bd 6c 02 00 00 00 	cmpb   $0x0,0x26c(%rbp)
   eb6d8:	0f 85 d6 07 00 00    	jne    ebeb4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xab4>
   eb6de:	48 8d 85 88 01 00 00 	lea    0x188(%rbp),%rax
   eb6e5:	4c 89 bc 24 90 02 00 00 	mov    %r15,0x290(%rsp)
   eb6ed:	4c 8b 95 98 01 00 00 	mov    0x198(%rbp),%r10
   eb6f4:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
   eb6f8:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   eb6fd:	c6 85 6c 02 00 00 01 	movb   $0x1,0x26c(%rbp)
   eb704:	c6 44 24 63 00       	movb   $0x0,0x63(%rsp)
   eb709:	85 c9                	test   %ecx,%ecx
   eb70b:	0f 84 27 07 00 00    	je     ebe38 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa38>
   eb711:	8d 41 ff             	lea    -0x1(%rcx),%eax
   eb714:	83 f8 02             	cmp    $0x2,%eax
   eb717:	0f 86 55 07 00 00    	jbe    ebe72 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa72>
   eb71d:	89 cf                	mov    %ecx,%edi
   eb71f:	41 bb 04 00 00 00    	mov    $0x4,%r11d
   eb725:	66 0f 6f 05 63 41 06 00 	movdqa 0x64163(%rip),%xmm0        # 14f890 <C.66.5+0x270>
   eb72d:	4c 89 d0             	mov    %r10,%rax
   eb730:	c1 ef 02             	shr    $0x2,%edi
   eb733:	66 41 0f 6e cb       	movd   %r11d,%xmm1
   eb738:	89 fa                	mov    %edi,%edx
   eb73a:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   eb73f:	48 c1 e2 04          	shl    $0x4,%rdx
   eb743:	4c 01 d2             	add    %r10,%rdx
   eb746:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   eb750:	0f 11 00             	movups %xmm0,(%rax)
   eb753:	48 83 c0 10          	add    $0x10,%rax
   eb757:	66 0f fe c1          	paddd  %xmm1,%xmm0
   eb75b:	48 39 c2             	cmp    %rax,%rdx
   eb75e:	75 f0                	jne    eb750 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x350>
   eb760:	8d 04 bd 00 00 00 00 	lea    0x0(,%rdi,4),%eax
   eb767:	39 c1                	cmp    %eax,%ecx
   eb769:	74 20                	je     eb78b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x38b>
   eb76b:	89 c2                	mov    %eax,%edx
   eb76d:	41 89 04 92          	mov    %eax,(%r10,%rdx,4)
   eb771:	8d 50 01             	lea    0x1(%rax),%edx
   eb774:	39 ca                	cmp    %ecx,%edx
   eb776:	73 13                	jae    eb78b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x38b>
   eb778:	89 d7                	mov    %edx,%edi
   eb77a:	83 c0 02             	add    $0x2,%eax
   eb77d:	41 89 14 ba          	mov    %edx,(%r10,%rdi,4)
   eb781:	39 c8                	cmp    %ecx,%eax
   eb783:	73 06                	jae    eb78b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x38b>
   eb785:	89 c2                	mov    %eax,%edx
   eb787:	41 89 04 92          	mov    %eax,(%r10,%rdx,4)
   eb78b:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
   eb792:	0f 86 a0 06 00 00    	jbe    ebe38 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa38>
   eb798:	48 39 b5 48 02 00 00 	cmp    %rsi,0x248(%rbp)
   eb79f:	72 1f                	jb     eb7c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3c0>
   eb7a1:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   eb7ab:	48 f7 a5 60 02 00 00 	mulq   0x260(%rbp)
   eb7b2:	48 c1 ea 04          	shr    $0x4,%rdx
   eb7b6:	48 39 f2             	cmp    %rsi,%rdx
   eb7b9:	0f 83 ba 06 00 00    	jae    ebe79 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa79>
   eb7bf:	90                   	nop
   eb7c0:	48 89 f0             	mov    %rsi,%rax
   eb7c3:	31 c9                	xor    %ecx,%ecx
   eb7c5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eb7d0:	48 d1 e8             	shr    $1,%rax
   eb7d3:	83 c1 02             	add    $0x2,%ecx
   eb7d6:	48 83 f8 01          	cmp    $0x1,%rax
   eb7da:	75 f4                	jne    eb7d0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3d0>
   eb7dc:	4c 89 d7             	mov    %r10,%rdi
   eb7df:	4c 89 fa             	mov    %r15,%rdx
   eb7e2:	4c 89 14 24          	mov    %r10,(%rsp)
   eb7e6:	e8 d5 ab 05 00       	call   1463c0 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   eb7eb:	4c 8b 14 24          	mov    (%rsp),%r10
   eb7ef:	8b 95 d0 00 00 00    	mov    0xd0(%rbp),%edx
   eb7f5:	83 fa 01             	cmp    $0x1,%edx
   eb7f8:	0f 86 77 03 00 00    	jbe    ebb75 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x775>
   eb7fe:	4c 89 a4 24 78 02 00 00 	mov    %r12,0x278(%rsp)
   eb806:	4c 89 ac 24 80 02 00 00 	mov    %r13,0x280(%rsp)
   eb80e:	48 c7 44 24 38 01 00 00 00 	movq   $0x1,0x38(%rsp)
   eb817:	4c 89 54 24 50       	mov    %r10,0x50(%rsp)
   eb81c:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   eb821:	0f 1f 40 00          	nopl   0x0(%rax)
   eb825:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eb830:	0f b6 84 24 b0 00 00 00 	movzbl 0xb0(%rsp),%eax
   eb838:	84 c0                	test   %al,%al
   eb83a:	0f 85 20 03 00 00    	jne    ebb60 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x760>
   eb840:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
   eb845:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
   eb84a:	48 8d 4c 24 63       	lea    0x63(%rsp),%rcx
   eb84f:	4c 8d 8c 24 b0 00 00 00 	lea    0xb0(%rsp),%r9
   eb857:	8b 7c b3 fc          	mov    -0x4(%rbx,%rsi,4),%edi
   eb85b:	48 8d 5c 24 64       	lea    0x64(%rsp),%rbx
   eb860:	48 89 8c 24 80 00 00 00 	mov    %rcx,0x80(%rsp)
   eb868:	48 8d 4c 24 62       	lea    0x62(%rsp),%rcx
   eb86d:	48 89 8c 24 98 00 00 00 	mov    %rcx,0x98(%rsp)
   eb875:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
   eb87a:	48 89 5c 24 78       	mov    %rbx,0x78(%rsp)
   eb87f:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
   eb884:	48 89 8c 24 a0 00 00 00 	mov    %rcx,0xa0(%rsp)
   eb88c:	8b 8d 64 01 00 00    	mov    0x164(%rbp),%ecx
   eb892:	89 7c 24 64          	mov    %edi,0x64(%rsp)
   eb896:	48 c7 44 24 68 00 00 00 00 	movq   $0x0,0x68(%rsp)
   eb89f:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
   eb8a4:	48 89 9c 24 88 00 00 00 	mov    %rbx,0x88(%rsp)
   eb8ac:	4c 89 8c 24 90 00 00 00 	mov    %r9,0x90(%rsp)
   eb8b4:	83 f9 ff             	cmp    $0xffffffff,%ecx
   eb8b7:	0f 84 b3 04 00 00    	je     ebd70 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x970>
   eb8bd:	89 ce                	mov    %ecx,%esi
   eb8bf:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   eb8c3:	48 03 b5 f8 00 00 00 	add    0xf8(%rbp),%rsi
   eb8ca:	44 8b 46 64          	mov    0x64(%rsi),%r8d
   eb8ce:	45 85 c0             	test   %r8d,%r8d
   eb8d1:	0f 84 49 05 00 00    	je     ebe20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa20>
   eb8d7:	48 8b 84 24 e8 00 00 00 	mov    0xe8(%rsp),%rax
   eb8df:	48 85 c0             	test   %rax,%rax
   eb8e2:	0f 84 68 05 00 00    	je     ebe50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa50>
   eb8e8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   eb8ec:	74 0c                	je     eb8fa <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x4fa>
   eb8ee:	48 83 e8 01          	sub    $0x1,%rax
   eb8f2:	48 89 84 24 e8 00 00 00 	mov    %rax,0xe8(%rsp)
   eb8fa:	48 8b 84 24 b8 00 00 00 	mov    0xb8(%rsp),%rax
   eb902:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   eb906:	74 0c                	je     eb914 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x514>
   eb908:	48 83 c0 01          	add    $0x1,%rax
   eb90c:	48 89 84 24 b8 00 00 00 	mov    %rax,0xb8(%rsp)
   eb914:	48 89 fa             	mov    %rdi,%rdx
   eb917:	8b 46 1c             	mov    0x1c(%rsi),%eax
   eb91a:	48 c1 e2 04          	shl    $0x4,%rdx
   eb91e:	48 03 55 58          	add    0x58(%rbp),%rdx
   eb922:	39 02                	cmp    %eax,(%rdx)
   eb924:	0f 8f f6 04 00 00    	jg     ebe20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa20>
   eb92a:	8b 42 08             	mov    0x8(%rdx),%eax
   eb92d:	39 46 14             	cmp    %eax,0x14(%rsi)
   eb930:	0f 8f ea 04 00 00    	jg     ebe20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa20>
   eb936:	8b 46 20             	mov    0x20(%rsi),%eax
   eb939:	39 42 04             	cmp    %eax,0x4(%rdx)
   eb93c:	0f 8f de 04 00 00    	jg     ebe20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa20>
   eb942:	8b 42 0c             	mov    0xc(%rdx),%eax
   eb945:	39 46 18             	cmp    %eax,0x18(%rsi)
   eb948:	0f 8f d2 04 00 00    	jg     ebe20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa20>
   eb94e:	48 8b 45 68          	mov    0x68(%rbp),%rax
   eb952:	48 c1 e7 05          	shl    $0x5,%rdi
   eb956:	48 83 ec 08          	sub    $0x8,%rsp
   eb95a:	48 01 f8             	add    %rdi,%rax
   eb95d:	4c 89 ff             	mov    %r15,%rdi
   eb960:	48 8b 08             	mov    (%rax),%rcx
   eb963:	4c 8b 40 08          	mov    0x8(%rax),%r8
   eb967:	48 8d 44 24 78       	lea    0x78(%rsp),%rax
   eb96c:	50                   	push   %rax
   eb96d:	e8 5e 0e f3 ff       	call   1c7d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE11walkOrderedIZNKS2_11orderedSelfIZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS5_8CountersERT_mEUlRKSC_RKT0_E_NS_6detail9AcceptAllEEEvRNS_9WorkspaceIiEEbRNS2_7ContextESD_RSG_EUljE_EEvRKNS2_4NodeERKNS_3BoxIiEENS_6FilterESQ_SD_>
   eb972:	0f b6 84 24 c0 00 00 00 	movzbl 0xc0(%rsp),%eax
   eb97a:	5a                   	pop    %rdx
   eb97b:	59                   	pop    %rcx
   eb97c:	0f 1f 40 00          	nopl   0x0(%rax)
   eb980:	84 c0                	test   %al,%al
   eb982:	0f 85 d8 01 00 00    	jne    ebb60 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x760>
   eb988:	48 8b 85 b0 01 00 00 	mov    0x1b0(%rbp),%rax
   eb98f:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
   eb994:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   eb999:	48 83 fe 7f          	cmp    $0x7f,%rsi
   eb99d:	0f 86 66 04 00 00    	jbe    ebe09 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa09>
   eb9a3:	48 39 b5 48 02 00 00 	cmp    %rsi,0x248(%rbp)
   eb9aa:	0f 82 80 03 00 00    	jb     ebd30 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x930>
   eb9b0:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   eb9ba:	48 f7 a5 60 02 00 00 	mulq   0x260(%rbp)
   eb9c1:	48 c1 ea 04          	shr    $0x4,%rdx
   eb9c5:	48 39 f2             	cmp    %rsi,%rdx
   eb9c8:	0f 82 62 03 00 00    	jb     ebd30 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x930>
   eb9ce:	89 f1                	mov    %esi,%ecx
   eb9d0:	48 8b 7d 68          	mov    0x68(%rbp),%rdi
   eb9d4:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   eb9d9:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   eb9de:	e8 bd 69 f2 ff       	call   123a0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   eb9e3:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
   eb9e8:	48 85 f6             	test   %rsi,%rsi
   eb9eb:	0f 84 49 01 00 00    	je     ebb3a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x73a>
   eb9f1:	44 8b 6c 24 64       	mov    0x64(%rsp),%r13d
   eb9f6:	48 8b 45 68          	mov    0x68(%rbp),%rax
   eb9fa:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   eb9ff:	49 8b 16             	mov    (%r14),%rdx
   eba02:	49 8b 5e 08          	mov    0x8(%r14),%rbx
   eba06:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
   eba0b:	31 ed                	xor    %ebp,%ebp
   eba0d:	4d 89 ec             	mov    %r13,%r12
   eba10:	49 c1 e5 05          	shl    $0x5,%r13
   eba14:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   eba19:	4c 8b 8c 24 d8 00 00 00 	mov    0xd8(%rsp),%r9
   eba21:	4c 01 e8             	add    %r13,%rax
   eba24:	49 89 dd             	mov    %rbx,%r13
   eba27:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   eba2c:	48 8d 42 01          	lea    0x1(%rdx),%rax
   eba30:	4c 89 cb             	mov    %r9,%rbx
   eba33:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   eba38:	4c 89 f0             	mov    %r14,%rax
   eba3b:	45 89 e6             	mov    %r12d,%r14d
   eba3e:	49 89 c4             	mov    %rax,%r12
   eba41:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   eba46:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   eba4b:	4c 89 fe             	mov    %r15,%rsi
   eba4e:	8b 14 a8             	mov    (%rax,%rbp,4),%edx
   eba51:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   eba56:	48 8b 78 10          	mov    0x10(%rax),%rdi
   eba5a:	89 d0                	mov    %edx,%eax
   eba5c:	48 c1 e0 05          	shl    $0x5,%rax
   eba60:	48 39 7c 01 10       	cmp    %rdi,0x10(%rcx,%rax,1)
   eba65:	89 d0                	mov    %edx,%eax
   eba67:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   eba6c:	48 8d bc 24 f0 00 00 00 	lea    0xf0(%rsp),%rdi
   eba74:	41 0f 42 c6          	cmovb  %r14d,%eax
   eba78:	41 0f 43 d6          	cmovae %r14d,%edx
   eba7c:	89 04 24             	mov    %eax,(%rsp)
   eba7f:	e8 ec 32 05 00       	call   13ed70 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   eba84:	8b 14 24             	mov    (%rsp),%edx
   eba87:	4c 89 fe             	mov    %r15,%rsi
   eba8a:	48 8d bc 24 30 01 00 00 	lea    0x130(%rsp),%rdi
   eba92:	e8 d9 32 05 00       	call   13ed70 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   eba97:	48 8b 94 24 08 01 00 00 	mov    0x108(%rsp),%rdx
   eba9f:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   ebaa4:	48 8b 84 24 48 01 00 00 	mov    0x148(%rsp),%rax
   ebaac:	8b 32                	mov    (%rdx),%esi
   ebaae:	48 8d 14 29          	lea    (%rcx,%rbp,1),%rdx
   ebab2:	48 b9 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rcx
   ebabc:	8b 00                	mov    (%rax),%eax
   ebabe:	49 89 14 24          	mov    %rdx,(%r12)
   ebac2:	89 f2                	mov    %esi,%edx
   ebac4:	39 f0                	cmp    %esi,%eax
   ebac6:	0f 46 d0             	cmovbe %eax,%edx
   ebac9:	48 c1 e2 20          	shl    $0x20,%rdx
   ebacd:	39 f0                	cmp    %esi,%eax
   ebacf:	0f 42 c6             	cmovb  %esi,%eax
   ebad2:	48 09 c2             	or     %rax,%rdx
   ebad5:	48 89 d0             	mov    %rdx,%rax
   ebad8:	48 c1 e8 1e          	shr    $0x1e,%rax
   ebadc:	48 31 d0             	xor    %rdx,%rax
   ebadf:	48 0f af c1          	imul   %rcx,%rax
   ebae3:	48 b9 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rcx
   ebaed:	48 89 c2             	mov    %rax,%rdx
   ebaf0:	48 c1 ea 1b          	shr    $0x1b,%rdx
   ebaf4:	48 31 d0             	xor    %rdx,%rax
   ebaf7:	48 0f af c1          	imul   %rcx,%rax
   ebafb:	48 89 c2             	mov    %rax,%rdx
   ebafe:	48 c1 ea 1f          	shr    $0x1f,%rdx
   ebb02:	48 31 d0             	xor    %rdx,%rax
   ebb05:	49 01 c5             	add    %rax,%r13
   ebb08:	4d 89 6c 24 08       	mov    %r13,0x8(%r12)
   ebb0d:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   ebb11:	0f 84 09 01 00 00    	je     ebc20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x820>
   ebb17:	48 83 c3 01          	add    $0x1,%rbx
   ebb1b:	48 83 c5 01          	add    $0x1,%rbp
   ebb1f:	48 89 9c 24 d8 00 00 00 	mov    %rbx,0xd8(%rsp)
   ebb27:	48 39 6c 24 30       	cmp    %rbp,0x30(%rsp)
   ebb2c:	0f 85 0f ff ff ff    	jne    eba41 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x641>
   ebb32:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
   ebb37:	4d 89 e6             	mov    %r12,%r14
   ebb3a:	8b 85 d0 00 00 00    	mov    0xd0(%rbp),%eax
   ebb40:	48 83 44 24 38 01    	addq   $0x1,0x38(%rsp)
   ebb46:	48 89 c2             	mov    %rax,%rdx
   ebb49:	48 39 44 24 38       	cmp    %rax,0x38(%rsp)
   ebb4e:	0f 82 dc fc ff ff    	jb     eb830 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x430>
   ebb54:	90                   	nop
   ebb55:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ebb60:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
   ebb65:	4c 8b a4 24 78 02 00 00 	mov    0x278(%rsp),%r12
   ebb6d:	4c 8b ac 24 80 02 00 00 	mov    0x280(%rsp),%r13
   ebb75:	c6 85 6c 02 00 00 00 	movb   $0x0,0x26c(%rbp)
   ebb7c:	48 8d bc 24 70 01 00 00 	lea    0x170(%rsp),%rdi
   ebb84:	e8 57 c0 00 00       	call   f7be0 <_ZN8QuadTree9WorkspaceIiED1Ev>
   ebb89:	0f b6 94 24 b0 00 00 00 	movzbl 0xb0(%rsp),%edx
   ebb91:	66 0f 6f 84 24 c0 00 00 00 	movdqa 0xc0(%rsp),%xmm0
   ebb9a:	66 0f 6f 94 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm2
   ebba3:	0f 29 84 24 80 01 00 00 	movaps %xmm0,0x180(%rsp)
   ebbab:	66 0f 6f 84 24 d0 00 00 00 	movdqa 0xd0(%rsp),%xmm0
   ebbb4:	0f 29 94 24 70 01 00 00 	movaps %xmm2,0x170(%rsp)
   ebbbc:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   ebbc4:	80 fa 0b             	cmp    $0xb,%dl
   ebbc7:	74 08                	je     ebbd1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7d1>
   ebbc9:	84 d2                	test   %dl,%dl
   ebbcb:	0f 85 96 f8 ff ff    	jne    eb467 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x67>
   ebbd1:	8b 85 d0 00 00 00    	mov    0xd0(%rbp),%eax
   ebbd7:	4c 8b bc 24 90 02 00 00 	mov    0x290(%rsp),%r15
   ebbdf:	e9 cc f8 ff ff       	jmp    eb4b0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xb0>
   ebbe4:	0f 1f 40 00          	nopl   0x0(%rax)
   ebbe8:	48 8d bc 24 70 01 00 00 	lea    0x170(%rsp),%rdi
   ebbf0:	e8 eb bf 00 00       	call   f7be0 <_ZN8QuadTree9WorkspaceIiED1Ev>
   ebbf5:	4c 89 bc 24 90 02 00 00 	mov    %r15,0x290(%rsp)
   ebbfd:	ba 05 00 00 00       	mov    $0x5,%edx
   ebc02:	e9 60 f8 ff ff       	jmp    eb467 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x67>
   ebc07:	e8 d4 49 00 00       	call   f05e0 <_ZN8QuadTree15defaultResourceEv>
   ebc0c:	8b b5 d0 00 00 00    	mov    0xd0(%rbp),%esi
   ebc12:	48 89 f1             	mov    %rsi,%rcx
   ebc15:	e9 62 f9 ff ff       	jmp    eb57c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x17c>
   ebc1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ebc20:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   ebc25:	4c 89 e0             	mov    %r12,%rax
   ebc28:	4c 89 eb             	mov    %r13,%rbx
   ebc2b:	4c 8d 6d 01          	lea    0x1(%rbp),%r13
   ebc2f:	45 89 f4             	mov    %r14d,%r12d
   ebc32:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
   ebc37:	49 89 c6             	mov    %rax,%r14
   ebc3a:	49 39 f5             	cmp    %rsi,%r13
   ebc3d:	0f 84 f7 fe ff ff    	je     ebb3a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x73a>
   ebc43:	48 89 34 24          	mov    %rsi,(%rsp)
   ebc47:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
   ebc4c:	44 89 e5             	mov    %r12d,%ebp
   ebc4f:	4d 89 ec             	mov    %r13,%r12
   ebc52:	49 89 dd             	mov    %rbx,%r13
   ebc55:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ebc5a:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
   ebc5f:	48 8d bc 24 f0 00 00 00 	lea    0xf0(%rsp),%rdi
   ebc67:	42 8b 14 a0          	mov    (%rax,%r12,4),%edx
   ebc6b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   ebc70:	48 89 d3             	mov    %rdx,%rbx
   ebc73:	48 c1 e2 05          	shl    $0x5,%rdx
   ebc77:	48 39 74 10 10       	cmp    %rsi,0x10(%rax,%rdx,1)
   ebc7c:	89 da                	mov    %ebx,%edx
   ebc7e:	4c 89 fe             	mov    %r15,%rsi
   ebc81:	0f 42 dd             	cmovb  %ebp,%ebx
   ebc84:	0f 43 d5             	cmovae %ebp,%edx
   ebc87:	e8 e4 30 05 00       	call   13ed70 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ebc8c:	89 da                	mov    %ebx,%edx
   ebc8e:	4c 89 fe             	mov    %r15,%rsi
   ebc91:	48 8d bc 24 30 01 00 00 	lea    0x130(%rsp),%rdi
   ebc99:	e8 d2 30 05 00       	call   13ed70 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ebc9e:	48 8b 84 24 48 01 00 00 	mov    0x148(%rsp),%rax
   ebca6:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   ebcab:	8b 30                	mov    (%rax),%esi
   ebcad:	48 8b 84 24 08 01 00 00 	mov    0x108(%rsp),%rax
   ebcb5:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
   ebcb9:	48 bb eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rbx
   ebcc3:	8b 00                	mov    (%rax),%eax
   ebcc5:	49 89 16             	mov    %rdx,(%r14)
   ebcc8:	89 f2                	mov    %esi,%edx
   ebcca:	39 f0                	cmp    %esi,%eax
   ebccc:	0f 46 d0             	cmovbe %eax,%edx
   ebccf:	48 c1 e2 20          	shl    $0x20,%rdx
   ebcd3:	39 f0                	cmp    %esi,%eax
   ebcd5:	0f 42 c6             	cmovb  %esi,%eax
   ebcd8:	49 83 c4 01          	add    $0x1,%r12
   ebcdc:	48 09 d0             	or     %rdx,%rax
   ebcdf:	48 89 c2             	mov    %rax,%rdx
   ebce2:	48 c1 ea 1e          	shr    $0x1e,%rdx
   ebce6:	48 31 c2             	xor    %rax,%rdx
   ebce9:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   ebcf3:	48 0f af d0          	imul   %rax,%rdx
   ebcf7:	48 89 d0             	mov    %rdx,%rax
   ebcfa:	48 c1 e8 1b          	shr    $0x1b,%rax
   ebcfe:	48 31 d0             	xor    %rdx,%rax
   ebd01:	48 0f af c3          	imul   %rbx,%rax
   ebd05:	48 89 c2             	mov    %rax,%rdx
   ebd08:	48 c1 ea 1f          	shr    $0x1f,%rdx
   ebd0c:	48 31 d0             	xor    %rdx,%rax
   ebd0f:	49 01 c5             	add    %rax,%r13
   ebd12:	4d 89 6e 08          	mov    %r13,0x8(%r14)
   ebd16:	4c 3b 24 24          	cmp    (%rsp),%r12
   ebd1a:	0f 82 35 ff ff ff    	jb     ebc55 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x855>
   ebd20:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
   ebd25:	e9 10 fe ff ff       	jmp    ebb3a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x73a>
   ebd2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ebd30:	48 89 f0             	mov    %rsi,%rax
   ebd33:	31 c9                	xor    %ecx,%ecx
   ebd35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ebd40:	48 d1 e8             	shr    $1,%rax
   ebd43:	83 c1 02             	add    $0x2,%ecx
   ebd46:	48 83 f8 01          	cmp    $0x1,%rax
   ebd4a:	75 f4                	jne    ebd40 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x940>
   ebd4c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   ebd51:	4c 89 fa             	mov    %r15,%rdx
   ebd54:	48 89 34 24          	mov    %rsi,(%rsp)
   ebd58:	e8 63 a6 05 00       	call   1463c0 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   ebd5d:	48 8b 34 24          	mov    (%rsp),%rsi
   ebd61:	e9 82 fc ff ff       	jmp    eb9e8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5e8>
   ebd66:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   ebd70:	4c 8b 65 68          	mov    0x68(%rbp),%r12
   ebd74:	31 db                	xor    %ebx,%ebx
   ebd76:	eb 55                	jmp    ebdcd <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9cd>
   ebd78:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   ebd80:	4c 89 c9             	mov    %r9,%rcx
   ebd83:	44 89 ea             	mov    %r13d,%edx
   ebd86:	4c 89 ff             	mov    %r15,%rdi
   ebd89:	e8 12 5e f2 ff       	call   11ba0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_7ContextERT0_.isra.0>
   ebd8e:	4c 8d 8c 24 b0 00 00 00 	lea    0xb0(%rsp),%r9
   ebd96:	84 c0                	test   %al,%al
   ebd98:	74 19                	je     ebdb3 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9b3>
   ebd9a:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   ebd9f:	48 8d 50 01          	lea    0x1(%rax),%rdx
   ebda3:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   ebda8:	48 8b 95 b0 01 00 00 	mov    0x1b0(%rbp),%rdx
   ebdaf:	44 89 2c 82          	mov    %r13d,(%rdx,%rax,4)
   ebdb3:	8b 95 d0 00 00 00    	mov    0xd0(%rbp),%edx
   ebdb9:	48 83 c3 01          	add    $0x1,%rbx
   ebdbd:	0f b6 84 24 b0 00 00 00 	movzbl 0xb0(%rsp),%eax
   ebdc5:	39 d3                	cmp    %edx,%ebx
   ebdc7:	0f 83 b3 fb ff ff    	jae    eb980 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x580>
   ebdcd:	84 c0                	test   %al,%al
   ebdcf:	0f 85 8b fd ff ff    	jne    ebb60 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x760>
   ebdd5:	8b 44 24 64          	mov    0x64(%rsp),%eax
   ebdd9:	41 89 dd             	mov    %ebx,%r13d
   ebddc:	48 89 c6             	mov    %rax,%rsi
   ebddf:	48 c1 e0 05          	shl    $0x5,%rax
   ebde3:	4c 01 e0             	add    %r12,%rax
   ebde6:	48 89 d9             	mov    %rbx,%rcx
   ebde9:	48 c1 e1 05          	shl    $0x5,%rcx
   ebded:	49 8b 4c 0c 10       	mov    0x10(%r12,%rcx,1),%rcx
   ebdf2:	48 39 48 10          	cmp    %rcx,0x10(%rax)
   ebdf6:	72 88                	jb     ebd80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x980>
   ebdf8:	48 83 c3 01          	add    $0x1,%rbx
   ebdfc:	39 d3                	cmp    %edx,%ebx
   ebdfe:	0f 83 84 fb ff ff    	jae    eb988 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x588>
   ebe04:	41 89 dd             	mov    %ebx,%r13d
   ebe07:	eb dd                	jmp    ebde6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9e6>
   ebe09:	48 83 fe 01          	cmp    $0x1,%rsi
   ebe0d:	0f 87 1d ff ff ff    	ja     ebd30 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x930>
   ebe13:	31 c9                	xor    %ecx,%ecx
   ebe15:	e9 32 ff ff ff       	jmp    ebd4c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x94c>
   ebe1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ebe20:	48 8b bd b0 01 00 00 	mov    0x1b0(%rbp),%rdi
   ebe27:	31 c9                	xor    %ecx,%ecx
   ebe29:	4c 89 fa             	mov    %r15,%rdx
   ebe2c:	31 f6                	xor    %esi,%esi
   ebe2e:	e8 8d a5 05 00       	call   1463c0 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   ebe33:	e9 02 fd ff ff       	jmp    ebb3a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x73a>
   ebe38:	48 83 fe 01          	cmp    $0x1,%rsi
   ebe3c:	0f 87 7e f9 ff ff    	ja     eb7c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3c0>
   ebe42:	31 c9                	xor    %ecx,%ecx
   ebe44:	e9 93 f9 ff ff       	jmp    eb7dc <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3dc>
   ebe49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   ebe50:	c6 84 24 b0 00 00 00 0b 	movb   $0xb,0xb0(%rsp)
   ebe58:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
   ebe5d:	4c 8b a4 24 78 02 00 00 	mov    0x278(%rsp),%r12
   ebe65:	4c 8b ac 24 80 02 00 00 	mov    0x280(%rsp),%r13
   ebe6d:	e9 03 fd ff ff       	jmp    ebb75 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x775>
   ebe72:	31 c0                	xor    %eax,%eax
   ebe74:	e9 f2 f8 ff ff       	jmp    eb76b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x36b>
   ebe79:	48 8b 7d 68          	mov    0x68(%rbp),%rdi
   ebe7d:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   ebe82:	4c 89 d2             	mov    %r10,%rdx
   ebe85:	4c 89 14 24          	mov    %r10,(%rsp)
   ebe89:	e8 12 65 f2 ff       	call   123a0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   ebe8e:	4c 8b 14 24          	mov    (%rsp),%r10
   ebe92:	e9 58 f9 ff ff       	jmp    eb7ef <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3ef>
   ebe97:	4c 89 a4 24 78 02 00 00 	mov    %r12,0x278(%rsp)
   ebe9f:	4c 89 ac 24 80 02 00 00 	mov    %r13,0x280(%rsp)
   ebea7:	4c 89 bc 24 90 02 00 00 	mov    %r15,0x290(%rsp)
   ebeaf:	e8 ac b3 f1 ff       	call   7260 <__stack_chk_fail@plt>
   ebeb4:	4c 89 a4 24 78 02 00 00 	mov    %r12,0x278(%rsp)
   ebebc:	4c 89 ac 24 80 02 00 00 	mov    %r13,0x280(%rsp)
   ebec4:	4c 89 bc 24 90 02 00 00 	mov    %r15,0x290(%rsp)
   ebecc:	e8 ef 4d 00 00       	call   f0cc0 <_ZN8QuadTree6detail15activeWorkspaceEv>

# candidate unordered_helper QuadTree::QueryResult QuadTree::Index<unsigned int, int, QuadTree::Unchecked, true>::forEachNonemptyUnorderedPair<bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const::{lambda(auto:1 const&, auto:2 const&)#1}, QuadTree::detail::AcceptAll>((anonymous namespace)::PairSink&, QuadTree::WorkBudget, QuadTree::detail::AcceptAll&) const

/home/dima/.cache/quadtree-g1-unordered-empty.OwlJhL/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000c7ed0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_>:
   c7ed0:	48 81 ec 48 01 00 00 	sub    $0x148,%rsp
   c7ed7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   c7edb:	48 89 9c 24 18 01 00 00 	mov    %rbx,0x118(%rsp)
   c7ee3:	48 89 fb             	mov    %rdi,%rbx
   c7ee6:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   c7eeb:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
   c7ef4:	48 89 84 24 08 01 00 00 	mov    %rax,0x108(%rsp)
   c7efc:	8b 86 c8 00 00 00    	mov    0xc8(%rsi),%eax
   c7f02:	83 f8 01             	cmp    $0x1,%eax
   c7f05:	0f 84 85 03 00 00    	je     c8290 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x3c0>
   c7f0b:	4c 89 bc 24 40 01 00 00 	mov    %r15,0x140(%rsp)
   c7f13:	49 89 f7             	mov    %rsi,%r15
   c7f16:	8b b6 5c 01 00 00    	mov    0x15c(%rsi),%esi
   c7f1c:	c6 44 24 40 00       	movb   $0x0,0x40(%rsp)
   c7f21:	48 c7 44 24 68 00 00 00 00 	movq   $0x0,0x68(%rsp)
   c7f2a:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   c7f2f:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   c7f34:	0f 11 44 24 48       	movups %xmm0,0x48(%rsp)
   c7f39:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
   c7f3e:	83 fe ff             	cmp    $0xffffffff,%esi
   c7f41:	0f 85 19 02 00 00    	jne    c8160 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x290>
   c7f47:	49 89 c2             	mov    %rax,%r10
   c7f4a:	48 83 f8 04          	cmp    $0x4,%rax
   c7f4e:	0f 86 54 03 00 00    	jbe    c82a8 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x3d8>
   c7f54:	41 80 7f 19 01       	cmpb   $0x1,0x19(%r15)
   c7f59:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   c7f5f:	4c 89 b4 24 38 01 00 00 	mov    %r14,0x138(%rsp)
   c7f67:	49 8b 7f 50          	mov    0x50(%r15),%rdi
   c7f6b:	4d 8b 77 58          	mov    0x58(%r15),%r14
   c7f6f:	48 89 ac 24 20 01 00 00 	mov    %rbp,0x120(%rsp)
   c7f77:	49 8b 77 60          	mov    0x60(%r15),%rsi
   c7f7b:	4c 89 a4 24 28 01 00 00 	mov    %r12,0x128(%rsp)
   c7f83:	49 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%r15
   c7f8d:	4c 89 ac 24 30 01 00 00 	mov    %r13,0x130(%rsp)
   c7f95:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   c7f9a:	0f 94 44 24 1c       	sete   0x1c(%rsp)
   c7f9f:	45 39 d0             	cmp    %r10d,%r8d
   c7fa2:	0f 83 87 01 00 00    	jae    c812f <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x25f>
   c7fa8:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
   c7fad:	48 89 f9             	mov    %rdi,%rcx
   c7fb0:	4c 89 c2             	mov    %r8,%rdx
   c7fb3:	48 89 f0             	mov    %rsi,%rax
   c7fb6:	4d 8d 60 ff          	lea    -0x1(%r8),%r12
   c7fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   c7fc0:	4c 8b 06             	mov    (%rsi),%r8
   c7fc3:	4c 85 40 28          	test   %r8,0x28(%rax)
   c7fc7:	0f 84 03 02 00 00    	je     c81d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x300>
   c7fcd:	4c 8b 46 08          	mov    0x8(%rsi),%r8
   c7fd1:	4c 85 40 20          	test   %r8,0x20(%rax)
   c7fd5:	0f 84 f5 01 00 00    	je     c81d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x300>
   c7fdb:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
   c7fe0:	4d 85 c0             	test   %r8,%r8
   c7fe3:	0f 84 17 02 00 00    	je     c8200 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x330>
   c7fe9:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
   c7fed:	74 09                	je     c7ff8 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x128>
   c7fef:	49 83 e8 01          	sub    $0x1,%r8
   c7ff3:	4c 89 44 24 70       	mov    %r8,0x70(%rsp)
   c7ff8:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
   c7ffd:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
   c8001:	74 09                	je     c800c <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x13c>
   c8003:	49 83 c0 01          	add    $0x1,%r8
   c8007:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
   c800c:	44 8b 0f             	mov    (%rdi),%r9d
   c800f:	44 8b 5f 08          	mov    0x8(%rdi),%r11d
   c8013:	44 8b 47 04          	mov    0x4(%rdi),%r8d
   c8017:	8b 5f 0c             	mov    0xc(%rdi),%ebx
   c801a:	45 39 d9             	cmp    %r11d,%r9d
   c801d:	8b 69 18             	mov    0x18(%rcx),%ebp
   c8020:	41 0f 94 c5          	sete   %r13b
   c8024:	41 39 d8             	cmp    %ebx,%r8d
   c8027:	44 89 44 24 18       	mov    %r8d,0x18(%rsp)
   c802c:	41 0f 94 c0          	sete   %r8b
   c8030:	45 08 e8             	or     %r13b,%r8b
   c8033:	75 0b                	jne    c8040 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x170>
   c8035:	80 7c 24 1c 00       	cmpb   $0x0,0x1c(%rsp)
   c803a:	0f 84 f0 01 00 00    	je     c8230 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x360>
   c8040:	41 39 e9             	cmp    %ebp,%r9d
   c8043:	0f 8f b7 00 00 00    	jg     c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c8049:	44 3b 59 10          	cmp    0x10(%rcx),%r11d
   c804d:	0f 8c ad 00 00 00    	jl     c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c8053:	44 8b 5c 24 18       	mov    0x18(%rsp),%r11d
   c8058:	44 3b 59 1c          	cmp    0x1c(%rcx),%r11d
   c805c:	0f 8f 9e 00 00 00    	jg     c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c8062:	3b 59 14             	cmp    0x14(%rcx),%ebx
   c8065:	0f 8c 95 00 00 00    	jl     c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c806b:	8b 5e 18             	mov    0x18(%rsi),%ebx
   c806e:	39 58 38             	cmp    %ebx,0x38(%rax)
   c8071:	0f 82 79 01 00 00    	jb     c81f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x320>
   c8077:	4d 89 e1             	mov    %r12,%r9
   c807a:	49 89 d0             	mov    %rdx,%r8
   c807d:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   c8082:	47 8b 04 86          	mov    (%r14,%r8,4),%r8d
   c8086:	4c 8b 1b             	mov    (%rbx),%r11
   c8089:	43 8b 1c 8e          	mov    (%r14,%r9,4),%ebx
   c808d:	49 83 03 01          	addq   $0x1,(%r11)
   c8091:	41 89 d9             	mov    %ebx,%r9d
   c8094:	41 39 d8             	cmp    %ebx,%r8d
   c8097:	45 0f 46 c8          	cmovbe %r8d,%r9d
   c809b:	49 c1 e1 20          	shl    $0x20,%r9
   c809f:	41 39 d8             	cmp    %ebx,%r8d
   c80a2:	44 0f 42 c3          	cmovb  %ebx,%r8d
   c80a6:	48 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rbx
   c80b0:	4d 09 c1             	or     %r8,%r9
   c80b3:	4d 89 c8             	mov    %r9,%r8
   c80b6:	49 c1 e8 1e          	shr    $0x1e,%r8
   c80ba:	4d 31 c8             	xor    %r9,%r8
   c80bd:	4c 0f af c3          	imul   %rbx,%r8
   c80c1:	4d 89 c1             	mov    %r8,%r9
   c80c4:	49 c1 e9 1b          	shr    $0x1b,%r9
   c80c8:	4d 31 c8             	xor    %r9,%r8
   c80cb:	4d 0f af c7          	imul   %r15,%r8
   c80cf:	4d 89 c1             	mov    %r8,%r9
   c80d2:	49 c1 e9 1f          	shr    $0x1f,%r9
   c80d6:	4d 31 c8             	xor    %r9,%r8
   c80d9:	4d 01 43 08          	add    %r8,0x8(%r11)
   c80dd:	4c 8b 44 24 68       	mov    0x68(%rsp),%r8
   c80e2:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
   c80e6:	74 18                	je     c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c80e8:	49 83 c0 01          	add    $0x1,%r8
   c80ec:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
   c80f1:	0f 1f 40 00          	nopl   0x0(%rax)
   c80f5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   c8100:	48 83 c2 01          	add    $0x1,%rdx
   c8104:	48 83 c1 10          	add    $0x10,%rcx
   c8108:	48 83 c0 20          	add    $0x20,%rax
   c810c:	44 39 d2             	cmp    %r10d,%edx
   c810f:	0f 82 ab fe ff ff    	jb     c7fc0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0xf0>
   c8115:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
   c811a:	48 83 c7 10          	add    $0x10,%rdi
   c811e:	48 83 c6 20          	add    $0x20,%rsi
   c8122:	49 83 c0 01          	add    $0x1,%r8
   c8126:	45 39 d0             	cmp    %r10d,%r8d
   c8129:	0f 82 79 fe ff ff    	jb     c7fa8 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0xd8>
   c812f:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   c8134:	48 8b ac 24 20 01 00 00 	mov    0x120(%rsp),%rbp
   c813c:	4c 8b a4 24 28 01 00 00 	mov    0x128(%rsp),%r12
   c8144:	4c 8b ac 24 30 01 00 00 	mov    0x130(%rsp),%r13
   c814c:	4c 8b b4 24 38 01 00 00 	mov    0x138(%rsp),%r14
   c8154:	eb 2a                	jmp    c8180 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x2b0>
   c8156:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   c8160:	48 89 d1             	mov    %rdx,%rcx
   c8163:	4d 89 c8             	mov    %r9,%r8
   c8166:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
   c816b:	4c 89 ff             	mov    %r15,%rdi
   c816e:	e8 3d f8 ff ff       	call   c79b0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE9selfPairsIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvjRNS2_7ContextESC_RSF_>
   c8173:	66 90                	xchg   %ax,%ax
   c8175:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   c8180:	66 0f 6f 44 24 40    	movdqa 0x40(%rsp),%xmm0
   c8186:	4c 8b bc 24 40 01 00 00 	mov    0x140(%rsp),%r15
   c818e:	0f 11 03             	movups %xmm0,(%rbx)
   c8191:	66 0f 6f 44 24 50    	movdqa 0x50(%rsp),%xmm0
   c8197:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
   c819b:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   c81a1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   c81a5:	48 8b 84 24 08 01 00 00 	mov    0x108(%rsp),%rax
   c81ad:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   c81b6:	0f 85 c3 03 00 00    	jne    c857f <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x6af>
   c81bc:	48 89 d8             	mov    %rbx,%rax
   c81bf:	48 8b 9c 24 18 01 00 00 	mov    0x118(%rsp),%rbx
   c81c7:	48 81 c4 48 01 00 00 	add    $0x148,%rsp
   c81ce:	c3                   	ret
   c81cf:	90                   	nop
   c81d0:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
   c81d5:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
   c81d9:	0f 84 21 ff ff ff    	je     c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c81df:	49 83 c0 01          	add    $0x1,%r8
   c81e3:	4c 89 44 24 58       	mov    %r8,0x58(%rsp)
   c81e8:	e9 13 ff ff ff       	jmp    c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c81ed:	0f 1f 00             	nopl   (%rax)
   c81f0:	49 89 d1             	mov    %rdx,%r9
   c81f3:	4d 89 e0             	mov    %r12,%r8
   c81f6:	e9 82 fe ff ff       	jmp    c807d <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x1ad>
   c81fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   c8200:	c6 44 24 40 0b       	movb   $0xb,0x40(%rsp)
   c8205:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   c820a:	48 8b ac 24 20 01 00 00 	mov    0x120(%rsp),%rbp
   c8212:	4c 8b a4 24 28 01 00 00 	mov    0x128(%rsp),%r12
   c821a:	4c 8b ac 24 30 01 00 00 	mov    0x130(%rsp),%r13
   c8222:	4c 8b b4 24 38 01 00 00 	mov    0x138(%rsp),%r14
   c822a:	e9 51 ff ff ff       	jmp    c8180 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x2b0>
   c822f:	90                   	nop
   c8230:	44 8b 41 10          	mov    0x10(%rcx),%r8d
   c8234:	41 39 e8             	cmp    %ebp,%r8d
   c8237:	0f 84 03 fe ff ff    	je     c8040 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x170>
   c823d:	44 8b 69 14          	mov    0x14(%rcx),%r13d
   c8241:	44 89 6c 24 28       	mov    %r13d,0x28(%rsp)
   c8246:	44 8b 69 1c          	mov    0x1c(%rcx),%r13d
   c824a:	44 39 6c 24 28       	cmp    %r13d,0x28(%rsp)
   c824f:	0f 84 eb fd ff ff    	je     c8040 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x170>
   c8255:	45 39 c3             	cmp    %r8d,%r11d
   c8258:	41 0f 9f c0          	setg   %r8b
   c825c:	41 39 e9             	cmp    %ebp,%r9d
   c825f:	41 0f 9c c1          	setl   %r9b
   c8263:	45 21 c8             	and    %r9d,%r8d
   c8266:	44 39 6c 24 18       	cmp    %r13d,0x18(%rsp)
   c826b:	41 0f 9c c1          	setl   %r9b
   c826f:	45 84 c8             	test   %r9b,%r8b
   c8272:	0f 84 88 fe ff ff    	je     c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c8278:	3b 5c 24 28          	cmp    0x28(%rsp),%ebx
   c827c:	0f 8e 7e fe ff ff    	jle    c8100 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x230>
   c8282:	e9 e4 fd ff ff       	jmp    c806b <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x19b>
   c8287:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   c8290:	c6 07 00             	movb   $0x0,(%rdi)
   c8293:	48 c7 47 28 00 00 00 00 	movq   $0x0,0x28(%rdi)
   c829b:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   c829f:	0f 11 47 18          	movups %xmm0,0x18(%rdi)
   c82a3:	e9 fd fe ff ff       	jmp    c81a5 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x2d5>
   c82a8:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
   c82ac:	48 0f af c2          	imul   %rdx,%rax
   c82b0:	48 d1 e8             	shr    $1,%rax
   c82b3:	48 39 c1             	cmp    %rax,%rcx
   c82b6:	73 0e                	jae    c82c6 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x3f6>
   c82b8:	45 85 d2             	test   %r10d,%r10d
   c82bb:	0f 85 93 fc ff ff    	jne    c7f54 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x84>
   c82c1:	e9 ba fe ff ff       	jmp    c8180 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x2b0>
   c82c6:	41 83 fa 01          	cmp    $0x1,%r10d
   c82ca:	0f 86 b0 fe ff ff    	jbe    c8180 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x2b0>
   c82d0:	49 8b 47 60          	mov    0x60(%r15),%rax
   c82d4:	41 8d 4a ff          	lea    -0x1(%r10),%ecx
   c82d8:	4c 89 ac 24 30 01 00 00 	mov    %r13,0x130(%rsp)
   c82e0:	48 89 ac 24 20 01 00 00 	mov    %rbp,0x120(%rsp)
   c82e8:	4c 8d 68 20          	lea    0x20(%rax),%r13
   c82ec:	89 4c 24 1c          	mov    %ecx,0x1c(%rsp)
   c82f0:	49 8b 47 50          	mov    0x50(%r15),%rax
   c82f4:	4c 89 a4 24 28 01 00 00 	mov    %r12,0x128(%rsp)
   c82fc:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
   c8301:	4c 8d 58 10          	lea    0x10(%rax),%r11
   c8305:	4c 89 b4 24 38 01 00 00 	mov    %r14,0x138(%rsp)
   c830d:	45 89 d6             	mov    %r10d,%r14d
   c8310:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   c8315:	45 31 ff             	xor    %r15d,%r15d
   c8318:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   c8320:	44 89 7c 24 10       	mov    %r15d,0x10(%rsp)
   c8325:	41 83 c7 01          	add    $0x1,%r15d
   c8329:	4d 89 dc             	mov    %r11,%r12
   c832c:	4c 89 eb             	mov    %r13,%rbx
   c832f:	44 89 7c 24 18       	mov    %r15d,0x18(%rsp)
   c8334:	44 89 fd             	mov    %r15d,%ebp
   c8337:	eb 3d                	jmp    c8376 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x4a6>
   c8339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   c8340:	49 8b 45 e8          	mov    -0x18(%r13),%rax
   c8344:	48 85 03             	test   %rax,(%rbx)
   c8347:	74 37                	je     c8380 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x4b0>
   c8349:	41 8b 43 f0          	mov    -0x10(%r11),%eax
   c834d:	41 8b 54 24 08       	mov    0x8(%r12),%edx
   c8352:	48 83 44 24 50 01    	addq   $0x1,0x50(%rsp)
   c8358:	39 d0                	cmp    %edx,%eax
   c835a:	0f 8c 90 00 00 00    	jl     c83f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x520>
   c8360:	0f 84 8e 01 00 00    	je     c84f4 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x624>
   c8366:	83 c5 01             	add    $0x1,%ebp
   c8369:	48 83 c3 20          	add    $0x20,%rbx
   c836d:	49 83 c4 10          	add    $0x10,%r12
   c8371:	44 39 f5             	cmp    %r14d,%ebp
   c8374:	73 2e                	jae    c83a4 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x4d4>
   c8376:	49 8b 45 e0          	mov    -0x20(%r13),%rax
   c837a:	48 85 43 08          	test   %rax,0x8(%rbx)
   c837e:	75 c0                	jne    c8340 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x470>
   c8380:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   c8385:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   c8389:	74 db                	je     c8366 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x496>
   c838b:	48 83 c0 01          	add    $0x1,%rax
   c838f:	83 c5 01             	add    $0x1,%ebp
   c8392:	48 83 c3 20          	add    $0x20,%rbx
   c8396:	49 83 c4 10          	add    $0x10,%r12
   c839a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   c839f:	44 39 f5             	cmp    %r14d,%ebp
   c83a2:	72 d2                	jb     c8376 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x4a6>
   c83a4:	44 8b 7c 24 18       	mov    0x18(%rsp),%r15d
   c83a9:	49 83 c5 20          	add    $0x20,%r13
   c83ad:	49 83 c3 10          	add    $0x10,%r11
   c83b1:	44 3b 7c 24 1c       	cmp    0x1c(%rsp),%r15d
   c83b6:	0f 85 64 ff ff ff    	jne    c8320 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x450>
   c83bc:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   c83c1:	48 8b ac 24 20 01 00 00 	mov    0x120(%rsp),%rbp
   c83c9:	4c 8b a4 24 28 01 00 00 	mov    0x128(%rsp),%r12
   c83d1:	4c 8b ac 24 30 01 00 00 	mov    0x130(%rsp),%r13
   c83d9:	4c 8b b4 24 38 01 00 00 	mov    0x138(%rsp),%r14
   c83e1:	e9 9a fd ff ff       	jmp    c8180 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x2b0>
   c83e6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   c83f0:	41 8b 34 24          	mov    (%r12),%esi
   c83f4:	41 8b 4b f8          	mov    -0x8(%r11),%ecx
   c83f8:	39 ce                	cmp    %ecx,%esi
   c83fa:	0f 8d 00 01 00 00    	jge    c8500 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x630>
   c8400:	41 8b 7b f4          	mov    -0xc(%r11),%edi
   c8404:	41 3b 7c 24 0c       	cmp    0xc(%r12),%edi
   c8409:	0f 8d fd 00 00 00    	jge    c850c <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x63c>
   c840f:	45 8b 53 fc          	mov    -0x4(%r11),%r10d
   c8413:	45 39 54 24 04       	cmp    %r10d,0x4(%r12)
   c8418:	0f 8d ee 00 00 00    	jge    c850c <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x63c>
   c841e:	41 8b 45 f8          	mov    -0x8(%r13),%eax
   c8422:	39 43 18             	cmp    %eax,0x18(%rbx)
   c8425:	0f 82 45 01 00 00    	jb     c8570 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x6a0>
   c842b:	89 6c 24 20          	mov    %ebp,0x20(%rsp)
   c842f:	8b 54 24 10          	mov    0x10(%rsp),%edx
   c8433:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   c8438:	48 8d bc 24 80 00 00 00 	lea    0x80(%rsp),%rdi
   c8440:	4c 89 5c 24 28       	mov    %r11,0x28(%rsp)
   c8445:	4c 89 fe             	mov    %r15,%rsi
   c8448:	e8 23 69 07 00       	call   13ed70 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   c844d:	8b 54 24 20          	mov    0x20(%rsp),%edx
   c8451:	4c 89 fe             	mov    %r15,%rsi
   c8454:	48 8d bc 24 c0 00 00 00 	lea    0xc0(%rsp),%rdi
   c845c:	e8 0f 69 07 00       	call   13ed70 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   c8461:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   c8466:	4c 8b 5c 24 28       	mov    0x28(%rsp),%r11
   c846b:	48 bf b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdi
   c8475:	48 8b 8c 24 98 00 00 00 	mov    0x98(%rsp),%rcx
   c847d:	48 8b 10             	mov    (%rax),%rdx
   c8480:	48 8b 84 24 d8 00 00 00 	mov    0xd8(%rsp),%rax
   c8488:	8b 31                	mov    (%rcx),%esi
   c848a:	8b 00                	mov    (%rax),%eax
   c848c:	48 83 02 01          	addq   $0x1,(%rdx)
   c8490:	89 f1                	mov    %esi,%ecx
   c8492:	39 f0                	cmp    %esi,%eax
   c8494:	0f 46 c8             	cmovbe %eax,%ecx
   c8497:	48 c1 e1 20          	shl    $0x20,%rcx
   c849b:	39 f0                	cmp    %esi,%eax
   c849d:	0f 42 c6             	cmovb  %esi,%eax
   c84a0:	48 09 c1             	or     %rax,%rcx
   c84a3:	48 89 c8             	mov    %rcx,%rax
   c84a6:	48 c1 e8 1e          	shr    $0x1e,%rax
   c84aa:	48 31 c8             	xor    %rcx,%rax
   c84ad:	48 0f af c7          	imul   %rdi,%rax
   c84b1:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   c84bb:	48 89 c1             	mov    %rax,%rcx
   c84be:	48 c1 e9 1b          	shr    $0x1b,%rcx
   c84c2:	48 31 c8             	xor    %rcx,%rax
   c84c5:	48 0f af c7          	imul   %rdi,%rax
   c84c9:	48 89 c1             	mov    %rax,%rcx
   c84cc:	48 c1 e9 1f          	shr    $0x1f,%rcx
   c84d0:	48 31 c8             	xor    %rcx,%rax
   c84d3:	48 01 42 08          	add    %rax,0x8(%rdx)
   c84d7:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   c84dc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   c84e0:	0f 84 80 fe ff ff    	je     c8366 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x496>
   c84e6:	48 83 c0 01          	add    $0x1,%rax
   c84ea:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   c84ef:	e9 72 fe ff ff       	jmp    c8366 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x496>
   c84f4:	41 8b 34 24          	mov    (%r12),%esi
   c84f8:	41 8b 4b f8          	mov    -0x8(%r11),%ecx
   c84fc:	0f 1f 40 00          	nopl   0x0(%rax)
   c8500:	39 ce                	cmp    %ecx,%esi
   c8502:	0f 8f 5e fe ff ff    	jg     c8366 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x496>
   c8508:	41 8b 7b f4          	mov    -0xc(%r11),%edi
   c850c:	45 8b 44 24 0c       	mov    0xc(%r12),%r8d
   c8511:	44 39 c7             	cmp    %r8d,%edi
   c8514:	0f 8f 4c fe ff ff    	jg     c8366 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x496>
   c851a:	45 8b 4c 24 04       	mov    0x4(%r12),%r9d
   c851f:	45 8b 53 fc          	mov    -0x4(%r11),%r10d
   c8523:	45 39 d1             	cmp    %r10d,%r9d
   c8526:	0f 8f 3a fe ff ff    	jg     c8366 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x496>
   c852c:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   c8531:	41 80 7f 19 01       	cmpb   $0x1,0x19(%r15)
   c8536:	0f 95 44 24 20       	setne  0x20(%rsp)
   c853b:	44 39 d7             	cmp    %r10d,%edi
   c853e:	40 0f 95 c7          	setne  %dil
   c8542:	40 22 7c 24 20       	and    0x20(%rsp),%dil
   c8547:	45 39 c8             	cmp    %r9d,%r8d
   c854a:	41 0f 95 c0          	setne  %r8b
   c854e:	44 21 c7             	and    %r8d,%edi
   c8551:	39 c1                	cmp    %eax,%ecx
   c8553:	0f 95 c0             	setne  %al
   c8556:	40 84 c7             	test   %al,%dil
   c8559:	0f 84 bf fe ff ff    	je     c841e <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x54e>
   c855f:	39 f2                	cmp    %esi,%edx
   c8561:	0f 84 b7 fe ff ff    	je     c841e <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x54e>
   c8567:	e9 fa fd ff ff       	jmp    c8366 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x496>
   c856c:	0f 1f 40 00          	nopl   0x0(%rax)
   c8570:	8b 44 24 10          	mov    0x10(%rsp),%eax
   c8574:	89 ea                	mov    %ebp,%edx
   c8576:	89 44 24 20          	mov    %eax,0x20(%rsp)
   c857a:	e9 b4 fe ff ff       	jmp    c8433 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE28forEachNonemptyUnorderedPairIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEENS_11QueryResultESC_NS_10WorkBudgetERSF_+0x563>
   c857f:	48 89 ac 24 20 01 00 00 	mov    %rbp,0x120(%rsp)
   c8587:	4c 89 a4 24 28 01 00 00 	mov    %r12,0x128(%rsp)
   c858f:	4c 89 ac 24 30 01 00 00 	mov    %r13,0x130(%rsp)
   c8597:	4c 89 b4 24 38 01 00 00 	mov    %r14,0x138(%rsp)
   c859f:	4c 89 bc 24 40 01 00 00 	mov    %r15,0x140(%rsp)
   c85a7:	e8 b4 ec f3 ff       	call   7260 <__stack_chk_fail@plt>
