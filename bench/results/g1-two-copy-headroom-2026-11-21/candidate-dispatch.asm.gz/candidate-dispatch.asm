
# candidate unordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, false>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-two-copy-headroom.qUEHc7/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000ecf10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   ecf10:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   ecf17:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ecf1b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   ecf23:	48 8b 2a             	mov    (%rdx),%rbp
   ecf26:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   ecf2e:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   ecf32:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   ecf3a:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   ecf42:	49 89 ff             	mov    %rdi,%r15
   ecf45:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   ecf4d:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   ecf54:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   ecf59:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   ecf62:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   ecf6a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   ecf6e:	0f 11 07             	movups %xmm0,(%rdi)
   ecf71:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   ecf75:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   ecf79:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   ecf7d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   ecf81:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   ecf85:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   ecf89:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   ecf8d:	48 89 14 24          	mov    %rdx,(%rsp)
   ecf91:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   ecf95:	e8 06 0f 06 00       	call   14dea0 <_ZN5bench6memory11allocationsEv>
   ecf9a:	80 3d d7 12 08 00 00 	cmpb   $0x0,0x812d7(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ecfa1:	4c 8b 1c 24          	mov    (%rsp),%r11
   ecfa5:	49 89 c6             	mov    %rax,%r14
   ecfa8:	0f 84 01 0f 00 00    	je     edeaf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf9f>
   ecfae:	0f 31                	rdtsc
   ecfb0:	48 c1 e2 20          	shl    $0x20,%rdx
   ecfb4:	48 09 d0             	or     %rdx,%rax
   ecfb7:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   ecfbf:	49 8b 13             	mov    (%r11),%rdx
   ecfc2:	49 3b 53 08          	cmp    0x8(%r11),%rdx
   ecfc6:	0f 84 13 09 00 00    	je     ed8df <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9cf>
   ecfcc:	49 29 ec             	sub    %rbp,%r12
   ecfcf:	48 c7 04 24 00 00 00 00 	movq   $0x0,(%rsp)
   ecfd7:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ecfdb:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   ecfe3:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   ecfeb:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   ecff4:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   ecffd:	c7 44 24 1c 00 00 00 00 	movl   $0x0,0x1c(%rsp)
   ed005:	4c 89 9c 24 88 00 00 00 	mov    %r11,0x88(%rsp)
   ed00d:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   ed015:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   ed01d:	45 31 ed             	xor    %r13d,%r13d
   ed020:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   ed028:	45 31 f6             	xor    %r14d,%r14d
   ed02b:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   ed030:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   ed035:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ed040:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   ed045:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed049:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   ed04d:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   ed055:	48 8b 28             	mov    (%rax),%rbp
   ed058:	4c 8b 60 08          	mov    0x8(%rax),%r12
   ed05c:	49 29 ec             	sub    %rbp,%r12
   ed05f:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
   ed064:	49 c1 fc 04          	sar    $0x4,%r12
   ed068:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   ed06f:	74 13                	je     ed084 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x174>
   ed071:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ed078:	3b 83 b8 02 00 00    	cmp    0x2b8(%rbx),%eax
   ed07e:	0f 84 b8 05 00 00    	je     ed63c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x72c>
   ed084:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   ed08c:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed090:	31 f6                	xor    %esi,%esi
   ed092:	66 0f 6f 3d 26 a8 06 00 	movdqa 0x6a826(%rip),%xmm7        # 1578c0 <C.66.5+0x2a0>
   ed09a:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   ed0a2:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ed0aa:	ba 88 01 00 00       	mov    $0x188,%edx
   ed0af:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   ed0b6:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   ed0bb:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   ed0c3:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   ed0cb:	66 48 0f 6e c0       	movq   %rax,%xmm0
   ed0d0:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   ed0d8:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   ed0dc:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   ed0e5:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   ed0ed:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   ed0f6:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   ed0fe:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   ed107:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   ed10f:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   ed117:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   ed11c:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   ed124:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   ed129:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   ed131:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   ed136:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   ed13e:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   ed14a:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   ed156:	e8 b5 9f f1 ff       	call   7110 <memset@plt>
   ed15b:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   ed161:	66 0f ef c9          	pxor   %xmm1,%xmm1
   ed165:	66 0f 6f 05 63 a7 06 00 	movdqa 0x6a763(%rip),%xmm0        # 1578d0 <C.66.5+0x2b0>
   ed16d:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   ed173:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   ed179:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ed17d:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ed184:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   ed18c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ed191:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   ed199:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   ed1a1:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   ed1a9:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   ed1b5:	48 89 9c 24 d8 01 00 00 	mov    %rbx,0x1d8(%rsp)
   ed1bd:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   ed1c9:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   ed1d5:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   ed1e1:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   ed1ed:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   ed1f9:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   ed204:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   ed20c:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   ed217:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   ed223:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   ed22b:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   ed237:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   ed242:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   ed24a:	48 89 9c 24 78 02 00 00 	mov    %rbx,0x278(%rsp)
   ed252:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   ed25e:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   ed26a:	48 89 9c 24 90 02 00 00 	mov    %rbx,0x290(%rsp)
   ed272:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   ed27e:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   ed286:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   ed28e:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   ed296:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   ed29e:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   ed2a6:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   ed2b2:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   ed2ba:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   ed2c3:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   ed2cb:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   ed2d3:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   ed2dc:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   ed2e4:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   ed2ec:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   ed2f5:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   ed2fd:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ed304:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   ed30c:	48 89 9c 24 a8 02 00 00 	mov    %rbx,0x2a8(%rsp)
   ed314:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   ed320:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   ed32c:	48 89 9c 24 c0 02 00 00 	mov    %rbx,0x2c0(%rsp)
   ed334:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   ed340:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   ed34c:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   ed358:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   ed363:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   ed36f:	48 89 9c 24 60 03 00 00 	mov    %rbx,0x360(%rsp)
   ed377:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   ed382:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   ed38d:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   ed399:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   ed3a1:	48 89 9c 24 00 04 00 00 	mov    %rbx,0x400(%rsp)
   ed3a9:	48 89 9c 24 18 04 00 00 	mov    %rbx,0x418(%rsp)
   ed3b1:	48 89 9c 24 30 04 00 00 	mov    %rbx,0x430(%rsp)
   ed3b9:	48 89 9c 24 48 04 00 00 	mov    %rbx,0x448(%rsp)
   ed3c1:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   ed3c9:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   ed3d1:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   ed3d9:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   ed3e1:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ed3e9:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   ed3f0:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   ed3f9:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   ed404:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   ed40b:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   ed412:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   ed41d:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   ed424:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   ed42c:	e8 ef 02 01 00       	call   fd720 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ed431:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   ed438:	0f 85 32 07 00 00    	jne    edb70 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc60>
   ed43e:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   ed447:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   ed44f:	48 89 5b 50          	mov    %rbx,0x50(%rbx)
   ed453:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   ed45b:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   ed464:	c6 83 ec 00 00 00 00 	movb   $0x0,0xec(%rbx)
   ed46b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
   ed46f:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   ed478:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   ed480:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   ed484:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   ed48d:	48 89 43 48          	mov    %rax,0x48(%rbx)
   ed491:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ed498:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
   ed49c:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   ed4a5:	48 89 83 98 00 00 00 	mov    %rax,0x98(%rbx)
   ed4ac:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ed4b1:	0f 11 43 38          	movups %xmm0,0x38(%rbx)
   ed4b5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed4b9:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
   ed4c0:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   ed4c9:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
   ed4d0:	0f 11 83 a8 00 00 00 	movups %xmm0,0xa8(%rbx)
   ed4d7:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   ed4df:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   ed4e8:	48 c7 43 58 00 00 00 00 	movq   $0x0,0x58(%rbx)
   ed4f0:	0f 11 83 b1 00 00 00 	movups %xmm0,0xb1(%rbx)
   ed4f7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed4fb:	0f 11 83 d0 00 00 00 	movups %xmm0,0xd0(%rbx)
   ed502:	48 c7 43 60 00 00 00 00 	movq   $0x0,0x60(%rbx)
   ed50a:	48 c7 43 68 00 00 00 00 	movq   $0x0,0x68(%rbx)
   ed512:	48 c7 43 70 00 00 00 00 	movq   $0x0,0x70(%rbx)
   ed51a:	48 c7 43 78 00 00 00 00 	movq   $0x0,0x78(%rbx)
   ed522:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   ed52c:	c6 83 94 00 00 00 00 	movb   $0x0,0x94(%rbx)
   ed533:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   ed53d:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   ed548:	c7 83 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%rbx)
   ed552:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   ed559:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   ed562:	48 89 9b f0 00 00 00 	mov    %rbx,0xf0(%rbx)
   ed569:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
   ed56f:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   ed576:	48 c7 83 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rbx)
   ed581:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   ed588:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ed58d:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   ed594:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ed59b:	48 c7 83 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rbx)
   ed5a6:	48 89 9b 08 01 00 00 	mov    %rbx,0x108(%rbx)
   ed5ad:	48 c7 83 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rbx)
   ed5b8:	48 c7 83 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rbx)
   ed5c3:	48 89 9b 20 01 00 00 	mov    %rbx,0x120(%rbx)
   ed5ca:	48 c7 83 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rbx)
   ed5d5:	48 c7 83 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rbx)
   ed5e0:	48 89 9b 38 01 00 00 	mov    %rbx,0x138(%rbx)
   ed5e7:	48 c7 83 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rbx)
   ed5f2:	48 c7 83 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rbx)
   ed5fd:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   ed608:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   ed612:	c6 83 80 01 00 00 01 	movb   $0x1,0x180(%rbx)
   ed619:	89 83 b8 02 00 00    	mov    %eax,0x2b8(%rbx)
   ed61f:	0f 11 83 50 01 00 00 	movups %xmm0,0x150(%rbx)
   ed626:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   ed62f:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ed637:	e8 e4 00 01 00       	call   fd720 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ed63c:	4c 39 a3 c0 02 00 00 	cmp    %r12,0x2c0(%rbx)
   ed643:	0f 82 e7 04 00 00    	jb     edb30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc20>
   ed649:	4c 8b 93 78 02 00 00 	mov    0x278(%rbx),%r10
   ed650:	4c 8b 8b 70 02 00 00 	mov    0x270(%rbx),%r9
   ed657:	48 be b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rsi
   ed661:	4d 89 d3             	mov    %r10,%r11
   ed664:	4d 29 cb             	sub    %r9,%r11
   ed667:	4c 89 d8             	mov    %r11,%rax
   ed66a:	48 c1 f8 03          	sar    $0x3,%rax
   ed66e:	48 0f af c6          	imul   %rsi,%rax
   ed672:	4c 39 e0             	cmp    %r12,%rax
   ed675:	0f 82 35 04 00 00    	jb     edab0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   ed67b:	49 39 c4             	cmp    %rax,%r12
   ed67e:	0f 83 14 04 00 00    	jae    eda98 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb88>
   ed684:	49 6b c4 38          	imul   $0x38,%r12,%rax
   ed688:	4c 01 c8             	add    %r9,%rax
   ed68b:	49 39 c2             	cmp    %rax,%r10
   ed68e:	74 0a                	je     ed69a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   ed690:	48 89 83 78 02 00 00 	mov    %rax,0x278(%rbx)
   ed697:	49 89 c2             	mov    %rax,%r10
   ed69a:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   ed6a0:	74 4f                	je     ed6f1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7e1>
   ed6a2:	4c 89 c8             	mov    %r9,%rax
   ed6a5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed6a9:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   ed6ad:	31 d2                	xor    %edx,%edx
   ed6af:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ed6b5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ed6c0:	f3 0f 6f 4d 00       	movdqu 0x0(%rbp),%xmm1
   ed6c5:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   ed6c9:	48 83 c5 10          	add    $0x10,%rbp
   ed6cd:	48 83 c0 38          	add    $0x38,%rax
   ed6d1:	89 50 d8             	mov    %edx,-0x28(%rax)
   ed6d4:	48 83 c2 01          	add    $0x1,%rdx
   ed6d8:	0f 11 40 e8          	movups %xmm0,-0x18(%rax)
   ed6dc:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   ed6e4:	0f 11 48 c8          	movups %xmm1,-0x38(%rax)
   ed6e8:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
   ed6ec:	4c 39 e2             	cmp    %r12,%rdx
   ed6ef:	72 cf                	jb     ed6c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7b0>
   ed6f1:	48 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rcx
   ed6fb:	4c 89 d0             	mov    %r10,%rax
   ed6fe:	4c 29 c8             	sub    %r9,%rax
   ed701:	48 c1 f8 03          	sar    $0x3,%rax
   ed705:	48 0f af c1          	imul   %rcx,%rax
   ed709:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   ed715:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed719:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   ed721:	48 83 f8 02          	cmp    $0x2,%rax
   ed725:	0f 84 f5 02 00 00    	je     eda20 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb10>
   ed72b:	4d 39 ca             	cmp    %r9,%r10
   ed72e:	0f 84 54 04 00 00    	je     edb88 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc78>
   ed734:	48 39 43 38          	cmp    %rax,0x38(%rbx)
   ed738:	0f 82 d2 04 00 00    	jb     edc10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd00>
   ed73e:	48 83 ec 20          	sub    $0x20,%rsp
   ed742:	48 8d 8b 88 01 00 00 	lea    0x188(%rbx),%rcx
   ed749:	48 8d b3 70 02 00 00 	lea    0x270(%rbx),%rsi
   ed750:	48 8b 94 24 40 03 00 00 	mov    0x340(%rsp),%rdx
   ed758:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   ed75c:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   ed765:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   ed76a:	48 89 c2             	mov    %rax,%rdx
   ed76d:	0f 11 04 24          	movups %xmm0,(%rsp)
   ed771:	e8 7a 3c fe ff       	call   d13f0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   ed776:	48 83 c4 20          	add    $0x20,%rsp
   ed77a:	84 c0                	test   %al,%al
   ed77c:	0f 85 6b 07 00 00    	jne    edeed <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfdd>
   ed782:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   ed78b:	0f 84 e7 01 00 00    	je     ed978 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa68>
   ed791:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   ed796:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ed79e:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   ed7a6:	48 89 de             	mov    %rbx,%rsi
   ed7a9:	e8 e2 f0 ff ff       	call   ec890 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   ed7ae:	8b 74 24 1c          	mov    0x1c(%rsp),%esi
   ed7b2:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   ed7b9:	48 8b 8c 24 38 03 00 00 	mov    0x338(%rsp),%rcx
   ed7c1:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   ed7c7:	39 c6                	cmp    %eax,%esi
   ed7c9:	48 8b 94 24 c8 00 00 00 	mov    0xc8(%rsp),%rdx
   ed7d1:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   ed7da:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   ed7e3:	0f 43 c6             	cmovae %esi,%eax
   ed7e6:	48 01 0c 24          	add    %rcx,(%rsp)
   ed7ea:	48 8b b4 24 c0 00 00 00 	mov    0xc0(%rsp),%rsi
   ed7f2:	48 01 74 24 08       	add    %rsi,0x8(%rsp)
   ed7f7:	4c 01 ea             	add    %r13,%rdx
   ed7fa:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   ed7fe:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   ed802:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   ed80b:	41 89 47 38          	mov    %eax,0x38(%r15)
   ed80f:	48 8b 04 24          	mov    (%rsp),%rax
   ed813:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   ed817:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   ed81d:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   ed822:	49 89 47 40          	mov    %rax,0x40(%r15)
   ed826:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ed82b:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   ed830:	49 89 47 48          	mov    %rax,0x48(%r15)
   ed834:	48 89 d0             	mov    %rdx,%rax
   ed837:	48 c1 e8 1e          	shr    $0x1e,%rax
   ed83b:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   ed840:	48 31 d0             	xor    %rdx,%rax
   ed843:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   ed848:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   ed852:	48 0f af c2          	imul   %rdx,%rax
   ed856:	48 89 c2             	mov    %rax,%rdx
   ed859:	48 c1 ea 1b          	shr    $0x1b,%rdx
   ed85d:	48 31 d0             	xor    %rdx,%rax
   ed860:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   ed86a:	48 0f af c2          	imul   %rdx,%rax
   ed86e:	48 89 c2             	mov    %rax,%rdx
   ed871:	48 c1 ea 1f          	shr    $0x1f,%rdx
   ed875:	48 31 d0             	xor    %rdx,%rax
   ed878:	48 01 44 24 10       	add    %rax,0x10(%rsp)
   ed87d:	45 84 f6             	test   %r14b,%r14b
   ed880:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   ed885:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   ed88d:	49 89 4f 50          	mov    %rcx,0x50(%r15)
   ed891:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   ed89b:	44 0f 44 f0          	cmove  %eax,%r14d
   ed89f:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   ed8a7:	49 83 c5 01          	add    $0x1,%r13
   ed8ab:	48 8b 10             	mov    (%rax),%rdx
   ed8ae:	45 88 77 68          	mov    %r14b,0x68(%r15)
   ed8b2:	48 8b 40 08          	mov    0x8(%rax),%rax
   ed8b6:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   ed8bb:	48 29 d0             	sub    %rdx,%rax
   ed8be:	48 c1 f8 03          	sar    $0x3,%rax
   ed8c2:	48 0f af c1          	imul   %rcx,%rax
   ed8c6:	49 39 c5             	cmp    %rax,%r13
   ed8c9:	0f 82 71 f7 ff ff    	jb     ed040 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   ed8cf:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   ed8d7:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   ed8df:	80 3d 92 09 08 00 00 	cmpb   $0x0,0x80992(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ed8e6:	0f 84 dd 05 00 00    	je     edec9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfb9>
   ed8ec:	0f 31                	rdtsc
   ed8ee:	48 c1 e2 20          	shl    $0x20,%rdx
   ed8f2:	48 09 d0             	or     %rdx,%rax
   ed8f5:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   ed8fd:	0f 88 8e 05 00 00    	js     ede91 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf81>
   ed903:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed907:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ed90c:	f2 0f 59 05 1c 09 08 00 	mulsd  0x8091c(%rip),%xmm0        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ed914:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ed919:	49 89 07             	mov    %rax,(%r15)
   ed91c:	e8 7f 05 06 00       	call   14dea0 <_ZN5bench6memory11allocationsEv>
   ed921:	4c 29 f0             	sub    %r14,%rax
   ed924:	49 89 47 58          	mov    %rax,0x58(%r15)
   ed928:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   ed930:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   ed939:	0f 85 b6 05 00 00    	jne    edef5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfe5>
   ed93f:	4c 89 f8             	mov    %r15,%rax
   ed942:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   ed94a:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   ed952:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   ed95a:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   ed962:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   ed96a:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   ed971:	c3                   	ret
   ed972:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ed978:	80 3d f9 08 08 00 00 	cmpb   $0x0,0x808f9(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ed97f:	0f 84 93 04 00 00    	je     ede18 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf08>
   ed985:	0f 31                	rdtsc
   ed987:	48 c1 e2 20          	shl    $0x20,%rdx
   ed98b:	48 09 d0             	or     %rdx,%rax
   ed98e:	48 89 c5             	mov    %rax,%rbp
   ed991:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   ed996:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ed99e:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   ed9a6:	48 89 de             	mov    %rbx,%rsi
   ed9a9:	e8 e2 ee ff ff       	call   ec890 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   ed9ae:	f2 0f 10 0d 7a 08 08 00 	movsd  0x8087a(%rip),%xmm1        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ed9b6:	48 89 e8             	mov    %rbp,%rax
   ed9b9:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   ed9c1:	0f 88 19 04 00 00    	js     edde0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xed0>
   ed9c7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed9cb:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ed9d0:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   ed9d4:	80 3d 9d 08 08 00 00 	cmpb   $0x0,0x8089d(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ed9db:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ed9e0:	49 89 47 08          	mov    %rax,0x8(%r15)
   ed9e4:	0f 84 16 04 00 00    	je     ede00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef0>
   ed9ea:	0f 31                	rdtsc
   ed9ec:	48 c1 e2 20          	shl    $0x20,%rdx
   ed9f0:	48 09 d0             	or     %rdx,%rax
   ed9f3:	48 29 e8             	sub    %rbp,%rax
   ed9f6:	0f 88 bc 03 00 00    	js     eddb8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xea8>
   ed9fc:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eda00:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   eda05:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   eda09:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   eda0e:	49 89 47 10          	mov    %rax,0x10(%r15)
   eda12:	e9 97 fd ff ff       	jmp    ed7ae <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x89e>
   eda17:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   eda20:	83 bb d0 00 00 00 02 	cmpl   $0x2,0xd0(%rbx)
   eda27:	0f 85 fe fc ff ff    	jne    ed72b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x81b>
   eda2d:	80 7b 08 02          	cmpb   $0x2,0x8(%rbx)
   eda31:	0f 85 f4 fc ff ff    	jne    ed72b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x81b>
   eda37:	83 bb 64 01 00 00 ff 	cmpl   $0xffffffff,0x164(%rbx)
   eda3e:	0f 85 e7 fc ff ff    	jne    ed72b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x81b>
   eda44:	48 83 bb 88 00 00 00 00 	cmpq   $0x0,0x88(%rbx)
   eda4c:	0f 85 d9 fc ff ff    	jne    ed72b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x81b>
   eda52:	48 8b 43 58          	mov    0x58(%rbx),%rax
   eda56:	f3 41 0f 6f 01       	movdqu (%r9),%xmm0
   eda5b:	41 8b 51 10          	mov    0x10(%r9),%edx
   eda5f:	0f 11 00             	movups %xmm0,(%rax)
   eda62:	f3 41 0f 6f 41 38    	movdqu 0x38(%r9),%xmm0
   eda68:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   eda6c:	48 8b 43 60          	mov    0x60(%rbx),%rax
   eda70:	f3 41 0f 6f 41 18    	movdqu 0x18(%r9),%xmm0
   eda76:	89 10                	mov    %edx,(%rax)
   eda78:	41 8b 51 48          	mov    0x48(%r9),%edx
   eda7c:	89 50 04             	mov    %edx,0x4(%rax)
   eda7f:	48 8b 43 68          	mov    0x68(%rbx),%rax
   eda83:	0f 11 00             	movups %xmm0,(%rax)
   eda86:	f3 41 0f 6f 41 50    	movdqu 0x50(%r9),%xmm0
   eda8c:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   eda90:	e9 ed fc ff ff       	jmp    ed782 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x872>
   eda95:	0f 1f 00             	nopl   (%rax)
   eda98:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   eda9e:	0f 85 fe fb ff ff    	jne    ed6a2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x792>
   edaa4:	e9 60 fc ff ff       	jmp    ed709 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7f9>
   edaa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   edab0:	48 8b b3 80 02 00 00 	mov    0x280(%rbx),%rsi
   edab7:	4c 89 e2             	mov    %r12,%rdx
   edaba:	48 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rcx
   edac4:	48 29 c2             	sub    %rax,%rdx
   edac7:	48 89 f7             	mov    %rsi,%rdi
   edaca:	4c 29 d7             	sub    %r10,%rdi
   edacd:	48 c1 ff 03          	sar    $0x3,%rdi
   edad1:	48 0f af f9          	imul   %rcx,%rdi
   edad5:	48 39 d7             	cmp    %rdx,%rdi
   edad8:	0f 82 52 01 00 00    	jb     edc30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd20>
   edade:	48 89 d6             	mov    %rdx,%rsi
   edae1:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edae5:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   edae9:	4c 89 d0             	mov    %r10,%rax
   edaec:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   edaf5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edb00:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   edb04:	48 83 c0 38          	add    $0x38,%rax
   edb08:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   edb0c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   edb10:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   edb14:	48 83 ee 01          	sub    $0x1,%rsi
   edb18:	75 e6                	jne    edb00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbf0>
   edb1a:	48 6b d2 38          	imul   $0x38,%rdx,%rdx
   edb1e:	49 01 d2             	add    %rdx,%r10
   edb21:	4c 89 93 78 02 00 00 	mov    %r10,0x278(%rbx)
   edb28:	e9 6d fb ff ff       	jmp    ed69a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   edb2d:	0f 1f 00             	nopl   (%rax)
   edb30:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edb34:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   edb3c:	48 8d bb 88 01 00 00 	lea    0x188(%rbx),%rdi
   edb43:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   edb4b:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   edb53:	e8 a8 46 02 00       	call   112200 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   edb58:	84 c0                	test   %al,%al
   edb5a:	0f 85 8d 03 00 00    	jne    edeed <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfdd>
   edb60:	4c 89 a3 c0 02 00 00 	mov    %r12,0x2c0(%rbx)
   edb67:	e9 dd fa ff ff       	jmp    ed649 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x739>
   edb6c:	0f 1f 40 00          	nopl   0x0(%rax)
   edb70:	c6 83 80 01 00 00 00 	movb   $0x0,0x180(%rbx)
   edb77:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   edb7b:	e8 a0 fb 00 00       	call   fd720 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   edb80:	e9 b9 f8 ff ff       	jmp    ed43e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x52e>
   edb85:	0f 1f 00             	nopl   (%rax)
   edb88:	48 83 bb c8 00 00 00 00 	cmpq   $0x0,0xc8(%rbx)
   edb90:	74 55                	je     edbe7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcd7>
   edb92:	48 8b 93 80 00 00 00 	mov    0x80(%rbx),%rdx
   edb99:	48 85 d2             	test   %rdx,%rdx
   edb9c:	0f 85 83 02 00 00    	jne    ede25 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf15>
   edba2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   edba7:	66 0f 6f 05 d1 9c 06 00 	movdqa 0x69cd1(%rip),%xmm0        # 157880 <C.66.5+0x260>
   edbaf:	c7 83 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%rbx)
   edbb9:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   edbc4:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   edbcb:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   edbd6:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   edbe0:	0f 11 83 dc 00 00 00 	movups %xmm0,0xdc(%rbx)
   edbe7:	80 7b 08 00          	cmpb   $0x0,0x8(%rbx)
   edbeb:	0f 84 91 fb ff ff    	je     ed782 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x872>
   edbf1:	80 bb 60 01 00 00 00 	cmpb   $0x0,0x160(%rbx)
   edbf8:	0f 84 84 fb ff ff    	je     ed782 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x872>
   edbfe:	c6 83 60 01 00 00 00 	movb   $0x0,0x160(%rbx)
   edc05:	e9 78 fb ff ff       	jmp    ed782 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x872>
   edc0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   edc10:	ba 10 00 00 00       	mov    $0x10,%edx
   edc15:	48 8b 3d 44 06 08 00 	mov    0x80644(%rip),%rdi        # 16e260 <stderr@GLIBC_2.2.5>
   edc1c:	48 8d 35 7d 7d 06 00 	lea    0x67d7d(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   edc23:	31 c0                	xor    %eax,%eax
   edc25:	e8 16 97 f1 ff       	call   7340 <fprintf@plt>
   edc2a:	e8 f1 94 f1 ff       	call   7120 <abort@plt>
   edc2f:	90                   	nop
   edc30:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   edc3a:	48 29 c7             	sub    %rax,%rdi
   edc3d:	48 39 d7             	cmp    %rdx,%rdi
   edc40:	0f 82 0c f1 f1 ff    	jb     cd52 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   edc46:	48 39 d0             	cmp    %rdx,%rax
   edc49:	48 89 d1             	mov    %rdx,%rcx
   edc4c:	4c 89 8c 24 b0 00 00 00 	mov    %r9,0xb0(%rsp)
   edc54:	48 0f 43 c8          	cmovae %rax,%rcx
   edc58:	4c 89 94 24 a8 00 00 00 	mov    %r10,0xa8(%rsp)
   edc60:	48 89 b4 24 a0 00 00 00 	mov    %rsi,0xa0(%rsp)
   edc68:	48 01 c1             	add    %rax,%rcx
   edc6b:	4c 89 5c 24 60       	mov    %r11,0x60(%rsp)
   edc70:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   edc7a:	48 39 c1             	cmp    %rax,%rcx
   edc7d:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   edc82:	48 0f 47 c8          	cmova  %rax,%rcx
   edc86:	48 6b c1 38          	imul   $0x38,%rcx,%rax
   edc8a:	48 89 c7             	mov    %rax,%rdi
   edc8d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   edc92:	e8 e9 02 06 00       	call   14df80 <_Znwm>
   edc97:	48 6b 54 24 50 38    	imul   $0x38,0x50(%rsp),%rdx
   edc9d:	4c 8b 5c 24 60       	mov    0x60(%rsp),%r11
   edca2:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edca6:	48 8b b4 24 a0 00 00 00 	mov    0xa0(%rsp),%rsi
   edcae:	4c 8b 94 24 a8 00 00 00 	mov    0xa8(%rsp),%r10
   edcb6:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   edcba:	49 01 c3             	add    %rax,%r11
   edcbd:	4c 8b 8c 24 b0 00 00 00 	mov    0xb0(%rsp),%r9
   edcc5:	4c 01 da             	add    %r11,%rdx
   edcc8:	66 90                	xchg   %ax,%ax
   edcca:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edcd5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edce0:	41 0f 11 43 10       	movups %xmm0,0x10(%r11)
   edce5:	49 83 c3 38          	add    $0x38,%r11
   edce9:	41 0f 11 43 c8       	movups %xmm0,-0x38(%r11)
   edcee:	41 0f 11 4b e0       	movups %xmm1,-0x20(%r11)
   edcf3:	41 0f 11 43 f0       	movups %xmm0,-0x10(%r11)
   edcf8:	49 39 d3             	cmp    %rdx,%r11
   edcfb:	75 e3                	jne    edce0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdd0>
   edcfd:	4d 39 ca             	cmp    %r9,%r10
   edd00:	74 6d                	je     edd6f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe5f>
   edd02:	4c 89 ca             	mov    %r9,%rdx
   edd05:	48 89 c7             	mov    %rax,%rdi
   edd08:	90                   	nop
   edd09:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edd14:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edd1f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edd2a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edd35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edd40:	f3 0f 6f 02          	movdqu (%rdx),%xmm0
   edd44:	48 8b 4a 30          	mov    0x30(%rdx),%rcx
   edd48:	48 83 c2 38          	add    $0x38,%rdx
   edd4c:	48 83 c7 38          	add    $0x38,%rdi
   edd50:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   edd54:	f3 0f 6f 42 d8       	movdqu -0x28(%rdx),%xmm0
   edd59:	48 89 4f f8          	mov    %rcx,-0x8(%rdi)
   edd5d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   edd61:	f3 0f 6f 42 e8       	movdqu -0x18(%rdx),%xmm0
   edd66:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   edd6a:	49 39 d2             	cmp    %rdx,%r10
   edd6d:	75 d1                	jne    edd40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe30>
   edd6f:	4d 85 c9             	test   %r9,%r9
   edd72:	74 15                	je     edd89 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe79>
   edd74:	4c 29 ce             	sub    %r9,%rsi
   edd77:	4c 89 cf             	mov    %r9,%rdi
   edd7a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   edd7f:	e8 fc 02 06 00       	call   14e080 <_ZdlPvm>
   edd84:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   edd89:	4d 6b d4 38          	imul   $0x38,%r12,%r10
   edd8d:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   edd92:	48 89 83 70 02 00 00 	mov    %rax,0x270(%rbx)
   edd99:	49 89 c1             	mov    %rax,%r9
   edd9c:	48 01 c2             	add    %rax,%rdx
   edd9f:	49 01 c2             	add    %rax,%r10
   edda2:	48 89 93 80 02 00 00 	mov    %rdx,0x280(%rbx)
   edda9:	4c 89 93 78 02 00 00 	mov    %r10,0x278(%rbx)
   eddb0:	e9 e5 f8 ff ff       	jmp    ed69a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   eddb5:	0f 1f 00             	nopl   (%rax)
   eddb8:	48 89 c2             	mov    %rax,%rdx
   eddbb:	83 e0 01             	and    $0x1,%eax
   eddbe:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eddc2:	48 d1 ea             	shr    $1,%rdx
   eddc5:	48 09 c2             	or     %rax,%rdx
   eddc8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   eddcd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   eddd1:	e9 2f fc ff ff       	jmp    eda05 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf5>
   eddd6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   edde0:	48 89 c2             	mov    %rax,%rdx
   edde3:	83 e0 01             	and    $0x1,%eax
   edde6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eddea:	48 d1 ea             	shr    $1,%rdx
   edded:	48 09 c2             	or     %rax,%rdx
   eddf0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   eddf5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   eddf9:	e9 d2 fb ff ff       	jmp    ed9d0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xac0>
   eddfe:	66 90                	xchg   %ax,%ax
   ede00:	e8 cb 94 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   ede05:	f2 0f 10 0d 23 04 08 00 	movsd  0x80423(%rip),%xmm1        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ede0d:	e9 e1 fb ff ff       	jmp    ed9f3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xae3>
   ede12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ede18:	e8 b3 94 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   ede1d:	48 89 c5             	mov    %rax,%rbp
   ede20:	e9 6c fb ff ff       	jmp    ed991 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa81>
   ede25:	48 c7 83 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%rbx)
   ede30:	80 bb 94 00 00 00 00 	cmpb   $0x0,0x94(%rbx)
   ede37:	0f 85 96 00 00 00    	jne    eded3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfc3>
   ede3d:	8b 83 90 00 00 00    	mov    0x90(%rbx),%eax
   ede43:	83 c0 01             	add    $0x1,%eax
   ede46:	89 83 90 00 00 00    	mov    %eax,0x90(%rbx)
   ede4c:	83 f8 ff             	cmp    $0xffffffff,%eax
   ede4f:	0f 85 4d fd ff ff    	jne    edba2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   ede55:	48 8b 43 78          	mov    0x78(%rbx),%rax
   ede59:	48 89 d1             	mov    %rdx,%rcx
   ede5c:	48 c1 e1 04          	shl    $0x4,%rcx
   ede60:	48 01 c1             	add    %rax,%rcx
   ede63:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   ede6a:	48 83 c0 10          	add    $0x10,%rax
   ede6e:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   ede76:	48 39 c8             	cmp    %rcx,%rax
   ede79:	75 e8                	jne    ede63 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf53>
   ede7b:	48 01 93 b0 00 00 00 	add    %rdx,0xb0(%rbx)
   ede82:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   ede8c:	e9 11 fd ff ff       	jmp    edba2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   ede91:	48 89 c2             	mov    %rax,%rdx
   ede94:	83 e0 01             	and    $0x1,%eax
   ede97:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ede9b:	48 d1 ea             	shr    $1,%rdx
   ede9e:	48 09 c2             	or     %rax,%rdx
   edea1:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   edea6:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   edeaa:	e9 5d fa ff ff       	jmp    ed90c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9fc>
   edeaf:	4c 89 1c 24          	mov    %r11,(%rsp)
   edeb3:	e8 e8 31 f2 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   edeb8:	4c 8b 1c 24          	mov    (%rsp),%r11
   edebc:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   edec4:	e9 f6 f0 ff ff       	jmp    ecfbf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf>
   edec9:	e8 d2 31 f2 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   edece:	e9 22 fa ff ff       	jmp    ed8f5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9e5>
   eded3:	48 c7 83 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rbx)
   edede:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   edee8:	e9 b5 fc ff ff       	jmp    edba2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   edeed:	0f b6 d0             	movzbl %al,%edx
   edef0:	e9 20 fd ff ff       	jmp    edc15 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd05>
   edef5:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   edefd:	e8 5e 93 f1 ff       	call   7260 <__stack_chk_fail@plt>

# candidate ordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, true>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-two-copy-headroom.qUEHc7/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f0c00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f0c00:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f0c07:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f0c0b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f0c13:	48 8b 2a             	mov    (%rdx),%rbp
   f0c16:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f0c1e:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f0c22:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f0c2a:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f0c32:	49 89 ff             	mov    %rdi,%r15
   f0c35:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f0c3d:	89 8c 24 98 00 00 00 	mov    %ecx,0x98(%rsp)
   f0c44:	4c 89 84 24 80 00 00 00 	mov    %r8,0x80(%rsp)
   f0c4c:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f0c55:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f0c5d:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f0c61:	0f 11 07             	movups %xmm0,(%rdi)
   f0c64:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f0c68:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f0c6c:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f0c70:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f0c74:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f0c78:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f0c7c:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f0c80:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   f0c85:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f0c89:	e8 12 d2 05 00       	call   14dea0 <_ZN5bench6memory11allocationsEv>
   f0c8e:	80 3d e3 d5 07 00 00 	cmpb   $0x0,0x7d5e3(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f0c95:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f0c9a:	49 89 c6             	mov    %rax,%r14
   f0c9d:	0f 84 40 0f 00 00    	je     f1be3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfe3>
   f0ca3:	0f 31                	rdtsc
   f0ca5:	48 c1 e2 20          	shl    $0x20,%rdx
   f0ca9:	48 09 d0             	or     %rdx,%rax
   f0cac:	48 89 84 24 a0 00 00 00 	mov    %rax,0xa0(%rsp)
   f0cb4:	49 8b 11             	mov    (%r9),%rdx
   f0cb7:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   f0cbb:	0f 84 5e 09 00 00    	je     f161f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa1f>
   f0cc1:	49 29 ec             	sub    %rbp,%r12
   f0cc4:	c6 44 24 47 00       	movb   $0x0,0x47(%rsp)
   f0cc9:	83 bc 24 98 00 00 00 01 	cmpl   $0x1,0x98(%rsp)
   f0cd1:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f0cd5:	4c 89 a4 24 88 00 00 00 	mov    %r12,0x88(%rsp)
   f0cdd:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   f0ce6:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f0cef:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f0cf8:	c7 44 24 40 00 00 00 00 	movl   $0x0,0x40(%rsp)
   f0d00:	4c 89 8c 24 90 00 00 00 	mov    %r9,0x90(%rsp)
   f0d08:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f0d10:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   f0d18:	49 89 de             	mov    %rbx,%r14
   f0d1b:	0f 94 84 24 9f 00 00 00 	sete   0x9f(%rsp)
   f0d23:	45 31 ed             	xor    %r13d,%r13d
   f0d26:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f0d2b:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f0d30:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   f0d35:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f0d39:	48 8b 28             	mov    (%rax),%rbp
   f0d3c:	4c 8b 60 08          	mov    0x8(%rax),%r12
   f0d40:	49 29 ec             	sub    %rbp,%r12
   f0d43:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
   f0d48:	49 c1 fc 04          	sar    $0x4,%r12
   f0d4c:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f0d54:	74 14                	je     f0d6a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x16a>
   f0d56:	8b 84 24 98 00 00 00 	mov    0x98(%rsp),%eax
   f0d5d:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   f0d64:	0f 84 cb 05 00 00    	je     f1335 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x735>
   f0d6a:	0f b6 84 24 9f 00 00 00 	movzbl 0x9f(%rsp),%eax
   f0d72:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f0d76:	31 f6                	xor    %esi,%esi
   f0d78:	66 0f 6f 3d 40 6b 06 00 	movdqa 0x66b40(%rip),%xmm7        # 1578c0 <C.66.5+0x2a0>
   f0d80:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f0d88:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f0d90:	ba 88 01 00 00       	mov    $0x188,%edx
   f0d95:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f0d9c:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f0da1:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f0da9:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f0db1:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f0db6:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f0dbe:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f0dc2:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f0dcb:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f0dd3:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f0ddc:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f0de4:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f0ded:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f0df5:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f0dfd:	0f 29 64 24 70       	movaps %xmm4,0x70(%rsp)
   f0e02:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f0e0a:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
   f0e0f:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f0e17:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
   f0e1c:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f0e24:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f0e30:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f0e3c:	e8 cf 62 f1 ff       	call   7110 <memset@plt>
   f0e41:	66 0f 6f 64 24 70    	movdqa 0x70(%rsp),%xmm4
   f0e47:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f0e4b:	66 0f 6f 05 7d 6a 06 00 	movdqa 0x66a7d(%rip),%xmm0        # 1578d0 <C.66.5+0x2b0>
   f0e53:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
   f0e59:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
   f0e5f:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f0e63:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f0e6a:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f0e72:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f0e77:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f0e7f:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f0e87:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f0e8f:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f0e9b:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   f0ea3:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f0eaf:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f0ebb:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f0ec7:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f0ed3:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f0edf:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f0eea:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f0ef2:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f0efd:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f0f09:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f0f11:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f0f1d:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f0f28:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f0f30:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   f0f38:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f0f44:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f0f50:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   f0f58:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f0f64:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f0f6c:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f0f74:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f0f7c:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f0f84:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f0f8c:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f0f98:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f0fa0:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f0fa9:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f0fb1:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f0fb9:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f0fc2:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f0fca:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f0fd2:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f0fdb:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f0fe3:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f0fea:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f0ff2:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   f0ffa:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f1006:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f1012:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   f101a:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f1026:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f1032:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f103e:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f1049:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f1055:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   f105d:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f1068:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f1073:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f107f:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f1087:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   f108f:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   f1097:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   f109f:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   f10a7:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f10af:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f10b7:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f10bf:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f10c7:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f10cf:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f10d6:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f10df:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f10ea:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f10f1:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f10f8:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f1103:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f110a:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f1112:	e8 09 c6 00 00       	call   fd720 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1117:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f111f:	0f 85 b3 07 00 00    	jne    f18d8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcd8>
   f1125:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f112e:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f1136:	4d 89 76 50          	mov    %r14,0x50(%r14)
   f113a:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f1142:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f114b:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   f1153:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   f1158:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f1161:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f1169:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   f116e:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f1177:	49 89 46 48          	mov    %rax,0x48(%r14)
   f117b:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1182:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   f1187:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f1190:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   f1197:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f119c:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   f11a1:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f11a5:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   f11ad:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f11b6:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   f11bd:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   f11c5:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f11cd:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f11d6:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   f11de:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   f11e6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f11ea:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   f11f2:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   f11fa:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   f1202:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   f120a:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   f1212:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f121d:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   f1225:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f1230:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f123b:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   f1246:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f124d:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f1256:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   f125d:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   f1264:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f126b:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   f1276:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f127d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1282:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f1289:	8b 84 24 98 00 00 00 	mov    0x98(%rsp),%eax
   f1290:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   f129b:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   f12a2:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   f12ad:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   f12b8:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   f12bf:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   f12ca:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   f12d5:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   f12dc:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   f12e7:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   f12f2:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f12fd:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f1308:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   f1310:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   f1317:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   f131f:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f1328:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f1330:	e8 eb c3 00 00       	call   fd720 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1335:	4d 39 a6 c0 02 00 00 	cmp    %r12,0x2c0(%r14)
   f133c:	0f 82 4e 05 00 00    	jb     f1890 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc90>
   f1342:	4d 8b 96 78 02 00 00 	mov    0x278(%r14),%r10
   f1349:	4d 8b 8e 70 02 00 00 	mov    0x270(%r14),%r9
   f1350:	48 bb b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rbx
   f135a:	4d 89 d3             	mov    %r10,%r11
   f135d:	4d 29 cb             	sub    %r9,%r11
   f1360:	4c 89 d8             	mov    %r11,%rax
   f1363:	48 c1 f8 03          	sar    $0x3,%rax
   f1367:	48 0f af c3          	imul   %rbx,%rax
   f136b:	4c 39 e0             	cmp    %r12,%rax
   f136e:	0f 82 a4 04 00 00    	jb     f1818 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc18>
   f1374:	49 39 c4             	cmp    %rax,%r12
   f1377:	0f 83 83 04 00 00    	jae    f1800 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc00>
   f137d:	49 6b c4 38          	imul   $0x38,%r12,%rax
   f1381:	4c 01 c8             	add    %r9,%rax
   f1384:	49 39 c2             	cmp    %rax,%r10
   f1387:	74 0a                	je     f1393 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x793>
   f1389:	49 89 86 78 02 00 00 	mov    %rax,0x278(%r14)
   f1390:	49 89 c2             	mov    %rax,%r10
   f1393:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
   f1399:	74 7c                	je     f1417 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x817>
   f139b:	4c 89 ca             	mov    %r9,%rdx
   f139e:	31 f6                	xor    %esi,%esi
   f13a0:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f13a4:	49 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%r11
   f13ae:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   f13b8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f13c0:	89 f1                	mov    %esi,%ecx
   f13c2:	f3 0f 6f 45 00       	movdqu 0x0(%rbp),%xmm0
   f13c7:	89 72 10             	mov    %esi,0x10(%rdx)
   f13ca:	48 83 c6 01          	add    $0x1,%rsi
   f13ce:	81 f1 6b 6e 61 72    	xor    $0x72616e6b,%ecx
   f13d4:	c6 42 30 01          	movb   $0x1,0x30(%rdx)
   f13d8:	48 83 c5 10          	add    $0x10,%rbp
   f13dc:	48 83 c2 38          	add    $0x38,%rdx
   f13e0:	48 89 c8             	mov    %rcx,%rax
   f13e3:	0f 11 42 c8          	movups %xmm0,-0x38(%rdx)
   f13e7:	48 c1 e8 1e          	shr    $0x1e,%rax
   f13eb:	0f 11 4a e0          	movups %xmm1,-0x20(%rdx)
   f13ef:	48 31 c8             	xor    %rcx,%rax
   f13f2:	49 0f af c3          	imul   %r11,%rax
   f13f6:	48 89 c1             	mov    %rax,%rcx
   f13f9:	48 c1 e9 1b          	shr    $0x1b,%rcx
   f13fd:	48 31 c8             	xor    %rcx,%rax
   f1400:	48 0f af c7          	imul   %rdi,%rax
   f1404:	48 89 c1             	mov    %rax,%rcx
   f1407:	48 c1 e9 1f          	shr    $0x1f,%rcx
   f140b:	48 31 c8             	xor    %rcx,%rax
   f140e:	48 89 42 f0          	mov    %rax,-0x10(%rdx)
   f1412:	4c 39 e6             	cmp    %r12,%rsi
   f1415:	72 a9                	jb     f13c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f1417:	48 bb b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rbx
   f1421:	4c 89 d0             	mov    %r10,%rax
   f1424:	4c 29 c8             	sub    %r9,%rax
   f1427:	48 c1 f8 03          	sar    $0x3,%rax
   f142b:	48 0f af c3          	imul   %rbx,%rax
   f142f:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f143b:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f143f:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f1447:	48 83 f8 02          	cmp    $0x2,%rax
   f144b:	0f 84 2f 03 00 00    	je     f1780 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb80>
   f1451:	4d 39 ca             	cmp    %r9,%r10
   f1454:	0f 84 96 04 00 00    	je     f18f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcf0>
   f145a:	49 39 46 38          	cmp    %rax,0x38(%r14)
   f145e:	0f 82 1c 05 00 00    	jb     f1980 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f1464:	48 83 ec 20          	sub    $0x20,%rsp
   f1468:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   f146f:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   f1476:	48 8b 94 24 40 03 00 00 	mov    0x340(%rsp),%rdx
   f147e:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f1482:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f148b:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   f1490:	48 89 c2             	mov    %rax,%rdx
   f1493:	0f 11 04 24          	movups %xmm0,(%rsp)
   f1497:	e8 54 ff fd ff       	call   d13f0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f149c:	48 83 c4 20          	add    $0x20,%rsp
   f14a0:	84 c0                	test   %al,%al
   f14a2:	0f 85 7c 07 00 00    	jne    f1c24 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x1024>
   f14a8:	48 83 bc 24 88 00 00 00 18 	cmpq   $0x18,0x88(%rsp)
   f14b1:	0f 84 01 02 00 00    	je     f16b8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab8>
   f14b7:	48 8b 8c 24 80 00 00 00 	mov    0x80(%rsp),%rcx
   f14bf:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f14c3:	4c 89 f6             	mov    %r14,%rsi
   f14c6:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f14ce:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f14d6:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f14de:	e8 fd ec ff ff       	call   f01e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f14e3:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f14eb:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f14f3:	8b 7c 24 40          	mov    0x40(%rsp),%edi
   f14f7:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f14fe:	49 8d 54 1d 00       	lea    0x0(%r13,%rbx,1),%rdx
   f1503:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f150d:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f1516:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f151c:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f1525:	39 c7                	cmp    %eax,%edi
   f1527:	0f 43 c7             	cmovae %edi,%eax
   f152a:	48 8b bc 24 38 03 00 00 	mov    0x338(%rsp),%rdi
   f1532:	48 01 7c 24 08       	add    %rdi,0x8(%rsp)
   f1537:	4c 01 64 24 10       	add    %r12,0x10(%rsp)
   f153c:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f1540:	89 44 24 40          	mov    %eax,0x40(%rsp)
   f1544:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f1548:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f1551:	41 89 47 38          	mov    %eax,0x38(%r15)
   f1555:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f155a:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f1560:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f1565:	49 89 47 40          	mov    %rax,0x40(%r15)
   f1569:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f156e:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f1573:	49 89 47 48          	mov    %rax,0x48(%r15)
   f1577:	48 89 d0             	mov    %rdx,%rax
   f157a:	48 c1 e8 1e          	shr    $0x1e,%rax
   f157e:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f1583:	48 31 d0             	xor    %rdx,%rax
   f1586:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f158b:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f1595:	48 0f af c2          	imul   %rdx,%rax
   f1599:	48 89 c2             	mov    %rax,%rdx
   f159c:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f15a0:	48 31 d0             	xor    %rdx,%rax
   f15a3:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f15ad:	48 0f af c2          	imul   %rdx,%rax
   f15b1:	48 89 c2             	mov    %rax,%rdx
   f15b4:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f15b8:	48 31 d0             	xor    %rdx,%rax
   f15bb:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   f15c0:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   f15c5:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f15cd:	49 89 5f 50          	mov    %rbx,0x50(%r15)
   f15d1:	0f b6 5c 24 47       	movzbl 0x47(%rsp),%ebx
   f15d6:	84 db                	test   %bl,%bl
   f15d8:	0f 44 d8             	cmove  %eax,%ebx
   f15db:	48 8b 84 24 90 00 00 00 	mov    0x90(%rsp),%rax
   f15e3:	49 83 c5 01          	add    $0x1,%r13
   f15e7:	48 8b 10             	mov    (%rax),%rdx
   f15ea:	88 5c 24 47          	mov    %bl,0x47(%rsp)
   f15ee:	41 88 5f 68          	mov    %bl,0x68(%r15)
   f15f2:	48 8b 40 08          	mov    0x8(%rax),%rax
   f15f6:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   f15fb:	48 29 d0             	sub    %rdx,%rax
   f15fe:	48 c1 f8 03          	sar    $0x3,%rax
   f1602:	48 0f af c1          	imul   %rcx,%rax
   f1606:	49 39 c5             	cmp    %rax,%r13
   f1609:	0f 82 21 f7 ff ff    	jb     f0d30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f160f:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   f1617:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f161f:	80 3d 52 cc 07 00 00 	cmpb   $0x0,0x7cc52(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1626:	0f 84 d3 05 00 00    	je     f1bff <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfff>
   f162c:	0f 31                	rdtsc
   f162e:	48 c1 e2 20          	shl    $0x20,%rdx
   f1632:	48 09 d0             	or     %rdx,%rax
   f1635:	48 2b 84 24 a0 00 00 00 	sub    0xa0(%rsp),%rax
   f163d:	0f 88 82 05 00 00    	js     f1bc5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfc5>
   f1643:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1647:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f164c:	f2 0f 59 05 dc cb 07 00 	mulsd  0x7cbdc(%rip),%xmm0        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1654:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1659:	49 89 07             	mov    %rax,(%r15)
   f165c:	e8 3f c8 05 00       	call   14dea0 <_ZN5bench6memory11allocationsEv>
   f1661:	4c 29 f0             	sub    %r14,%rax
   f1664:	49 89 47 58          	mov    %rax,0x58(%r15)
   f1668:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f1670:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f1679:	0f 85 ad 05 00 00    	jne    f1c2c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x102c>
   f167f:	4c 89 f8             	mov    %r15,%rax
   f1682:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f168a:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f1692:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f169a:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f16a2:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f16aa:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f16b1:	c3                   	ret
   f16b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f16b8:	80 3d b9 cb 07 00 00 	cmpb   $0x0,0x7cbb9(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f16bf:	0f 84 83 04 00 00    	je     f1b48 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf48>
   f16c5:	0f 31                	rdtsc
   f16c7:	48 c1 e2 20          	shl    $0x20,%rdx
   f16cb:	48 09 d0             	or     %rdx,%rax
   f16ce:	48 89 c5             	mov    %rax,%rbp
   f16d1:	48 8b 8c 24 80 00 00 00 	mov    0x80(%rsp),%rcx
   f16d9:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f16dd:	4c 89 f6             	mov    %r14,%rsi
   f16e0:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f16e8:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f16f0:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f16f8:	e8 e3 ea ff ff       	call   f01e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f16fd:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f1705:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f170d:	48 89 e8             	mov    %rbp,%rax
   f1710:	f2 0f 10 0d 18 cb 07 00 	movsd  0x7cb18(%rip),%xmm1        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1718:	48 2b 84 24 a0 00 00 00 	sub    0xa0(%rsp),%rax
   f1720:	0f 88 ea 03 00 00    	js     f1b10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf10>
   f1726:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f172a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f172f:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1733:	80 3d 3e cb 07 00 00 	cmpb   $0x0,0x7cb3e(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f173a:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f173f:	49 89 47 08          	mov    %rax,0x8(%r15)
   f1743:	0f 84 e7 03 00 00    	je     f1b30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf30>
   f1749:	0f 31                	rdtsc
   f174b:	48 c1 e2 20          	shl    $0x20,%rdx
   f174f:	48 09 d0             	or     %rdx,%rax
   f1752:	48 29 e8             	sub    %rbp,%rax
   f1755:	0f 88 95 03 00 00    	js     f1af0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef0>
   f175b:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f175f:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1764:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1768:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f176d:	49 89 47 10          	mov    %rax,0x10(%r15)
   f1771:	e9 7d fd ff ff       	jmp    f14f3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8f3>
   f1776:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f1780:	41 83 be d0 00 00 00 02 	cmpl   $0x2,0xd0(%r14)
   f1788:	0f 85 c3 fc ff ff    	jne    f1451 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x851>
   f178e:	41 80 7e 08 02       	cmpb   $0x2,0x8(%r14)
   f1793:	0f 85 b8 fc ff ff    	jne    f1451 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x851>
   f1799:	41 83 be 64 01 00 00 ff 	cmpl   $0xffffffff,0x164(%r14)
   f17a1:	0f 85 aa fc ff ff    	jne    f1451 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x851>
   f17a7:	49 83 be 88 00 00 00 00 	cmpq   $0x0,0x88(%r14)
   f17af:	0f 85 9c fc ff ff    	jne    f1451 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x851>
   f17b5:	49 8b 46 58          	mov    0x58(%r14),%rax
   f17b9:	f3 41 0f 6f 01       	movdqu (%r9),%xmm0
   f17be:	41 8b 51 10          	mov    0x10(%r9),%edx
   f17c2:	0f 11 00             	movups %xmm0,(%rax)
   f17c5:	f3 41 0f 6f 41 38    	movdqu 0x38(%r9),%xmm0
   f17cb:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f17cf:	49 8b 46 60          	mov    0x60(%r14),%rax
   f17d3:	f3 41 0f 6f 41 18    	movdqu 0x18(%r9),%xmm0
   f17d9:	89 10                	mov    %edx,(%rax)
   f17db:	41 8b 51 48          	mov    0x48(%r9),%edx
   f17df:	89 50 04             	mov    %edx,0x4(%rax)
   f17e2:	49 8b 46 68          	mov    0x68(%r14),%rax
   f17e6:	0f 11 00             	movups %xmm0,(%rax)
   f17e9:	f3 41 0f 6f 41 50    	movdqu 0x50(%r9),%xmm0
   f17ef:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   f17f3:	e9 b0 fc ff ff       	jmp    f14a8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8a8>
   f17f8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1800:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
   f1806:	0f 85 8f fb ff ff    	jne    f139b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x79b>
   f180c:	e9 1e fc ff ff       	jmp    f142f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x82f>
   f1811:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f1818:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   f181f:	4c 89 e2             	mov    %r12,%rdx
   f1822:	48 29 c2             	sub    %rax,%rdx
   f1825:	48 89 f7             	mov    %rsi,%rdi
   f1828:	4c 29 d7             	sub    %r10,%rdi
   f182b:	48 c1 ff 03          	sar    $0x3,%rdi
   f182f:	48 0f af fb          	imul   %rbx,%rdi
   f1833:	48 39 d7             	cmp    %rdx,%rdi
   f1836:	0f 82 64 01 00 00    	jb     f19a0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xda0>
   f183c:	48 89 d6             	mov    %rdx,%rsi
   f183f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1843:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1847:	4c 89 d0             	mov    %r10,%rax
   f184a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1855:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1860:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f1864:	48 83 c0 38          	add    $0x38,%rax
   f1868:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f186c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f1870:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f1874:	48 83 ee 01          	sub    $0x1,%rsi
   f1878:	75 e6                	jne    f1860 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc60>
   f187a:	48 6b d2 38          	imul   $0x38,%rdx,%rdx
   f187e:	49 01 d2             	add    %rdx,%r10
   f1881:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f1888:	e9 06 fb ff ff       	jmp    f1393 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x793>
   f188d:	0f 1f 00             	nopl   (%rax)
   f1890:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f1898:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   f189f:	4c 89 a4 24 10 03 00 00 	mov    %r12,0x310(%rsp)
   f18a7:	48 c7 84 24 18 03 00 00 00 00 00 00 	movq   $0x0,0x318(%rsp)
   f18b3:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   f18bb:	e8 40 09 02 00       	call   112200 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f18c0:	84 c0                	test   %al,%al
   f18c2:	0f 85 5c 03 00 00    	jne    f1c24 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x1024>
   f18c8:	4d 89 a6 c0 02 00 00 	mov    %r12,0x2c0(%r14)
   f18cf:	e9 6e fa ff ff       	jmp    f1342 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x742>
   f18d4:	0f 1f 40 00          	nopl   0x0(%rax)
   f18d8:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   f18e0:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f18e4:	e8 37 be 00 00       	call   fd720 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f18e9:	e9 37 f8 ff ff       	jmp    f1125 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x525>
   f18ee:	66 90                	xchg   %ax,%ax
   f18f0:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   f18f8:	74 58                	je     f1952 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd52>
   f18fa:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   f1901:	48 85 d2             	test   %rdx,%rdx
   f1904:	0f 85 4b 02 00 00    	jne    f1b55 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf55>
   f190a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f190f:	66 0f 6f 05 69 5f 06 00 	movdqa 0x65f69(%rip),%xmm0        # 157880 <C.66.5+0x260>
   f1917:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   f1922:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f192d:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f1934:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f193f:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f194a:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   f1952:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f1957:	0f 84 4b fb ff ff    	je     f14a8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8a8>
   f195d:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   f1965:	0f 84 3d fb ff ff    	je     f14a8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8a8>
   f196b:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   f1973:	e9 30 fb ff ff       	jmp    f14a8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8a8>
   f1978:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1980:	ba 10 00 00 00       	mov    $0x10,%edx
   f1985:	48 8b 3d d4 c8 07 00 	mov    0x7c8d4(%rip),%rdi        # 16e260 <stderr@GLIBC_2.2.5>
   f198c:	48 8d 35 0d 40 06 00 	lea    0x6400d(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   f1993:	31 c0                	xor    %eax,%eax
   f1995:	e8 a6 59 f1 ff       	call   7340 <fprintf@plt>
   f199a:	e8 81 57 f1 ff       	call   7120 <abort@plt>
   f199f:	90                   	nop
   f19a0:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f19aa:	48 29 c7             	sub    %rax,%rdi
   f19ad:	48 39 d7             	cmp    %rdx,%rdi
   f19b0:	0f 82 88 b4 f1 ff    	jb     ce3e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f19b6:	48 39 d0             	cmp    %rdx,%rax
   f19b9:	48 89 d3             	mov    %rdx,%rbx
   f19bc:	4c 89 8c 24 b0 00 00 00 	mov    %r9,0xb0(%rsp)
   f19c4:	48 0f 43 d8          	cmovae %rax,%rbx
   f19c8:	4c 89 94 24 a8 00 00 00 	mov    %r10,0xa8(%rsp)
   f19d0:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
   f19d5:	48 01 c3             	add    %rax,%rbx
   f19d8:	4c 89 5c 24 60       	mov    %r11,0x60(%rsp)
   f19dd:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f19e7:	48 39 c3             	cmp    %rax,%rbx
   f19ea:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   f19ef:	48 0f 47 d8          	cmova  %rax,%rbx
   f19f3:	48 6b db 38          	imul   $0x38,%rbx,%rbx
   f19f7:	48 89 df             	mov    %rbx,%rdi
   f19fa:	e8 81 c5 05 00       	call   14df80 <_Znwm>
   f19ff:	48 6b 54 24 50 38    	imul   $0x38,0x50(%rsp),%rdx
   f1a05:	4c 8b 5c 24 60       	mov    0x60(%rsp),%r11
   f1a0a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1a0e:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   f1a13:	4c 8b 94 24 a8 00 00 00 	mov    0xa8(%rsp),%r10
   f1a1b:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1a1f:	49 01 c3             	add    %rax,%r11
   f1a22:	4c 8b 8c 24 b0 00 00 00 	mov    0xb0(%rsp),%r9
   f1a2a:	4c 01 da             	add    %r11,%rdx
   f1a2d:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1a35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1a40:	41 0f 11 43 10       	movups %xmm0,0x10(%r11)
   f1a45:	49 83 c3 38          	add    $0x38,%r11
   f1a49:	41 0f 11 43 c8       	movups %xmm0,-0x38(%r11)
   f1a4e:	41 0f 11 4b e0       	movups %xmm1,-0x20(%r11)
   f1a53:	41 0f 11 43 f0       	movups %xmm0,-0x10(%r11)
   f1a58:	49 39 d3             	cmp    %rdx,%r11
   f1a5b:	75 e3                	jne    f1a40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe40>
   f1a5d:	4d 39 ca             	cmp    %r9,%r10
   f1a60:	74 4d                	je     f1aaf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xeaf>
   f1a62:	4c 89 ca             	mov    %r9,%rdx
   f1a65:	48 89 c7             	mov    %rax,%rdi
   f1a68:	66 90                	xchg   %ax,%ax
   f1a6a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1a75:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1a80:	f3 0f 6f 02          	movdqu (%rdx),%xmm0
   f1a84:	48 8b 4a 30          	mov    0x30(%rdx),%rcx
   f1a88:	48 83 c2 38          	add    $0x38,%rdx
   f1a8c:	48 83 c7 38          	add    $0x38,%rdi
   f1a90:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f1a94:	f3 0f 6f 42 d8       	movdqu -0x28(%rdx),%xmm0
   f1a99:	48 89 4f f8          	mov    %rcx,-0x8(%rdi)
   f1a9d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f1aa1:	f3 0f 6f 42 e8       	movdqu -0x18(%rdx),%xmm0
   f1aa6:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f1aaa:	49 39 d2             	cmp    %rdx,%r10
   f1aad:	75 d1                	jne    f1a80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe80>
   f1aaf:	4d 85 c9             	test   %r9,%r9
   f1ab2:	74 15                	je     f1ac9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xec9>
   f1ab4:	4c 29 ce             	sub    %r9,%rsi
   f1ab7:	4c 89 cf             	mov    %r9,%rdi
   f1aba:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f1abf:	e8 bc c5 05 00       	call   14e080 <_ZdlPvm>
   f1ac4:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f1ac9:	4d 6b d4 38          	imul   $0x38,%r12,%r10
   f1acd:	48 01 c3             	add    %rax,%rbx
   f1ad0:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   f1ad7:	49 89 c1             	mov    %rax,%r9
   f1ada:	49 89 9e 80 02 00 00 	mov    %rbx,0x280(%r14)
   f1ae1:	49 01 c2             	add    %rax,%r10
   f1ae4:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f1aeb:	e9 a3 f8 ff ff       	jmp    f1393 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x793>
   f1af0:	48 89 c2             	mov    %rax,%rdx
   f1af3:	83 e0 01             	and    $0x1,%eax
   f1af6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1afa:	48 d1 ea             	shr    $1,%rdx
   f1afd:	48 09 c2             	or     %rax,%rdx
   f1b00:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1b05:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1b09:	e9 56 fc ff ff       	jmp    f1764 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb64>
   f1b0e:	66 90                	xchg   %ax,%ax
   f1b10:	48 89 c2             	mov    %rax,%rdx
   f1b13:	83 e0 01             	and    $0x1,%eax
   f1b16:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1b1a:	48 d1 ea             	shr    $1,%rdx
   f1b1d:	48 09 c2             	or     %rax,%rdx
   f1b20:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1b25:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1b29:	e9 01 fc ff ff       	jmp    f172f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb2f>
   f1b2e:	66 90                	xchg   %ax,%ax
   f1b30:	e8 9b 57 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f1b35:	f2 0f 10 0d f3 c6 07 00 	movsd  0x7c6f3(%rip),%xmm1        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1b3d:	e9 10 fc ff ff       	jmp    f1752 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb52>
   f1b42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1b48:	e8 83 57 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f1b4d:	48 89 c5             	mov    %rax,%rbp
   f1b50:	e9 7c fb ff ff       	jmp    f16d1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xad1>
   f1b55:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   f1b60:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   f1b68:	0f 85 9b 00 00 00    	jne    f1c09 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x1009>
   f1b6e:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   f1b75:	83 c0 01             	add    $0x1,%eax
   f1b78:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   f1b7f:	83 f8 ff             	cmp    $0xffffffff,%eax
   f1b82:	0f 85 82 fd ff ff    	jne    f190a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd0a>
   f1b88:	49 8b 46 78          	mov    0x78(%r14),%rax
   f1b8c:	48 89 d1             	mov    %rdx,%rcx
   f1b8f:	48 c1 e1 04          	shl    $0x4,%rcx
   f1b93:	48 01 c1             	add    %rax,%rcx
   f1b96:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f1b9d:	48 83 c0 10          	add    $0x10,%rax
   f1ba1:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f1ba9:	48 39 c8             	cmp    %rcx,%rax
   f1bac:	75 e8                	jne    f1b96 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf96>
   f1bae:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   f1bb5:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f1bc0:	e9 45 fd ff ff       	jmp    f190a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd0a>
   f1bc5:	48 89 c2             	mov    %rax,%rdx
   f1bc8:	83 e0 01             	and    $0x1,%eax
   f1bcb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1bcf:	48 d1 ea             	shr    $1,%rdx
   f1bd2:	48 09 c2             	or     %rax,%rdx
   f1bd5:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1bda:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1bde:	e9 69 fa ff ff       	jmp    f164c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa4c>
   f1be3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f1be8:	e8 b3 f4 f1 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f1bed:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f1bf2:	48 89 84 24 a0 00 00 00 	mov    %rax,0xa0(%rsp)
   f1bfa:	e9 b5 f0 ff ff       	jmp    f0cb4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb4>
   f1bff:	e8 9c f4 f1 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f1c04:	e9 2c fa ff ff       	jmp    f1635 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa35>
   f1c09:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   f1c14:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f1c1f:	e9 e6 fc ff ff       	jmp    f190a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd0a>
   f1c24:	0f b6 d0             	movzbl %al,%edx
   f1c27:	e9 59 fd ff ff       	jmp    f1985 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd85>
   f1c2c:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f1c34:	e8 27 56 f1 ff       	call   7260 <__stack_chk_fail@plt>

# candidate unordered_pairs bench::Counters bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-two-copy-headroom.qUEHc7/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000ec890 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   ec890:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
   ec897:	44 8b 8e d0 00 00 00 	mov    0xd0(%rsi),%r9d
   ec89e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ec8a2:	48 89 9c 24 38 01 00 00 	mov    %rbx,0x138(%rsp)
   ec8aa:	48 89 fb             	mov    %rdi,%rbx
   ec8ad:	48 89 ac 24 40 01 00 00 	mov    %rbp,0x140(%rsp)
   ec8b5:	4c 89 cd             	mov    %r9,%rbp
   ec8b8:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   ec8bd:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
   ec8c6:	48 89 84 24 28 01 00 00 	mov    %rax,0x128(%rsp)
   ec8ce:	31 c0                	xor    %eax,%eax
   ec8d0:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   ec8d5:	41 83 f9 01          	cmp    $0x1,%r9d
   ec8d9:	0f 86 09 03 00 00    	jbe    ecbe8 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x358>
   ec8df:	4c 89 b4 24 58 01 00 00 	mov    %r14,0x158(%rsp)
   ec8e7:	66 48 0f 6e c9       	movq   %rcx,%xmm1
   ec8ec:	4c 8d 76 08          	lea    0x8(%rsi),%r14
   ec8f0:	8b b6 64 01 00 00    	mov    0x164(%rsi),%esi
   ec8f6:	0f 11 44 24 68       	movups %xmm0,0x68(%rsp)
   ec8fb:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   ec900:	66 48 0f 6e c0       	movq   %rax,%xmm0
   ec905:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
   ec909:	c6 44 24 60 00       	movb   $0x0,0x60(%rsp)
   ec90e:	48 c7 84 24 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rsp)
   ec91a:	0f 11 84 24 88 00 00 00 	movups %xmm0,0x88(%rsp)
   ec922:	83 fe ff             	cmp    $0xffffffff,%esi
   ec925:	0f 85 d5 01 00 00    	jne    ecb00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x270>
   ec92b:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   ec933:	49 89 d7             	mov    %rdx,%r15
   ec936:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   ec93e:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   ec946:	49 83 f9 04          	cmp    $0x4,%r9
   ec94a:	0f 86 a5 02 00 00    	jbe    ecbf5 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x365>
   ec950:	8d 45 ff             	lea    -0x1(%rbp),%eax
   ec953:	89 6c 24 24          	mov    %ebp,0x24(%rsp)
   ec957:	45 31 ed             	xor    %r13d,%r13d
   ec95a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   ec95f:	31 c0                	xor    %eax,%eax
   ec961:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   ec966:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   ec96b:	84 c0                	test   %al,%al
   ec96d:	0f 85 63 01 00 00    	jne    ecad6 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x246>
   ec973:	66 90                	xchg   %ax,%ax
   ec975:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ec980:	4c 39 6c 24 28       	cmp    %r13,0x28(%rsp)
   ec985:	0f 84 4b 01 00 00    	je     ecad6 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x246>
   ec98b:	4c 89 ef             	mov    %r13,%rdi
   ec98e:	41 8d 6d 01          	lea    0x1(%r13),%ebp
   ec992:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   ec997:	45 89 ec             	mov    %r13d,%r12d
   ec99a:	48 c1 e7 05          	shl    $0x5,%rdi
   ec99e:	41 89 ed             	mov    %ebp,%r13d
   ec9a1:	8b 6c 24 24          	mov    0x24(%rsp),%ebp
   ec9a5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   ec9aa:	48 8d 5f 20          	lea    0x20(%rdi),%rbx
   ec9ae:	eb 1c                	jmp    ec9cc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x13c>
   ec9b0:	41 83 c5 01          	add    $0x1,%r13d
   ec9b4:	41 39 ed             	cmp    %ebp,%r13d
   ec9b7:	0f 83 03 01 00 00    	jae    ecac0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x230>
   ec9bd:	48 83 c3 20          	add    $0x20,%rbx
   ec9c1:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
   ec9c6:	0f 85 f4 00 00 00    	jne    ecac0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x230>
   ec9cc:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
   ec9d1:	44 89 ea             	mov    %r13d,%edx
   ec9d4:	44 89 e6             	mov    %r12d,%esi
   ec9d7:	4c 89 f7             	mov    %r14,%rdi
   ec9da:	e8 c1 51 f2 ff       	call   11ba0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_7ContextERT0_.isra.0>
   ec9df:	84 c0                	test   %al,%al
   ec9e1:	74 cd                	je     ec9b0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x120>
   ec9e3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   ec9e8:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   ec9ed:	48 8b 40 68          	mov    0x68(%rax),%rax
   ec9f1:	8b 7c 30 18          	mov    0x18(%rax,%rsi,1),%edi
   ec9f5:	39 7c 18 18          	cmp    %edi,0x18(%rax,%rbx,1)
   ec9f9:	0f 82 d9 01 00 00    	jb     ecbd8 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x348>
   ec9ff:	44 89 2c 24          	mov    %r13d,(%rsp)
   eca03:	44 89 e2             	mov    %r12d,%edx
   eca06:	4c 89 f6             	mov    %r14,%rsi
   eca09:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
   eca11:	e8 da 62 04 00       	call   132cf0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   eca16:	8b 14 24             	mov    (%rsp),%edx
   eca19:	4c 89 f6             	mov    %r14,%rsi
   eca1c:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   eca24:	e8 c7 62 04 00       	call   132cf0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   eca29:	48 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%rdx
   eca31:	48 8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%rax
   eca39:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   eca43:	8b 00                	mov    (%rax),%eax
   eca45:	8b 0a                	mov    (%rdx),%ecx
   eca47:	49 83 07 01          	addq   $0x1,(%r15)
   eca4b:	89 ca                	mov    %ecx,%edx
   eca4d:	39 c8                	cmp    %ecx,%eax
   eca4f:	0f 46 d0             	cmovbe %eax,%edx
   eca52:	48 c1 e2 20          	shl    $0x20,%rdx
   eca56:	39 c8                	cmp    %ecx,%eax
   eca58:	0f 42 c1             	cmovb  %ecx,%eax
   eca5b:	48 09 c2             	or     %rax,%rdx
   eca5e:	48 89 d0             	mov    %rdx,%rax
   eca61:	48 c1 e8 1e          	shr    $0x1e,%rax
   eca65:	48 31 d0             	xor    %rdx,%rax
   eca68:	48 0f af c6          	imul   %rsi,%rax
   eca6c:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   eca76:	48 89 c2             	mov    %rax,%rdx
   eca79:	48 c1 ea 1b          	shr    $0x1b,%rdx
   eca7d:	48 31 d0             	xor    %rdx,%rax
   eca80:	48 0f af c6          	imul   %rsi,%rax
   eca84:	48 89 c2             	mov    %rax,%rdx
   eca87:	48 c1 ea 1f          	shr    $0x1f,%rdx
   eca8b:	48 31 d0             	xor    %rdx,%rax
   eca8e:	49 01 47 08          	add    %rax,0x8(%r15)
   eca92:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   eca9a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   eca9e:	0f 84 0c ff ff ff    	je     ec9b0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x120>
   ecaa4:	48 83 c0 01          	add    $0x1,%rax
   ecaa8:	41 83 c5 01          	add    $0x1,%r13d
   ecaac:	48 89 84 24 88 00 00 00 	mov    %rax,0x88(%rsp)
   ecab4:	41 39 ed             	cmp    %ebp,%r13d
   ecab7:	0f 82 00 ff ff ff    	jb     ec9bd <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x12d>
   ecabd:	0f 1f 00             	nopl   (%rax)
   ecac0:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
   ecac5:	0f b6 44 24 60       	movzbl 0x60(%rsp),%eax
   ecaca:	49 83 c5 01          	add    $0x1,%r13
   ecace:	84 c0                	test   %al,%al
   ecad0:	0f 84 aa fe ff ff    	je     ec980 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xf0>
   ecad6:	8b 6c 24 24          	mov    0x24(%rsp),%ebp
   ecada:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   ecadf:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   ecae4:	4c 8b a4 24 48 01 00 00 	mov    0x148(%rsp),%r12
   ecaec:	4c 8b ac 24 50 01 00 00 	mov    0x150(%rsp),%r13
   ecaf4:	4c 8b bc 24 60 01 00 00 	mov    0x160(%rsp),%r15
   ecafc:	eb 24                	jmp    ecb22 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x292>
   ecafe:	66 90                	xchg   %ax,%ax
   ecb00:	48 8d 4c 24 58       	lea    0x58(%rsp),%rcx
   ecb05:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
   ecb0a:	4c 89 f7             	mov    %r14,%rdi
   ecb0d:	4c 89 0c 24          	mov    %r9,(%rsp)
   ecb11:	4c 8d 84 24 a0 00 00 00 	lea    0xa0(%rsp),%r8
   ecb19:	e8 22 c6 fa ff       	call   99140 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE9selfPairsIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvjRNS2_7ContextESC_RSF_>
   ecb1e:	4c 8b 0c 24          	mov    (%rsp),%r9
   ecb22:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   ecb28:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
   ecb2e:	0f b6 44 24 60       	movzbl 0x60(%rsp),%eax
   ecb33:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   ecb3b:	66 0f 6f 84 24 80 00 00 00 	movdqa 0x80(%rsp),%xmm0
   ecb44:	0f 29 94 24 e0 00 00 00 	movaps %xmm2,0xe0(%rsp)
   ecb4c:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   ecb54:	84 c0                	test   %al,%al
   ecb56:	74 08                	je     ecb60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2d0>
   ecb58:	3c 0b                	cmp    $0xb,%al
   ecb5a:	0f 85 4e 03 00 00    	jne    eceae <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x61e>
   ecb60:	4c 8b b4 24 58 01 00 00 	mov    0x158(%rsp),%r14
   ecb68:	48 8b 94 24 f0 00 00 00 	mov    0xf0(%rsp),%rdx
   ecb70:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   ecb78:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   ecb80:	48 89 13             	mov    %rdx,(%rbx)
   ecb83:	48 8b 94 24 e8 00 00 00 	mov    0xe8(%rsp),%rdx
   ecb8b:	4c 89 4b 08          	mov    %r9,0x8(%rbx)
   ecb8f:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   ecb93:	31 d2                	xor    %edx,%edx
   ecb95:	85 ed                	test   %ebp,%ebp
   ecb97:	0f 95 c2             	setne  %dl
   ecb9a:	3c 0b                	cmp    $0xb,%al
   ecb9c:	89 53 20             	mov    %edx,0x20(%rbx)
   ecb9f:	0f 94 43 30          	sete   0x30(%rbx)
   ecba3:	48 8b 84 24 28 01 00 00 	mov    0x128(%rsp),%rax
   ecbab:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   ecbb4:	0f 85 29 03 00 00    	jne    ecee3 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x653>
   ecbba:	48 89 d8             	mov    %rbx,%rax
   ecbbd:	48 8b ac 24 40 01 00 00 	mov    0x140(%rsp),%rbp
   ecbc5:	48 8b 9c 24 38 01 00 00 	mov    0x138(%rsp),%rbx
   ecbcd:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
   ecbd4:	c3                   	ret
   ecbd5:	0f 1f 00             	nopl   (%rax)
   ecbd8:	44 89 24 24          	mov    %r12d,(%rsp)
   ecbdc:	44 89 ea             	mov    %r13d,%edx
   ecbdf:	e9 22 fe ff ff       	jmp    eca06 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x176>
   ecbe4:	0f 1f 40 00          	nopl   0x0(%rax)
   ecbe8:	0f 11 84 24 e8 00 00 00 	movups %xmm0,0xe8(%rsp)
   ecbf0:	e9 73 ff ff ff       	jmp    ecb68 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2d8>
   ecbf5:	49 8d 41 ff          	lea    -0x1(%r9),%rax
   ecbf9:	49 0f af c1          	imul   %r9,%rax
   ecbfd:	48 d1 e8             	shr    $1,%rax
   ecc00:	48 39 c1             	cmp    %rax,%rcx
   ecc03:	0f 82 47 fd ff ff    	jb     ec950 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xc0>
   ecc09:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   ecc0e:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   ecc13:	45 31 ff             	xor    %r15d,%r15d
   ecc16:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   ecc1b:	48 8b 70 68          	mov    0x68(%rax),%rsi
   ecc1f:	48 8b 40 58          	mov    0x58(%rax),%rax
   ecc23:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
   ecc28:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   ecc2d:	4c 8d 66 20          	lea    0x20(%rsi),%r12
   ecc31:	41 8d 71 ff          	lea    -0x1(%r9),%esi
   ecc35:	48 89 04 24          	mov    %rax,(%rsp)
   ecc39:	48 83 c0 10          	add    $0x10,%rax
   ecc3d:	89 74 24 18          	mov    %esi,0x18(%rsp)
   ecc41:	0f 1f 40 00          	nopl   0x0(%rax)
   ecc45:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ecc50:	44 89 7c 24 08       	mov    %r15d,0x8(%rsp)
   ecc55:	41 83 c7 01          	add    $0x1,%r15d
   ecc59:	49 89 c6             	mov    %rax,%r14
   ecc5c:	4c 89 e3             	mov    %r12,%rbx
   ecc5f:	44 89 3c 24          	mov    %r15d,(%rsp)
   ecc63:	45 89 fd             	mov    %r15d,%r13d
   ecc66:	eb 4d                	jmp    eccb5 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x425>
   ecc68:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   ecc70:	49 8b 54 24 e8       	mov    -0x18(%r12),%rdx
   ecc75:	48 85 13             	test   %rdx,(%rbx)
   ecc78:	74 46                	je     eccc0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x430>
   ecc7a:	8b 50 f0             	mov    -0x10(%rax),%edx
   ecc7d:	41 8b 4e 08          	mov    0x8(%r14),%ecx
   ecc81:	48 83 44 24 70 01    	addq   $0x1,0x70(%rsp)
   ecc87:	39 ca                	cmp    %ecx,%edx
   ecc89:	7c 55                	jl     ecce0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x450>
   ecc8b:	0f 84 54 01 00 00    	je     ecde5 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x555>
   ecc91:	0f 1f 40 00          	nopl   0x0(%rax)
   ecc95:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ecca0:	41 83 c5 01          	add    $0x1,%r13d
   ecca4:	48 83 c3 20          	add    $0x20,%rbx
   ecca8:	49 83 c6 10          	add    $0x10,%r14
   eccac:	41 39 ed             	cmp    %ebp,%r13d
   eccaf:	0f 83 ab 01 00 00    	jae    ece60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5d0>
   eccb5:	49 8b 54 24 e0       	mov    -0x20(%r12),%rdx
   eccba:	48 85 53 08          	test   %rdx,0x8(%rbx)
   eccbe:	75 b0                	jne    ecc70 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   eccc0:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   eccc5:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
   eccc9:	74 d5                	je     ecca0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ecccb:	48 83 c2 01          	add    $0x1,%rdx
   ecccf:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
   eccd4:	eb ca                	jmp    ecca0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   eccd6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   ecce0:	41 8b 3e             	mov    (%r14),%edi
   ecce3:	8b 70 f8             	mov    -0x8(%rax),%esi
   ecce6:	39 f7                	cmp    %esi,%edi
   ecce8:	0f 8d 02 01 00 00    	jge    ecdf0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x560>
   eccee:	44 8b 40 f4          	mov    -0xc(%rax),%r8d
   eccf2:	45 3b 46 0c          	cmp    0xc(%r14),%r8d
   eccf6:	0f 8d 00 01 00 00    	jge    ecdfc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x56c>
   eccfc:	44 8b 50 fc          	mov    -0x4(%rax),%r10d
   ecd00:	45 39 56 04          	cmp    %r10d,0x4(%r14)
   ecd04:	0f 8d f2 00 00 00    	jge    ecdfc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x56c>
   ecd0a:	41 8b 7c 24 f8       	mov    -0x8(%r12),%edi
   ecd0f:	39 7b 18             	cmp    %edi,0x18(%rbx)
   ecd12:	0f 82 86 01 00 00    	jb     ece9e <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x60e>
   ecd18:	44 89 6c 24 24       	mov    %r13d,0x24(%rsp)
   ecd1d:	8b 54 24 08          	mov    0x8(%rsp),%edx
   ecd21:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   ecd26:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
   ecd2e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   ecd33:	4c 89 fe             	mov    %r15,%rsi
   ecd36:	e8 b5 5f 04 00       	call   132cf0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ecd3b:	8b 54 24 24          	mov    0x24(%rsp),%edx
   ecd3f:	4c 89 fe             	mov    %r15,%rsi
   ecd42:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   ecd4a:	e8 a1 5f 04 00       	call   132cf0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ecd4f:	48 8b 8c 24 b8 00 00 00 	mov    0xb8(%rsp),%rcx
   ecd57:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   ecd5c:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   ecd64:	8b 31                	mov    (%rcx),%esi
   ecd66:	8b 12                	mov    (%rdx),%edx
   ecd68:	48 83 00 01          	addq   $0x1,(%rax)
   ecd6c:	89 f1                	mov    %esi,%ecx
   ecd6e:	39 f2                	cmp    %esi,%edx
   ecd70:	0f 46 ca             	cmovbe %edx,%ecx
   ecd73:	48 c1 e1 20          	shl    $0x20,%rcx
   ecd77:	39 f2                	cmp    %esi,%edx
   ecd79:	0f 42 d6             	cmovb  %esi,%edx
   ecd7c:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   ecd86:	48 09 d1             	or     %rdx,%rcx
   ecd89:	48 89 ca             	mov    %rcx,%rdx
   ecd8c:	48 c1 ea 1e          	shr    $0x1e,%rdx
   ecd90:	48 31 ca             	xor    %rcx,%rdx
   ecd93:	48 0f af d6          	imul   %rsi,%rdx
   ecd97:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   ecda1:	48 89 d1             	mov    %rdx,%rcx
   ecda4:	48 c1 e9 1b          	shr    $0x1b,%rcx
   ecda8:	48 31 ca             	xor    %rcx,%rdx
   ecdab:	48 0f af d6          	imul   %rsi,%rdx
   ecdaf:	48 89 d1             	mov    %rdx,%rcx
   ecdb2:	48 c1 e9 1f          	shr    $0x1f,%rcx
   ecdb6:	48 31 ca             	xor    %rcx,%rdx
   ecdb9:	48 01 50 08          	add    %rdx,0x8(%rax)
   ecdbd:	48 8b 94 24 88 00 00 00 	mov    0x88(%rsp),%rdx
   ecdc5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   ecdca:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
   ecdce:	0f 84 cc fe ff ff    	je     ecca0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ecdd4:	48 83 c2 01          	add    $0x1,%rdx
   ecdd8:	48 89 94 24 88 00 00 00 	mov    %rdx,0x88(%rsp)
   ecde0:	e9 bb fe ff ff       	jmp    ecca0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ecde5:	41 8b 3e             	mov    (%r14),%edi
   ecde8:	8b 70 f8             	mov    -0x8(%rax),%esi
   ecdeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   ecdf0:	39 f7                	cmp    %esi,%edi
   ecdf2:	0f 8f a8 fe ff ff    	jg     ecca0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ecdf8:	44 8b 40 f4          	mov    -0xc(%rax),%r8d
   ecdfc:	45 8b 4e 0c          	mov    0xc(%r14),%r9d
   ece00:	45 39 c8             	cmp    %r9d,%r8d
   ece03:	0f 8f 97 fe ff ff    	jg     ecca0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ece09:	45 8b 56 04          	mov    0x4(%r14),%r10d
   ece0d:	44 8b 58 fc          	mov    -0x4(%rax),%r11d
   ece11:	45 39 da             	cmp    %r11d,%r10d
   ece14:	0f 8f 86 fe ff ff    	jg     ecca0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ece1a:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
   ece1f:	41 80 7f 21 01       	cmpb   $0x1,0x21(%r15)
   ece24:	0f 95 44 24 24       	setne  0x24(%rsp)
   ece29:	45 39 d8             	cmp    %r11d,%r8d
   ece2c:	41 0f 95 c0          	setne  %r8b
   ece30:	44 22 44 24 24       	and    0x24(%rsp),%r8b
   ece35:	45 39 d1             	cmp    %r10d,%r9d
   ece38:	41 0f 95 c1          	setne  %r9b
   ece3c:	45 21 c8             	and    %r9d,%r8d
   ece3f:	39 f2                	cmp    %esi,%edx
   ece41:	0f 95 c2             	setne  %dl
   ece44:	41 84 d0             	test   %dl,%r8b
   ece47:	0f 84 bd fe ff ff    	je     ecd0a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x47a>
   ece4d:	39 f9                	cmp    %edi,%ecx
   ece4f:	0f 84 b5 fe ff ff    	je     ecd0a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x47a>
   ece55:	e9 46 fe ff ff       	jmp    ecca0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ece5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ece60:	44 8b 3c 24          	mov    (%rsp),%r15d
   ece64:	49 83 c4 20          	add    $0x20,%r12
   ece68:	48 83 c0 10          	add    $0x10,%rax
   ece6c:	44 39 7c 24 18       	cmp    %r15d,0x18(%rsp)
   ece71:	0f 85 d9 fd ff ff    	jne    ecc50 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3c0>
   ece77:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
   ece7c:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
   ece81:	4c 8b a4 24 48 01 00 00 	mov    0x148(%rsp),%r12
   ece89:	4c 8b ac 24 50 01 00 00 	mov    0x150(%rsp),%r13
   ece91:	4c 8b bc 24 60 01 00 00 	mov    0x160(%rsp),%r15
   ece99:	e9 84 fc ff ff       	jmp    ecb22 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x292>
   ece9e:	8b 74 24 08          	mov    0x8(%rsp),%esi
   ecea2:	44 89 ea             	mov    %r13d,%edx
   ecea5:	89 74 24 24          	mov    %esi,0x24(%rsp)
   ecea9:	e9 73 fe ff ff       	jmp    ecd21 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x491>
   eceae:	48 8b 3d ab 13 08 00 	mov    0x813ab(%rip),%rdi        # 16e260 <stderr@GLIBC_2.2.5>
   eceb5:	0f b6 d0             	movzbl %al,%edx
   eceb8:	48 8d 35 e1 8a 06 00 	lea    0x68ae1(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   ecebf:	31 c0                	xor    %eax,%eax
   ecec1:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   ecec9:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   eced1:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   eced9:	e8 62 a4 f1 ff       	call   7340 <fprintf@plt>
   ecede:	e8 3d a2 f1 ff       	call   7120 <abort@plt>
   ecee3:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   eceeb:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   ecef3:	4c 89 b4 24 58 01 00 00 	mov    %r14,0x158(%rsp)
   ecefb:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   ecf03:	e8 58 a3 f1 ff       	call   7260 <__stack_chk_fail@plt>

# candidate ordered_pairs bench::Counters bench::LibraryIndex<int, true>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-two-copy-headroom.qUEHc7/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f01e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f01e0:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
   f01e7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f01eb:	48 89 9c 24 c8 01 00 00 	mov    %rbx,0x1c8(%rsp)
   f01f3:	48 89 fb             	mov    %rdi,%rbx
   f01f6:	4c 89 bc 24 f0 01 00 00 	mov    %r15,0x1f0(%rsp)
   f01fe:	49 89 f7             	mov    %rsi,%r15
   f0201:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   f0206:	8b 96 d0 00 00 00    	mov    0xd0(%rsi),%edx
   f020c:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
   f0213:	64 48 8b 3c 25 28 00 00 00 	mov    %fs:0x28,%rdi
   f021c:	48 89 bc 24 b8 01 00 00 	mov    %rdi,0x1b8(%rsp)
   f0224:	31 ff                	xor    %edi,%edi
   f0226:	83 fa 01             	cmp    $0x1,%edx
   f0229:	0f 86 01 03 00 00    	jbe    f0530 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x350>
   f022f:	48 39 f2             	cmp    %rsi,%rdx
   f0232:	74 44                	je     f0278 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x98>
   f0234:	ba 07 00 00 00       	mov    $0x7,%edx
   f0239:	48 8b 3d 20 e0 07 00 	mov    0x7e020(%rip),%rdi        # 16e260 <stderr@GLIBC_2.2.5>
   f0240:	48 8d 35 59 57 06 00 	lea    0x65759(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   f0247:	31 c0                	xor    %eax,%eax
   f0249:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f0251:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f0259:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f0261:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f0269:	e8 d2 70 f1 ff       	call   7340 <fprintf@plt>
   f026e:	e8 ad 6e f1 ff       	call   7120 <abort@plt>
   f0273:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f0278:	49 89 c8             	mov    %rcx,%r8
   f027b:	0f 11 84 24 98 00 00 00 	movups %xmm0,0x98(%rsp)
   f0283:	49 8b 47 50          	mov    0x50(%r15),%rax
   f0287:	89 d1                	mov    %edx,%ecx
   f0289:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f0291:	66 49 0f 6e d0       	movq   %r8,%xmm2
   f0296:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   f029b:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
   f029f:	c6 84 24 90 00 00 00 00 	movb   $0x0,0x90(%rsp)
   f02a7:	48 c7 84 24 c8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xc8(%rsp)
   f02b3:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f02bb:	48 85 c0             	test   %rax,%rax
   f02be:	0f 84 c6 08 00 00    	je     f0b8a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9aa>
   f02c4:	48 89 84 24 d0 00 00 00 	mov    %rax,0xd0(%rsp)
   f02cc:	48 89 84 24 d8 00 00 00 	mov    %rax,0xd8(%rsp)
   f02d4:	48 c7 84 24 e0 00 00 00 00 00 00 00 	movq   $0x0,0xe0(%rsp)
   f02e0:	48 c7 84 24 e8 00 00 00 00 00 00 00 	movq   $0x0,0xe8(%rsp)
   f02ec:	48 89 84 24 f0 00 00 00 	mov    %rax,0xf0(%rsp)
   f02f4:	48 c7 84 24 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rsp)
   f0300:	48 c7 84 24 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rsp)
   f030c:	48 89 84 24 08 01 00 00 	mov    %rax,0x108(%rsp)
   f0314:	48 c7 84 24 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rsp)
   f0320:	48 c7 84 24 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rsp)
   f032c:	48 89 84 24 20 01 00 00 	mov    %rax,0x120(%rsp)
   f0334:	48 c7 84 24 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rsp)
   f0340:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f034c:	48 89 84 24 38 01 00 00 	mov    %rax,0x138(%rsp)
   f0354:	48 c7 84 24 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rsp)
   f0360:	48 c7 84 24 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rsp)
   f036c:	48 89 84 24 50 01 00 00 	mov    %rax,0x150(%rsp)
   f0374:	48 c7 84 24 58 01 00 00 00 00 00 00 	movq   $0x0,0x158(%rsp)
   f0380:	48 c7 84 24 60 01 00 00 00 00 00 00 	movq   $0x0,0x160(%rsp)
   f038c:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f0394:	48 c7 84 24 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rsp)
   f03a0:	48 c7 84 24 78 01 00 00 00 00 00 00 	movq   $0x0,0x178(%rsp)
   f03ac:	48 89 84 24 80 01 00 00 	mov    %rax,0x180(%rsp)
   f03b4:	48 c7 84 24 88 01 00 00 00 00 00 00 	movq   $0x0,0x188(%rsp)
   f03c0:	48 c7 84 24 90 01 00 00 00 00 00 00 	movq   $0x0,0x190(%rsp)
   f03cc:	48 89 84 24 98 01 00 00 	mov    %rax,0x198(%rsp)
   f03d4:	48 c7 84 24 a0 01 00 00 00 00 00 00 	movq   $0x0,0x1a0(%rsp)
   f03e0:	48 c7 84 24 a8 01 00 00 00 00 00 00 	movq   $0x0,0x1a8(%rsp)
   f03ec:	c7 84 24 b0 01 00 00 00 00 00 00 	movl   $0x0,0x1b0(%rsp)
   f03f7:	c6 84 24 b4 01 00 00 00 	movb   $0x0,0x1b4(%rsp)
   f03ff:	49 39 b7 a0 01 00 00 	cmp    %rsi,0x1a0(%r15)
   f0406:	0f 82 b4 01 00 00    	jb     f05c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f040c:	49 39 b7 b8 01 00 00 	cmp    %rsi,0x1b8(%r15)
   f0413:	0f 82 a7 01 00 00    	jb     f05c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f0419:	41 80 bf 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r15)
   f0421:	0f 85 aa 07 00 00    	jne    f0bd1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9f1>
   f0427:	49 8d 47 08          	lea    0x8(%r15),%rax
   f042b:	4d 8b 9f 98 01 00 00 	mov    0x198(%r15),%r11
   f0432:	c6 44 24 43 00       	movb   $0x0,0x43(%rsp)
   f0437:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   f043c:	49 8d 87 88 01 00 00 	lea    0x188(%r15),%rax
   f0443:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f0448:	41 c6 87 6c 02 00 00 01 	movb   $0x1,0x26c(%r15)
   f0450:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
   f0455:	85 c9                	test   %ecx,%ecx
   f0457:	0f 84 7a 01 00 00    	je     f05d7 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f045d:	8d 41 ff             	lea    -0x1(%rcx),%eax
   f0460:	83 f8 02             	cmp    $0x2,%eax
   f0463:	0f 86 3c 07 00 00    	jbe    f0ba5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9c5>
   f0469:	89 cf                	mov    %ecx,%edi
   f046b:	4c 89 d8             	mov    %r11,%rax
   f046e:	66 0f 6f 05 1a 74 06 00 	movdqa 0x6741a(%rip),%xmm0        # 157890 <C.66.5+0x270>
   f0476:	c1 ef 02             	shr    $0x2,%edi
   f0479:	89 fa                	mov    %edi,%edx
   f047b:	48 c1 e2 04          	shl    $0x4,%rdx
   f047f:	4c 01 da             	add    %r11,%rdx
   f0482:	41 bb 04 00 00 00    	mov    $0x4,%r11d
   f0488:	66 41 0f 6e cb       	movd   %r11d,%xmm1
   f048d:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   f0492:	0f 1f 00             	nopl   (%rax)
   f0495:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f04a0:	0f 11 00             	movups %xmm0,(%rax)
   f04a3:	48 83 c0 10          	add    $0x10,%rax
   f04a7:	66 0f fe c1          	paddd  %xmm1,%xmm0
   f04ab:	48 39 d0             	cmp    %rdx,%rax
   f04ae:	75 f0                	jne    f04a0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2c0>
   f04b0:	8d 04 bd 00 00 00 00 	lea    0x0(,%rdi,4),%eax
   f04b7:	39 c8                	cmp    %ecx,%eax
   f04b9:	74 25                	je     f04e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f04bb:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
   f04c0:	89 c2                	mov    %eax,%edx
   f04c2:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f04c6:	8d 50 01             	lea    0x1(%rax),%edx
   f04c9:	39 ca                	cmp    %ecx,%edx
   f04cb:	73 13                	jae    f04e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f04cd:	89 d7                	mov    %edx,%edi
   f04cf:	83 c0 02             	add    $0x2,%eax
   f04d2:	41 89 14 bb          	mov    %edx,(%r11,%rdi,4)
   f04d6:	39 c8                	cmp    %ecx,%eax
   f04d8:	73 06                	jae    f04e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f04da:	89 c2                	mov    %eax,%edx
   f04dc:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f04e0:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
   f04e7:	0f 86 ea 00 00 00    	jbe    f05d7 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f04ed:	49 39 b7 48 02 00 00 	cmp    %rsi,0x248(%r15)
   f04f4:	0f 82 e7 00 00 00    	jb     f05e1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f04fa:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f0504:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f050b:	48 c1 ea 04          	shr    $0x4,%rdx
   f050f:	48 39 f2             	cmp    %rsi,%rdx
   f0512:	0f 82 c9 00 00 00    	jb     f05e1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f0518:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f051c:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   f0521:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f0526:	e8 b5 20 f2 ff       	call   125e0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f052b:	e9 db 00 00 00       	jmp    f060b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x42b>
   f0530:	48 39 f2             	cmp    %rsi,%rdx
   f0533:	0f 85 fb fc ff ff    	jne    f0234 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54>
   f0539:	48 89 d0             	mov    %rdx,%rax
   f053c:	0f 11 84 24 d8 00 00 00 	movups %xmm0,0xd8(%rsp)
   f0544:	31 d2                	xor    %edx,%edx
   f0546:	48 8b 8c 24 e0 00 00 00 	mov    0xe0(%rsp),%rcx
   f054e:	85 c0                	test   %eax,%eax
   f0550:	89 c7                	mov    %eax,%edi
   f0552:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   f055a:	0f 95 c0             	setne  %al
   f055d:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   f0565:	80 fa 0b             	cmp    $0xb,%dl
   f0568:	48 89 0b             	mov    %rcx,(%rbx)
   f056b:	48 8b 8c 24 d8 00 00 00 	mov    0xd8(%rsp),%rcx
   f0573:	0f b6 c0             	movzbl %al,%eax
   f0576:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
   f057a:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   f057e:	89 43 20             	mov    %eax,0x20(%rbx)
   f0581:	0f 94 43 30          	sete   0x30(%rbx)
   f0585:	48 8b 84 24 b8 01 00 00 	mov    0x1b8(%rsp),%rax
   f058d:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f0596:	0f 85 10 06 00 00    	jne    f0bac <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9cc>
   f059c:	48 89 d8             	mov    %rbx,%rax
   f059f:	4c 8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%r15
   f05a7:	48 8b 9c 24 c8 01 00 00 	mov    0x1c8(%rsp),%rbx
   f05af:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
   f05b6:	c3                   	ret
   f05b7:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   f05c0:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f05c8:	e8 d3 c3 00 00       	call   fc9a0 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f05cd:	ba 05 00 00 00       	mov    $0x5,%edx
   f05d2:	e9 62 fc ff ff       	jmp    f0239 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f05d7:	48 83 fe 01          	cmp    $0x1,%rsi
   f05db:	0f 86 bd 05 00 00    	jbe    f0b9e <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9be>
   f05e1:	48 89 f0             	mov    %rsi,%rax
   f05e4:	31 c9                	xor    %ecx,%ecx
   f05e6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f05f0:	48 d1 e8             	shr    $1,%rax
   f05f3:	83 c1 02             	add    $0x2,%ecx
   f05f6:	48 83 f8 01          	cmp    $0x1,%rax
   f05fa:	75 f4                	jne    f05f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f05fc:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f0601:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f0606:	e8 55 d4 05 00       	call   14da60 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f060b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f0612:	83 fa 01             	cmp    $0x1,%edx
   f0615:	0f 86 2a 03 00 00    	jbe    f0945 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f061b:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f0623:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f062b:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f0633:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f063b:	48 c7 44 24 08 01 00 00 00 	movq   $0x1,0x8(%rsp)
   f0644:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   f0649:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f0650:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f0658:	84 c0                	test   %al,%al
   f065a:	0f 85 c0 02 00 00    	jne    f0920 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f0660:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   f0665:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f066a:	48 8d 4c 24 43       	lea    0x43(%rsp),%rcx
   f066f:	4c 8d ac 24 90 00 00 00 	lea    0x90(%rsp),%r13
   f0677:	8b 7c 9f fc          	mov    -0x4(%rdi,%rbx,4),%edi
   f067b:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   f0680:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   f0685:	48 8d 4c 24 42       	lea    0x42(%rsp),%rcx
   f068a:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   f068f:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   f0694:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   f0699:	48 8d 5c 24 44       	lea    0x44(%rsp),%rbx
   f069e:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   f06a3:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
   f06a8:	48 89 8c 24 80 00 00 00 	mov    %rcx,0x80(%rsp)
   f06b0:	41 8b 8f 64 01 00 00 	mov    0x164(%r15),%ecx
   f06b7:	89 7c 24 44          	mov    %edi,0x44(%rsp)
   f06bb:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
   f06c4:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
   f06c9:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   f06ce:	83 f9 ff             	cmp    $0xffffffff,%ecx
   f06d1:	0f 84 d9 02 00 00    	je     f09b0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7d0>
   f06d7:	89 ce                	mov    %ecx,%esi
   f06d9:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   f06dd:	49 03 b7 f8 00 00 00 	add    0xf8(%r15),%rsi
   f06e4:	44 8b 46 64          	mov    0x64(%rsi),%r8d
   f06e8:	45 85 c0             	test   %r8d,%r8d
   f06eb:	0f 84 ff 01 00 00    	je     f08f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f06f1:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f06f9:	48 85 c0             	test   %rax,%rax
   f06fc:	0f 84 56 04 00 00    	je     f0b58 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x978>
   f0702:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f0706:	74 0c                	je     f0714 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x534>
   f0708:	48 83 e8 01          	sub    $0x1,%rax
   f070c:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f0714:	48 8b 84 24 98 00 00 00 	mov    0x98(%rsp),%rax
   f071c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f0720:	74 0c                	je     f072e <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54e>
   f0722:	48 83 c0 01          	add    $0x1,%rax
   f0726:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f072e:	48 89 fa             	mov    %rdi,%rdx
   f0731:	8b 46 1c             	mov    0x1c(%rsi),%eax
   f0734:	48 c1 e2 04          	shl    $0x4,%rdx
   f0738:	49 03 57 58          	add    0x58(%r15),%rdx
   f073c:	39 02                	cmp    %eax,(%rdx)
   f073e:	0f 8f ac 01 00 00    	jg     f08f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0744:	8b 42 08             	mov    0x8(%rdx),%eax
   f0747:	39 46 14             	cmp    %eax,0x14(%rsi)
   f074a:	0f 8f a0 01 00 00    	jg     f08f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0750:	8b 46 20             	mov    0x20(%rsi),%eax
   f0753:	39 42 04             	cmp    %eax,0x4(%rdx)
   f0756:	0f 8f 94 01 00 00    	jg     f08f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f075c:	8b 42 0c             	mov    0xc(%rdx),%eax
   f075f:	39 46 18             	cmp    %eax,0x18(%rsi)
   f0762:	0f 8f 88 01 00 00    	jg     f08f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0768:	49 8b 47 68          	mov    0x68(%r15),%rax
   f076c:	48 c1 e7 05          	shl    $0x5,%rdi
   f0770:	48 83 ec 08          	sub    $0x8,%rsp
   f0774:	4d 89 e9             	mov    %r13,%r9
   f0777:	48 01 f8             	add    %rdi,%rax
   f077a:	48 8b 08             	mov    (%rax),%rcx
   f077d:	4c 8b 40 08          	mov    0x8(%rax),%r8
   f0781:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   f0786:	50                   	push   %rax
   f0787:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f078c:	e8 8f cc f2 ff       	call   1d420 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE11walkOrderedIZNKS2_11orderedSelfIZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS5_8CountersERT_mEUlRKSC_RKT0_E_NS_6detail9AcceptAllEEEvRNS_9WorkspaceIiEEbRNS2_7ContextESD_RSG_EUljE_EEvRKNS2_4NodeERKNS_3BoxIiEENS_6FilterESQ_SD_>
   f0791:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f0799:	5a                   	pop    %rdx
   f079a:	59                   	pop    %rcx
   f079b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f07a0:	84 c0                	test   %al,%al
   f07a2:	0f 85 78 01 00 00    	jne    f0920 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f07a8:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f07ad:	49 8b 9f b0 01 00 00 	mov    0x1b0(%r15),%rbx
   f07b4:	48 83 fd 7f          	cmp    $0x7f,%rbp
   f07b8:	0f 86 5b 03 00 00    	jbe    f0b19 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x939>
   f07be:	49 39 af 48 02 00 00 	cmp    %rbp,0x248(%r15)
   f07c5:	0f 82 58 03 00 00    	jb     f0b23 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f07cb:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f07d5:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f07dc:	48 c1 ea 04          	shr    $0x4,%rdx
   f07e0:	48 39 ea             	cmp    %rbp,%rdx
   f07e3:	0f 82 3a 03 00 00    	jb     f0b23 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f07e9:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f07ed:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f07f2:	89 e9                	mov    %ebp,%ecx
   f07f4:	48 89 da             	mov    %rbx,%rdx
   f07f7:	e8 e4 1d f2 ff       	call   125e0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f07fc:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f0801:	48 85 ed             	test   %rbp,%rbp
   f0804:	0f 84 fb 00 00 00    	je     f0905 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f080a:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
   f080f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   f0814:	31 c9                	xor    %ecx,%ecx
   f0816:	4d 8b 5f 68          	mov    0x68(%r15),%r11
   f081a:	4d 8b 4f 60          	mov    0x60(%r15),%r9
   f081e:	4c 89 c2             	mov    %r8,%rdx
   f0821:	48 8b 07             	mov    (%rdi),%rax
   f0824:	4c 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%r10
   f082c:	48 c1 e2 05          	shl    $0x5,%rdx
   f0830:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
   f0834:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   f0839:	4d 8d 34 13          	lea    (%r11,%rdx,1),%r14
   f083d:	4c 8d 68 01          	lea    0x1(%rax),%r13
   f0841:	8b 14 8b             	mov    (%rbx,%rcx,4),%edx
   f0844:	49 8b 76 10          	mov    0x10(%r14),%rsi
   f0848:	4d 8d 64 0d 00       	lea    0x0(%r13,%rcx,1),%r12
   f084d:	48 89 d0             	mov    %rdx,%rax
   f0850:	48 c1 e0 05          	shl    $0x5,%rax
   f0854:	49 39 74 03 10       	cmp    %rsi,0x10(%r11,%rax,1)
   f0859:	48 89 d0             	mov    %rdx,%rax
   f085c:	49 0f 42 c0          	cmovb  %r8,%rax
   f0860:	49 0f 43 d0          	cmovae %r8,%rdx
   f0864:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f0868:	41 8b 34 91          	mov    (%r9,%rdx,4),%esi
   f086c:	39 f0                	cmp    %esi,%eax
   f086e:	89 f2                	mov    %esi,%edx
   f0870:	0f 46 d0             	cmovbe %eax,%edx
   f0873:	48 c1 e2 20          	shl    $0x20,%rdx
   f0877:	39 f0                	cmp    %esi,%eax
   f0879:	0f 42 c6             	cmovb  %esi,%eax
   f087c:	48 09 d0             	or     %rdx,%rax
   f087f:	48 89 c2             	mov    %rax,%rdx
   f0882:	48 c1 ea 1e          	shr    $0x1e,%rdx
   f0886:	48 31 c2             	xor    %rax,%rdx
   f0889:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   f0893:	48 0f af d0          	imul   %rax,%rdx
   f0897:	48 89 d0             	mov    %rdx,%rax
   f089a:	48 c1 e8 1b          	shr    $0x1b,%rax
   f089e:	48 31 c2             	xor    %rax,%rdx
   f08a1:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f08ab:	48 0f af d0          	imul   %rax,%rdx
   f08af:	48 89 d0             	mov    %rdx,%rax
   f08b2:	48 c1 e8 1f          	shr    $0x1f,%rax
   f08b6:	48 31 c2             	xor    %rax,%rdx
   f08b9:	48 01 d7             	add    %rdx,%rdi
   f08bc:	49 83 fa ff          	cmp    $0xffffffffffffffff,%r10
   f08c0:	0f 84 82 01 00 00    	je     f0a48 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x868>
   f08c6:	49 83 c2 01          	add    $0x1,%r10
   f08ca:	48 83 c1 01          	add    $0x1,%rcx
   f08ce:	4c 89 94 24 b8 00 00 00 	mov    %r10,0xb8(%rsp)
   f08d6:	48 39 cd             	cmp    %rcx,%rbp
   f08d9:	0f 85 62 ff ff ff    	jne    f0841 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x661>
   f08df:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f08e4:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f08e8:	4c 89 20             	mov    %r12,(%rax)
   f08eb:	eb 18                	jmp    f0905 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f08ed:	0f 1f 00             	nopl   (%rax)
   f08f0:	49 8b bf b0 01 00 00 	mov    0x1b0(%r15),%rdi
   f08f7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f08fc:	31 c9                	xor    %ecx,%ecx
   f08fe:	31 f6                	xor    %esi,%esi
   f0900:	e8 5b d1 05 00       	call   14da60 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f0905:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f090c:	48 83 44 24 08 01    	addq   $0x1,0x8(%rsp)
   f0912:	48 89 c2             	mov    %rax,%rdx
   f0915:	48 39 44 24 08       	cmp    %rax,0x8(%rsp)
   f091a:	0f 82 30 fd ff ff    	jb     f0650 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x470>
   f0920:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f0925:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f092d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f0935:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f093d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f0945:	41 c6 87 6c 02 00 00 00 	movb   $0x0,0x26c(%r15)
   f094d:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f0955:	e8 46 c0 00 00       	call   fc9a0 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f095a:	0f b6 94 24 90 00 00 00 	movzbl 0x90(%rsp),%edx
   f0962:	66 0f 6f 84 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm0
   f096b:	66 0f 6f 9c 24 90 00 00 00 	movdqa 0x90(%rsp),%xmm3
   f0974:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f097c:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f0985:	0f 29 9c 24 d0 00 00 00 	movaps %xmm3,0xd0(%rsp)
   f098d:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f0995:	80 fa 0b             	cmp    $0xb,%dl
   f0998:	74 08                	je     f09a2 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7c2>
   f099a:	84 d2                	test   %dl,%dl
   f099c:	0f 85 97 f8 ff ff    	jne    f0239 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f09a2:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f09a9:	e9 98 fb ff ff       	jmp    f0546 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x366>
   f09ae:	66 90                	xchg   %ax,%ax
   f09b0:	49 8b 6f 68          	mov    0x68(%r15),%rbp
   f09b4:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
   f09b9:	31 db                	xor    %ebx,%ebx
   f09bb:	eb 49                	jmp    f0a06 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x826>
   f09bd:	0f 1f 00             	nopl   (%rax)
   f09c0:	4c 89 e9             	mov    %r13,%rcx
   f09c3:	44 89 f2             	mov    %r14d,%edx
   f09c6:	4c 89 e7             	mov    %r12,%rdi
   f09c9:	e8 d2 11 f2 ff       	call   11ba0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_7ContextERT0_.isra.0>
   f09ce:	84 c0                	test   %al,%al
   f09d0:	74 19                	je     f09eb <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x80b>
   f09d2:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   f09d7:	48 8d 50 01          	lea    0x1(%rax),%rdx
   f09db:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f09e0:	49 8b 97 b0 01 00 00 	mov    0x1b0(%r15),%rdx
   f09e7:	44 89 34 82          	mov    %r14d,(%rdx,%rax,4)
   f09eb:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f09f2:	48 83 c3 01          	add    $0x1,%rbx
   f09f6:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f09fe:	39 d3                	cmp    %edx,%ebx
   f0a00:	0f 83 9a fd ff ff    	jae    f07a0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f0a06:	84 c0                	test   %al,%al
   f0a08:	0f 85 12 ff ff ff    	jne    f0920 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f0a0e:	8b 44 24 44          	mov    0x44(%rsp),%eax
   f0a12:	41 89 de             	mov    %ebx,%r14d
   f0a15:	48 89 c6             	mov    %rax,%rsi
   f0a18:	48 c1 e0 05          	shl    $0x5,%rax
   f0a1c:	48 01 e8             	add    %rbp,%rax
   f0a1f:	48 89 d9             	mov    %rbx,%rcx
   f0a22:	48 c1 e1 05          	shl    $0x5,%rcx
   f0a26:	48 8b 7c 0d 10       	mov    0x10(%rbp,%rcx,1),%rdi
   f0a2b:	48 39 78 10          	cmp    %rdi,0x10(%rax)
   f0a2f:	72 8f                	jb     f09c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e0>
   f0a31:	48 83 c3 01          	add    $0x1,%rbx
   f0a35:	39 d3                	cmp    %edx,%ebx
   f0a37:	0f 83 6b fd ff ff    	jae    f07a8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c8>
   f0a3d:	41 89 de             	mov    %ebx,%r14d
   f0a40:	eb dd                	jmp    f0a1f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x83f>
   f0a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f0a48:	4c 8d 69 01          	lea    0x1(%rcx),%r13
   f0a4c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   f0a51:	4c 39 ed             	cmp    %r13,%rbp
   f0a54:	0f 84 85 fe ff ff    	je     f08df <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x6ff>
   f0a5a:	4d 8b 74 13 10       	mov    0x10(%r11,%rdx,1),%r14
   f0a5f:	4c 89 ee             	mov    %r13,%rsi
   f0a62:	0f 1f 00             	nopl   (%rax)
   f0a65:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0a70:	8b 04 b3             	mov    (%rbx,%rsi,4),%eax
   f0a73:	48 89 c2             	mov    %rax,%rdx
   f0a76:	48 c1 e2 05          	shl    $0x5,%rdx
   f0a7a:	4d 39 74 13 10       	cmp    %r14,0x10(%r11,%rdx,1)
   f0a7f:	48 89 c2             	mov    %rax,%rdx
   f0a82:	49 0f 42 d0          	cmovb  %r8,%rdx
   f0a86:	49 0f 43 c0          	cmovae %r8,%rax
   f0a8a:	45 8b 14 91          	mov    (%r9,%rdx,4),%r10d
   f0a8e:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f0a92:	44 89 d2             	mov    %r10d,%edx
   f0a95:	44 39 d0             	cmp    %r10d,%eax
   f0a98:	0f 46 d0             	cmovbe %eax,%edx
   f0a9b:	48 c1 e2 20          	shl    $0x20,%rdx
   f0a9f:	44 39 d0             	cmp    %r10d,%eax
   f0aa2:	41 0f 42 c2          	cmovb  %r10d,%eax
   f0aa6:	48 83 c6 01          	add    $0x1,%rsi
   f0aaa:	48 09 c2             	or     %rax,%rdx
   f0aad:	48 89 d0             	mov    %rdx,%rax
   f0ab0:	48 c1 e8 1e          	shr    $0x1e,%rax
   f0ab4:	48 31 d0             	xor    %rdx,%rax
   f0ab7:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f0ac1:	48 0f af c2          	imul   %rdx,%rax
   f0ac5:	48 89 c2             	mov    %rax,%rdx
   f0ac8:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f0acc:	48 31 c2             	xor    %rax,%rdx
   f0acf:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f0ad9:	48 0f af d0          	imul   %rax,%rdx
   f0add:	48 89 d0             	mov    %rdx,%rax
   f0ae0:	48 c1 e8 1f          	shr    $0x1f,%rax
   f0ae4:	48 31 d0             	xor    %rdx,%rax
   f0ae7:	48 01 c7             	add    %rax,%rdi
   f0aea:	48 39 ee             	cmp    %rbp,%rsi
   f0aed:	72 81                	jb     f0a70 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x890>
   f0aef:	48 8d 45 ff          	lea    -0x1(%rbp),%rax
   f0af3:	48 83 c1 02          	add    $0x2,%rcx
   f0af7:	31 d2                	xor    %edx,%edx
   f0af9:	4c 29 e8             	sub    %r13,%rax
   f0afc:	48 39 cd             	cmp    %rcx,%rbp
   f0aff:	48 0f 42 c2          	cmovb  %rdx,%rax
   f0b03:	4d 8d 64 04 01       	lea    0x1(%r12,%rax,1),%r12
   f0b08:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f0b0d:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f0b11:	4c 89 20             	mov    %r12,(%rax)
   f0b14:	e9 ec fd ff ff       	jmp    f0905 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f0b19:	48 83 fd 01          	cmp    $0x1,%rbp
   f0b1d:	0f 86 d3 00 00 00    	jbe    f0bf6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa16>
   f0b23:	48 89 e8             	mov    %rbp,%rax
   f0b26:	31 c9                	xor    %ecx,%ecx
   f0b28:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f0b30:	48 d1 e8             	shr    $1,%rax
   f0b33:	83 c1 02             	add    $0x2,%ecx
   f0b36:	48 83 f8 01          	cmp    $0x1,%rax
   f0b3a:	75 f4                	jne    f0b30 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x950>
   f0b3c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f0b41:	48 89 ee             	mov    %rbp,%rsi
   f0b44:	48 89 df             	mov    %rbx,%rdi
   f0b47:	e8 14 cf 05 00       	call   14da60 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f0b4c:	e9 b0 fc ff ff       	jmp    f0801 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x621>
   f0b51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f0b58:	c6 84 24 90 00 00 00 0b 	movb   $0xb,0x90(%rsp)
   f0b60:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f0b65:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f0b6d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f0b75:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f0b7d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f0b85:	e9 bb fd ff ff       	jmp    f0945 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f0b8a:	e8 e1 47 00 00       	call   f5370 <_ZN8QuadTree15defaultResourceEv>
   f0b8f:	41 8b b7 d0 00 00 00 	mov    0xd0(%r15),%esi
   f0b96:	48 89 f1             	mov    %rsi,%rcx
   f0b99:	e9 26 f7 ff ff       	jmp    f02c4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xe4>
   f0b9e:	31 c9                	xor    %ecx,%ecx
   f0ba0:	e9 57 fa ff ff       	jmp    f05fc <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x41c>
   f0ba5:	31 c0                	xor    %eax,%eax
   f0ba7:	e9 0f f9 ff ff       	jmp    f04bb <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2db>
   f0bac:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f0bb4:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f0bbc:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f0bc4:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f0bcc:	e8 8f 66 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f0bd1:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f0bd9:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f0be1:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f0be9:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f0bf1:	e8 4a 4e 00 00       	call   f5a40 <_ZN8QuadTree6detail15activeWorkspaceEv>
   f0bf6:	31 c9                	xor    %ecx,%ecx
   f0bf8:	e9 3f ff ff ff       	jmp    f0b3c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x95c>
