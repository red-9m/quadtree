
# control unordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, false>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/control-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000ed1d0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   ed1d0:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   ed1d7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed1db:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   ed1e3:	48 8b 2a             	mov    (%rdx),%rbp
   ed1e6:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   ed1ee:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   ed1f2:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   ed1fa:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   ed202:	49 89 ff             	mov    %rdi,%r15
   ed205:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   ed20d:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   ed214:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   ed219:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   ed222:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   ed22a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   ed22e:	0f 11 07             	movups %xmm0,(%rdi)
   ed231:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   ed235:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   ed239:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   ed23d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   ed241:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   ed245:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   ed249:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   ed24d:	48 89 14 24          	mov    %rdx,(%rsp)
   ed251:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   ed255:	e8 46 10 06 00       	call   14e2a0 <_ZN5bench6memory11allocationsEv>
   ed25a:	80 3d 17 10 08 00 00 	cmpb   $0x0,0x81017(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ed261:	4c 8b 1c 24          	mov    (%rsp),%r11
   ed265:	49 89 c6             	mov    %rax,%r14
   ed268:	0f 84 31 0e 00 00    	je     ee09f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xecf>
   ed26e:	0f 31                	rdtsc
   ed270:	48 c1 e2 20          	shl    $0x20,%rdx
   ed274:	48 09 d0             	or     %rdx,%rax
   ed277:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   ed27f:	49 8b 13             	mov    (%r11),%rdx
   ed282:	49 3b 53 08          	cmp    0x8(%r11),%rdx
   ed286:	0f 84 ff 08 00 00    	je     edb8b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9bb>
   ed28c:	49 29 ec             	sub    %rbp,%r12
   ed28f:	48 c7 04 24 00 00 00 00 	movq   $0x0,(%rsp)
   ed297:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ed29b:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   ed2a3:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   ed2ab:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   ed2b4:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   ed2bd:	c7 44 24 1c 00 00 00 00 	movl   $0x0,0x1c(%rsp)
   ed2c5:	4c 89 9c 24 88 00 00 00 	mov    %r11,0x88(%rsp)
   ed2cd:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   ed2d5:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   ed2dd:	45 31 ed             	xor    %r13d,%r13d
   ed2e0:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   ed2e8:	45 31 f6             	xor    %r14d,%r14d
   ed2eb:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   ed2f0:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   ed2f5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ed300:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   ed305:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed309:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   ed30d:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   ed315:	48 8b 28             	mov    (%rax),%rbp
   ed318:	4c 8b 60 08          	mov    0x8(%rax),%r12
   ed31c:	49 29 ec             	sub    %rbp,%r12
   ed31f:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
   ed324:	49 c1 fc 04          	sar    $0x4,%r12
   ed328:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   ed32f:	74 13                	je     ed344 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x174>
   ed331:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ed338:	3b 83 b8 02 00 00    	cmp    0x2b8(%rbx),%eax
   ed33e:	0f 84 b8 05 00 00    	je     ed8fc <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x72c>
   ed344:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   ed34c:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed350:	31 f6                	xor    %esi,%esi
   ed352:	66 0f 6f 3d 66 a5 06 00 	movdqa 0x6a566(%rip),%xmm7        # 1578c0 <C.66.5+0x2a0>
   ed35a:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   ed362:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ed36a:	ba 88 01 00 00       	mov    $0x188,%edx
   ed36f:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   ed376:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   ed37b:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   ed383:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   ed38b:	66 48 0f 6e c0       	movq   %rax,%xmm0
   ed390:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   ed398:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   ed39c:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   ed3a5:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   ed3ad:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   ed3b6:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   ed3be:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   ed3c7:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   ed3cf:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   ed3d7:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   ed3dc:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   ed3e4:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   ed3e9:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   ed3f1:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   ed3f6:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   ed3fe:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   ed40a:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   ed416:	e8 f5 9c f1 ff       	call   7110 <memset@plt>
   ed41b:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   ed421:	66 0f ef c9          	pxor   %xmm1,%xmm1
   ed425:	66 0f 6f 05 a3 a4 06 00 	movdqa 0x6a4a3(%rip),%xmm0        # 1578d0 <C.66.5+0x2b0>
   ed42d:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   ed433:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   ed439:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ed43d:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ed444:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   ed44c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ed451:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   ed459:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   ed461:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   ed469:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   ed475:	48 89 9c 24 d8 01 00 00 	mov    %rbx,0x1d8(%rsp)
   ed47d:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   ed489:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   ed495:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   ed4a1:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   ed4ad:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   ed4b9:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   ed4c4:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   ed4cc:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   ed4d7:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   ed4e3:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   ed4eb:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   ed4f7:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   ed502:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   ed50a:	48 89 9c 24 78 02 00 00 	mov    %rbx,0x278(%rsp)
   ed512:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   ed51e:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   ed52a:	48 89 9c 24 90 02 00 00 	mov    %rbx,0x290(%rsp)
   ed532:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   ed53e:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   ed546:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   ed54e:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   ed556:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   ed55e:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   ed566:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   ed572:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   ed57a:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   ed583:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   ed58b:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   ed593:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   ed59c:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   ed5a4:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   ed5ac:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   ed5b5:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   ed5bd:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ed5c4:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   ed5cc:	48 89 9c 24 a8 02 00 00 	mov    %rbx,0x2a8(%rsp)
   ed5d4:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   ed5e0:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   ed5ec:	48 89 9c 24 c0 02 00 00 	mov    %rbx,0x2c0(%rsp)
   ed5f4:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   ed600:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   ed60c:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   ed618:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   ed623:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   ed62f:	48 89 9c 24 60 03 00 00 	mov    %rbx,0x360(%rsp)
   ed637:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   ed642:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   ed64d:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   ed659:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   ed661:	48 89 9c 24 00 04 00 00 	mov    %rbx,0x400(%rsp)
   ed669:	48 89 9c 24 18 04 00 00 	mov    %rbx,0x418(%rsp)
   ed671:	48 89 9c 24 30 04 00 00 	mov    %rbx,0x430(%rsp)
   ed679:	48 89 9c 24 48 04 00 00 	mov    %rbx,0x448(%rsp)
   ed681:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   ed689:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   ed691:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   ed699:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   ed6a1:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ed6a9:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   ed6b0:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   ed6b9:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   ed6c4:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   ed6cb:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   ed6d2:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   ed6dd:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   ed6e4:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   ed6ec:	e8 2f 04 01 00       	call   fdb20 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ed6f1:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   ed6f8:	0f 85 72 06 00 00    	jne    edd70 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   ed6fe:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   ed707:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   ed70f:	48 89 5b 50          	mov    %rbx,0x50(%rbx)
   ed713:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   ed71b:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   ed724:	c6 83 ec 00 00 00 00 	movb   $0x0,0xec(%rbx)
   ed72b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
   ed72f:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   ed738:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   ed740:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   ed744:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   ed74d:	48 89 43 48          	mov    %rax,0x48(%rbx)
   ed751:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ed758:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
   ed75c:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   ed765:	48 89 83 98 00 00 00 	mov    %rax,0x98(%rbx)
   ed76c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ed771:	0f 11 43 38          	movups %xmm0,0x38(%rbx)
   ed775:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed779:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
   ed780:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   ed789:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
   ed790:	0f 11 83 a8 00 00 00 	movups %xmm0,0xa8(%rbx)
   ed797:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   ed79f:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   ed7a8:	48 c7 43 58 00 00 00 00 	movq   $0x0,0x58(%rbx)
   ed7b0:	0f 11 83 b1 00 00 00 	movups %xmm0,0xb1(%rbx)
   ed7b7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed7bb:	0f 11 83 d0 00 00 00 	movups %xmm0,0xd0(%rbx)
   ed7c2:	48 c7 43 60 00 00 00 00 	movq   $0x0,0x60(%rbx)
   ed7ca:	48 c7 43 68 00 00 00 00 	movq   $0x0,0x68(%rbx)
   ed7d2:	48 c7 43 70 00 00 00 00 	movq   $0x0,0x70(%rbx)
   ed7da:	48 c7 43 78 00 00 00 00 	movq   $0x0,0x78(%rbx)
   ed7e2:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   ed7ec:	c6 83 94 00 00 00 00 	movb   $0x0,0x94(%rbx)
   ed7f3:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   ed7fd:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   ed808:	c7 83 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%rbx)
   ed812:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   ed819:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   ed822:	48 89 9b f0 00 00 00 	mov    %rbx,0xf0(%rbx)
   ed829:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
   ed82f:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   ed836:	48 c7 83 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rbx)
   ed841:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   ed848:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ed84d:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   ed854:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ed85b:	48 c7 83 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rbx)
   ed866:	48 89 9b 08 01 00 00 	mov    %rbx,0x108(%rbx)
   ed86d:	48 c7 83 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rbx)
   ed878:	48 c7 83 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rbx)
   ed883:	48 89 9b 20 01 00 00 	mov    %rbx,0x120(%rbx)
   ed88a:	48 c7 83 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rbx)
   ed895:	48 c7 83 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rbx)
   ed8a0:	48 89 9b 38 01 00 00 	mov    %rbx,0x138(%rbx)
   ed8a7:	48 c7 83 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rbx)
   ed8b2:	48 c7 83 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rbx)
   ed8bd:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   ed8c8:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   ed8d2:	c6 83 80 01 00 00 01 	movb   $0x1,0x180(%rbx)
   ed8d9:	89 83 b8 02 00 00    	mov    %eax,0x2b8(%rbx)
   ed8df:	0f 11 83 50 01 00 00 	movups %xmm0,0x150(%rbx)
   ed8e6:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   ed8ef:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ed8f7:	e8 24 02 01 00       	call   fdb20 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ed8fc:	4c 39 a3 c0 02 00 00 	cmp    %r12,0x2c0(%rbx)
   ed903:	0f 82 27 04 00 00    	jb     edd30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb60>
   ed909:	48 8b 93 78 02 00 00 	mov    0x278(%rbx),%rdx
   ed910:	4c 8b 93 70 02 00 00 	mov    0x270(%rbx),%r10
   ed917:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   ed921:	48 89 d1             	mov    %rdx,%rcx
   ed924:	4c 29 d1             	sub    %r10,%rcx
   ed927:	48 89 c8             	mov    %rcx,%rax
   ed92a:	48 c1 f8 03          	sar    $0x3,%rax
   ed92e:	48 0f af c7          	imul   %rdi,%rax
   ed932:	4c 39 e0             	cmp    %r12,%rax
   ed935:	0f 82 85 03 00 00    	jb     edcc0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf0>
   ed93b:	49 39 c4             	cmp    %rax,%r12
   ed93e:	73 16                	jae    ed956 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   ed940:	49 6b c4 38          	imul   $0x38,%r12,%rax
   ed944:	49 01 c2             	add    %rax,%r10
   ed947:	4c 39 d2             	cmp    %r10,%rdx
   ed94a:	74 07                	je     ed953 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x783>
   ed94c:	4c 89 93 78 02 00 00 	mov    %r10,0x278(%rbx)
   ed953:	4c 89 d2             	mov    %r10,%rdx
   ed956:	48 8b b3 70 02 00 00 	mov    0x270(%rbx),%rsi
   ed95d:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   ed963:	74 4c                	je     ed9b1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7e1>
   ed965:	48 89 f0             	mov    %rsi,%rax
   ed968:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed96c:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   ed970:	31 c9                	xor    %ecx,%ecx
   ed972:	0f 1f 00             	nopl   (%rax)
   ed975:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ed980:	f3 0f 6f 4d 00       	movdqu 0x0(%rbp),%xmm1
   ed985:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   ed989:	48 83 c5 10          	add    $0x10,%rbp
   ed98d:	48 83 c0 38          	add    $0x38,%rax
   ed991:	89 48 d8             	mov    %ecx,-0x28(%rax)
   ed994:	48 83 c1 01          	add    $0x1,%rcx
   ed998:	0f 11 40 e8          	movups %xmm0,-0x18(%rax)
   ed99c:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   ed9a4:	0f 11 48 c8          	movups %xmm1,-0x38(%rax)
   ed9a8:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
   ed9ac:	4c 39 e1             	cmp    %r12,%rcx
   ed9af:	72 cf                	jb     ed980 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7b0>
   ed9b1:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   ed9bd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed9c1:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   ed9c9:	48 39 d6             	cmp    %rdx,%rsi
   ed9cc:	0f 84 b6 03 00 00    	je     edd88 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbb8>
   ed9d2:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   ed9dc:	48 29 f2             	sub    %rsi,%rdx
   ed9df:	48 c1 fa 03          	sar    $0x3,%rdx
   ed9e3:	48 0f af d0          	imul   %rax,%rdx
   ed9e7:	48 39 53 38          	cmp    %rdx,0x38(%rbx)
   ed9eb:	0f 82 1f 04 00 00    	jb     ede10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc40>
   ed9f1:	48 83 ec 20          	sub    $0x20,%rsp
   ed9f5:	48 8d 8b 88 01 00 00 	lea    0x188(%rbx),%rcx
   ed9fc:	48 8d b3 70 02 00 00 	lea    0x270(%rbx),%rsi
   eda03:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   eda0c:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   eda10:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   eda19:	0f 11 04 24          	movups %xmm0,(%rsp)
   eda1d:	e8 0e 3a fe ff       	call   d1430 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   eda22:	48 83 c4 20          	add    $0x20,%rsp
   eda26:	84 c0                	test   %al,%al
   eda28:	0f 85 bc 06 00 00    	jne    ee0ea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf1a>
   eda2e:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   eda37:	0f 84 e3 01 00 00    	je     edc20 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa50>
   eda3d:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   eda42:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   eda4a:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   eda52:	48 89 de             	mov    %rbx,%rsi
   eda55:	e8 f6 f0 ff ff       	call   ecb50 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   eda5a:	8b 74 24 1c          	mov    0x1c(%rsp),%esi
   eda5e:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   eda65:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   eda6f:	48 8b bc 24 38 03 00 00 	mov    0x338(%rsp),%rdi
   eda77:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   eda7d:	39 c6                	cmp    %eax,%esi
   eda7f:	48 8b 94 24 c8 00 00 00 	mov    0xc8(%rsp),%rdx
   eda87:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   eda90:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   eda99:	0f 43 c6             	cmovae %esi,%eax
   eda9c:	48 01 3c 24          	add    %rdi,(%rsp)
   edaa0:	48 8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%rdi
   edaa8:	48 01 7c 24 08       	add    %rdi,0x8(%rsp)
   edaad:	4c 01 ea             	add    %r13,%rdx
   edab0:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   edab4:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   edab8:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   edac1:	41 89 47 38          	mov    %eax,0x38(%r15)
   edac5:	48 8b 04 24          	mov    (%rsp),%rax
   edac9:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   edacd:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   edad3:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   edad8:	49 89 47 40          	mov    %rax,0x40(%r15)
   edadc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   edae1:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   edae6:	49 89 47 48          	mov    %rax,0x48(%r15)
   edaea:	48 89 d0             	mov    %rdx,%rax
   edaed:	48 c1 e8 1e          	shr    $0x1e,%rax
   edaf1:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   edaf6:	48 31 d0             	xor    %rdx,%rax
   edaf9:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   edafe:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   edb08:	48 0f af c2          	imul   %rdx,%rax
   edb0c:	48 89 c2             	mov    %rax,%rdx
   edb0f:	48 c1 ea 1b          	shr    $0x1b,%rdx
   edb13:	48 31 d0             	xor    %rdx,%rax
   edb16:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   edb20:	48 0f af c2          	imul   %rdx,%rax
   edb24:	48 89 c2             	mov    %rax,%rdx
   edb27:	48 c1 ea 1f          	shr    $0x1f,%rdx
   edb2b:	48 31 d0             	xor    %rdx,%rax
   edb2e:	48 01 44 24 10       	add    %rax,0x10(%rsp)
   edb33:	45 84 f6             	test   %r14b,%r14b
   edb36:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   edb3b:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   edb43:	49 89 77 50          	mov    %rsi,0x50(%r15)
   edb47:	44 0f 44 f0          	cmove  %eax,%r14d
   edb4b:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   edb53:	49 83 c5 01          	add    $0x1,%r13
   edb57:	48 8b 10             	mov    (%rax),%rdx
   edb5a:	45 88 77 68          	mov    %r14b,0x68(%r15)
   edb5e:	48 8b 40 08          	mov    0x8(%rax),%rax
   edb62:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   edb67:	48 29 d0             	sub    %rdx,%rax
   edb6a:	48 c1 f8 03          	sar    $0x3,%rax
   edb6e:	48 0f af c1          	imul   %rcx,%rax
   edb72:	49 39 c5             	cmp    %rax,%r13
   edb75:	0f 82 85 f7 ff ff    	jb     ed300 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   edb7b:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   edb83:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   edb8b:	80 3d e6 06 08 00 00 	cmpb   $0x0,0x806e6(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   edb92:	0f 84 21 05 00 00    	je     ee0b9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xee9>
   edb98:	0f 31                	rdtsc
   edb9a:	48 c1 e2 20          	shl    $0x20,%rdx
   edb9e:	48 09 d0             	or     %rdx,%rax
   edba1:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   edba9:	0f 88 d2 04 00 00    	js     ee081 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xeb1>
   edbaf:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edbb3:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   edbb8:	f2 0f 59 05 70 06 08 00 	mulsd  0x80670(%rip),%xmm0        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   edbc0:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   edbc5:	49 89 07             	mov    %rax,(%r15)
   edbc8:	e8 d3 06 06 00       	call   14e2a0 <_ZN5bench6memory11allocationsEv>
   edbcd:	4c 29 f0             	sub    %r14,%rax
   edbd0:	49 89 47 58          	mov    %rax,0x58(%r15)
   edbd4:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   edbdc:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   edbe5:	0f 85 f2 04 00 00    	jne    ee0dd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf0d>
   edbeb:	4c 89 f8             	mov    %r15,%rax
   edbee:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   edbf6:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   edbfe:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   edc06:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   edc0e:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   edc16:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   edc1d:	c3                   	ret
   edc1e:	66 90                	xchg   %ax,%ax
   edc20:	80 3d 51 06 08 00 00 	cmpb   $0x0,0x80651(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   edc27:	0f 84 db 03 00 00    	je     ee008 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe38>
   edc2d:	0f 31                	rdtsc
   edc2f:	48 c1 e2 20          	shl    $0x20,%rdx
   edc33:	48 09 d0             	or     %rdx,%rax
   edc36:	48 89 c5             	mov    %rax,%rbp
   edc39:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   edc3e:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   edc46:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   edc4e:	48 89 de             	mov    %rbx,%rsi
   edc51:	e8 fa ee ff ff       	call   ecb50 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   edc56:	f2 0f 10 0d d2 05 08 00 	movsd  0x805d2(%rip),%xmm1        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   edc5e:	48 89 e8             	mov    %rbp,%rax
   edc61:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   edc69:	0f 88 61 03 00 00    	js     edfd0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe00>
   edc6f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edc73:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   edc78:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   edc7c:	80 3d f5 05 08 00 00 	cmpb   $0x0,0x805f5(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   edc83:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   edc88:	49 89 47 08          	mov    %rax,0x8(%r15)
   edc8c:	0f 84 5e 03 00 00    	je     edff0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe20>
   edc92:	0f 31                	rdtsc
   edc94:	48 c1 e2 20          	shl    $0x20,%rdx
   edc98:	48 09 d0             	or     %rdx,%rax
   edc9b:	48 29 e8             	sub    %rbp,%rax
   edc9e:	0f 88 0c 03 00 00    	js     edfb0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xde0>
   edca4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edca8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   edcad:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   edcb1:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   edcb6:	49 89 47 10          	mov    %rax,0x10(%r15)
   edcba:	e9 9b fd ff ff       	jmp    eda5a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x88a>
   edcbf:	90                   	nop
   edcc0:	48 8b b3 80 02 00 00 	mov    0x280(%rbx),%rsi
   edcc7:	4d 89 e3             	mov    %r12,%r11
   edcca:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   edcd4:	49 29 c3             	sub    %rax,%r11
   edcd7:	48 89 f7             	mov    %rsi,%rdi
   edcda:	48 29 d7             	sub    %rdx,%rdi
   edcdd:	48 c1 ff 03          	sar    $0x3,%rdi
   edce1:	49 0f af f9          	imul   %r9,%rdi
   edce5:	4c 39 df             	cmp    %r11,%rdi
   edce8:	0f 82 42 01 00 00    	jb     ede30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc60>
   edcee:	4c 89 d9             	mov    %r11,%rcx
   edcf1:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edcf5:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   edcf9:	48 89 d0             	mov    %rdx,%rax
   edcfc:	0f 1f 40 00          	nopl   0x0(%rax)
   edd00:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   edd04:	48 83 c0 38          	add    $0x38,%rax
   edd08:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   edd0c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   edd10:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   edd14:	48 83 e9 01          	sub    $0x1,%rcx
   edd18:	75 e6                	jne    edd00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb30>
   edd1a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   edd1e:	4c 01 da             	add    %r11,%rdx
   edd21:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   edd28:	e9 29 fc ff ff       	jmp    ed956 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   edd2d:	0f 1f 00             	nopl   (%rax)
   edd30:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edd34:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   edd3c:	48 8d bb 88 01 00 00 	lea    0x188(%rbx),%rdi
   edd43:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   edd4b:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   edd53:	e8 a8 48 02 00       	call   112600 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   edd58:	84 c0                	test   %al,%al
   edd5a:	0f 85 8a 03 00 00    	jne    ee0ea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf1a>
   edd60:	4c 89 a3 c0 02 00 00 	mov    %r12,0x2c0(%rbx)
   edd67:	e9 9d fb ff ff       	jmp    ed909 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x739>
   edd6c:	0f 1f 40 00          	nopl   0x0(%rax)
   edd70:	c6 83 80 01 00 00 00 	movb   $0x0,0x180(%rbx)
   edd77:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   edd7b:	e8 a0 fd 00 00       	call   fdb20 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   edd80:	e9 79 f9 ff ff       	jmp    ed6fe <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x52e>
   edd85:	0f 1f 00             	nopl   (%rax)
   edd88:	48 83 bb c8 00 00 00 00 	cmpq   $0x0,0xc8(%rbx)
   edd90:	74 55                	je     edde7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc17>
   edd92:	48 8b 93 80 00 00 00 	mov    0x80(%rbx),%rdx
   edd99:	48 85 d2             	test   %rdx,%rdx
   edd9c:	0f 85 73 02 00 00    	jne    ee015 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe45>
   edda2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   edda7:	66 0f 6f 05 d1 9a 06 00 	movdqa 0x69ad1(%rip),%xmm0        # 157880 <C.66.5+0x260>
   eddaf:	c7 83 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%rbx)
   eddb9:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   eddc4:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   eddcb:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   eddd6:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   edde0:	0f 11 83 dc 00 00 00 	movups %xmm0,0xdc(%rbx)
   edde7:	80 7b 08 00          	cmpb   $0x0,0x8(%rbx)
   eddeb:	0f 84 3d fc ff ff    	je     eda2e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x85e>
   eddf1:	80 bb 60 01 00 00 00 	cmpb   $0x0,0x160(%rbx)
   eddf8:	0f 84 30 fc ff ff    	je     eda2e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x85e>
   eddfe:	c6 83 60 01 00 00 00 	movb   $0x0,0x160(%rbx)
   ede05:	e9 24 fc ff ff       	jmp    eda2e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x85e>
   ede0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ede10:	ba 10 00 00 00       	mov    $0x10,%edx
   ede15:	48 8b 3d 44 04 08 00 	mov    0x80444(%rip),%rdi        # 16e260 <stderr@GLIBC_2.2.5>
   ede1c:	48 8d 35 7d 7b 06 00 	lea    0x67b7d(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   ede23:	31 c0                	xor    %eax,%eax
   ede25:	e8 16 95 f1 ff       	call   7340 <fprintf@plt>
   ede2a:	e8 f1 92 f1 ff       	call   7120 <abort@plt>
   ede2f:	90                   	nop
   ede30:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   ede3a:	48 29 c7             	sub    %rax,%rdi
   ede3d:	4c 39 df             	cmp    %r11,%rdi
   ede40:	0f 82 20 ef f1 ff    	jb     cd66 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   ede46:	4c 39 d8             	cmp    %r11,%rax
   ede49:	4c 89 df             	mov    %r11,%rdi
   ede4c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   ede54:	48 0f 43 f8          	cmovae %rax,%rdi
   ede58:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   ede60:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   ede68:	48 01 c7             	add    %rax,%rdi
   ede6b:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   ede70:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   ede7a:	48 39 c7             	cmp    %rax,%rdi
   ede7d:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   ede82:	48 0f 47 f8          	cmova  %rax,%rdi
   ede86:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   ede8a:	48 89 c7             	mov    %rax,%rdi
   ede8d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   ede92:	e8 e9 04 06 00       	call   14e380 <_Znwm>
   ede97:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   ede9d:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   edea5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edea9:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   edeae:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   edeb6:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   edeba:	48 01 c1             	add    %rax,%rcx
   edebd:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   edec5:	49 01 cb             	add    %rcx,%r11
   edec8:	66 90                	xchg   %ax,%ax
   edeca:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eded5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edee0:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   edee4:	48 83 c1 38          	add    $0x38,%rcx
   edee8:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   edeec:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   edef0:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   edef4:	4c 39 d9             	cmp    %r11,%rcx
   edef7:	75 e7                	jne    edee0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd10>
   edef9:	4c 39 d2             	cmp    %r10,%rdx
   edefc:	74 71                	je     edf6f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd9f>
   edefe:	4c 89 d1             	mov    %r10,%rcx
   edf01:	48 89 c7             	mov    %rax,%rdi
   edf04:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   edf09:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edf14:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edf1f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edf2a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edf35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edf40:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   edf44:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   edf48:	48 83 c1 38          	add    $0x38,%rcx
   edf4c:	48 83 c7 38          	add    $0x38,%rdi
   edf50:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   edf54:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   edf59:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   edf5d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   edf61:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   edf66:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   edf6a:	48 39 ca             	cmp    %rcx,%rdx
   edf6d:	75 d1                	jne    edf40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd70>
   edf6f:	4d 85 d2             	test   %r10,%r10
   edf72:	74 15                	je     edf89 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdb9>
   edf74:	4c 29 d6             	sub    %r10,%rsi
   edf77:	4c 89 d7             	mov    %r10,%rdi
   edf7a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   edf7f:	e8 fc 04 06 00       	call   14e480 <_ZdlPvm>
   edf84:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   edf89:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   edf8d:	48 89 83 70 02 00 00 	mov    %rax,0x270(%rbx)
   edf94:	48 01 c2             	add    %rax,%rdx
   edf97:	48 03 44 24 40       	add    0x40(%rsp),%rax
   edf9c:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   edfa3:	48 89 83 80 02 00 00 	mov    %rax,0x280(%rbx)
   edfaa:	e9 a7 f9 ff ff       	jmp    ed956 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   edfaf:	90                   	nop
   edfb0:	48 89 c2             	mov    %rax,%rdx
   edfb3:	83 e0 01             	and    $0x1,%eax
   edfb6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edfba:	48 d1 ea             	shr    $1,%rdx
   edfbd:	48 09 c2             	or     %rax,%rdx
   edfc0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   edfc5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   edfc9:	e9 df fc ff ff       	jmp    edcad <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xadd>
   edfce:	66 90                	xchg   %ax,%ax
   edfd0:	48 89 c2             	mov    %rax,%rdx
   edfd3:	83 e0 01             	and    $0x1,%eax
   edfd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edfda:	48 d1 ea             	shr    $1,%rdx
   edfdd:	48 09 c2             	or     %rax,%rdx
   edfe0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   edfe5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   edfe9:	e9 8a fc ff ff       	jmp    edc78 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa8>
   edfee:	66 90                	xchg   %ax,%ax
   edff0:	e8 db 92 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   edff5:	f2 0f 10 0d 33 02 08 00 	movsd  0x80233(%rip),%xmm1        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   edffd:	e9 99 fc ff ff       	jmp    edc9b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xacb>
   ee002:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ee008:	e8 c3 92 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   ee00d:	48 89 c5             	mov    %rax,%rbp
   ee010:	e9 24 fc ff ff       	jmp    edc39 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa69>
   ee015:	48 c7 83 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%rbx)
   ee020:	80 bb 94 00 00 00 00 	cmpb   $0x0,0x94(%rbx)
   ee027:	0f 85 96 00 00 00    	jne    ee0c3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef3>
   ee02d:	8b 83 90 00 00 00    	mov    0x90(%rbx),%eax
   ee033:	83 c0 01             	add    $0x1,%eax
   ee036:	89 83 90 00 00 00    	mov    %eax,0x90(%rbx)
   ee03c:	83 f8 ff             	cmp    $0xffffffff,%eax
   ee03f:	0f 85 5d fd ff ff    	jne    edda2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd2>
   ee045:	48 8b 43 78          	mov    0x78(%rbx),%rax
   ee049:	48 89 d1             	mov    %rdx,%rcx
   ee04c:	48 c1 e1 04          	shl    $0x4,%rcx
   ee050:	48 01 c1             	add    %rax,%rcx
   ee053:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   ee05a:	48 83 c0 10          	add    $0x10,%rax
   ee05e:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   ee066:	48 39 c8             	cmp    %rcx,%rax
   ee069:	75 e8                	jne    ee053 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe83>
   ee06b:	48 01 93 b0 00 00 00 	add    %rdx,0xb0(%rbx)
   ee072:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   ee07c:	e9 21 fd ff ff       	jmp    edda2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd2>
   ee081:	48 89 c2             	mov    %rax,%rdx
   ee084:	83 e0 01             	and    $0x1,%eax
   ee087:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee08b:	48 d1 ea             	shr    $1,%rdx
   ee08e:	48 09 c2             	or     %rax,%rdx
   ee091:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   ee096:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   ee09a:	e9 19 fb ff ff       	jmp    edbb8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9e8>
   ee09f:	4c 89 1c 24          	mov    %r11,(%rsp)
   ee0a3:	e8 38 30 f2 ff       	call   110e0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   ee0a8:	4c 8b 1c 24          	mov    (%rsp),%r11
   ee0ac:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   ee0b4:	e9 c6 f1 ff ff       	jmp    ed27f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf>
   ee0b9:	e8 22 30 f2 ff       	call   110e0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   ee0be:	e9 de fa ff ff       	jmp    edba1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9d1>
   ee0c3:	48 c7 83 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rbx)
   ee0ce:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   ee0d8:	e9 c5 fc ff ff       	jmp    edda2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd2>
   ee0dd:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   ee0e5:	e8 76 91 f1 ff       	call   7260 <__stack_chk_fail@plt>
   ee0ea:	0f b6 d0             	movzbl %al,%edx
   ee0ed:	e9 23 fd ff ff       	jmp    ede15 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc45>

# control ordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, true>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/control-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f10a0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f10a0:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f10a7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f10ab:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f10b3:	48 8b 2a             	mov    (%rdx),%rbp
   f10b6:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f10be:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f10c2:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f10ca:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f10d2:	49 89 ff             	mov    %rdi,%r15
   f10d5:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f10dd:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f10e4:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f10e9:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f10f2:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f10fa:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f10fe:	0f 11 07             	movups %xmm0,(%rdi)
   f1101:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f1105:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f1109:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f110d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f1111:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f1115:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f1119:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f111d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   f1122:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f1126:	e8 75 d1 05 00       	call   14e2a0 <_ZN5bench6memory11allocationsEv>
   f112b:	80 3d 46 d1 07 00 00 	cmpb   $0x0,0x7d146(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1132:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f1137:	49 89 c6             	mov    %rax,%r14
   f113a:	0f 84 a3 0e 00 00    	je     f1fe3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf43>
   f1140:	0f 31                	rdtsc
   f1142:	48 c1 e2 20          	shl    $0x20,%rdx
   f1146:	48 09 d0             	or     %rdx,%rax
   f1149:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f1151:	49 8b 11             	mov    (%r9),%rdx
   f1154:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   f1158:	0f 84 4b 09 00 00    	je     f1aa9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa09>
   f115e:	49 29 ec             	sub    %rbp,%r12
   f1161:	c6 44 24 77 00       	movb   $0x0,0x77(%rsp)
   f1166:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f116e:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f1172:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f117a:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   f1183:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f118c:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f1195:	c7 44 24 70 00 00 00 00 	movl   $0x0,0x70(%rsp)
   f119d:	4c 89 8c 24 88 00 00 00 	mov    %r9,0x88(%rsp)
   f11a5:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f11ad:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   f11b5:	49 89 de             	mov    %rbx,%r14
   f11b8:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f11c0:	45 31 ed             	xor    %r13d,%r13d
   f11c3:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f11c8:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f11cd:	0f 1f 00             	nopl   (%rax)
   f11d0:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   f11d5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f11d9:	48 8b 28             	mov    (%rax),%rbp
   f11dc:	48 8b 58 08          	mov    0x8(%rax),%rbx
   f11e0:	48 29 eb             	sub    %rbp,%rbx
   f11e3:	49 89 dc             	mov    %rbx,%r12
   f11e6:	49 c1 fc 04          	sar    $0x4,%r12
   f11ea:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f11f2:	74 14                	je     f1208 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x168>
   f11f4:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f11fb:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   f1202:	0f 84 cb 05 00 00    	je     f17d3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x733>
   f1208:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f1210:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1214:	31 f6                	xor    %esi,%esi
   f1216:	66 0f 6f 3d a2 66 06 00 	movdqa 0x666a2(%rip),%xmm7        # 1578c0 <C.66.5+0x2a0>
   f121e:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f1226:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f122e:	ba 88 01 00 00       	mov    $0x188,%edx
   f1233:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f123a:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f123f:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f1247:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f124f:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f1254:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f125c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f1260:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f1269:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f1271:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f127a:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f1282:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f128b:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f1293:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f129b:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f12a0:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f12a8:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f12ad:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f12b5:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f12ba:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f12c2:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f12ce:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f12da:	e8 31 5e f1 ff       	call   7110 <memset@plt>
   f12df:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f12e5:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f12e9:	66 0f 6f 05 df 65 06 00 	movdqa 0x665df(%rip),%xmm0        # 1578d0 <C.66.5+0x2b0>
   f12f1:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f12f7:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f12fd:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f1301:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1308:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f1310:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1315:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f131d:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f1325:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f132d:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f1339:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   f1341:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f134d:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f1359:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f1365:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f1371:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f137d:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f1388:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f1390:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f139b:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f13a7:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f13af:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f13bb:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f13c6:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f13ce:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   f13d6:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f13e2:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f13ee:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   f13f6:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f1402:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f140a:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f1412:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f141a:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f1422:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f142a:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f1436:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f143e:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f1447:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f144f:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f1457:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f1460:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f1468:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f1470:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f1479:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f1481:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1488:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f1490:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   f1498:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f14a4:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f14b0:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   f14b8:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f14c4:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f14d0:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f14dc:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f14e7:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f14f3:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   f14fb:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f1506:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f1511:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f151d:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f1525:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   f152d:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   f1535:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   f153d:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   f1545:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f154d:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f1555:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f155d:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f1565:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f156d:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f1574:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f157d:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f1588:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f158f:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f1596:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f15a1:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f15a8:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f15b0:	e8 6b c5 00 00       	call   fdb20 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f15b5:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f15bd:	0f 85 f5 06 00 00    	jne    f1cb8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc18>
   f15c3:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f15cc:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f15d4:	4d 89 76 50          	mov    %r14,0x50(%r14)
   f15d8:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f15e0:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f15e9:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   f15f1:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   f15f6:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f15ff:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f1607:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   f160c:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f1615:	49 89 46 48          	mov    %rax,0x48(%r14)
   f1619:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1620:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   f1625:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f162e:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   f1635:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f163a:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   f163f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1643:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   f164b:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f1654:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   f165b:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   f1663:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f166b:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f1674:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   f167c:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   f1684:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1688:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   f1690:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   f1698:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   f16a0:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   f16a8:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   f16b0:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f16bb:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   f16c3:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f16ce:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f16d9:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   f16e4:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f16eb:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f16f4:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   f16fb:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   f1702:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f1709:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   f1714:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f171b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1720:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f1727:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f172e:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   f1739:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   f1740:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   f174b:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   f1756:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   f175d:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   f1768:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   f1773:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   f177a:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   f1785:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   f1790:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f179b:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f17a6:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   f17ae:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   f17b5:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   f17bd:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f17c6:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f17ce:	e8 4d c3 00 00       	call   fdb20 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f17d3:	4d 39 a6 c0 02 00 00 	cmp    %r12,0x2c0(%r14)
   f17da:	0f 82 90 04 00 00    	jb     f1c70 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd0>
   f17e0:	49 8b 96 78 02 00 00 	mov    0x278(%r14),%rdx
   f17e7:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f17ee:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   f17f8:	48 89 d1             	mov    %rdx,%rcx
   f17fb:	4c 29 d1             	sub    %r10,%rcx
   f17fe:	48 89 c8             	mov    %rcx,%rax
   f1801:	48 c1 f8 03          	sar    $0x3,%rax
   f1805:	48 0f af c7          	imul   %rdi,%rax
   f1809:	4c 39 e0             	cmp    %r12,%rax
   f180c:	0f 82 ee 03 00 00    	jb     f1c00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb60>
   f1812:	49 39 c4             	cmp    %rax,%r12
   f1815:	73 16                	jae    f182d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f1817:	49 6b c4 38          	imul   $0x38,%r12,%rax
   f181b:	49 01 c2             	add    %rax,%r10
   f181e:	4c 39 d2             	cmp    %r10,%rdx
   f1821:	74 07                	je     f182a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   f1823:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f182a:	4c 89 d2             	mov    %r10,%rdx
   f182d:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f1834:	48 85 db             	test   %rbx,%rbx
   f1837:	0f 84 7c 00 00 00    	je     f18b9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x819>
   f183d:	4c 89 d1             	mov    %r10,%rcx
   f1840:	31 f6                	xor    %esi,%esi
   f1842:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1846:	49 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%r11
   f1850:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   f185a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1860:	41 89 f0             	mov    %esi,%r8d
   f1863:	f3 0f 6f 45 00       	movdqu 0x0(%rbp),%xmm0
   f1868:	89 71 10             	mov    %esi,0x10(%rcx)
   f186b:	48 83 c6 01          	add    $0x1,%rsi
   f186f:	41 81 f0 6b 6e 61 72 	xor    $0x72616e6b,%r8d
   f1876:	c6 41 30 01          	movb   $0x1,0x30(%rcx)
   f187a:	48 83 c5 10          	add    $0x10,%rbp
   f187e:	48 83 c1 38          	add    $0x38,%rcx
   f1882:	4c 89 c0             	mov    %r8,%rax
   f1885:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f1889:	48 c1 e8 1e          	shr    $0x1e,%rax
   f188d:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f1891:	4c 31 c0             	xor    %r8,%rax
   f1894:	49 0f af c3          	imul   %r11,%rax
   f1898:	49 89 c0             	mov    %rax,%r8
   f189b:	49 c1 e8 1b          	shr    $0x1b,%r8
   f189f:	4c 31 c0             	xor    %r8,%rax
   f18a2:	48 0f af c7          	imul   %rdi,%rax
   f18a6:	49 89 c0             	mov    %rax,%r8
   f18a9:	49 c1 e8 1f          	shr    $0x1f,%r8
   f18ad:	4c 31 c0             	xor    %r8,%rax
   f18b0:	48 89 41 f0          	mov    %rax,-0x10(%rcx)
   f18b4:	4c 39 e6             	cmp    %r12,%rsi
   f18b7:	72 a7                	jb     f1860 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f18b9:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f18c5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f18c9:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f18d1:	4c 39 d2             	cmp    %r10,%rdx
   f18d4:	0f 84 f6 03 00 00    	je     f1cd0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc30>
   f18da:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f18e4:	4c 29 d2             	sub    %r10,%rdx
   f18e7:	48 c1 fa 03          	sar    $0x3,%rdx
   f18eb:	48 0f af d0          	imul   %rax,%rdx
   f18ef:	49 39 56 38          	cmp    %rdx,0x38(%r14)
   f18f3:	0f 82 67 04 00 00    	jb     f1d60 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc0>
   f18f9:	48 83 ec 20          	sub    $0x20,%rsp
   f18fd:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   f1904:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   f190b:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f1914:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f1918:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f1921:	0f 11 04 24          	movups %xmm0,(%rsp)
   f1925:	e8 06 fb fd ff       	call   d1430 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f192a:	48 83 c4 20          	add    $0x20,%rsp
   f192e:	84 c0                	test   %al,%al
   f1930:	0f 85 fb 06 00 00    	jne    f2031 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf91>
   f1936:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f193f:	0f 84 fb 01 00 00    	je     f1b40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa0>
   f1945:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f194a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f194e:	4c 89 f6             	mov    %r14,%rsi
   f1951:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f1959:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f1961:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f1969:	e8 12 ed ff ff       	call   f0680 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f196e:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f1976:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f197e:	8b 7c 24 70          	mov    0x70(%rsp),%edi
   f1982:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f1989:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   f198d:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f1997:	48 8b b4 24 38 03 00 00 	mov    0x338(%rsp),%rsi
   f199f:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f19a5:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f19ae:	39 c7                	cmp    %eax,%edi
   f19b0:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f19b9:	0f 43 c7             	cmovae %edi,%eax
   f19bc:	48 01 74 24 08       	add    %rsi,0x8(%rsp)
   f19c1:	4c 01 64 24 10       	add    %r12,0x10(%rsp)
   f19c6:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f19ca:	89 44 24 70          	mov    %eax,0x70(%rsp)
   f19ce:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f19d2:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f19db:	41 89 47 38          	mov    %eax,0x38(%r15)
   f19df:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f19e4:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f19ea:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f19ef:	49 89 47 40          	mov    %rax,0x40(%r15)
   f19f3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f19f8:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f19fd:	49 89 47 48          	mov    %rax,0x48(%r15)
   f1a01:	48 89 d0             	mov    %rdx,%rax
   f1a04:	48 c1 e8 1e          	shr    $0x1e,%rax
   f1a08:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f1a0d:	48 31 d0             	xor    %rdx,%rax
   f1a10:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f1a15:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f1a1f:	48 0f af c2          	imul   %rdx,%rax
   f1a23:	48 89 c2             	mov    %rax,%rdx
   f1a26:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f1a2a:	48 31 d0             	xor    %rdx,%rax
   f1a2d:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f1a37:	48 0f af c2          	imul   %rdx,%rax
   f1a3b:	48 89 c2             	mov    %rax,%rdx
   f1a3e:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f1a42:	48 31 d0             	xor    %rdx,%rax
   f1a45:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   f1a4a:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   f1a4f:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f1a57:	49 89 5f 50          	mov    %rbx,0x50(%r15)
   f1a5b:	0f b6 5c 24 77       	movzbl 0x77(%rsp),%ebx
   f1a60:	84 db                	test   %bl,%bl
   f1a62:	0f 44 d8             	cmove  %eax,%ebx
   f1a65:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f1a6d:	49 83 c5 01          	add    $0x1,%r13
   f1a71:	48 8b 10             	mov    (%rax),%rdx
   f1a74:	88 5c 24 77          	mov    %bl,0x77(%rsp)
   f1a78:	41 88 5f 68          	mov    %bl,0x68(%r15)
   f1a7c:	48 8b 40 08          	mov    0x8(%rax),%rax
   f1a80:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f1a85:	48 29 d0             	sub    %rdx,%rax
   f1a88:	48 c1 f8 03          	sar    $0x3,%rax
   f1a8c:	48 0f af c1          	imul   %rcx,%rax
   f1a90:	49 39 c5             	cmp    %rax,%r13
   f1a93:	0f 82 37 f7 ff ff    	jb     f11d0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f1a99:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   f1aa1:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f1aa9:	80 3d c8 c7 07 00 00 	cmpb   $0x0,0x7c7c8(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1ab0:	0f 84 49 05 00 00    	je     f1fff <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf5f>
   f1ab6:	0f 31                	rdtsc
   f1ab8:	48 c1 e2 20          	shl    $0x20,%rdx
   f1abc:	48 09 d0             	or     %rdx,%rax
   f1abf:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f1ac7:	0f 88 f8 04 00 00    	js     f1fc5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf25>
   f1acd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1ad1:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1ad6:	f2 0f 59 05 52 c7 07 00 	mulsd  0x7c752(%rip),%xmm0        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1ade:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1ae3:	49 89 07             	mov    %rax,(%r15)
   f1ae6:	e8 b5 c7 05 00       	call   14e2a0 <_ZN5bench6memory11allocationsEv>
   f1aeb:	4c 29 f0             	sub    %r14,%rax
   f1aee:	49 89 47 58          	mov    %rax,0x58(%r15)
   f1af2:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f1afa:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f1b03:	0f 85 1b 05 00 00    	jne    f2024 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf84>
   f1b09:	4c 89 f8             	mov    %r15,%rax
   f1b0c:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f1b14:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f1b1c:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f1b24:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f1b2c:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f1b34:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f1b3b:	c3                   	ret
   f1b3c:	0f 1f 40 00          	nopl   0x0(%rax)
   f1b40:	80 3d 31 c7 07 00 00 	cmpb   $0x0,0x7c731(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1b47:	0f 84 fb 03 00 00    	je     f1f48 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xea8>
   f1b4d:	0f 31                	rdtsc
   f1b4f:	48 c1 e2 20          	shl    $0x20,%rdx
   f1b53:	48 09 d0             	or     %rdx,%rax
   f1b56:	48 89 c5             	mov    %rax,%rbp
   f1b59:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f1b5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1b62:	4c 89 f6             	mov    %r14,%rsi
   f1b65:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f1b6d:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f1b75:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f1b7d:	e8 fe ea ff ff       	call   f0680 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f1b82:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f1b8a:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f1b92:	48 89 e8             	mov    %rbp,%rax
   f1b95:	f2 0f 10 0d 93 c6 07 00 	movsd  0x7c693(%rip),%xmm1        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1b9d:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f1ba5:	0f 88 65 03 00 00    	js     f1f10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   f1bab:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1baf:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1bb4:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1bb8:	80 3d b9 c6 07 00 00 	cmpb   $0x0,0x7c6b9(%rip)        # 16e278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1bbf:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1bc4:	49 89 47 08          	mov    %rax,0x8(%r15)
   f1bc8:	0f 84 62 03 00 00    	je     f1f30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe90>
   f1bce:	0f 31                	rdtsc
   f1bd0:	48 c1 e2 20          	shl    $0x20,%rdx
   f1bd4:	48 09 d0             	or     %rdx,%rax
   f1bd7:	48 29 e8             	sub    %rbp,%rax
   f1bda:	0f 88 10 03 00 00    	js     f1ef0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe50>
   f1be0:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1be4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1be9:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1bed:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1bf2:	49 89 47 10          	mov    %rax,0x10(%r15)
   f1bf6:	e9 83 fd ff ff       	jmp    f197e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8de>
   f1bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f1c00:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   f1c07:	4d 89 e3             	mov    %r12,%r11
   f1c0a:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   f1c14:	49 29 c3             	sub    %rax,%r11
   f1c17:	48 89 f7             	mov    %rsi,%rdi
   f1c1a:	48 29 d7             	sub    %rdx,%rdi
   f1c1d:	48 c1 ff 03          	sar    $0x3,%rdi
   f1c21:	49 0f af f9          	imul   %r9,%rdi
   f1c25:	4c 39 df             	cmp    %r11,%rdi
   f1c28:	0f 82 52 01 00 00    	jb     f1d80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xce0>
   f1c2e:	4c 89 d9             	mov    %r11,%rcx
   f1c31:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1c35:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1c39:	48 89 d0             	mov    %rdx,%rax
   f1c3c:	0f 1f 40 00          	nopl   0x0(%rax)
   f1c40:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f1c44:	48 83 c0 38          	add    $0x38,%rax
   f1c48:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f1c4c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f1c50:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f1c54:	48 83 e9 01          	sub    $0x1,%rcx
   f1c58:	75 e6                	jne    f1c40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   f1c5a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f1c5e:	4c 01 da             	add    %r11,%rdx
   f1c61:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f1c68:	e9 c0 fb ff ff       	jmp    f182d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f1c6d:	0f 1f 00             	nopl   (%rax)
   f1c70:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f1c78:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   f1c7f:	4c 89 a4 24 10 03 00 00 	mov    %r12,0x310(%rsp)
   f1c87:	48 c7 84 24 18 03 00 00 00 00 00 00 	movq   $0x0,0x318(%rsp)
   f1c93:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   f1c9b:	e8 60 09 02 00       	call   112600 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f1ca0:	84 c0                	test   %al,%al
   f1ca2:	0f 85 89 03 00 00    	jne    f2031 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf91>
   f1ca8:	4d 89 a6 c0 02 00 00 	mov    %r12,0x2c0(%r14)
   f1caf:	e9 2c fb ff ff       	jmp    f17e0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x740>
   f1cb4:	0f 1f 40 00          	nopl   0x0(%rax)
   f1cb8:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   f1cc0:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f1cc4:	e8 57 be 00 00       	call   fdb20 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1cc9:	e9 f5 f8 ff ff       	jmp    f15c3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x523>
   f1cce:	66 90                	xchg   %ax,%ax
   f1cd0:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   f1cd8:	74 58                	je     f1d32 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   f1cda:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   f1ce1:	48 85 d2             	test   %rdx,%rdx
   f1ce4:	0f 85 6b 02 00 00    	jne    f1f55 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xeb5>
   f1cea:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1cef:	66 0f 6f 05 89 5b 06 00 	movdqa 0x65b89(%rip),%xmm0        # 157880 <C.66.5+0x260>
   f1cf7:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   f1d02:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f1d0d:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f1d14:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f1d1f:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f1d2a:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   f1d32:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f1d37:	0f 84 f9 fb ff ff    	je     f1936 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f1d3d:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   f1d45:	0f 84 eb fb ff ff    	je     f1936 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f1d4b:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   f1d53:	e9 de fb ff ff       	jmp    f1936 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f1d58:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1d60:	ba 10 00 00 00       	mov    $0x10,%edx
   f1d65:	48 8b 3d f4 c4 07 00 	mov    0x7c4f4(%rip),%rdi        # 16e260 <stderr@GLIBC_2.2.5>
   f1d6c:	48 8d 35 2d 3c 06 00 	lea    0x63c2d(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   f1d73:	31 c0                	xor    %eax,%eax
   f1d75:	e8 c6 55 f1 ff       	call   7340 <fprintf@plt>
   f1d7a:	e8 a1 53 f1 ff       	call   7120 <abort@plt>
   f1d7f:	90                   	nop
   f1d80:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f1d8a:	48 29 c7             	sub    %rax,%rdi
   f1d8d:	4c 39 df             	cmp    %r11,%rdi
   f1d90:	0f 82 d0 b0 f1 ff    	jb     ce66 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f1d96:	4c 39 d8             	cmp    %r11,%rax
   f1d99:	4c 89 df             	mov    %r11,%rdi
   f1d9c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f1da4:	48 0f 43 f8          	cmovae %rax,%rdi
   f1da8:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   f1db0:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f1db8:	48 01 c7             	add    %rax,%rdi
   f1dbb:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   f1dc0:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f1dca:	48 39 c7             	cmp    %rax,%rdi
   f1dcd:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f1dd2:	48 0f 47 f8          	cmova  %rax,%rdi
   f1dd6:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   f1dda:	48 89 c7             	mov    %rax,%rdi
   f1ddd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f1de2:	e8 99 c5 05 00       	call   14e380 <_Znwm>
   f1de7:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f1ded:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   f1df5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1df9:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   f1dfe:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f1e06:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1e0a:	48 01 c1             	add    %rax,%rcx
   f1e0d:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f1e15:	49 01 cb             	add    %rcx,%r11
   f1e18:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1e20:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   f1e24:	48 83 c1 38          	add    $0x38,%rcx
   f1e28:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f1e2c:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f1e30:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   f1e34:	4c 39 d9             	cmp    %r11,%rcx
   f1e37:	75 e7                	jne    f1e20 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f1e39:	4c 39 d2             	cmp    %r10,%rdx
   f1e3c:	74 71                	je     f1eaf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe0f>
   f1e3e:	4c 89 d1             	mov    %r10,%rcx
   f1e41:	48 89 c7             	mov    %rax,%rdi
   f1e44:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f1e49:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1e54:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1e5f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1e6a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1e75:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1e80:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   f1e84:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   f1e88:	48 83 c1 38          	add    $0x38,%rcx
   f1e8c:	48 83 c7 38          	add    $0x38,%rdi
   f1e90:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f1e94:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   f1e99:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   f1e9d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f1ea1:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   f1ea6:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f1eaa:	48 39 ca             	cmp    %rcx,%rdx
   f1ead:	75 d1                	jne    f1e80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xde0>
   f1eaf:	4d 85 d2             	test   %r10,%r10
   f1eb2:	74 15                	je     f1ec9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe29>
   f1eb4:	4c 29 d6             	sub    %r10,%rsi
   f1eb7:	4c 89 d7             	mov    %r10,%rdi
   f1eba:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f1ebf:	e8 bc c5 05 00       	call   14e480 <_ZdlPvm>
   f1ec4:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f1ec9:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   f1ecd:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   f1ed4:	48 01 c2             	add    %rax,%rdx
   f1ed7:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f1edc:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f1ee3:	49 89 86 80 02 00 00 	mov    %rax,0x280(%r14)
   f1eea:	e9 3e f9 ff ff       	jmp    f182d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f1eef:	90                   	nop
   f1ef0:	48 89 c2             	mov    %rax,%rdx
   f1ef3:	83 e0 01             	and    $0x1,%eax
   f1ef6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1efa:	48 d1 ea             	shr    $1,%rdx
   f1efd:	48 09 c2             	or     %rax,%rdx
   f1f00:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1f05:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1f09:	e9 db fc ff ff       	jmp    f1be9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb49>
   f1f0e:	66 90                	xchg   %ax,%ax
   f1f10:	48 89 c2             	mov    %rax,%rdx
   f1f13:	83 e0 01             	and    $0x1,%eax
   f1f16:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1f1a:	48 d1 ea             	shr    $1,%rdx
   f1f1d:	48 09 c2             	or     %rax,%rdx
   f1f20:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1f25:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1f29:	e9 86 fc ff ff       	jmp    f1bb4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb14>
   f1f2e:	66 90                	xchg   %ax,%ax
   f1f30:	e8 9b 53 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f1f35:	f2 0f 10 0d f3 c2 07 00 	movsd  0x7c2f3(%rip),%xmm1        # 16e230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1f3d:	e9 95 fc ff ff       	jmp    f1bd7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb37>
   f1f42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1f48:	e8 83 53 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f1f4d:	48 89 c5             	mov    %rax,%rbp
   f1f50:	e9 04 fc ff ff       	jmp    f1b59 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab9>
   f1f55:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   f1f60:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   f1f68:	0f 85 9b 00 00 00    	jne    f2009 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf69>
   f1f6e:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   f1f75:	83 c0 01             	add    $0x1,%eax
   f1f78:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   f1f7f:	83 f8 ff             	cmp    $0xffffffff,%eax
   f1f82:	0f 85 62 fd ff ff    	jne    f1cea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f1f88:	49 8b 46 78          	mov    0x78(%r14),%rax
   f1f8c:	48 89 d1             	mov    %rdx,%rcx
   f1f8f:	48 c1 e1 04          	shl    $0x4,%rcx
   f1f93:	48 01 c1             	add    %rax,%rcx
   f1f96:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f1f9d:	48 83 c0 10          	add    $0x10,%rax
   f1fa1:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f1fa9:	48 39 c8             	cmp    %rcx,%rax
   f1fac:	75 e8                	jne    f1f96 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef6>
   f1fae:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   f1fb5:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f1fc0:	e9 25 fd ff ff       	jmp    f1cea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f1fc5:	48 89 c2             	mov    %rax,%rdx
   f1fc8:	83 e0 01             	and    $0x1,%eax
   f1fcb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1fcf:	48 d1 ea             	shr    $1,%rdx
   f1fd2:	48 09 c2             	or     %rax,%rdx
   f1fd5:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1fda:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1fde:	e9 f3 fa ff ff       	jmp    f1ad6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa36>
   f1fe3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f1fe8:	e8 f3 f0 f1 ff       	call   110e0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f1fed:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f1ff2:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f1ffa:	e9 52 f1 ff ff       	jmp    f1151 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb1>
   f1fff:	e8 dc f0 f1 ff       	call   110e0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f2004:	e9 b6 fa ff ff       	jmp    f1abf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa1f>
   f2009:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   f2014:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f201f:	e9 c6 fc ff ff       	jmp    f1cea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f2024:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f202c:	e8 2f 52 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f2031:	0f b6 d0             	movzbl %al,%edx
   f2034:	e9 2c fd ff ff       	jmp    f1d65 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc5>

# control unordered_pairs bench::Counters bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/control-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000ecb50 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   ecb50:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
   ecb57:	44 8b 8e d0 00 00 00 	mov    0xd0(%rsi),%r9d
   ecb5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ecb62:	48 89 9c 24 38 01 00 00 	mov    %rbx,0x138(%rsp)
   ecb6a:	48 89 fb             	mov    %rdi,%rbx
   ecb6d:	48 89 ac 24 40 01 00 00 	mov    %rbp,0x140(%rsp)
   ecb75:	4c 89 cd             	mov    %r9,%rbp
   ecb78:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   ecb7d:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
   ecb86:	48 89 84 24 28 01 00 00 	mov    %rax,0x128(%rsp)
   ecb8e:	31 c0                	xor    %eax,%eax
   ecb90:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   ecb95:	41 83 f9 01          	cmp    $0x1,%r9d
   ecb99:	0f 86 09 03 00 00    	jbe    ecea8 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x358>
   ecb9f:	4c 89 b4 24 58 01 00 00 	mov    %r14,0x158(%rsp)
   ecba7:	66 48 0f 6e c9       	movq   %rcx,%xmm1
   ecbac:	4c 8d 76 08          	lea    0x8(%rsi),%r14
   ecbb0:	8b b6 64 01 00 00    	mov    0x164(%rsi),%esi
   ecbb6:	0f 11 44 24 68       	movups %xmm0,0x68(%rsp)
   ecbbb:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   ecbc0:	66 48 0f 6e c0       	movq   %rax,%xmm0
   ecbc5:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
   ecbc9:	c6 44 24 60 00       	movb   $0x0,0x60(%rsp)
   ecbce:	48 c7 84 24 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rsp)
   ecbda:	0f 11 84 24 88 00 00 00 	movups %xmm0,0x88(%rsp)
   ecbe2:	83 fe ff             	cmp    $0xffffffff,%esi
   ecbe5:	0f 85 d5 01 00 00    	jne    ecdc0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x270>
   ecbeb:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   ecbf3:	49 89 d7             	mov    %rdx,%r15
   ecbf6:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   ecbfe:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   ecc06:	49 83 f9 04          	cmp    $0x4,%r9
   ecc0a:	0f 86 a5 02 00 00    	jbe    eceb5 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x365>
   ecc10:	8d 45 ff             	lea    -0x1(%rbp),%eax
   ecc13:	89 6c 24 24          	mov    %ebp,0x24(%rsp)
   ecc17:	45 31 ed             	xor    %r13d,%r13d
   ecc1a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   ecc1f:	31 c0                	xor    %eax,%eax
   ecc21:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   ecc26:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   ecc2b:	84 c0                	test   %al,%al
   ecc2d:	0f 85 63 01 00 00    	jne    ecd96 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x246>
   ecc33:	66 90                	xchg   %ax,%ax
   ecc35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ecc40:	4c 39 6c 24 28       	cmp    %r13,0x28(%rsp)
   ecc45:	0f 84 4b 01 00 00    	je     ecd96 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x246>
   ecc4b:	4c 89 ef             	mov    %r13,%rdi
   ecc4e:	41 8d 6d 01          	lea    0x1(%r13),%ebp
   ecc52:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   ecc57:	45 89 ec             	mov    %r13d,%r12d
   ecc5a:	48 c1 e7 05          	shl    $0x5,%rdi
   ecc5e:	41 89 ed             	mov    %ebp,%r13d
   ecc61:	8b 6c 24 24          	mov    0x24(%rsp),%ebp
   ecc65:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   ecc6a:	48 8d 5f 20          	lea    0x20(%rdi),%rbx
   ecc6e:	eb 1c                	jmp    ecc8c <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x13c>
   ecc70:	41 83 c5 01          	add    $0x1,%r13d
   ecc74:	41 39 ed             	cmp    %ebp,%r13d
   ecc77:	0f 83 03 01 00 00    	jae    ecd80 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x230>
   ecc7d:	48 83 c3 20          	add    $0x20,%rbx
   ecc81:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
   ecc86:	0f 85 f4 00 00 00    	jne    ecd80 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x230>
   ecc8c:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
   ecc91:	44 89 ea             	mov    %r13d,%edx
   ecc94:	44 89 e6             	mov    %r12d,%esi
   ecc97:	4c 89 f7             	mov    %r14,%rdi
   ecc9a:	e8 c1 4d f2 ff       	call   11a60 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_7ContextERT0_.isra.0>
   ecc9f:	84 c0                	test   %al,%al
   ecca1:	74 cd                	je     ecc70 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x120>
   ecca3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   ecca8:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   eccad:	48 8b 40 68          	mov    0x68(%rax),%rax
   eccb1:	8b 7c 30 18          	mov    0x18(%rax,%rsi,1),%edi
   eccb5:	39 7c 18 18          	cmp    %edi,0x18(%rax,%rbx,1)
   eccb9:	0f 82 d9 01 00 00    	jb     ece98 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x348>
   eccbf:	44 89 2c 24          	mov    %r13d,(%rsp)
   eccc3:	44 89 e2             	mov    %r12d,%edx
   eccc6:	4c 89 f6             	mov    %r14,%rsi
   eccc9:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
   eccd1:	e8 1a 64 04 00       	call   1330f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   eccd6:	8b 14 24             	mov    (%rsp),%edx
   eccd9:	4c 89 f6             	mov    %r14,%rsi
   eccdc:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   ecce4:	e8 07 64 04 00       	call   1330f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ecce9:	48 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%rdx
   eccf1:	48 8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%rax
   eccf9:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   ecd03:	8b 00                	mov    (%rax),%eax
   ecd05:	8b 0a                	mov    (%rdx),%ecx
   ecd07:	49 83 07 01          	addq   $0x1,(%r15)
   ecd0b:	89 ca                	mov    %ecx,%edx
   ecd0d:	39 c8                	cmp    %ecx,%eax
   ecd0f:	0f 46 d0             	cmovbe %eax,%edx
   ecd12:	48 c1 e2 20          	shl    $0x20,%rdx
   ecd16:	39 c8                	cmp    %ecx,%eax
   ecd18:	0f 42 c1             	cmovb  %ecx,%eax
   ecd1b:	48 09 c2             	or     %rax,%rdx
   ecd1e:	48 89 d0             	mov    %rdx,%rax
   ecd21:	48 c1 e8 1e          	shr    $0x1e,%rax
   ecd25:	48 31 d0             	xor    %rdx,%rax
   ecd28:	48 0f af c6          	imul   %rsi,%rax
   ecd2c:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   ecd36:	48 89 c2             	mov    %rax,%rdx
   ecd39:	48 c1 ea 1b          	shr    $0x1b,%rdx
   ecd3d:	48 31 d0             	xor    %rdx,%rax
   ecd40:	48 0f af c6          	imul   %rsi,%rax
   ecd44:	48 89 c2             	mov    %rax,%rdx
   ecd47:	48 c1 ea 1f          	shr    $0x1f,%rdx
   ecd4b:	48 31 d0             	xor    %rdx,%rax
   ecd4e:	49 01 47 08          	add    %rax,0x8(%r15)
   ecd52:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   ecd5a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   ecd5e:	0f 84 0c ff ff ff    	je     ecc70 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x120>
   ecd64:	48 83 c0 01          	add    $0x1,%rax
   ecd68:	41 83 c5 01          	add    $0x1,%r13d
   ecd6c:	48 89 84 24 88 00 00 00 	mov    %rax,0x88(%rsp)
   ecd74:	41 39 ed             	cmp    %ebp,%r13d
   ecd77:	0f 82 00 ff ff ff    	jb     ecc7d <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x12d>
   ecd7d:	0f 1f 00             	nopl   (%rax)
   ecd80:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
   ecd85:	0f b6 44 24 60       	movzbl 0x60(%rsp),%eax
   ecd8a:	49 83 c5 01          	add    $0x1,%r13
   ecd8e:	84 c0                	test   %al,%al
   ecd90:	0f 84 aa fe ff ff    	je     ecc40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xf0>
   ecd96:	8b 6c 24 24          	mov    0x24(%rsp),%ebp
   ecd9a:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   ecd9f:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   ecda4:	4c 8b a4 24 48 01 00 00 	mov    0x148(%rsp),%r12
   ecdac:	4c 8b ac 24 50 01 00 00 	mov    0x150(%rsp),%r13
   ecdb4:	4c 8b bc 24 60 01 00 00 	mov    0x160(%rsp),%r15
   ecdbc:	eb 24                	jmp    ecde2 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x292>
   ecdbe:	66 90                	xchg   %ax,%ax
   ecdc0:	48 8d 4c 24 58       	lea    0x58(%rsp),%rcx
   ecdc5:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
   ecdca:	4c 89 f7             	mov    %r14,%rdi
   ecdcd:	4c 89 0c 24          	mov    %r9,(%rsp)
   ecdd1:	4c 8d 84 24 a0 00 00 00 	lea    0xa0(%rsp),%r8
   ecdd9:	e8 a2 c3 fa ff       	call   99180 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE9selfPairsIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvjRNS2_7ContextESC_RSF_>
   ecdde:	4c 8b 0c 24          	mov    (%rsp),%r9
   ecde2:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   ecde8:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
   ecdee:	0f b6 44 24 60       	movzbl 0x60(%rsp),%eax
   ecdf3:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   ecdfb:	66 0f 6f 84 24 80 00 00 00 	movdqa 0x80(%rsp),%xmm0
   ece04:	0f 29 94 24 e0 00 00 00 	movaps %xmm2,0xe0(%rsp)
   ece0c:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   ece14:	84 c0                	test   %al,%al
   ece16:	74 08                	je     ece20 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2d0>
   ece18:	3c 0b                	cmp    $0xb,%al
   ece1a:	0f 85 4e 03 00 00    	jne    ed16e <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x61e>
   ece20:	4c 8b b4 24 58 01 00 00 	mov    0x158(%rsp),%r14
   ece28:	48 8b 94 24 f0 00 00 00 	mov    0xf0(%rsp),%rdx
   ece30:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   ece38:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   ece40:	48 89 13             	mov    %rdx,(%rbx)
   ece43:	48 8b 94 24 e8 00 00 00 	mov    0xe8(%rsp),%rdx
   ece4b:	4c 89 4b 08          	mov    %r9,0x8(%rbx)
   ece4f:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   ece53:	31 d2                	xor    %edx,%edx
   ece55:	85 ed                	test   %ebp,%ebp
   ece57:	0f 95 c2             	setne  %dl
   ece5a:	3c 0b                	cmp    $0xb,%al
   ece5c:	89 53 20             	mov    %edx,0x20(%rbx)
   ece5f:	0f 94 43 30          	sete   0x30(%rbx)
   ece63:	48 8b 84 24 28 01 00 00 	mov    0x128(%rsp),%rax
   ece6b:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   ece74:	0f 85 29 03 00 00    	jne    ed1a3 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x653>
   ece7a:	48 89 d8             	mov    %rbx,%rax
   ece7d:	48 8b ac 24 40 01 00 00 	mov    0x140(%rsp),%rbp
   ece85:	48 8b 9c 24 38 01 00 00 	mov    0x138(%rsp),%rbx
   ece8d:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
   ece94:	c3                   	ret
   ece95:	0f 1f 00             	nopl   (%rax)
   ece98:	44 89 24 24          	mov    %r12d,(%rsp)
   ece9c:	44 89 ea             	mov    %r13d,%edx
   ece9f:	e9 22 fe ff ff       	jmp    eccc6 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x176>
   ecea4:	0f 1f 40 00          	nopl   0x0(%rax)
   ecea8:	0f 11 84 24 e8 00 00 00 	movups %xmm0,0xe8(%rsp)
   eceb0:	e9 73 ff ff ff       	jmp    ece28 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2d8>
   eceb5:	49 8d 41 ff          	lea    -0x1(%r9),%rax
   eceb9:	49 0f af c1          	imul   %r9,%rax
   ecebd:	48 d1 e8             	shr    $1,%rax
   ecec0:	48 39 c1             	cmp    %rax,%rcx
   ecec3:	0f 82 47 fd ff ff    	jb     ecc10 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xc0>
   ecec9:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   ecece:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   eced3:	45 31 ff             	xor    %r15d,%r15d
   eced6:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   ecedb:	48 8b 70 68          	mov    0x68(%rax),%rsi
   ecedf:	48 8b 40 58          	mov    0x58(%rax),%rax
   ecee3:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
   ecee8:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   eceed:	4c 8d 66 20          	lea    0x20(%rsi),%r12
   ecef1:	41 8d 71 ff          	lea    -0x1(%r9),%esi
   ecef5:	48 89 04 24          	mov    %rax,(%rsp)
   ecef9:	48 83 c0 10          	add    $0x10,%rax
   ecefd:	89 74 24 18          	mov    %esi,0x18(%rsp)
   ecf01:	0f 1f 40 00          	nopl   0x0(%rax)
   ecf05:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ecf10:	44 89 7c 24 08       	mov    %r15d,0x8(%rsp)
   ecf15:	41 83 c7 01          	add    $0x1,%r15d
   ecf19:	49 89 c6             	mov    %rax,%r14
   ecf1c:	4c 89 e3             	mov    %r12,%rbx
   ecf1f:	44 89 3c 24          	mov    %r15d,(%rsp)
   ecf23:	45 89 fd             	mov    %r15d,%r13d
   ecf26:	eb 4d                	jmp    ecf75 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x425>
   ecf28:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   ecf30:	49 8b 54 24 e8       	mov    -0x18(%r12),%rdx
   ecf35:	48 85 13             	test   %rdx,(%rbx)
   ecf38:	74 46                	je     ecf80 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x430>
   ecf3a:	8b 50 f0             	mov    -0x10(%rax),%edx
   ecf3d:	41 8b 4e 08          	mov    0x8(%r14),%ecx
   ecf41:	48 83 44 24 70 01    	addq   $0x1,0x70(%rsp)
   ecf47:	39 ca                	cmp    %ecx,%edx
   ecf49:	7c 55                	jl     ecfa0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x450>
   ecf4b:	0f 84 54 01 00 00    	je     ed0a5 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x555>
   ecf51:	0f 1f 40 00          	nopl   0x0(%rax)
   ecf55:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ecf60:	41 83 c5 01          	add    $0x1,%r13d
   ecf64:	48 83 c3 20          	add    $0x20,%rbx
   ecf68:	49 83 c6 10          	add    $0x10,%r14
   ecf6c:	41 39 ed             	cmp    %ebp,%r13d
   ecf6f:	0f 83 ab 01 00 00    	jae    ed120 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5d0>
   ecf75:	49 8b 54 24 e0       	mov    -0x20(%r12),%rdx
   ecf7a:	48 85 53 08          	test   %rdx,0x8(%rbx)
   ecf7e:	75 b0                	jne    ecf30 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   ecf80:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   ecf85:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
   ecf89:	74 d5                	je     ecf60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ecf8b:	48 83 c2 01          	add    $0x1,%rdx
   ecf8f:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
   ecf94:	eb ca                	jmp    ecf60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ecf96:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   ecfa0:	41 8b 3e             	mov    (%r14),%edi
   ecfa3:	8b 70 f8             	mov    -0x8(%rax),%esi
   ecfa6:	39 f7                	cmp    %esi,%edi
   ecfa8:	0f 8d 02 01 00 00    	jge    ed0b0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x560>
   ecfae:	44 8b 40 f4          	mov    -0xc(%rax),%r8d
   ecfb2:	45 3b 46 0c          	cmp    0xc(%r14),%r8d
   ecfb6:	0f 8d 00 01 00 00    	jge    ed0bc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x56c>
   ecfbc:	44 8b 50 fc          	mov    -0x4(%rax),%r10d
   ecfc0:	45 39 56 04          	cmp    %r10d,0x4(%r14)
   ecfc4:	0f 8d f2 00 00 00    	jge    ed0bc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x56c>
   ecfca:	41 8b 7c 24 f8       	mov    -0x8(%r12),%edi
   ecfcf:	39 7b 18             	cmp    %edi,0x18(%rbx)
   ecfd2:	0f 82 86 01 00 00    	jb     ed15e <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x60e>
   ecfd8:	44 89 6c 24 24       	mov    %r13d,0x24(%rsp)
   ecfdd:	8b 54 24 08          	mov    0x8(%rsp),%edx
   ecfe1:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   ecfe6:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
   ecfee:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   ecff3:	4c 89 fe             	mov    %r15,%rsi
   ecff6:	e8 f5 60 04 00       	call   1330f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ecffb:	8b 54 24 24          	mov    0x24(%rsp),%edx
   ecfff:	4c 89 fe             	mov    %r15,%rsi
   ed002:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   ed00a:	e8 e1 60 04 00       	call   1330f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ed00f:	48 8b 8c 24 b8 00 00 00 	mov    0xb8(%rsp),%rcx
   ed017:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   ed01c:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   ed024:	8b 31                	mov    (%rcx),%esi
   ed026:	8b 12                	mov    (%rdx),%edx
   ed028:	48 83 00 01          	addq   $0x1,(%rax)
   ed02c:	89 f1                	mov    %esi,%ecx
   ed02e:	39 f2                	cmp    %esi,%edx
   ed030:	0f 46 ca             	cmovbe %edx,%ecx
   ed033:	48 c1 e1 20          	shl    $0x20,%rcx
   ed037:	39 f2                	cmp    %esi,%edx
   ed039:	0f 42 d6             	cmovb  %esi,%edx
   ed03c:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   ed046:	48 09 d1             	or     %rdx,%rcx
   ed049:	48 89 ca             	mov    %rcx,%rdx
   ed04c:	48 c1 ea 1e          	shr    $0x1e,%rdx
   ed050:	48 31 ca             	xor    %rcx,%rdx
   ed053:	48 0f af d6          	imul   %rsi,%rdx
   ed057:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   ed061:	48 89 d1             	mov    %rdx,%rcx
   ed064:	48 c1 e9 1b          	shr    $0x1b,%rcx
   ed068:	48 31 ca             	xor    %rcx,%rdx
   ed06b:	48 0f af d6          	imul   %rsi,%rdx
   ed06f:	48 89 d1             	mov    %rdx,%rcx
   ed072:	48 c1 e9 1f          	shr    $0x1f,%rcx
   ed076:	48 31 ca             	xor    %rcx,%rdx
   ed079:	48 01 50 08          	add    %rdx,0x8(%rax)
   ed07d:	48 8b 94 24 88 00 00 00 	mov    0x88(%rsp),%rdx
   ed085:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   ed08a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
   ed08e:	0f 84 cc fe ff ff    	je     ecf60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ed094:	48 83 c2 01          	add    $0x1,%rdx
   ed098:	48 89 94 24 88 00 00 00 	mov    %rdx,0x88(%rsp)
   ed0a0:	e9 bb fe ff ff       	jmp    ecf60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ed0a5:	41 8b 3e             	mov    (%r14),%edi
   ed0a8:	8b 70 f8             	mov    -0x8(%rax),%esi
   ed0ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   ed0b0:	39 f7                	cmp    %esi,%edi
   ed0b2:	0f 8f a8 fe ff ff    	jg     ecf60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ed0b8:	44 8b 40 f4          	mov    -0xc(%rax),%r8d
   ed0bc:	45 8b 4e 0c          	mov    0xc(%r14),%r9d
   ed0c0:	45 39 c8             	cmp    %r9d,%r8d
   ed0c3:	0f 8f 97 fe ff ff    	jg     ecf60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ed0c9:	45 8b 56 04          	mov    0x4(%r14),%r10d
   ed0cd:	44 8b 58 fc          	mov    -0x4(%rax),%r11d
   ed0d1:	45 39 da             	cmp    %r11d,%r10d
   ed0d4:	0f 8f 86 fe ff ff    	jg     ecf60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ed0da:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
   ed0df:	41 80 7f 21 01       	cmpb   $0x1,0x21(%r15)
   ed0e4:	0f 95 44 24 24       	setne  0x24(%rsp)
   ed0e9:	45 39 d8             	cmp    %r11d,%r8d
   ed0ec:	41 0f 95 c0          	setne  %r8b
   ed0f0:	44 22 44 24 24       	and    0x24(%rsp),%r8b
   ed0f5:	45 39 d1             	cmp    %r10d,%r9d
   ed0f8:	41 0f 95 c1          	setne  %r9b
   ed0fc:	45 21 c8             	and    %r9d,%r8d
   ed0ff:	39 f2                	cmp    %esi,%edx
   ed101:	0f 95 c2             	setne  %dl
   ed104:	41 84 d0             	test   %dl,%r8b
   ed107:	0f 84 bd fe ff ff    	je     ecfca <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x47a>
   ed10d:	39 f9                	cmp    %edi,%ecx
   ed10f:	0f 84 b5 fe ff ff    	je     ecfca <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x47a>
   ed115:	e9 46 fe ff ff       	jmp    ecf60 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   ed11a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ed120:	44 8b 3c 24          	mov    (%rsp),%r15d
   ed124:	49 83 c4 20          	add    $0x20,%r12
   ed128:	48 83 c0 10          	add    $0x10,%rax
   ed12c:	44 39 7c 24 18       	cmp    %r15d,0x18(%rsp)
   ed131:	0f 85 d9 fd ff ff    	jne    ecf10 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3c0>
   ed137:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
   ed13c:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
   ed141:	4c 8b a4 24 48 01 00 00 	mov    0x148(%rsp),%r12
   ed149:	4c 8b ac 24 50 01 00 00 	mov    0x150(%rsp),%r13
   ed151:	4c 8b bc 24 60 01 00 00 	mov    0x160(%rsp),%r15
   ed159:	e9 84 fc ff ff       	jmp    ecde2 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x292>
   ed15e:	8b 74 24 08          	mov    0x8(%rsp),%esi
   ed162:	44 89 ea             	mov    %r13d,%edx
   ed165:	89 74 24 24          	mov    %esi,0x24(%rsp)
   ed169:	e9 73 fe ff ff       	jmp    ecfe1 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x491>
   ed16e:	48 8b 3d eb 10 08 00 	mov    0x810eb(%rip),%rdi        # 16e260 <stderr@GLIBC_2.2.5>
   ed175:	0f b6 d0             	movzbl %al,%edx
   ed178:	48 8d 35 21 88 06 00 	lea    0x68821(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   ed17f:	31 c0                	xor    %eax,%eax
   ed181:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   ed189:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   ed191:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   ed199:	e8 a2 a1 f1 ff       	call   7340 <fprintf@plt>
   ed19e:	e8 7d 9f f1 ff       	call   7120 <abort@plt>
   ed1a3:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   ed1ab:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   ed1b3:	4c 89 b4 24 58 01 00 00 	mov    %r14,0x158(%rsp)
   ed1bb:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   ed1c3:	e8 98 a0 f1 ff       	call   7260 <__stack_chk_fail@plt>

# control ordered_pairs bench::Counters bench::LibraryIndex<int, true>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/control-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f0680 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f0680:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
   f0687:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f068b:	48 89 9c 24 c8 01 00 00 	mov    %rbx,0x1c8(%rsp)
   f0693:	48 89 fb             	mov    %rdi,%rbx
   f0696:	4c 89 bc 24 f0 01 00 00 	mov    %r15,0x1f0(%rsp)
   f069e:	49 89 f7             	mov    %rsi,%r15
   f06a1:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   f06a6:	8b 96 d0 00 00 00    	mov    0xd0(%rsi),%edx
   f06ac:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
   f06b3:	64 48 8b 3c 25 28 00 00 00 	mov    %fs:0x28,%rdi
   f06bc:	48 89 bc 24 b8 01 00 00 	mov    %rdi,0x1b8(%rsp)
   f06c4:	31 ff                	xor    %edi,%edi
   f06c6:	83 fa 01             	cmp    $0x1,%edx
   f06c9:	0f 86 01 03 00 00    	jbe    f09d0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x350>
   f06cf:	48 39 f2             	cmp    %rsi,%rdx
   f06d2:	74 44                	je     f0718 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x98>
   f06d4:	ba 07 00 00 00       	mov    $0x7,%edx
   f06d9:	48 8b 3d 80 db 07 00 	mov    0x7db80(%rip),%rdi        # 16e260 <stderr@GLIBC_2.2.5>
   f06e0:	48 8d 35 b9 52 06 00 	lea    0x652b9(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   f06e7:	31 c0                	xor    %eax,%eax
   f06e9:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f06f1:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f06f9:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f0701:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f0709:	e8 32 6c f1 ff       	call   7340 <fprintf@plt>
   f070e:	e8 0d 6a f1 ff       	call   7120 <abort@plt>
   f0713:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f0718:	49 89 c8             	mov    %rcx,%r8
   f071b:	0f 11 84 24 98 00 00 00 	movups %xmm0,0x98(%rsp)
   f0723:	49 8b 47 50          	mov    0x50(%r15),%rax
   f0727:	89 d1                	mov    %edx,%ecx
   f0729:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f0731:	66 49 0f 6e d0       	movq   %r8,%xmm2
   f0736:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   f073b:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
   f073f:	c6 84 24 90 00 00 00 00 	movb   $0x0,0x90(%rsp)
   f0747:	48 c7 84 24 c8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xc8(%rsp)
   f0753:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f075b:	48 85 c0             	test   %rax,%rax
   f075e:	0f 84 c6 08 00 00    	je     f102a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9aa>
   f0764:	48 89 84 24 d0 00 00 00 	mov    %rax,0xd0(%rsp)
   f076c:	48 89 84 24 d8 00 00 00 	mov    %rax,0xd8(%rsp)
   f0774:	48 c7 84 24 e0 00 00 00 00 00 00 00 	movq   $0x0,0xe0(%rsp)
   f0780:	48 c7 84 24 e8 00 00 00 00 00 00 00 	movq   $0x0,0xe8(%rsp)
   f078c:	48 89 84 24 f0 00 00 00 	mov    %rax,0xf0(%rsp)
   f0794:	48 c7 84 24 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rsp)
   f07a0:	48 c7 84 24 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rsp)
   f07ac:	48 89 84 24 08 01 00 00 	mov    %rax,0x108(%rsp)
   f07b4:	48 c7 84 24 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rsp)
   f07c0:	48 c7 84 24 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rsp)
   f07cc:	48 89 84 24 20 01 00 00 	mov    %rax,0x120(%rsp)
   f07d4:	48 c7 84 24 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rsp)
   f07e0:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f07ec:	48 89 84 24 38 01 00 00 	mov    %rax,0x138(%rsp)
   f07f4:	48 c7 84 24 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rsp)
   f0800:	48 c7 84 24 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rsp)
   f080c:	48 89 84 24 50 01 00 00 	mov    %rax,0x150(%rsp)
   f0814:	48 c7 84 24 58 01 00 00 00 00 00 00 	movq   $0x0,0x158(%rsp)
   f0820:	48 c7 84 24 60 01 00 00 00 00 00 00 	movq   $0x0,0x160(%rsp)
   f082c:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f0834:	48 c7 84 24 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rsp)
   f0840:	48 c7 84 24 78 01 00 00 00 00 00 00 	movq   $0x0,0x178(%rsp)
   f084c:	48 89 84 24 80 01 00 00 	mov    %rax,0x180(%rsp)
   f0854:	48 c7 84 24 88 01 00 00 00 00 00 00 	movq   $0x0,0x188(%rsp)
   f0860:	48 c7 84 24 90 01 00 00 00 00 00 00 	movq   $0x0,0x190(%rsp)
   f086c:	48 89 84 24 98 01 00 00 	mov    %rax,0x198(%rsp)
   f0874:	48 c7 84 24 a0 01 00 00 00 00 00 00 	movq   $0x0,0x1a0(%rsp)
   f0880:	48 c7 84 24 a8 01 00 00 00 00 00 00 	movq   $0x0,0x1a8(%rsp)
   f088c:	c7 84 24 b0 01 00 00 00 00 00 00 	movl   $0x0,0x1b0(%rsp)
   f0897:	c6 84 24 b4 01 00 00 00 	movb   $0x0,0x1b4(%rsp)
   f089f:	49 39 b7 a0 01 00 00 	cmp    %rsi,0x1a0(%r15)
   f08a6:	0f 82 b4 01 00 00    	jb     f0a60 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f08ac:	49 39 b7 b8 01 00 00 	cmp    %rsi,0x1b8(%r15)
   f08b3:	0f 82 a7 01 00 00    	jb     f0a60 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f08b9:	41 80 bf 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r15)
   f08c1:	0f 85 aa 07 00 00    	jne    f1071 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9f1>
   f08c7:	49 8d 47 08          	lea    0x8(%r15),%rax
   f08cb:	4d 8b 9f 98 01 00 00 	mov    0x198(%r15),%r11
   f08d2:	c6 44 24 43 00       	movb   $0x0,0x43(%rsp)
   f08d7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   f08dc:	49 8d 87 88 01 00 00 	lea    0x188(%r15),%rax
   f08e3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f08e8:	41 c6 87 6c 02 00 00 01 	movb   $0x1,0x26c(%r15)
   f08f0:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
   f08f5:	85 c9                	test   %ecx,%ecx
   f08f7:	0f 84 7a 01 00 00    	je     f0a77 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f08fd:	8d 41 ff             	lea    -0x1(%rcx),%eax
   f0900:	83 f8 02             	cmp    $0x2,%eax
   f0903:	0f 86 3c 07 00 00    	jbe    f1045 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9c5>
   f0909:	89 cf                	mov    %ecx,%edi
   f090b:	4c 89 d8             	mov    %r11,%rax
   f090e:	66 0f 6f 05 7a 6f 06 00 	movdqa 0x66f7a(%rip),%xmm0        # 157890 <C.66.5+0x270>
   f0916:	c1 ef 02             	shr    $0x2,%edi
   f0919:	89 fa                	mov    %edi,%edx
   f091b:	48 c1 e2 04          	shl    $0x4,%rdx
   f091f:	4c 01 da             	add    %r11,%rdx
   f0922:	41 bb 04 00 00 00    	mov    $0x4,%r11d
   f0928:	66 41 0f 6e cb       	movd   %r11d,%xmm1
   f092d:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   f0932:	0f 1f 00             	nopl   (%rax)
   f0935:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0940:	0f 11 00             	movups %xmm0,(%rax)
   f0943:	48 83 c0 10          	add    $0x10,%rax
   f0947:	66 0f fe c1          	paddd  %xmm1,%xmm0
   f094b:	48 39 d0             	cmp    %rdx,%rax
   f094e:	75 f0                	jne    f0940 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2c0>
   f0950:	8d 04 bd 00 00 00 00 	lea    0x0(,%rdi,4),%eax
   f0957:	39 c8                	cmp    %ecx,%eax
   f0959:	74 25                	je     f0980 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f095b:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
   f0960:	89 c2                	mov    %eax,%edx
   f0962:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f0966:	8d 50 01             	lea    0x1(%rax),%edx
   f0969:	39 ca                	cmp    %ecx,%edx
   f096b:	73 13                	jae    f0980 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f096d:	89 d7                	mov    %edx,%edi
   f096f:	83 c0 02             	add    $0x2,%eax
   f0972:	41 89 14 bb          	mov    %edx,(%r11,%rdi,4)
   f0976:	39 c8                	cmp    %ecx,%eax
   f0978:	73 06                	jae    f0980 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f097a:	89 c2                	mov    %eax,%edx
   f097c:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f0980:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
   f0987:	0f 86 ea 00 00 00    	jbe    f0a77 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f098d:	49 39 b7 48 02 00 00 	cmp    %rsi,0x248(%r15)
   f0994:	0f 82 e7 00 00 00    	jb     f0a81 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f099a:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f09a4:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f09ab:	48 c1 ea 04          	shr    $0x4,%rdx
   f09af:	48 39 f2             	cmp    %rsi,%rdx
   f09b2:	0f 82 c9 00 00 00    	jb     f0a81 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f09b8:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f09bc:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   f09c1:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f09c6:	e8 d5 1a f2 ff       	call   124a0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f09cb:	e9 db 00 00 00       	jmp    f0aab <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x42b>
   f09d0:	48 39 f2             	cmp    %rsi,%rdx
   f09d3:	0f 85 fb fc ff ff    	jne    f06d4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54>
   f09d9:	48 89 d0             	mov    %rdx,%rax
   f09dc:	0f 11 84 24 d8 00 00 00 	movups %xmm0,0xd8(%rsp)
   f09e4:	31 d2                	xor    %edx,%edx
   f09e6:	48 8b 8c 24 e0 00 00 00 	mov    0xe0(%rsp),%rcx
   f09ee:	85 c0                	test   %eax,%eax
   f09f0:	89 c7                	mov    %eax,%edi
   f09f2:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   f09fa:	0f 95 c0             	setne  %al
   f09fd:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   f0a05:	80 fa 0b             	cmp    $0xb,%dl
   f0a08:	48 89 0b             	mov    %rcx,(%rbx)
   f0a0b:	48 8b 8c 24 d8 00 00 00 	mov    0xd8(%rsp),%rcx
   f0a13:	0f b6 c0             	movzbl %al,%eax
   f0a16:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
   f0a1a:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   f0a1e:	89 43 20             	mov    %eax,0x20(%rbx)
   f0a21:	0f 94 43 30          	sete   0x30(%rbx)
   f0a25:	48 8b 84 24 b8 01 00 00 	mov    0x1b8(%rsp),%rax
   f0a2d:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f0a36:	0f 85 10 06 00 00    	jne    f104c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9cc>
   f0a3c:	48 89 d8             	mov    %rbx,%rax
   f0a3f:	4c 8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%r15
   f0a47:	48 8b 9c 24 c8 01 00 00 	mov    0x1c8(%rsp),%rbx
   f0a4f:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
   f0a56:	c3                   	ret
   f0a57:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   f0a60:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f0a68:	e8 33 c3 00 00       	call   fcda0 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f0a6d:	ba 05 00 00 00       	mov    $0x5,%edx
   f0a72:	e9 62 fc ff ff       	jmp    f06d9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f0a77:	48 83 fe 01          	cmp    $0x1,%rsi
   f0a7b:	0f 86 bd 05 00 00    	jbe    f103e <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9be>
   f0a81:	48 89 f0             	mov    %rsi,%rax
   f0a84:	31 c9                	xor    %ecx,%ecx
   f0a86:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f0a90:	48 d1 e8             	shr    $1,%rax
   f0a93:	83 c1 02             	add    $0x2,%ecx
   f0a96:	48 83 f8 01          	cmp    $0x1,%rax
   f0a9a:	75 f4                	jne    f0a90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f0a9c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f0aa1:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f0aa6:	e8 b5 d3 05 00       	call   14de60 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f0aab:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f0ab2:	83 fa 01             	cmp    $0x1,%edx
   f0ab5:	0f 86 2a 03 00 00    	jbe    f0de5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f0abb:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f0ac3:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f0acb:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f0ad3:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f0adb:	48 c7 44 24 08 01 00 00 00 	movq   $0x1,0x8(%rsp)
   f0ae4:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   f0ae9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f0af0:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f0af8:	84 c0                	test   %al,%al
   f0afa:	0f 85 c0 02 00 00    	jne    f0dc0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f0b00:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   f0b05:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f0b0a:	48 8d 4c 24 43       	lea    0x43(%rsp),%rcx
   f0b0f:	4c 8d ac 24 90 00 00 00 	lea    0x90(%rsp),%r13
   f0b17:	8b 7c 9f fc          	mov    -0x4(%rdi,%rbx,4),%edi
   f0b1b:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   f0b20:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   f0b25:	48 8d 4c 24 42       	lea    0x42(%rsp),%rcx
   f0b2a:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   f0b2f:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   f0b34:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   f0b39:	48 8d 5c 24 44       	lea    0x44(%rsp),%rbx
   f0b3e:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   f0b43:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
   f0b48:	48 89 8c 24 80 00 00 00 	mov    %rcx,0x80(%rsp)
   f0b50:	41 8b 8f 64 01 00 00 	mov    0x164(%r15),%ecx
   f0b57:	89 7c 24 44          	mov    %edi,0x44(%rsp)
   f0b5b:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
   f0b64:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
   f0b69:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   f0b6e:	83 f9 ff             	cmp    $0xffffffff,%ecx
   f0b71:	0f 84 d9 02 00 00    	je     f0e50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7d0>
   f0b77:	89 ce                	mov    %ecx,%esi
   f0b79:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   f0b7d:	49 03 b7 f8 00 00 00 	add    0xf8(%r15),%rsi
   f0b84:	44 8b 46 64          	mov    0x64(%rsi),%r8d
   f0b88:	45 85 c0             	test   %r8d,%r8d
   f0b8b:	0f 84 ff 01 00 00    	je     f0d90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0b91:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f0b99:	48 85 c0             	test   %rax,%rax
   f0b9c:	0f 84 56 04 00 00    	je     f0ff8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x978>
   f0ba2:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f0ba6:	74 0c                	je     f0bb4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x534>
   f0ba8:	48 83 e8 01          	sub    $0x1,%rax
   f0bac:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f0bb4:	48 8b 84 24 98 00 00 00 	mov    0x98(%rsp),%rax
   f0bbc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f0bc0:	74 0c                	je     f0bce <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54e>
   f0bc2:	48 83 c0 01          	add    $0x1,%rax
   f0bc6:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f0bce:	48 89 fa             	mov    %rdi,%rdx
   f0bd1:	8b 46 1c             	mov    0x1c(%rsi),%eax
   f0bd4:	48 c1 e2 04          	shl    $0x4,%rdx
   f0bd8:	49 03 57 58          	add    0x58(%r15),%rdx
   f0bdc:	39 02                	cmp    %eax,(%rdx)
   f0bde:	0f 8f ac 01 00 00    	jg     f0d90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0be4:	8b 42 08             	mov    0x8(%rdx),%eax
   f0be7:	39 46 14             	cmp    %eax,0x14(%rsi)
   f0bea:	0f 8f a0 01 00 00    	jg     f0d90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0bf0:	8b 46 20             	mov    0x20(%rsi),%eax
   f0bf3:	39 42 04             	cmp    %eax,0x4(%rdx)
   f0bf6:	0f 8f 94 01 00 00    	jg     f0d90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0bfc:	8b 42 0c             	mov    0xc(%rdx),%eax
   f0bff:	39 46 18             	cmp    %eax,0x18(%rsi)
   f0c02:	0f 8f 88 01 00 00    	jg     f0d90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0c08:	49 8b 47 68          	mov    0x68(%r15),%rax
   f0c0c:	48 c1 e7 05          	shl    $0x5,%rdi
   f0c10:	48 83 ec 08          	sub    $0x8,%rsp
   f0c14:	4d 89 e9             	mov    %r13,%r9
   f0c17:	48 01 f8             	add    %rdi,%rax
   f0c1a:	48 8b 08             	mov    (%rax),%rcx
   f0c1d:	4c 8b 40 08          	mov    0x8(%rax),%r8
   f0c21:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   f0c26:	50                   	push   %rax
   f0c27:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f0c2c:	e8 2f c8 f2 ff       	call   1d460 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE11walkOrderedIZNKS2_11orderedSelfIZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS5_8CountersERT_mEUlRKSC_RKT0_E_NS_6detail9AcceptAllEEEvRNS_9WorkspaceIiEEbRNS2_7ContextESD_RSG_EUljE_EEvRKNS2_4NodeERKNS_3BoxIiEENS_6FilterESQ_SD_>
   f0c31:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f0c39:	5a                   	pop    %rdx
   f0c3a:	59                   	pop    %rcx
   f0c3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f0c40:	84 c0                	test   %al,%al
   f0c42:	0f 85 78 01 00 00    	jne    f0dc0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f0c48:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f0c4d:	49 8b 9f b0 01 00 00 	mov    0x1b0(%r15),%rbx
   f0c54:	48 83 fd 7f          	cmp    $0x7f,%rbp
   f0c58:	0f 86 5b 03 00 00    	jbe    f0fb9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x939>
   f0c5e:	49 39 af 48 02 00 00 	cmp    %rbp,0x248(%r15)
   f0c65:	0f 82 58 03 00 00    	jb     f0fc3 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f0c6b:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f0c75:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f0c7c:	48 c1 ea 04          	shr    $0x4,%rdx
   f0c80:	48 39 ea             	cmp    %rbp,%rdx
   f0c83:	0f 82 3a 03 00 00    	jb     f0fc3 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f0c89:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f0c8d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f0c92:	89 e9                	mov    %ebp,%ecx
   f0c94:	48 89 da             	mov    %rbx,%rdx
   f0c97:	e8 04 18 f2 ff       	call   124a0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f0c9c:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f0ca1:	48 85 ed             	test   %rbp,%rbp
   f0ca4:	0f 84 fb 00 00 00    	je     f0da5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f0caa:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
   f0caf:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   f0cb4:	31 c9                	xor    %ecx,%ecx
   f0cb6:	4d 8b 5f 68          	mov    0x68(%r15),%r11
   f0cba:	4d 8b 4f 60          	mov    0x60(%r15),%r9
   f0cbe:	4c 89 c2             	mov    %r8,%rdx
   f0cc1:	48 8b 07             	mov    (%rdi),%rax
   f0cc4:	4c 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%r10
   f0ccc:	48 c1 e2 05          	shl    $0x5,%rdx
   f0cd0:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
   f0cd4:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   f0cd9:	4d 8d 34 13          	lea    (%r11,%rdx,1),%r14
   f0cdd:	4c 8d 68 01          	lea    0x1(%rax),%r13
   f0ce1:	8b 14 8b             	mov    (%rbx,%rcx,4),%edx
   f0ce4:	49 8b 76 10          	mov    0x10(%r14),%rsi
   f0ce8:	4d 8d 64 0d 00       	lea    0x0(%r13,%rcx,1),%r12
   f0ced:	48 89 d0             	mov    %rdx,%rax
   f0cf0:	48 c1 e0 05          	shl    $0x5,%rax
   f0cf4:	49 39 74 03 10       	cmp    %rsi,0x10(%r11,%rax,1)
   f0cf9:	48 89 d0             	mov    %rdx,%rax
   f0cfc:	49 0f 42 c0          	cmovb  %r8,%rax
   f0d00:	49 0f 43 d0          	cmovae %r8,%rdx
   f0d04:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f0d08:	41 8b 34 91          	mov    (%r9,%rdx,4),%esi
   f0d0c:	39 f0                	cmp    %esi,%eax
   f0d0e:	89 f2                	mov    %esi,%edx
   f0d10:	0f 46 d0             	cmovbe %eax,%edx
   f0d13:	48 c1 e2 20          	shl    $0x20,%rdx
   f0d17:	39 f0                	cmp    %esi,%eax
   f0d19:	0f 42 c6             	cmovb  %esi,%eax
   f0d1c:	48 09 d0             	or     %rdx,%rax
   f0d1f:	48 89 c2             	mov    %rax,%rdx
   f0d22:	48 c1 ea 1e          	shr    $0x1e,%rdx
   f0d26:	48 31 c2             	xor    %rax,%rdx
   f0d29:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   f0d33:	48 0f af d0          	imul   %rax,%rdx
   f0d37:	48 89 d0             	mov    %rdx,%rax
   f0d3a:	48 c1 e8 1b          	shr    $0x1b,%rax
   f0d3e:	48 31 c2             	xor    %rax,%rdx
   f0d41:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f0d4b:	48 0f af d0          	imul   %rax,%rdx
   f0d4f:	48 89 d0             	mov    %rdx,%rax
   f0d52:	48 c1 e8 1f          	shr    $0x1f,%rax
   f0d56:	48 31 c2             	xor    %rax,%rdx
   f0d59:	48 01 d7             	add    %rdx,%rdi
   f0d5c:	49 83 fa ff          	cmp    $0xffffffffffffffff,%r10
   f0d60:	0f 84 82 01 00 00    	je     f0ee8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x868>
   f0d66:	49 83 c2 01          	add    $0x1,%r10
   f0d6a:	48 83 c1 01          	add    $0x1,%rcx
   f0d6e:	4c 89 94 24 b8 00 00 00 	mov    %r10,0xb8(%rsp)
   f0d76:	48 39 cd             	cmp    %rcx,%rbp
   f0d79:	0f 85 62 ff ff ff    	jne    f0ce1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x661>
   f0d7f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f0d84:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f0d88:	4c 89 20             	mov    %r12,(%rax)
   f0d8b:	eb 18                	jmp    f0da5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f0d8d:	0f 1f 00             	nopl   (%rax)
   f0d90:	49 8b bf b0 01 00 00 	mov    0x1b0(%r15),%rdi
   f0d97:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f0d9c:	31 c9                	xor    %ecx,%ecx
   f0d9e:	31 f6                	xor    %esi,%esi
   f0da0:	e8 bb d0 05 00       	call   14de60 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f0da5:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f0dac:	48 83 44 24 08 01    	addq   $0x1,0x8(%rsp)
   f0db2:	48 89 c2             	mov    %rax,%rdx
   f0db5:	48 39 44 24 08       	cmp    %rax,0x8(%rsp)
   f0dba:	0f 82 30 fd ff ff    	jb     f0af0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x470>
   f0dc0:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f0dc5:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f0dcd:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f0dd5:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f0ddd:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f0de5:	41 c6 87 6c 02 00 00 00 	movb   $0x0,0x26c(%r15)
   f0ded:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f0df5:	e8 a6 bf 00 00       	call   fcda0 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f0dfa:	0f b6 94 24 90 00 00 00 	movzbl 0x90(%rsp),%edx
   f0e02:	66 0f 6f 84 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm0
   f0e0b:	66 0f 6f 9c 24 90 00 00 00 	movdqa 0x90(%rsp),%xmm3
   f0e14:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f0e1c:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f0e25:	0f 29 9c 24 d0 00 00 00 	movaps %xmm3,0xd0(%rsp)
   f0e2d:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f0e35:	80 fa 0b             	cmp    $0xb,%dl
   f0e38:	74 08                	je     f0e42 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7c2>
   f0e3a:	84 d2                	test   %dl,%dl
   f0e3c:	0f 85 97 f8 ff ff    	jne    f06d9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f0e42:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f0e49:	e9 98 fb ff ff       	jmp    f09e6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x366>
   f0e4e:	66 90                	xchg   %ax,%ax
   f0e50:	49 8b 6f 68          	mov    0x68(%r15),%rbp
   f0e54:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
   f0e59:	31 db                	xor    %ebx,%ebx
   f0e5b:	eb 49                	jmp    f0ea6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x826>
   f0e5d:	0f 1f 00             	nopl   (%rax)
   f0e60:	4c 89 e9             	mov    %r13,%rcx
   f0e63:	44 89 f2             	mov    %r14d,%edx
   f0e66:	4c 89 e7             	mov    %r12,%rdi
   f0e69:	e8 f2 0b f2 ff       	call   11a60 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_7ContextERT0_.isra.0>
   f0e6e:	84 c0                	test   %al,%al
   f0e70:	74 19                	je     f0e8b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x80b>
   f0e72:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   f0e77:	48 8d 50 01          	lea    0x1(%rax),%rdx
   f0e7b:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f0e80:	49 8b 97 b0 01 00 00 	mov    0x1b0(%r15),%rdx
   f0e87:	44 89 34 82          	mov    %r14d,(%rdx,%rax,4)
   f0e8b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f0e92:	48 83 c3 01          	add    $0x1,%rbx
   f0e96:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f0e9e:	39 d3                	cmp    %edx,%ebx
   f0ea0:	0f 83 9a fd ff ff    	jae    f0c40 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f0ea6:	84 c0                	test   %al,%al
   f0ea8:	0f 85 12 ff ff ff    	jne    f0dc0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f0eae:	8b 44 24 44          	mov    0x44(%rsp),%eax
   f0eb2:	41 89 de             	mov    %ebx,%r14d
   f0eb5:	48 89 c6             	mov    %rax,%rsi
   f0eb8:	48 c1 e0 05          	shl    $0x5,%rax
   f0ebc:	48 01 e8             	add    %rbp,%rax
   f0ebf:	48 89 d9             	mov    %rbx,%rcx
   f0ec2:	48 c1 e1 05          	shl    $0x5,%rcx
   f0ec6:	48 8b 7c 0d 10       	mov    0x10(%rbp,%rcx,1),%rdi
   f0ecb:	48 39 78 10          	cmp    %rdi,0x10(%rax)
   f0ecf:	72 8f                	jb     f0e60 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e0>
   f0ed1:	48 83 c3 01          	add    $0x1,%rbx
   f0ed5:	39 d3                	cmp    %edx,%ebx
   f0ed7:	0f 83 6b fd ff ff    	jae    f0c48 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c8>
   f0edd:	41 89 de             	mov    %ebx,%r14d
   f0ee0:	eb dd                	jmp    f0ebf <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x83f>
   f0ee2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f0ee8:	4c 8d 69 01          	lea    0x1(%rcx),%r13
   f0eec:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   f0ef1:	4c 39 ed             	cmp    %r13,%rbp
   f0ef4:	0f 84 85 fe ff ff    	je     f0d7f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x6ff>
   f0efa:	4d 8b 74 13 10       	mov    0x10(%r11,%rdx,1),%r14
   f0eff:	4c 89 ee             	mov    %r13,%rsi
   f0f02:	0f 1f 00             	nopl   (%rax)
   f0f05:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0f10:	8b 04 b3             	mov    (%rbx,%rsi,4),%eax
   f0f13:	48 89 c2             	mov    %rax,%rdx
   f0f16:	48 c1 e2 05          	shl    $0x5,%rdx
   f0f1a:	4d 39 74 13 10       	cmp    %r14,0x10(%r11,%rdx,1)
   f0f1f:	48 89 c2             	mov    %rax,%rdx
   f0f22:	49 0f 42 d0          	cmovb  %r8,%rdx
   f0f26:	49 0f 43 c0          	cmovae %r8,%rax
   f0f2a:	45 8b 14 91          	mov    (%r9,%rdx,4),%r10d
   f0f2e:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f0f32:	44 89 d2             	mov    %r10d,%edx
   f0f35:	44 39 d0             	cmp    %r10d,%eax
   f0f38:	0f 46 d0             	cmovbe %eax,%edx
   f0f3b:	48 c1 e2 20          	shl    $0x20,%rdx
   f0f3f:	44 39 d0             	cmp    %r10d,%eax
   f0f42:	41 0f 42 c2          	cmovb  %r10d,%eax
   f0f46:	48 83 c6 01          	add    $0x1,%rsi
   f0f4a:	48 09 c2             	or     %rax,%rdx
   f0f4d:	48 89 d0             	mov    %rdx,%rax
   f0f50:	48 c1 e8 1e          	shr    $0x1e,%rax
   f0f54:	48 31 d0             	xor    %rdx,%rax
   f0f57:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f0f61:	48 0f af c2          	imul   %rdx,%rax
   f0f65:	48 89 c2             	mov    %rax,%rdx
   f0f68:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f0f6c:	48 31 c2             	xor    %rax,%rdx
   f0f6f:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f0f79:	48 0f af d0          	imul   %rax,%rdx
   f0f7d:	48 89 d0             	mov    %rdx,%rax
   f0f80:	48 c1 e8 1f          	shr    $0x1f,%rax
   f0f84:	48 31 d0             	xor    %rdx,%rax
   f0f87:	48 01 c7             	add    %rax,%rdi
   f0f8a:	48 39 ee             	cmp    %rbp,%rsi
   f0f8d:	72 81                	jb     f0f10 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x890>
   f0f8f:	48 8d 45 ff          	lea    -0x1(%rbp),%rax
   f0f93:	48 83 c1 02          	add    $0x2,%rcx
   f0f97:	31 d2                	xor    %edx,%edx
   f0f99:	4c 29 e8             	sub    %r13,%rax
   f0f9c:	48 39 cd             	cmp    %rcx,%rbp
   f0f9f:	48 0f 42 c2          	cmovb  %rdx,%rax
   f0fa3:	4d 8d 64 04 01       	lea    0x1(%r12,%rax,1),%r12
   f0fa8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f0fad:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f0fb1:	4c 89 20             	mov    %r12,(%rax)
   f0fb4:	e9 ec fd ff ff       	jmp    f0da5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f0fb9:	48 83 fd 01          	cmp    $0x1,%rbp
   f0fbd:	0f 86 d3 00 00 00    	jbe    f1096 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa16>
   f0fc3:	48 89 e8             	mov    %rbp,%rax
   f0fc6:	31 c9                	xor    %ecx,%ecx
   f0fc8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f0fd0:	48 d1 e8             	shr    $1,%rax
   f0fd3:	83 c1 02             	add    $0x2,%ecx
   f0fd6:	48 83 f8 01          	cmp    $0x1,%rax
   f0fda:	75 f4                	jne    f0fd0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x950>
   f0fdc:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f0fe1:	48 89 ee             	mov    %rbp,%rsi
   f0fe4:	48 89 df             	mov    %rbx,%rdi
   f0fe7:	e8 74 ce 05 00       	call   14de60 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f0fec:	e9 b0 fc ff ff       	jmp    f0ca1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x621>
   f0ff1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f0ff8:	c6 84 24 90 00 00 00 0b 	movb   $0xb,0x90(%rsp)
   f1000:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f1005:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f100d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f1015:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f101d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f1025:	e9 bb fd ff ff       	jmp    f0de5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f102a:	e8 41 47 00 00       	call   f5770 <_ZN8QuadTree15defaultResourceEv>
   f102f:	41 8b b7 d0 00 00 00 	mov    0xd0(%r15),%esi
   f1036:	48 89 f1             	mov    %rsi,%rcx
   f1039:	e9 26 f7 ff ff       	jmp    f0764 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xe4>
   f103e:	31 c9                	xor    %ecx,%ecx
   f1040:	e9 57 fa ff ff       	jmp    f0a9c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x41c>
   f1045:	31 c0                	xor    %eax,%eax
   f1047:	e9 0f f9 ff ff       	jmp    f095b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2db>
   f104c:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f1054:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f105c:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f1064:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f106c:	e8 ef 61 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f1071:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f1079:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f1081:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f1089:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f1091:	e8 aa 4d 00 00       	call   f5e40 <_ZN8QuadTree6detail15activeWorkspaceEv>
   f1096:	31 c9                	xor    %ecx,%ecx
   f1098:	e9 3f ff ff ff       	jmp    f0fdc <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x95c>
