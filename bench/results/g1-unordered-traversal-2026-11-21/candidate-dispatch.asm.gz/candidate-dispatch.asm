
# candidate unordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, false>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000ed710 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   ed710:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   ed717:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed71b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   ed723:	48 8b 2a             	mov    (%rdx),%rbp
   ed726:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   ed72e:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   ed732:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   ed73a:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   ed742:	49 89 ff             	mov    %rdi,%r15
   ed745:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   ed74d:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   ed754:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   ed759:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   ed762:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   ed76a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   ed76e:	0f 11 07             	movups %xmm0,(%rdi)
   ed771:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   ed775:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   ed779:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   ed77d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   ed781:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   ed785:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   ed789:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   ed78d:	48 89 14 24          	mov    %rdx,(%rsp)
   ed791:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   ed795:	e8 86 0b 06 00       	call   14e320 <_ZN5bench6memory11allocationsEv>
   ed79a:	80 3d d7 1a 08 00 00 	cmpb   $0x0,0x81ad7(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ed7a1:	4c 8b 1c 24          	mov    (%rsp),%r11
   ed7a5:	49 89 c6             	mov    %rax,%r14
   ed7a8:	0f 84 31 0e 00 00    	je     ee5df <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xecf>
   ed7ae:	0f 31                	rdtsc
   ed7b0:	48 c1 e2 20          	shl    $0x20,%rdx
   ed7b4:	48 09 d0             	or     %rdx,%rax
   ed7b7:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   ed7bf:	49 8b 13             	mov    (%r11),%rdx
   ed7c2:	49 3b 53 08          	cmp    0x8(%r11),%rdx
   ed7c6:	0f 84 ff 08 00 00    	je     ee0cb <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9bb>
   ed7cc:	49 29 ec             	sub    %rbp,%r12
   ed7cf:	48 c7 04 24 00 00 00 00 	movq   $0x0,(%rsp)
   ed7d7:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ed7db:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   ed7e3:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   ed7eb:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   ed7f4:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   ed7fd:	c7 44 24 1c 00 00 00 00 	movl   $0x0,0x1c(%rsp)
   ed805:	4c 89 9c 24 88 00 00 00 	mov    %r11,0x88(%rsp)
   ed80d:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   ed815:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   ed81d:	45 31 ed             	xor    %r13d,%r13d
   ed820:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   ed828:	45 31 f6             	xor    %r14d,%r14d
   ed82b:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   ed830:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   ed835:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ed840:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   ed845:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed849:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   ed84d:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   ed855:	48 8b 28             	mov    (%rax),%rbp
   ed858:	4c 8b 60 08          	mov    0x8(%rax),%r12
   ed85c:	49 29 ec             	sub    %rbp,%r12
   ed85f:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
   ed864:	49 c1 fc 04          	sar    $0x4,%r12
   ed868:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   ed86f:	74 13                	je     ed884 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x174>
   ed871:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ed878:	3b 83 b8 02 00 00    	cmp    0x2b8(%rbx),%eax
   ed87e:	0f 84 b8 05 00 00    	je     ede3c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x72c>
   ed884:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   ed88c:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed890:	31 f6                	xor    %esi,%esi
   ed892:	66 0f 6f 3d 26 a0 06 00 	movdqa 0x6a026(%rip),%xmm7        # 1578c0 <C.66.5+0x2a0>
   ed89a:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   ed8a2:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ed8aa:	ba 88 01 00 00       	mov    $0x188,%edx
   ed8af:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   ed8b6:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   ed8bb:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   ed8c3:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   ed8cb:	66 48 0f 6e c0       	movq   %rax,%xmm0
   ed8d0:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   ed8d8:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   ed8dc:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   ed8e5:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   ed8ed:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   ed8f6:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   ed8fe:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   ed907:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   ed90f:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   ed917:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   ed91c:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   ed924:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   ed929:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   ed931:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   ed936:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   ed93e:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   ed94a:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   ed956:	e8 b5 97 f1 ff       	call   7110 <memset@plt>
   ed95b:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   ed961:	66 0f ef c9          	pxor   %xmm1,%xmm1
   ed965:	66 0f 6f 05 63 9f 06 00 	movdqa 0x69f63(%rip),%xmm0        # 1578d0 <C.66.5+0x2b0>
   ed96d:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   ed973:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   ed979:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ed97d:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ed984:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   ed98c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ed991:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   ed999:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   ed9a1:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   ed9a9:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   ed9b5:	48 89 9c 24 d8 01 00 00 	mov    %rbx,0x1d8(%rsp)
   ed9bd:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   ed9c9:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   ed9d5:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   ed9e1:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   ed9ed:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   ed9f9:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   eda04:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   eda0c:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   eda17:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   eda23:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   eda2b:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   eda37:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   eda42:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   eda4a:	48 89 9c 24 78 02 00 00 	mov    %rbx,0x278(%rsp)
   eda52:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   eda5e:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   eda6a:	48 89 9c 24 90 02 00 00 	mov    %rbx,0x290(%rsp)
   eda72:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   eda7e:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   eda86:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   eda8e:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   eda96:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   eda9e:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   edaa6:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   edab2:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   edaba:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   edac3:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   edacb:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   edad3:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   edadc:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   edae4:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   edaec:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   edaf5:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   edafd:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   edb04:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   edb0c:	48 89 9c 24 a8 02 00 00 	mov    %rbx,0x2a8(%rsp)
   edb14:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   edb20:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   edb2c:	48 89 9c 24 c0 02 00 00 	mov    %rbx,0x2c0(%rsp)
   edb34:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   edb40:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   edb4c:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   edb58:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   edb63:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   edb6f:	48 89 9c 24 60 03 00 00 	mov    %rbx,0x360(%rsp)
   edb77:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   edb82:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   edb8d:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   edb99:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   edba1:	48 89 9c 24 00 04 00 00 	mov    %rbx,0x400(%rsp)
   edba9:	48 89 9c 24 18 04 00 00 	mov    %rbx,0x418(%rsp)
   edbb1:	48 89 9c 24 30 04 00 00 	mov    %rbx,0x430(%rsp)
   edbb9:	48 89 9c 24 48 04 00 00 	mov    %rbx,0x448(%rsp)
   edbc1:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   edbc9:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   edbd1:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   edbd9:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   edbe1:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   edbe9:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   edbf0:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   edbf9:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   edc04:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   edc0b:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   edc12:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   edc1d:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   edc24:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   edc2c:	e8 8f 00 01 00       	call   fdcc0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   edc31:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   edc38:	0f 85 72 06 00 00    	jne    ee2b0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   edc3e:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   edc47:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   edc4f:	48 89 5b 50          	mov    %rbx,0x50(%rbx)
   edc53:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   edc5b:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   edc64:	c6 83 ec 00 00 00 00 	movb   $0x0,0xec(%rbx)
   edc6b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
   edc6f:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   edc78:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   edc80:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   edc84:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   edc8d:	48 89 43 48          	mov    %rax,0x48(%rbx)
   edc91:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   edc98:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
   edc9c:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   edca5:	48 89 83 98 00 00 00 	mov    %rax,0x98(%rbx)
   edcac:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   edcb1:	0f 11 43 38          	movups %xmm0,0x38(%rbx)
   edcb5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edcb9:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
   edcc0:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   edcc9:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
   edcd0:	0f 11 83 a8 00 00 00 	movups %xmm0,0xa8(%rbx)
   edcd7:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   edcdf:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   edce8:	48 c7 43 58 00 00 00 00 	movq   $0x0,0x58(%rbx)
   edcf0:	0f 11 83 b1 00 00 00 	movups %xmm0,0xb1(%rbx)
   edcf7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edcfb:	0f 11 83 d0 00 00 00 	movups %xmm0,0xd0(%rbx)
   edd02:	48 c7 43 60 00 00 00 00 	movq   $0x0,0x60(%rbx)
   edd0a:	48 c7 43 68 00 00 00 00 	movq   $0x0,0x68(%rbx)
   edd12:	48 c7 43 70 00 00 00 00 	movq   $0x0,0x70(%rbx)
   edd1a:	48 c7 43 78 00 00 00 00 	movq   $0x0,0x78(%rbx)
   edd22:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   edd2c:	c6 83 94 00 00 00 00 	movb   $0x0,0x94(%rbx)
   edd33:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   edd3d:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   edd48:	c7 83 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%rbx)
   edd52:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   edd59:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   edd62:	48 89 9b f0 00 00 00 	mov    %rbx,0xf0(%rbx)
   edd69:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
   edd6f:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   edd76:	48 c7 83 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rbx)
   edd81:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   edd88:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   edd8d:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   edd94:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   edd9b:	48 c7 83 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rbx)
   edda6:	48 89 9b 08 01 00 00 	mov    %rbx,0x108(%rbx)
   eddad:	48 c7 83 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rbx)
   eddb8:	48 c7 83 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rbx)
   eddc3:	48 89 9b 20 01 00 00 	mov    %rbx,0x120(%rbx)
   eddca:	48 c7 83 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rbx)
   eddd5:	48 c7 83 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rbx)
   edde0:	48 89 9b 38 01 00 00 	mov    %rbx,0x138(%rbx)
   edde7:	48 c7 83 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rbx)
   eddf2:	48 c7 83 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rbx)
   eddfd:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   ede08:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   ede12:	c6 83 80 01 00 00 01 	movb   $0x1,0x180(%rbx)
   ede19:	89 83 b8 02 00 00    	mov    %eax,0x2b8(%rbx)
   ede1f:	0f 11 83 50 01 00 00 	movups %xmm0,0x150(%rbx)
   ede26:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   ede2f:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ede37:	e8 84 fe 00 00       	call   fdcc0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ede3c:	4c 39 a3 c0 02 00 00 	cmp    %r12,0x2c0(%rbx)
   ede43:	0f 82 27 04 00 00    	jb     ee270 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb60>
   ede49:	48 8b 93 78 02 00 00 	mov    0x278(%rbx),%rdx
   ede50:	4c 8b 93 70 02 00 00 	mov    0x270(%rbx),%r10
   ede57:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   ede61:	48 89 d1             	mov    %rdx,%rcx
   ede64:	4c 29 d1             	sub    %r10,%rcx
   ede67:	48 89 c8             	mov    %rcx,%rax
   ede6a:	48 c1 f8 03          	sar    $0x3,%rax
   ede6e:	48 0f af c7          	imul   %rdi,%rax
   ede72:	4c 39 e0             	cmp    %r12,%rax
   ede75:	0f 82 85 03 00 00    	jb     ee200 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf0>
   ede7b:	49 39 c4             	cmp    %rax,%r12
   ede7e:	73 16                	jae    ede96 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   ede80:	49 6b c4 38          	imul   $0x38,%r12,%rax
   ede84:	49 01 c2             	add    %rax,%r10
   ede87:	4c 39 d2             	cmp    %r10,%rdx
   ede8a:	74 07                	je     ede93 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x783>
   ede8c:	4c 89 93 78 02 00 00 	mov    %r10,0x278(%rbx)
   ede93:	4c 89 d2             	mov    %r10,%rdx
   ede96:	48 8b b3 70 02 00 00 	mov    0x270(%rbx),%rsi
   ede9d:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   edea3:	74 4c                	je     edef1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7e1>
   edea5:	48 89 f0             	mov    %rsi,%rax
   edea8:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edeac:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   edeb0:	31 c9                	xor    %ecx,%ecx
   edeb2:	0f 1f 00             	nopl   (%rax)
   edeb5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edec0:	f3 0f 6f 4d 00       	movdqu 0x0(%rbp),%xmm1
   edec5:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   edec9:	48 83 c5 10          	add    $0x10,%rbp
   edecd:	48 83 c0 38          	add    $0x38,%rax
   eded1:	89 48 d8             	mov    %ecx,-0x28(%rax)
   eded4:	48 83 c1 01          	add    $0x1,%rcx
   eded8:	0f 11 40 e8          	movups %xmm0,-0x18(%rax)
   ededc:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   edee4:	0f 11 48 c8          	movups %xmm1,-0x38(%rax)
   edee8:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
   edeec:	4c 39 e1             	cmp    %r12,%rcx
   edeef:	72 cf                	jb     edec0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7b0>
   edef1:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   edefd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edf01:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   edf09:	48 39 d6             	cmp    %rdx,%rsi
   edf0c:	0f 84 b6 03 00 00    	je     ee2c8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbb8>
   edf12:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   edf1c:	48 29 f2             	sub    %rsi,%rdx
   edf1f:	48 c1 fa 03          	sar    $0x3,%rdx
   edf23:	48 0f af d0          	imul   %rax,%rdx
   edf27:	48 39 53 38          	cmp    %rdx,0x38(%rbx)
   edf2b:	0f 82 1f 04 00 00    	jb     ee350 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc40>
   edf31:	48 83 ec 20          	sub    $0x20,%rsp
   edf35:	48 8d 8b 88 01 00 00 	lea    0x188(%rbx),%rcx
   edf3c:	48 8d b3 70 02 00 00 	lea    0x270(%rbx),%rsi
   edf43:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   edf4c:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   edf50:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   edf59:	0f 11 04 24          	movups %xmm0,(%rsp)
   edf5d:	e8 8e 50 fe ff       	call   d2ff0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   edf62:	48 83 c4 20          	add    $0x20,%rsp
   edf66:	84 c0                	test   %al,%al
   edf68:	0f 85 bc 06 00 00    	jne    ee62a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf1a>
   edf6e:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   edf77:	0f 84 e3 01 00 00    	je     ee160 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa50>
   edf7d:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   edf82:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   edf8a:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   edf92:	48 89 de             	mov    %rbx,%rsi
   edf95:	e8 36 f6 ff ff       	call   ed5d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   edf9a:	8b 74 24 1c          	mov    0x1c(%rsp),%esi
   edf9e:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   edfa5:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   edfaf:	48 8b bc 24 38 03 00 00 	mov    0x338(%rsp),%rdi
   edfb7:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   edfbd:	39 c6                	cmp    %eax,%esi
   edfbf:	48 8b 94 24 c8 00 00 00 	mov    0xc8(%rsp),%rdx
   edfc7:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   edfd0:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   edfd9:	0f 43 c6             	cmovae %esi,%eax
   edfdc:	48 01 3c 24          	add    %rdi,(%rsp)
   edfe0:	48 8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%rdi
   edfe8:	48 01 7c 24 08       	add    %rdi,0x8(%rsp)
   edfed:	4c 01 ea             	add    %r13,%rdx
   edff0:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   edff4:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   edff8:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   ee001:	41 89 47 38          	mov    %eax,0x38(%r15)
   ee005:	48 8b 04 24          	mov    (%rsp),%rax
   ee009:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   ee00d:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   ee013:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   ee018:	49 89 47 40          	mov    %rax,0x40(%r15)
   ee01c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ee021:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   ee026:	49 89 47 48          	mov    %rax,0x48(%r15)
   ee02a:	48 89 d0             	mov    %rdx,%rax
   ee02d:	48 c1 e8 1e          	shr    $0x1e,%rax
   ee031:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   ee036:	48 31 d0             	xor    %rdx,%rax
   ee039:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   ee03e:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   ee048:	48 0f af c2          	imul   %rdx,%rax
   ee04c:	48 89 c2             	mov    %rax,%rdx
   ee04f:	48 c1 ea 1b          	shr    $0x1b,%rdx
   ee053:	48 31 d0             	xor    %rdx,%rax
   ee056:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   ee060:	48 0f af c2          	imul   %rdx,%rax
   ee064:	48 89 c2             	mov    %rax,%rdx
   ee067:	48 c1 ea 1f          	shr    $0x1f,%rdx
   ee06b:	48 31 d0             	xor    %rdx,%rax
   ee06e:	48 01 44 24 10       	add    %rax,0x10(%rsp)
   ee073:	45 84 f6             	test   %r14b,%r14b
   ee076:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   ee07b:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   ee083:	49 89 77 50          	mov    %rsi,0x50(%r15)
   ee087:	44 0f 44 f0          	cmove  %eax,%r14d
   ee08b:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   ee093:	49 83 c5 01          	add    $0x1,%r13
   ee097:	48 8b 10             	mov    (%rax),%rdx
   ee09a:	45 88 77 68          	mov    %r14b,0x68(%r15)
   ee09e:	48 8b 40 08          	mov    0x8(%rax),%rax
   ee0a2:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   ee0a7:	48 29 d0             	sub    %rdx,%rax
   ee0aa:	48 c1 f8 03          	sar    $0x3,%rax
   ee0ae:	48 0f af c1          	imul   %rcx,%rax
   ee0b2:	49 39 c5             	cmp    %rax,%r13
   ee0b5:	0f 82 85 f7 ff ff    	jb     ed840 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   ee0bb:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   ee0c3:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   ee0cb:	80 3d a6 11 08 00 00 	cmpb   $0x0,0x811a6(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ee0d2:	0f 84 21 05 00 00    	je     ee5f9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xee9>
   ee0d8:	0f 31                	rdtsc
   ee0da:	48 c1 e2 20          	shl    $0x20,%rdx
   ee0de:	48 09 d0             	or     %rdx,%rax
   ee0e1:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   ee0e9:	0f 88 d2 04 00 00    	js     ee5c1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xeb1>
   ee0ef:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee0f3:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ee0f8:	f2 0f 59 05 30 11 08 00 	mulsd  0x81130(%rip),%xmm0        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ee100:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ee105:	49 89 07             	mov    %rax,(%r15)
   ee108:	e8 13 02 06 00       	call   14e320 <_ZN5bench6memory11allocationsEv>
   ee10d:	4c 29 f0             	sub    %r14,%rax
   ee110:	49 89 47 58          	mov    %rax,0x58(%r15)
   ee114:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   ee11c:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   ee125:	0f 85 f2 04 00 00    	jne    ee61d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf0d>
   ee12b:	4c 89 f8             	mov    %r15,%rax
   ee12e:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   ee136:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   ee13e:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   ee146:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   ee14e:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   ee156:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   ee15d:	c3                   	ret
   ee15e:	66 90                	xchg   %ax,%ax
   ee160:	80 3d 11 11 08 00 00 	cmpb   $0x0,0x81111(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ee167:	0f 84 db 03 00 00    	je     ee548 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe38>
   ee16d:	0f 31                	rdtsc
   ee16f:	48 c1 e2 20          	shl    $0x20,%rdx
   ee173:	48 09 d0             	or     %rdx,%rax
   ee176:	48 89 c5             	mov    %rax,%rbp
   ee179:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   ee17e:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ee186:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   ee18e:	48 89 de             	mov    %rbx,%rsi
   ee191:	e8 3a f4 ff ff       	call   ed5d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   ee196:	f2 0f 10 0d 92 10 08 00 	movsd  0x81092(%rip),%xmm1        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ee19e:	48 89 e8             	mov    %rbp,%rax
   ee1a1:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   ee1a9:	0f 88 61 03 00 00    	js     ee510 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe00>
   ee1af:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee1b3:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ee1b8:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   ee1bc:	80 3d b5 10 08 00 00 	cmpb   $0x0,0x810b5(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ee1c3:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ee1c8:	49 89 47 08          	mov    %rax,0x8(%r15)
   ee1cc:	0f 84 5e 03 00 00    	je     ee530 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe20>
   ee1d2:	0f 31                	rdtsc
   ee1d4:	48 c1 e2 20          	shl    $0x20,%rdx
   ee1d8:	48 09 d0             	or     %rdx,%rax
   ee1db:	48 29 e8             	sub    %rbp,%rax
   ee1de:	0f 88 0c 03 00 00    	js     ee4f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xde0>
   ee1e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee1e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ee1ed:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   ee1f1:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ee1f6:	49 89 47 10          	mov    %rax,0x10(%r15)
   ee1fa:	e9 9b fd ff ff       	jmp    edf9a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x88a>
   ee1ff:	90                   	nop
   ee200:	48 8b b3 80 02 00 00 	mov    0x280(%rbx),%rsi
   ee207:	4d 89 e3             	mov    %r12,%r11
   ee20a:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   ee214:	49 29 c3             	sub    %rax,%r11
   ee217:	48 89 f7             	mov    %rsi,%rdi
   ee21a:	48 29 d7             	sub    %rdx,%rdi
   ee21d:	48 c1 ff 03          	sar    $0x3,%rdi
   ee221:	49 0f af f9          	imul   %r9,%rdi
   ee225:	4c 39 df             	cmp    %r11,%rdi
   ee228:	0f 82 42 01 00 00    	jb     ee370 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc60>
   ee22e:	4c 89 d9             	mov    %r11,%rcx
   ee231:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee235:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   ee239:	48 89 d0             	mov    %rdx,%rax
   ee23c:	0f 1f 40 00          	nopl   0x0(%rax)
   ee240:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   ee244:	48 83 c0 38          	add    $0x38,%rax
   ee248:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   ee24c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   ee250:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   ee254:	48 83 e9 01          	sub    $0x1,%rcx
   ee258:	75 e6                	jne    ee240 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb30>
   ee25a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   ee25e:	4c 01 da             	add    %r11,%rdx
   ee261:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   ee268:	e9 29 fc ff ff       	jmp    ede96 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   ee26d:	0f 1f 00             	nopl   (%rax)
   ee270:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee274:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   ee27c:	48 8d bb 88 01 00 00 	lea    0x188(%rbx),%rdi
   ee283:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   ee28b:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   ee293:	e8 68 43 02 00       	call   112600 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   ee298:	84 c0                	test   %al,%al
   ee29a:	0f 85 8a 03 00 00    	jne    ee62a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf1a>
   ee2a0:	4c 89 a3 c0 02 00 00 	mov    %r12,0x2c0(%rbx)
   ee2a7:	e9 9d fb ff ff       	jmp    ede49 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x739>
   ee2ac:	0f 1f 40 00          	nopl   0x0(%rax)
   ee2b0:	c6 83 80 01 00 00 00 	movb   $0x0,0x180(%rbx)
   ee2b7:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   ee2bb:	e8 00 fa 00 00       	call   fdcc0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ee2c0:	e9 79 f9 ff ff       	jmp    edc3e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x52e>
   ee2c5:	0f 1f 00             	nopl   (%rax)
   ee2c8:	48 83 bb c8 00 00 00 00 	cmpq   $0x0,0xc8(%rbx)
   ee2d0:	74 55                	je     ee327 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc17>
   ee2d2:	48 8b 93 80 00 00 00 	mov    0x80(%rbx),%rdx
   ee2d9:	48 85 d2             	test   %rdx,%rdx
   ee2dc:	0f 85 73 02 00 00    	jne    ee555 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe45>
   ee2e2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ee2e7:	66 0f 6f 05 91 95 06 00 	movdqa 0x69591(%rip),%xmm0        # 157880 <C.66.5+0x260>
   ee2ef:	c7 83 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%rbx)
   ee2f9:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   ee304:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   ee30b:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   ee316:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   ee320:	0f 11 83 dc 00 00 00 	movups %xmm0,0xdc(%rbx)
   ee327:	80 7b 08 00          	cmpb   $0x0,0x8(%rbx)
   ee32b:	0f 84 3d fc ff ff    	je     edf6e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x85e>
   ee331:	80 bb 60 01 00 00 00 	cmpb   $0x0,0x160(%rbx)
   ee338:	0f 84 30 fc ff ff    	je     edf6e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x85e>
   ee33e:	c6 83 60 01 00 00 00 	movb   $0x0,0x160(%rbx)
   ee345:	e9 24 fc ff ff       	jmp    edf6e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x85e>
   ee34a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ee350:	ba 10 00 00 00       	mov    $0x10,%edx
   ee355:	48 8b 3d 04 0f 08 00 	mov    0x80f04(%rip),%rdi        # 16f260 <stderr@GLIBC_2.2.5>
   ee35c:	48 8d 35 3d 76 06 00 	lea    0x6763d(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   ee363:	31 c0                	xor    %eax,%eax
   ee365:	e8 d6 8f f1 ff       	call   7340 <fprintf@plt>
   ee36a:	e8 b1 8d f1 ff       	call   7120 <abort@plt>
   ee36f:	90                   	nop
   ee370:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   ee37a:	48 29 c7             	sub    %rax,%rdi
   ee37d:	4c 39 df             	cmp    %r11,%rdi
   ee380:	0f 82 b4 e9 f1 ff    	jb     cd3a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   ee386:	4c 39 d8             	cmp    %r11,%rax
   ee389:	4c 89 df             	mov    %r11,%rdi
   ee38c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   ee394:	48 0f 43 f8          	cmovae %rax,%rdi
   ee398:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   ee3a0:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   ee3a8:	48 01 c7             	add    %rax,%rdi
   ee3ab:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   ee3b0:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   ee3ba:	48 39 c7             	cmp    %rax,%rdi
   ee3bd:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   ee3c2:	48 0f 47 f8          	cmova  %rax,%rdi
   ee3c6:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   ee3ca:	48 89 c7             	mov    %rax,%rdi
   ee3cd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   ee3d2:	e8 29 00 06 00       	call   14e400 <_Znwm>
   ee3d7:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   ee3dd:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   ee3e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee3e9:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   ee3ee:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   ee3f6:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   ee3fa:	48 01 c1             	add    %rax,%rcx
   ee3fd:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   ee405:	49 01 cb             	add    %rcx,%r11
   ee408:	66 90                	xchg   %ax,%ax
   ee40a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee415:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee420:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   ee424:	48 83 c1 38          	add    $0x38,%rcx
   ee428:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   ee42c:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   ee430:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   ee434:	4c 39 d9             	cmp    %r11,%rcx
   ee437:	75 e7                	jne    ee420 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd10>
   ee439:	4c 39 d2             	cmp    %r10,%rdx
   ee43c:	74 71                	je     ee4af <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd9f>
   ee43e:	4c 89 d1             	mov    %r10,%rcx
   ee441:	48 89 c7             	mov    %rax,%rdi
   ee444:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   ee449:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee454:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee45f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee46a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee475:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee480:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   ee484:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   ee488:	48 83 c1 38          	add    $0x38,%rcx
   ee48c:	48 83 c7 38          	add    $0x38,%rdi
   ee490:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   ee494:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   ee499:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   ee49d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   ee4a1:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   ee4a6:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   ee4aa:	48 39 ca             	cmp    %rcx,%rdx
   ee4ad:	75 d1                	jne    ee480 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd70>
   ee4af:	4d 85 d2             	test   %r10,%r10
   ee4b2:	74 15                	je     ee4c9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdb9>
   ee4b4:	4c 29 d6             	sub    %r10,%rsi
   ee4b7:	4c 89 d7             	mov    %r10,%rdi
   ee4ba:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   ee4bf:	e8 3c 00 06 00       	call   14e500 <_ZdlPvm>
   ee4c4:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   ee4c9:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   ee4cd:	48 89 83 70 02 00 00 	mov    %rax,0x270(%rbx)
   ee4d4:	48 01 c2             	add    %rax,%rdx
   ee4d7:	48 03 44 24 40       	add    0x40(%rsp),%rax
   ee4dc:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   ee4e3:	48 89 83 80 02 00 00 	mov    %rax,0x280(%rbx)
   ee4ea:	e9 a7 f9 ff ff       	jmp    ede96 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   ee4ef:	90                   	nop
   ee4f0:	48 89 c2             	mov    %rax,%rdx
   ee4f3:	83 e0 01             	and    $0x1,%eax
   ee4f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee4fa:	48 d1 ea             	shr    $1,%rdx
   ee4fd:	48 09 c2             	or     %rax,%rdx
   ee500:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   ee505:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   ee509:	e9 df fc ff ff       	jmp    ee1ed <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xadd>
   ee50e:	66 90                	xchg   %ax,%ax
   ee510:	48 89 c2             	mov    %rax,%rdx
   ee513:	83 e0 01             	and    $0x1,%eax
   ee516:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee51a:	48 d1 ea             	shr    $1,%rdx
   ee51d:	48 09 c2             	or     %rax,%rdx
   ee520:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   ee525:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   ee529:	e9 8a fc ff ff       	jmp    ee1b8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa8>
   ee52e:	66 90                	xchg   %ax,%ax
   ee530:	e8 9b 8d f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   ee535:	f2 0f 10 0d f3 0c 08 00 	movsd  0x80cf3(%rip),%xmm1        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ee53d:	e9 99 fc ff ff       	jmp    ee1db <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xacb>
   ee542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ee548:	e8 83 8d f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   ee54d:	48 89 c5             	mov    %rax,%rbp
   ee550:	e9 24 fc ff ff       	jmp    ee179 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa69>
   ee555:	48 c7 83 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%rbx)
   ee560:	80 bb 94 00 00 00 00 	cmpb   $0x0,0x94(%rbx)
   ee567:	0f 85 96 00 00 00    	jne    ee603 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef3>
   ee56d:	8b 83 90 00 00 00    	mov    0x90(%rbx),%eax
   ee573:	83 c0 01             	add    $0x1,%eax
   ee576:	89 83 90 00 00 00    	mov    %eax,0x90(%rbx)
   ee57c:	83 f8 ff             	cmp    $0xffffffff,%eax
   ee57f:	0f 85 5d fd ff ff    	jne    ee2e2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd2>
   ee585:	48 8b 43 78          	mov    0x78(%rbx),%rax
   ee589:	48 89 d1             	mov    %rdx,%rcx
   ee58c:	48 c1 e1 04          	shl    $0x4,%rcx
   ee590:	48 01 c1             	add    %rax,%rcx
   ee593:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   ee59a:	48 83 c0 10          	add    $0x10,%rax
   ee59e:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   ee5a6:	48 39 c8             	cmp    %rcx,%rax
   ee5a9:	75 e8                	jne    ee593 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe83>
   ee5ab:	48 01 93 b0 00 00 00 	add    %rdx,0xb0(%rbx)
   ee5b2:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   ee5bc:	e9 21 fd ff ff       	jmp    ee2e2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd2>
   ee5c1:	48 89 c2             	mov    %rax,%rdx
   ee5c4:	83 e0 01             	and    $0x1,%eax
   ee5c7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee5cb:	48 d1 ea             	shr    $1,%rdx
   ee5ce:	48 09 c2             	or     %rax,%rdx
   ee5d1:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   ee5d6:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   ee5da:	e9 19 fb ff ff       	jmp    ee0f8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9e8>
   ee5df:	4c 89 1c 24          	mov    %r11,(%rsp)
   ee5e3:	e8 b8 2a f2 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   ee5e8:	4c 8b 1c 24          	mov    (%rsp),%r11
   ee5ec:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   ee5f4:	e9 c6 f1 ff ff       	jmp    ed7bf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf>
   ee5f9:	e8 a2 2a f2 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   ee5fe:	e9 de fa ff ff       	jmp    ee0e1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9d1>
   ee603:	48 c7 83 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rbx)
   ee60e:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   ee618:	e9 c5 fc ff ff       	jmp    ee2e2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd2>
   ee61d:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   ee625:	e8 36 8c f1 ff       	call   7260 <__stack_chk_fail@plt>
   ee62a:	0f b6 d0             	movzbl %al,%edx
   ee62d:	e9 23 fd ff ff       	jmp    ee355 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc45>

# candidate ordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, true>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f1340 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f1340:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f1347:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f134b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f1353:	48 8b 2a             	mov    (%rdx),%rbp
   f1356:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f135e:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f1362:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f136a:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f1372:	49 89 ff             	mov    %rdi,%r15
   f1375:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f137d:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f1384:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f1389:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f1392:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f139a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f139e:	0f 11 07             	movups %xmm0,(%rdi)
   f13a1:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f13a5:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f13a9:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f13ad:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f13b1:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f13b5:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f13b9:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f13bd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   f13c2:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f13c6:	e8 55 cf 05 00       	call   14e320 <_ZN5bench6memory11allocationsEv>
   f13cb:	80 3d a6 de 07 00 00 	cmpb   $0x0,0x7dea6(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f13d2:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f13d7:	49 89 c6             	mov    %rax,%r14
   f13da:	0f 84 83 0e 00 00    	je     f2263 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf23>
   f13e0:	0f 31                	rdtsc
   f13e2:	48 c1 e2 20          	shl    $0x20,%rdx
   f13e6:	48 09 d0             	or     %rdx,%rax
   f13e9:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f13f1:	49 8b 11             	mov    (%r9),%rdx
   f13f4:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   f13f8:	0f 84 4b 09 00 00    	je     f1d49 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa09>
   f13fe:	49 29 ec             	sub    %rbp,%r12
   f1401:	c6 44 24 77 00       	movb   $0x0,0x77(%rsp)
   f1406:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f140e:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f1412:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f141a:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   f1423:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f142c:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f1435:	c7 44 24 70 00 00 00 00 	movl   $0x0,0x70(%rsp)
   f143d:	4c 89 8c 24 88 00 00 00 	mov    %r9,0x88(%rsp)
   f1445:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f144d:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   f1455:	49 89 de             	mov    %rbx,%r14
   f1458:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f1460:	45 31 ed             	xor    %r13d,%r13d
   f1463:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f1468:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f146d:	0f 1f 00             	nopl   (%rax)
   f1470:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   f1475:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f1479:	48 8b 28             	mov    (%rax),%rbp
   f147c:	48 8b 58 08          	mov    0x8(%rax),%rbx
   f1480:	48 29 eb             	sub    %rbp,%rbx
   f1483:	49 89 dc             	mov    %rbx,%r12
   f1486:	49 c1 fc 04          	sar    $0x4,%r12
   f148a:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f1492:	74 14                	je     f14a8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x168>
   f1494:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f149b:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   f14a2:	0f 84 cb 05 00 00    	je     f1a73 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x733>
   f14a8:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f14b0:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f14b4:	31 f6                	xor    %esi,%esi
   f14b6:	66 0f 6f 3d 02 64 06 00 	movdqa 0x66402(%rip),%xmm7        # 1578c0 <C.66.5+0x2a0>
   f14be:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f14c6:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f14ce:	ba 88 01 00 00       	mov    $0x188,%edx
   f14d3:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f14da:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f14df:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f14e7:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f14ef:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f14f4:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f14fc:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f1500:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f1509:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f1511:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f151a:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f1522:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f152b:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f1533:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f153b:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f1540:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f1548:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f154d:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f1555:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f155a:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f1562:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f156e:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f157a:	e8 91 5b f1 ff       	call   7110 <memset@plt>
   f157f:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f1585:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f1589:	66 0f 6f 05 3f 63 06 00 	movdqa 0x6633f(%rip),%xmm0        # 1578d0 <C.66.5+0x2b0>
   f1591:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f1597:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f159d:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f15a1:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f15a8:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f15b0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f15b5:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f15bd:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f15c5:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f15cd:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f15d9:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   f15e1:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f15ed:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f15f9:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f1605:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f1611:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f161d:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f1628:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f1630:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f163b:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f1647:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f164f:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f165b:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f1666:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f166e:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   f1676:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f1682:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f168e:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   f1696:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f16a2:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f16aa:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f16b2:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f16ba:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f16c2:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f16ca:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f16d6:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f16de:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f16e7:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f16ef:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f16f7:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f1700:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f1708:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f1710:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f1719:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f1721:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1728:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f1730:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   f1738:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f1744:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f1750:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   f1758:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f1764:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f1770:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f177c:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f1787:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f1793:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   f179b:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f17a6:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f17b1:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f17bd:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f17c5:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   f17cd:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   f17d5:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   f17dd:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   f17e5:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f17ed:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f17f5:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f17fd:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f1805:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f180d:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f1814:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f181d:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f1828:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f182f:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f1836:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f1841:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f1848:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f1850:	e8 6b c4 00 00       	call   fdcc0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1855:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f185d:	0f 85 f5 06 00 00    	jne    f1f58 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc18>
   f1863:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f186c:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f1874:	4d 89 76 50          	mov    %r14,0x50(%r14)
   f1878:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f1880:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f1889:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   f1891:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   f1896:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f189f:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f18a7:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   f18ac:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f18b5:	49 89 46 48          	mov    %rax,0x48(%r14)
   f18b9:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f18c0:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   f18c5:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f18ce:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   f18d5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f18da:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   f18df:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f18e3:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   f18eb:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f18f4:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   f18fb:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   f1903:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f190b:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f1914:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   f191c:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   f1924:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1928:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   f1930:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   f1938:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   f1940:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   f1948:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   f1950:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f195b:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   f1963:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f196e:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f1979:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   f1984:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f198b:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f1994:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   f199b:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   f19a2:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f19a9:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   f19b4:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f19bb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f19c0:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f19c7:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f19ce:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   f19d9:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   f19e0:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   f19eb:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   f19f6:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   f19fd:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   f1a08:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   f1a13:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   f1a1a:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   f1a25:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   f1a30:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f1a3b:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f1a46:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   f1a4e:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   f1a55:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   f1a5d:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f1a66:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f1a6e:	e8 4d c2 00 00       	call   fdcc0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1a73:	4d 39 a6 c0 02 00 00 	cmp    %r12,0x2c0(%r14)
   f1a7a:	0f 82 90 04 00 00    	jb     f1f10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd0>
   f1a80:	49 8b 96 78 02 00 00 	mov    0x278(%r14),%rdx
   f1a87:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f1a8e:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   f1a98:	48 89 d1             	mov    %rdx,%rcx
   f1a9b:	4c 29 d1             	sub    %r10,%rcx
   f1a9e:	48 89 c8             	mov    %rcx,%rax
   f1aa1:	48 c1 f8 03          	sar    $0x3,%rax
   f1aa5:	48 0f af c7          	imul   %rdi,%rax
   f1aa9:	4c 39 e0             	cmp    %r12,%rax
   f1aac:	0f 82 ee 03 00 00    	jb     f1ea0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb60>
   f1ab2:	49 39 c4             	cmp    %rax,%r12
   f1ab5:	73 16                	jae    f1acd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f1ab7:	49 6b c4 38          	imul   $0x38,%r12,%rax
   f1abb:	49 01 c2             	add    %rax,%r10
   f1abe:	4c 39 d2             	cmp    %r10,%rdx
   f1ac1:	74 07                	je     f1aca <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   f1ac3:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f1aca:	4c 89 d2             	mov    %r10,%rdx
   f1acd:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f1ad4:	48 85 db             	test   %rbx,%rbx
   f1ad7:	0f 84 7c 00 00 00    	je     f1b59 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x819>
   f1add:	4c 89 d1             	mov    %r10,%rcx
   f1ae0:	31 f6                	xor    %esi,%esi
   f1ae2:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1ae6:	49 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%r11
   f1af0:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   f1afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1b00:	41 89 f0             	mov    %esi,%r8d
   f1b03:	f3 0f 6f 45 00       	movdqu 0x0(%rbp),%xmm0
   f1b08:	89 71 10             	mov    %esi,0x10(%rcx)
   f1b0b:	48 83 c6 01          	add    $0x1,%rsi
   f1b0f:	41 81 f0 6b 6e 61 72 	xor    $0x72616e6b,%r8d
   f1b16:	c6 41 30 01          	movb   $0x1,0x30(%rcx)
   f1b1a:	48 83 c5 10          	add    $0x10,%rbp
   f1b1e:	48 83 c1 38          	add    $0x38,%rcx
   f1b22:	4c 89 c0             	mov    %r8,%rax
   f1b25:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f1b29:	48 c1 e8 1e          	shr    $0x1e,%rax
   f1b2d:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f1b31:	4c 31 c0             	xor    %r8,%rax
   f1b34:	49 0f af c3          	imul   %r11,%rax
   f1b38:	49 89 c0             	mov    %rax,%r8
   f1b3b:	49 c1 e8 1b          	shr    $0x1b,%r8
   f1b3f:	4c 31 c0             	xor    %r8,%rax
   f1b42:	48 0f af c7          	imul   %rdi,%rax
   f1b46:	49 89 c0             	mov    %rax,%r8
   f1b49:	49 c1 e8 1f          	shr    $0x1f,%r8
   f1b4d:	4c 31 c0             	xor    %r8,%rax
   f1b50:	48 89 41 f0          	mov    %rax,-0x10(%rcx)
   f1b54:	4c 39 e6             	cmp    %r12,%rsi
   f1b57:	72 a7                	jb     f1b00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f1b59:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f1b65:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1b69:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f1b71:	4c 39 d2             	cmp    %r10,%rdx
   f1b74:	0f 84 f6 03 00 00    	je     f1f70 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc30>
   f1b7a:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f1b84:	4c 29 d2             	sub    %r10,%rdx
   f1b87:	48 c1 fa 03          	sar    $0x3,%rdx
   f1b8b:	48 0f af d0          	imul   %rax,%rdx
   f1b8f:	49 39 56 38          	cmp    %rdx,0x38(%r14)
   f1b93:	0f 82 67 04 00 00    	jb     f2000 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc0>
   f1b99:	48 83 ec 20          	sub    $0x20,%rsp
   f1b9d:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   f1ba4:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   f1bab:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f1bb4:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f1bb8:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f1bc1:	0f 11 04 24          	movups %xmm0,(%rsp)
   f1bc5:	e8 26 14 fe ff       	call   d2ff0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f1bca:	48 83 c4 20          	add    $0x20,%rsp
   f1bce:	84 c0                	test   %al,%al
   f1bd0:	0f 85 db 06 00 00    	jne    f22b1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf71>
   f1bd6:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f1bdf:	0f 84 fb 01 00 00    	je     f1de0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa0>
   f1be5:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f1bea:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1bee:	4c 89 f6             	mov    %r14,%rsi
   f1bf1:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f1bf9:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f1c01:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f1c09:	e8 12 ed ff ff       	call   f0920 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f1c0e:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f1c16:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f1c1e:	8b 7c 24 70          	mov    0x70(%rsp),%edi
   f1c22:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f1c29:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   f1c2d:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f1c37:	48 8b b4 24 38 03 00 00 	mov    0x338(%rsp),%rsi
   f1c3f:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f1c45:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f1c4e:	39 c7                	cmp    %eax,%edi
   f1c50:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f1c59:	0f 43 c7             	cmovae %edi,%eax
   f1c5c:	48 01 74 24 08       	add    %rsi,0x8(%rsp)
   f1c61:	4c 01 64 24 10       	add    %r12,0x10(%rsp)
   f1c66:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f1c6a:	89 44 24 70          	mov    %eax,0x70(%rsp)
   f1c6e:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f1c72:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f1c7b:	41 89 47 38          	mov    %eax,0x38(%r15)
   f1c7f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f1c84:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f1c8a:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f1c8f:	49 89 47 40          	mov    %rax,0x40(%r15)
   f1c93:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f1c98:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f1c9d:	49 89 47 48          	mov    %rax,0x48(%r15)
   f1ca1:	48 89 d0             	mov    %rdx,%rax
   f1ca4:	48 c1 e8 1e          	shr    $0x1e,%rax
   f1ca8:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f1cad:	48 31 d0             	xor    %rdx,%rax
   f1cb0:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f1cb5:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f1cbf:	48 0f af c2          	imul   %rdx,%rax
   f1cc3:	48 89 c2             	mov    %rax,%rdx
   f1cc6:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f1cca:	48 31 d0             	xor    %rdx,%rax
   f1ccd:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f1cd7:	48 0f af c2          	imul   %rdx,%rax
   f1cdb:	48 89 c2             	mov    %rax,%rdx
   f1cde:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f1ce2:	48 31 d0             	xor    %rdx,%rax
   f1ce5:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   f1cea:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   f1cef:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f1cf7:	49 89 5f 50          	mov    %rbx,0x50(%r15)
   f1cfb:	0f b6 5c 24 77       	movzbl 0x77(%rsp),%ebx
   f1d00:	84 db                	test   %bl,%bl
   f1d02:	0f 44 d8             	cmove  %eax,%ebx
   f1d05:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f1d0d:	49 83 c5 01          	add    $0x1,%r13
   f1d11:	48 8b 10             	mov    (%rax),%rdx
   f1d14:	88 5c 24 77          	mov    %bl,0x77(%rsp)
   f1d18:	41 88 5f 68          	mov    %bl,0x68(%r15)
   f1d1c:	48 8b 40 08          	mov    0x8(%rax),%rax
   f1d20:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f1d25:	48 29 d0             	sub    %rdx,%rax
   f1d28:	48 c1 f8 03          	sar    $0x3,%rax
   f1d2c:	48 0f af c1          	imul   %rcx,%rax
   f1d30:	49 39 c5             	cmp    %rax,%r13
   f1d33:	0f 82 37 f7 ff ff    	jb     f1470 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f1d39:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   f1d41:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f1d49:	80 3d 28 d5 07 00 00 	cmpb   $0x0,0x7d528(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1d50:	0f 84 29 05 00 00    	je     f227f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf3f>
   f1d56:	0f 31                	rdtsc
   f1d58:	48 c1 e2 20          	shl    $0x20,%rdx
   f1d5c:	48 09 d0             	or     %rdx,%rax
   f1d5f:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f1d67:	0f 88 d8 04 00 00    	js     f2245 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf05>
   f1d6d:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1d71:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1d76:	f2 0f 59 05 b2 d4 07 00 	mulsd  0x7d4b2(%rip),%xmm0        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1d7e:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1d83:	49 89 07             	mov    %rax,(%r15)
   f1d86:	e8 95 c5 05 00       	call   14e320 <_ZN5bench6memory11allocationsEv>
   f1d8b:	4c 29 f0             	sub    %r14,%rax
   f1d8e:	49 89 47 58          	mov    %rax,0x58(%r15)
   f1d92:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f1d9a:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f1da3:	0f 85 fb 04 00 00    	jne    f22a4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf64>
   f1da9:	4c 89 f8             	mov    %r15,%rax
   f1dac:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f1db4:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f1dbc:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f1dc4:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f1dcc:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f1dd4:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f1ddb:	c3                   	ret
   f1ddc:	0f 1f 40 00          	nopl   0x0(%rax)
   f1de0:	80 3d 91 d4 07 00 00 	cmpb   $0x0,0x7d491(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1de7:	0f 84 db 03 00 00    	je     f21c8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe88>
   f1ded:	0f 31                	rdtsc
   f1def:	48 c1 e2 20          	shl    $0x20,%rdx
   f1df3:	48 09 d0             	or     %rdx,%rax
   f1df6:	48 89 c5             	mov    %rax,%rbp
   f1df9:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f1dfe:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1e02:	4c 89 f6             	mov    %r14,%rsi
   f1e05:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f1e0d:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f1e15:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f1e1d:	e8 fe ea ff ff       	call   f0920 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f1e22:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f1e2a:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f1e32:	48 89 e8             	mov    %rbp,%rax
   f1e35:	f2 0f 10 0d f3 d3 07 00 	movsd  0x7d3f3(%rip),%xmm1        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1e3d:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f1e45:	0f 88 45 03 00 00    	js     f2190 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe50>
   f1e4b:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1e4f:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1e54:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1e58:	80 3d 19 d4 07 00 00 	cmpb   $0x0,0x7d419(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1e5f:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1e64:	49 89 47 08          	mov    %rax,0x8(%r15)
   f1e68:	0f 84 42 03 00 00    	je     f21b0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   f1e6e:	0f 31                	rdtsc
   f1e70:	48 c1 e2 20          	shl    $0x20,%rdx
   f1e74:	48 09 d0             	or     %rdx,%rax
   f1e77:	48 29 e8             	sub    %rbp,%rax
   f1e7a:	0f 88 f0 02 00 00    	js     f2170 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe30>
   f1e80:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1e84:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1e89:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1e8d:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1e92:	49 89 47 10          	mov    %rax,0x10(%r15)
   f1e96:	e9 83 fd ff ff       	jmp    f1c1e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8de>
   f1e9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f1ea0:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   f1ea7:	4d 89 e3             	mov    %r12,%r11
   f1eaa:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   f1eb4:	49 29 c3             	sub    %rax,%r11
   f1eb7:	48 89 f7             	mov    %rsi,%rdi
   f1eba:	48 29 d7             	sub    %rdx,%rdi
   f1ebd:	48 c1 ff 03          	sar    $0x3,%rdi
   f1ec1:	49 0f af f9          	imul   %r9,%rdi
   f1ec5:	4c 39 df             	cmp    %r11,%rdi
   f1ec8:	0f 82 52 01 00 00    	jb     f2020 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xce0>
   f1ece:	4c 89 d9             	mov    %r11,%rcx
   f1ed1:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1ed5:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1ed9:	48 89 d0             	mov    %rdx,%rax
   f1edc:	0f 1f 40 00          	nopl   0x0(%rax)
   f1ee0:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f1ee4:	48 83 c0 38          	add    $0x38,%rax
   f1ee8:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f1eec:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f1ef0:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f1ef4:	48 83 e9 01          	sub    $0x1,%rcx
   f1ef8:	75 e6                	jne    f1ee0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   f1efa:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f1efe:	4c 01 da             	add    %r11,%rdx
   f1f01:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f1f08:	e9 c0 fb ff ff       	jmp    f1acd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f1f0d:	0f 1f 00             	nopl   (%rax)
   f1f10:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f1f18:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   f1f1f:	4c 89 a4 24 10 03 00 00 	mov    %r12,0x310(%rsp)
   f1f27:	48 c7 84 24 18 03 00 00 00 00 00 00 	movq   $0x0,0x318(%rsp)
   f1f33:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   f1f3b:	e8 c0 06 02 00       	call   112600 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f1f40:	84 c0                	test   %al,%al
   f1f42:	0f 85 69 03 00 00    	jne    f22b1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf71>
   f1f48:	4d 89 a6 c0 02 00 00 	mov    %r12,0x2c0(%r14)
   f1f4f:	e9 2c fb ff ff       	jmp    f1a80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x740>
   f1f54:	0f 1f 40 00          	nopl   0x0(%rax)
   f1f58:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   f1f60:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f1f64:	e8 57 bd 00 00       	call   fdcc0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1f69:	e9 f5 f8 ff ff       	jmp    f1863 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x523>
   f1f6e:	66 90                	xchg   %ax,%ax
   f1f70:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   f1f78:	74 58                	je     f1fd2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   f1f7a:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   f1f81:	48 85 d2             	test   %rdx,%rdx
   f1f84:	0f 85 4b 02 00 00    	jne    f21d5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe95>
   f1f8a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1f8f:	66 0f 6f 05 e9 58 06 00 	movdqa 0x658e9(%rip),%xmm0        # 157880 <C.66.5+0x260>
   f1f97:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   f1fa2:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f1fad:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f1fb4:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f1fbf:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f1fca:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   f1fd2:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f1fd7:	0f 84 f9 fb ff ff    	je     f1bd6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f1fdd:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   f1fe5:	0f 84 eb fb ff ff    	je     f1bd6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f1feb:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   f1ff3:	e9 de fb ff ff       	jmp    f1bd6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f1ff8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f2000:	ba 10 00 00 00       	mov    $0x10,%edx
   f2005:	48 8b 3d 54 d2 07 00 	mov    0x7d254(%rip),%rdi        # 16f260 <stderr@GLIBC_2.2.5>
   f200c:	48 8d 35 8d 39 06 00 	lea    0x6398d(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   f2013:	31 c0                	xor    %eax,%eax
   f2015:	e8 26 53 f1 ff       	call   7340 <fprintf@plt>
   f201a:	e8 01 51 f1 ff       	call   7120 <abort@plt>
   f201f:	90                   	nop
   f2020:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f202a:	48 29 c7             	sub    %rax,%rdi
   f202d:	4c 39 df             	cmp    %r11,%rdi
   f2030:	0f 82 f0 ad f1 ff    	jb     ce26 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f2036:	4c 39 d8             	cmp    %r11,%rax
   f2039:	4c 89 df             	mov    %r11,%rdi
   f203c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f2044:	48 0f 43 f8          	cmovae %rax,%rdi
   f2048:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   f2050:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f2058:	48 01 c7             	add    %rax,%rdi
   f205b:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   f2060:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f206a:	48 39 c7             	cmp    %rax,%rdi
   f206d:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f2072:	48 0f 47 f8          	cmova  %rax,%rdi
   f2076:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   f207a:	48 89 c7             	mov    %rax,%rdi
   f207d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f2082:	e8 79 c3 05 00       	call   14e400 <_Znwm>
   f2087:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f208d:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   f2095:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2099:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   f209e:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f20a6:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f20aa:	48 01 c1             	add    %rax,%rcx
   f20ad:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f20b5:	49 01 cb             	add    %rcx,%r11
   f20b8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f20c0:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   f20c4:	48 83 c1 38          	add    $0x38,%rcx
   f20c8:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f20cc:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f20d0:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   f20d4:	4c 39 d9             	cmp    %r11,%rcx
   f20d7:	75 e7                	jne    f20c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f20d9:	4c 39 d2             	cmp    %r10,%rdx
   f20dc:	74 51                	je     f212f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdef>
   f20de:	4c 89 d1             	mov    %r10,%rcx
   f20e1:	48 89 c7             	mov    %rax,%rdi
   f20e4:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f20ea:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f20f5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2100:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   f2104:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   f2108:	48 83 c1 38          	add    $0x38,%rcx
   f210c:	48 83 c7 38          	add    $0x38,%rdi
   f2110:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f2114:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   f2119:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   f211d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f2121:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   f2126:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f212a:	48 39 ca             	cmp    %rcx,%rdx
   f212d:	75 d1                	jne    f2100 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdc0>
   f212f:	4d 85 d2             	test   %r10,%r10
   f2132:	74 15                	je     f2149 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe09>
   f2134:	4c 29 d6             	sub    %r10,%rsi
   f2137:	4c 89 d7             	mov    %r10,%rdi
   f213a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f213f:	e8 bc c3 05 00       	call   14e500 <_ZdlPvm>
   f2144:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f2149:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   f214d:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   f2154:	48 01 c2             	add    %rax,%rdx
   f2157:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f215c:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f2163:	49 89 86 80 02 00 00 	mov    %rax,0x280(%r14)
   f216a:	e9 5e f9 ff ff       	jmp    f1acd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f216f:	90                   	nop
   f2170:	48 89 c2             	mov    %rax,%rdx
   f2173:	83 e0 01             	and    $0x1,%eax
   f2176:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f217a:	48 d1 ea             	shr    $1,%rdx
   f217d:	48 09 c2             	or     %rax,%rdx
   f2180:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f2185:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f2189:	e9 fb fc ff ff       	jmp    f1e89 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb49>
   f218e:	66 90                	xchg   %ax,%ax
   f2190:	48 89 c2             	mov    %rax,%rdx
   f2193:	83 e0 01             	and    $0x1,%eax
   f2196:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f219a:	48 d1 ea             	shr    $1,%rdx
   f219d:	48 09 c2             	or     %rax,%rdx
   f21a0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f21a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f21a9:	e9 a6 fc ff ff       	jmp    f1e54 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb14>
   f21ae:	66 90                	xchg   %ax,%ax
   f21b0:	e8 1b 51 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f21b5:	f2 0f 10 0d 73 d0 07 00 	movsd  0x7d073(%rip),%xmm1        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f21bd:	e9 b5 fc ff ff       	jmp    f1e77 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb37>
   f21c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f21c8:	e8 03 51 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f21cd:	48 89 c5             	mov    %rax,%rbp
   f21d0:	e9 24 fc ff ff       	jmp    f1df9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab9>
   f21d5:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   f21e0:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   f21e8:	0f 85 9b 00 00 00    	jne    f2289 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf49>
   f21ee:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   f21f5:	83 c0 01             	add    $0x1,%eax
   f21f8:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   f21ff:	83 f8 ff             	cmp    $0xffffffff,%eax
   f2202:	0f 85 82 fd ff ff    	jne    f1f8a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f2208:	49 8b 46 78          	mov    0x78(%r14),%rax
   f220c:	48 89 d1             	mov    %rdx,%rcx
   f220f:	48 c1 e1 04          	shl    $0x4,%rcx
   f2213:	48 01 c1             	add    %rax,%rcx
   f2216:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f221d:	48 83 c0 10          	add    $0x10,%rax
   f2221:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f2229:	48 39 c8             	cmp    %rcx,%rax
   f222c:	75 e8                	jne    f2216 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xed6>
   f222e:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   f2235:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f2240:	e9 45 fd ff ff       	jmp    f1f8a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f2245:	48 89 c2             	mov    %rax,%rdx
   f2248:	83 e0 01             	and    $0x1,%eax
   f224b:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f224f:	48 d1 ea             	shr    $1,%rdx
   f2252:	48 09 c2             	or     %rax,%rdx
   f2255:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f225a:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f225e:	e9 13 fb ff ff       	jmp    f1d76 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa36>
   f2263:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f2268:	e8 33 ee f1 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f226d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f2272:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f227a:	e9 72 f1 ff ff       	jmp    f13f1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb1>
   f227f:	e8 1c ee f1 ff       	call   110a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f2284:	e9 d6 fa ff ff       	jmp    f1d5f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa1f>
   f2289:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   f2294:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f229f:	e9 e6 fc ff ff       	jmp    f1f8a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f22a4:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f22ac:	e8 af 4f f1 ff       	call   7260 <__stack_chk_fail@plt>
   f22b1:	0f b6 d0             	movzbl %al,%edx
   f22b4:	e9 4c fd ff ff       	jmp    f2005 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc5>

# candidate unordered_pairs bench::Counters bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000ed5d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   ed5d0:	48 89 f8             	mov    %rdi,%rax
   ed5d3:	48 89 f7             	mov    %rsi,%rdi
   ed5d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed5da:	48 89 ce             	mov    %rcx,%rsi
   ed5dd:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
   ed5e4:	44 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8d
   ed5eb:	64 48 8b 0c 25 28 00 00 00 	mov    %fs:0x28,%rcx
   ed5f4:	48 89 8c 24 98 00 00 00 	mov    %rcx,0x98(%rsp)
   ed5fc:	31 c9                	xor    %ecx,%ecx
   ed5fe:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   ed603:	41 83 f8 01          	cmp    $0x1,%r8d
   ed607:	0f 86 db 00 00 00    	jbe    ed6e8 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x118>
   ed60d:	66 48 0f 6e ce       	movq   %rsi,%xmm1
   ed612:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
   ed617:	48 8d 54 24 18       	lea    0x18(%rsp),%rdx
   ed61c:	48 83 c7 08          	add    $0x8,%rdi
   ed620:	0f 11 44 24 68       	movups %xmm0,0x68(%rsp)
   ed625:	66 48 0f 6e c1       	movq   %rcx,%xmm0
   ed62a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   ed62f:	48 8d 4c 24 17       	lea    0x17(%rsp),%rcx
   ed634:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
   ed638:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   ed63d:	44 89 44 24 04       	mov    %r8d,0x4(%rsp)
   ed642:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   ed647:	c6 44 24 50 00       	movb   $0x0,0x50(%rsp)
   ed64c:	48 c7 84 24 88 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x88(%rsp)
   ed658:	e8 93 ec fd ff       	call   cc2f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0>
   ed65d:	0f b6 54 24 50       	movzbl 0x50(%rsp),%edx
   ed662:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
   ed668:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   ed66e:	44 8b 44 24 04       	mov    0x4(%rsp),%r8d
   ed673:	80 fa 0b             	cmp    $0xb,%dl
   ed676:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ed67b:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
   ed680:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
   ed685:	74 09                	je     ed690 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xc0>
   ed687:	84 d2                	test   %dl,%dl
   ed689:	75 66                	jne    ed6f1 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x121>
   ed68b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   ed690:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   ed695:	44 89 c6             	mov    %r8d,%esi
   ed698:	48 c7 40 18 00 00 00 00 	movq   $0x0,0x18(%rax)
   ed6a0:	48 c7 40 28 00 00 00 00 	movq   $0x0,0x28(%rax)
   ed6a8:	48 89 08             	mov    %rcx,(%rax)
   ed6ab:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   ed6b0:	48 89 70 08          	mov    %rsi,0x8(%rax)
   ed6b4:	48 89 48 10          	mov    %rcx,0x10(%rax)
   ed6b8:	31 c9                	xor    %ecx,%ecx
   ed6ba:	45 85 c0             	test   %r8d,%r8d
   ed6bd:	0f 95 c1             	setne  %cl
   ed6c0:	80 fa 0b             	cmp    $0xb,%dl
   ed6c3:	89 48 20             	mov    %ecx,0x20(%rax)
   ed6c6:	0f 94 40 30          	sete   0x30(%rax)
   ed6ca:	48 8b 94 24 98 00 00 00 	mov    0x98(%rsp),%rdx
   ed6d2:	64 48 2b 14 25 28 00 00 00 	sub    %fs:0x28,%rdx
   ed6db:	75 2e                	jne    ed70b <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x13b>
   ed6dd:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   ed6e4:	c3                   	ret
   ed6e5:	0f 1f 00             	nopl   (%rax)
   ed6e8:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
   ed6ed:	31 d2                	xor    %edx,%edx
   ed6ef:	eb 9f                	jmp    ed690 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xc0>
   ed6f1:	48 8b 3d 68 1b 08 00 	mov    0x81b68(%rip),%rdi        # 16f260 <stderr@GLIBC_2.2.5>
   ed6f8:	48 8d 35 a1 82 06 00 	lea    0x682a1(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   ed6ff:	31 c0                	xor    %eax,%eax
   ed701:	e8 3a 9c f1 ff       	call   7340 <fprintf@plt>
   ed706:	e8 15 9a f1 ff       	call   7120 <abort@plt>
   ed70b:	e8 50 9b f1 ff       	call   7260 <__stack_chk_fail@plt>

# candidate ordered_pairs bench::Counters bench::LibraryIndex<int, true>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f0920 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f0920:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
   f0927:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f092b:	48 89 9c 24 c8 01 00 00 	mov    %rbx,0x1c8(%rsp)
   f0933:	48 89 fb             	mov    %rdi,%rbx
   f0936:	4c 89 bc 24 f0 01 00 00 	mov    %r15,0x1f0(%rsp)
   f093e:	49 89 f7             	mov    %rsi,%r15
   f0941:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   f0946:	8b 96 d0 00 00 00    	mov    0xd0(%rsi),%edx
   f094c:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
   f0953:	64 48 8b 3c 25 28 00 00 00 	mov    %fs:0x28,%rdi
   f095c:	48 89 bc 24 b8 01 00 00 	mov    %rdi,0x1b8(%rsp)
   f0964:	31 ff                	xor    %edi,%edi
   f0966:	83 fa 01             	cmp    $0x1,%edx
   f0969:	0f 86 01 03 00 00    	jbe    f0c70 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x350>
   f096f:	48 39 f2             	cmp    %rsi,%rdx
   f0972:	74 44                	je     f09b8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x98>
   f0974:	ba 07 00 00 00       	mov    $0x7,%edx
   f0979:	48 8b 3d e0 e8 07 00 	mov    0x7e8e0(%rip),%rdi        # 16f260 <stderr@GLIBC_2.2.5>
   f0980:	48 8d 35 19 50 06 00 	lea    0x65019(%rip),%rsi        # 1559a0 <_IO_stdin_used+0x19a0>
   f0987:	31 c0                	xor    %eax,%eax
   f0989:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f0991:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f0999:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f09a1:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f09a9:	e8 92 69 f1 ff       	call   7340 <fprintf@plt>
   f09ae:	e8 6d 67 f1 ff       	call   7120 <abort@plt>
   f09b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f09b8:	49 89 c8             	mov    %rcx,%r8
   f09bb:	0f 11 84 24 98 00 00 00 	movups %xmm0,0x98(%rsp)
   f09c3:	49 8b 47 50          	mov    0x50(%r15),%rax
   f09c7:	89 d1                	mov    %edx,%ecx
   f09c9:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f09d1:	66 49 0f 6e d0       	movq   %r8,%xmm2
   f09d6:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   f09db:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
   f09df:	c6 84 24 90 00 00 00 00 	movb   $0x0,0x90(%rsp)
   f09e7:	48 c7 84 24 c8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xc8(%rsp)
   f09f3:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f09fb:	48 85 c0             	test   %rax,%rax
   f09fe:	0f 84 c6 08 00 00    	je     f12ca <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9aa>
   f0a04:	48 89 84 24 d0 00 00 00 	mov    %rax,0xd0(%rsp)
   f0a0c:	48 89 84 24 d8 00 00 00 	mov    %rax,0xd8(%rsp)
   f0a14:	48 c7 84 24 e0 00 00 00 00 00 00 00 	movq   $0x0,0xe0(%rsp)
   f0a20:	48 c7 84 24 e8 00 00 00 00 00 00 00 	movq   $0x0,0xe8(%rsp)
   f0a2c:	48 89 84 24 f0 00 00 00 	mov    %rax,0xf0(%rsp)
   f0a34:	48 c7 84 24 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rsp)
   f0a40:	48 c7 84 24 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rsp)
   f0a4c:	48 89 84 24 08 01 00 00 	mov    %rax,0x108(%rsp)
   f0a54:	48 c7 84 24 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rsp)
   f0a60:	48 c7 84 24 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rsp)
   f0a6c:	48 89 84 24 20 01 00 00 	mov    %rax,0x120(%rsp)
   f0a74:	48 c7 84 24 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rsp)
   f0a80:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f0a8c:	48 89 84 24 38 01 00 00 	mov    %rax,0x138(%rsp)
   f0a94:	48 c7 84 24 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rsp)
   f0aa0:	48 c7 84 24 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rsp)
   f0aac:	48 89 84 24 50 01 00 00 	mov    %rax,0x150(%rsp)
   f0ab4:	48 c7 84 24 58 01 00 00 00 00 00 00 	movq   $0x0,0x158(%rsp)
   f0ac0:	48 c7 84 24 60 01 00 00 00 00 00 00 	movq   $0x0,0x160(%rsp)
   f0acc:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f0ad4:	48 c7 84 24 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rsp)
   f0ae0:	48 c7 84 24 78 01 00 00 00 00 00 00 	movq   $0x0,0x178(%rsp)
   f0aec:	48 89 84 24 80 01 00 00 	mov    %rax,0x180(%rsp)
   f0af4:	48 c7 84 24 88 01 00 00 00 00 00 00 	movq   $0x0,0x188(%rsp)
   f0b00:	48 c7 84 24 90 01 00 00 00 00 00 00 	movq   $0x0,0x190(%rsp)
   f0b0c:	48 89 84 24 98 01 00 00 	mov    %rax,0x198(%rsp)
   f0b14:	48 c7 84 24 a0 01 00 00 00 00 00 00 	movq   $0x0,0x1a0(%rsp)
   f0b20:	48 c7 84 24 a8 01 00 00 00 00 00 00 	movq   $0x0,0x1a8(%rsp)
   f0b2c:	c7 84 24 b0 01 00 00 00 00 00 00 	movl   $0x0,0x1b0(%rsp)
   f0b37:	c6 84 24 b4 01 00 00 00 	movb   $0x0,0x1b4(%rsp)
   f0b3f:	49 39 b7 a0 01 00 00 	cmp    %rsi,0x1a0(%r15)
   f0b46:	0f 82 b4 01 00 00    	jb     f0d00 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f0b4c:	49 39 b7 b8 01 00 00 	cmp    %rsi,0x1b8(%r15)
   f0b53:	0f 82 a7 01 00 00    	jb     f0d00 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f0b59:	41 80 bf 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r15)
   f0b61:	0f 85 aa 07 00 00    	jne    f1311 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9f1>
   f0b67:	49 8d 47 08          	lea    0x8(%r15),%rax
   f0b6b:	4d 8b 9f 98 01 00 00 	mov    0x198(%r15),%r11
   f0b72:	c6 44 24 43 00       	movb   $0x0,0x43(%rsp)
   f0b77:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   f0b7c:	49 8d 87 88 01 00 00 	lea    0x188(%r15),%rax
   f0b83:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f0b88:	41 c6 87 6c 02 00 00 01 	movb   $0x1,0x26c(%r15)
   f0b90:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
   f0b95:	85 c9                	test   %ecx,%ecx
   f0b97:	0f 84 7a 01 00 00    	je     f0d17 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f0b9d:	8d 41 ff             	lea    -0x1(%rcx),%eax
   f0ba0:	83 f8 02             	cmp    $0x2,%eax
   f0ba3:	0f 86 3c 07 00 00    	jbe    f12e5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9c5>
   f0ba9:	89 cf                	mov    %ecx,%edi
   f0bab:	4c 89 d8             	mov    %r11,%rax
   f0bae:	66 0f 6f 05 da 6c 06 00 	movdqa 0x66cda(%rip),%xmm0        # 157890 <C.66.5+0x270>
   f0bb6:	c1 ef 02             	shr    $0x2,%edi
   f0bb9:	89 fa                	mov    %edi,%edx
   f0bbb:	48 c1 e2 04          	shl    $0x4,%rdx
   f0bbf:	4c 01 da             	add    %r11,%rdx
   f0bc2:	41 bb 04 00 00 00    	mov    $0x4,%r11d
   f0bc8:	66 41 0f 6e cb       	movd   %r11d,%xmm1
   f0bcd:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   f0bd2:	0f 1f 00             	nopl   (%rax)
   f0bd5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0be0:	0f 11 00             	movups %xmm0,(%rax)
   f0be3:	48 83 c0 10          	add    $0x10,%rax
   f0be7:	66 0f fe c1          	paddd  %xmm1,%xmm0
   f0beb:	48 39 d0             	cmp    %rdx,%rax
   f0bee:	75 f0                	jne    f0be0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2c0>
   f0bf0:	8d 04 bd 00 00 00 00 	lea    0x0(,%rdi,4),%eax
   f0bf7:	39 c8                	cmp    %ecx,%eax
   f0bf9:	74 25                	je     f0c20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f0bfb:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
   f0c00:	89 c2                	mov    %eax,%edx
   f0c02:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f0c06:	8d 50 01             	lea    0x1(%rax),%edx
   f0c09:	39 ca                	cmp    %ecx,%edx
   f0c0b:	73 13                	jae    f0c20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f0c0d:	89 d7                	mov    %edx,%edi
   f0c0f:	83 c0 02             	add    $0x2,%eax
   f0c12:	41 89 14 bb          	mov    %edx,(%r11,%rdi,4)
   f0c16:	39 c8                	cmp    %ecx,%eax
   f0c18:	73 06                	jae    f0c20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f0c1a:	89 c2                	mov    %eax,%edx
   f0c1c:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f0c20:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
   f0c27:	0f 86 ea 00 00 00    	jbe    f0d17 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f0c2d:	49 39 b7 48 02 00 00 	cmp    %rsi,0x248(%r15)
   f0c34:	0f 82 e7 00 00 00    	jb     f0d21 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f0c3a:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f0c44:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f0c4b:	48 c1 ea 04          	shr    $0x4,%rdx
   f0c4f:	48 39 f2             	cmp    %rsi,%rdx
   f0c52:	0f 82 c9 00 00 00    	jb     f0d21 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f0c58:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f0c5c:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   f0c61:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f0c66:	e8 f5 17 f2 ff       	call   12460 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f0c6b:	e9 db 00 00 00       	jmp    f0d4b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x42b>
   f0c70:	48 39 f2             	cmp    %rsi,%rdx
   f0c73:	0f 85 fb fc ff ff    	jne    f0974 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54>
   f0c79:	48 89 d0             	mov    %rdx,%rax
   f0c7c:	0f 11 84 24 d8 00 00 00 	movups %xmm0,0xd8(%rsp)
   f0c84:	31 d2                	xor    %edx,%edx
   f0c86:	48 8b 8c 24 e0 00 00 00 	mov    0xe0(%rsp),%rcx
   f0c8e:	85 c0                	test   %eax,%eax
   f0c90:	89 c7                	mov    %eax,%edi
   f0c92:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   f0c9a:	0f 95 c0             	setne  %al
   f0c9d:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   f0ca5:	80 fa 0b             	cmp    $0xb,%dl
   f0ca8:	48 89 0b             	mov    %rcx,(%rbx)
   f0cab:	48 8b 8c 24 d8 00 00 00 	mov    0xd8(%rsp),%rcx
   f0cb3:	0f b6 c0             	movzbl %al,%eax
   f0cb6:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
   f0cba:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   f0cbe:	89 43 20             	mov    %eax,0x20(%rbx)
   f0cc1:	0f 94 43 30          	sete   0x30(%rbx)
   f0cc5:	48 8b 84 24 b8 01 00 00 	mov    0x1b8(%rsp),%rax
   f0ccd:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f0cd6:	0f 85 10 06 00 00    	jne    f12ec <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9cc>
   f0cdc:	48 89 d8             	mov    %rbx,%rax
   f0cdf:	4c 8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%r15
   f0ce7:	48 8b 9c 24 c8 01 00 00 	mov    0x1c8(%rsp),%rbx
   f0cef:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
   f0cf6:	c3                   	ret
   f0cf7:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   f0d00:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f0d08:	e8 13 c3 00 00       	call   fd020 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f0d0d:	ba 05 00 00 00       	mov    $0x5,%edx
   f0d12:	e9 62 fc ff ff       	jmp    f0979 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f0d17:	48 83 fe 01          	cmp    $0x1,%rsi
   f0d1b:	0f 86 bd 05 00 00    	jbe    f12de <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9be>
   f0d21:	48 89 f0             	mov    %rsi,%rax
   f0d24:	31 c9                	xor    %ecx,%ecx
   f0d26:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f0d30:	48 d1 e8             	shr    $1,%rax
   f0d33:	83 c1 02             	add    $0x2,%ecx
   f0d36:	48 83 f8 01          	cmp    $0x1,%rax
   f0d3a:	75 f4                	jne    f0d30 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f0d3c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f0d41:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f0d46:	e8 95 d1 05 00       	call   14dee0 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f0d4b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f0d52:	83 fa 01             	cmp    $0x1,%edx
   f0d55:	0f 86 2a 03 00 00    	jbe    f1085 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f0d5b:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f0d63:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f0d6b:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f0d73:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f0d7b:	48 c7 44 24 08 01 00 00 00 	movq   $0x1,0x8(%rsp)
   f0d84:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   f0d89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f0d90:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f0d98:	84 c0                	test   %al,%al
   f0d9a:	0f 85 c0 02 00 00    	jne    f1060 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f0da0:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   f0da5:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f0daa:	48 8d 4c 24 43       	lea    0x43(%rsp),%rcx
   f0daf:	4c 8d ac 24 90 00 00 00 	lea    0x90(%rsp),%r13
   f0db7:	8b 7c 9f fc          	mov    -0x4(%rdi,%rbx,4),%edi
   f0dbb:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   f0dc0:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   f0dc5:	48 8d 4c 24 42       	lea    0x42(%rsp),%rcx
   f0dca:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   f0dcf:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   f0dd4:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   f0dd9:	48 8d 5c 24 44       	lea    0x44(%rsp),%rbx
   f0dde:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   f0de3:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
   f0de8:	48 89 8c 24 80 00 00 00 	mov    %rcx,0x80(%rsp)
   f0df0:	41 8b 8f 64 01 00 00 	mov    0x164(%r15),%ecx
   f0df7:	89 7c 24 44          	mov    %edi,0x44(%rsp)
   f0dfb:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
   f0e04:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
   f0e09:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   f0e0e:	83 f9 ff             	cmp    $0xffffffff,%ecx
   f0e11:	0f 84 d9 02 00 00    	je     f10f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7d0>
   f0e17:	89 ce                	mov    %ecx,%esi
   f0e19:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   f0e1d:	49 03 b7 f8 00 00 00 	add    0xf8(%r15),%rsi
   f0e24:	44 8b 46 64          	mov    0x64(%rsi),%r8d
   f0e28:	45 85 c0             	test   %r8d,%r8d
   f0e2b:	0f 84 ff 01 00 00    	je     f1030 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0e31:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f0e39:	48 85 c0             	test   %rax,%rax
   f0e3c:	0f 84 56 04 00 00    	je     f1298 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x978>
   f0e42:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f0e46:	74 0c                	je     f0e54 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x534>
   f0e48:	48 83 e8 01          	sub    $0x1,%rax
   f0e4c:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f0e54:	48 8b 84 24 98 00 00 00 	mov    0x98(%rsp),%rax
   f0e5c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f0e60:	74 0c                	je     f0e6e <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54e>
   f0e62:	48 83 c0 01          	add    $0x1,%rax
   f0e66:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f0e6e:	48 89 fa             	mov    %rdi,%rdx
   f0e71:	8b 46 1c             	mov    0x1c(%rsi),%eax
   f0e74:	48 c1 e2 04          	shl    $0x4,%rdx
   f0e78:	49 03 57 58          	add    0x58(%r15),%rdx
   f0e7c:	39 02                	cmp    %eax,(%rdx)
   f0e7e:	0f 8f ac 01 00 00    	jg     f1030 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0e84:	8b 42 08             	mov    0x8(%rdx),%eax
   f0e87:	39 46 14             	cmp    %eax,0x14(%rsi)
   f0e8a:	0f 8f a0 01 00 00    	jg     f1030 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0e90:	8b 46 20             	mov    0x20(%rsi),%eax
   f0e93:	39 42 04             	cmp    %eax,0x4(%rdx)
   f0e96:	0f 8f 94 01 00 00    	jg     f1030 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0e9c:	8b 42 0c             	mov    0xc(%rdx),%eax
   f0e9f:	39 46 18             	cmp    %eax,0x18(%rsi)
   f0ea2:	0f 8f 88 01 00 00    	jg     f1030 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f0ea8:	49 8b 47 68          	mov    0x68(%r15),%rax
   f0eac:	48 c1 e7 05          	shl    $0x5,%rdi
   f0eb0:	48 83 ec 08          	sub    $0x8,%rsp
   f0eb4:	4d 89 e9             	mov    %r13,%r9
   f0eb7:	48 01 f8             	add    %rdi,%rax
   f0eba:	48 8b 08             	mov    (%rax),%rcx
   f0ebd:	4c 8b 40 08          	mov    0x8(%rax),%r8
   f0ec1:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   f0ec6:	50                   	push   %rax
   f0ec7:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f0ecc:	e8 0f c7 f2 ff       	call   1d5e0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE11walkOrderedIZNKS2_11orderedSelfIZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS5_8CountersERT_mEUlRKSC_RKT0_E_NS_6detail9AcceptAllEEEvRNS_9WorkspaceIiEEbRNS2_7ContextESD_RSG_EUljE_EEvRKNS2_4NodeERKNS_3BoxIiEENS_6FilterESQ_SD_>
   f0ed1:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f0ed9:	5a                   	pop    %rdx
   f0eda:	59                   	pop    %rcx
   f0edb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f0ee0:	84 c0                	test   %al,%al
   f0ee2:	0f 85 78 01 00 00    	jne    f1060 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f0ee8:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f0eed:	49 8b 9f b0 01 00 00 	mov    0x1b0(%r15),%rbx
   f0ef4:	48 83 fd 7f          	cmp    $0x7f,%rbp
   f0ef8:	0f 86 5b 03 00 00    	jbe    f1259 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x939>
   f0efe:	49 39 af 48 02 00 00 	cmp    %rbp,0x248(%r15)
   f0f05:	0f 82 58 03 00 00    	jb     f1263 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f0f0b:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f0f15:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f0f1c:	48 c1 ea 04          	shr    $0x4,%rdx
   f0f20:	48 39 ea             	cmp    %rbp,%rdx
   f0f23:	0f 82 3a 03 00 00    	jb     f1263 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f0f29:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f0f2d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f0f32:	89 e9                	mov    %ebp,%ecx
   f0f34:	48 89 da             	mov    %rbx,%rdx
   f0f37:	e8 24 15 f2 ff       	call   12460 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f0f3c:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f0f41:	48 85 ed             	test   %rbp,%rbp
   f0f44:	0f 84 fb 00 00 00    	je     f1045 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f0f4a:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
   f0f4f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   f0f54:	31 c9                	xor    %ecx,%ecx
   f0f56:	4d 8b 5f 68          	mov    0x68(%r15),%r11
   f0f5a:	4d 8b 4f 60          	mov    0x60(%r15),%r9
   f0f5e:	4c 89 c2             	mov    %r8,%rdx
   f0f61:	48 8b 07             	mov    (%rdi),%rax
   f0f64:	4c 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%r10
   f0f6c:	48 c1 e2 05          	shl    $0x5,%rdx
   f0f70:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
   f0f74:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   f0f79:	4d 8d 34 13          	lea    (%r11,%rdx,1),%r14
   f0f7d:	4c 8d 68 01          	lea    0x1(%rax),%r13
   f0f81:	8b 14 8b             	mov    (%rbx,%rcx,4),%edx
   f0f84:	49 8b 76 10          	mov    0x10(%r14),%rsi
   f0f88:	4d 8d 64 0d 00       	lea    0x0(%r13,%rcx,1),%r12
   f0f8d:	48 89 d0             	mov    %rdx,%rax
   f0f90:	48 c1 e0 05          	shl    $0x5,%rax
   f0f94:	49 39 74 03 10       	cmp    %rsi,0x10(%r11,%rax,1)
   f0f99:	48 89 d0             	mov    %rdx,%rax
   f0f9c:	49 0f 42 c0          	cmovb  %r8,%rax
   f0fa0:	49 0f 43 d0          	cmovae %r8,%rdx
   f0fa4:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f0fa8:	41 8b 34 91          	mov    (%r9,%rdx,4),%esi
   f0fac:	39 f0                	cmp    %esi,%eax
   f0fae:	89 f2                	mov    %esi,%edx
   f0fb0:	0f 46 d0             	cmovbe %eax,%edx
   f0fb3:	48 c1 e2 20          	shl    $0x20,%rdx
   f0fb7:	39 f0                	cmp    %esi,%eax
   f0fb9:	0f 42 c6             	cmovb  %esi,%eax
   f0fbc:	48 09 d0             	or     %rdx,%rax
   f0fbf:	48 89 c2             	mov    %rax,%rdx
   f0fc2:	48 c1 ea 1e          	shr    $0x1e,%rdx
   f0fc6:	48 31 c2             	xor    %rax,%rdx
   f0fc9:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   f0fd3:	48 0f af d0          	imul   %rax,%rdx
   f0fd7:	48 89 d0             	mov    %rdx,%rax
   f0fda:	48 c1 e8 1b          	shr    $0x1b,%rax
   f0fde:	48 31 c2             	xor    %rax,%rdx
   f0fe1:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f0feb:	48 0f af d0          	imul   %rax,%rdx
   f0fef:	48 89 d0             	mov    %rdx,%rax
   f0ff2:	48 c1 e8 1f          	shr    $0x1f,%rax
   f0ff6:	48 31 c2             	xor    %rax,%rdx
   f0ff9:	48 01 d7             	add    %rdx,%rdi
   f0ffc:	49 83 fa ff          	cmp    $0xffffffffffffffff,%r10
   f1000:	0f 84 82 01 00 00    	je     f1188 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x868>
   f1006:	49 83 c2 01          	add    $0x1,%r10
   f100a:	48 83 c1 01          	add    $0x1,%rcx
   f100e:	4c 89 94 24 b8 00 00 00 	mov    %r10,0xb8(%rsp)
   f1016:	48 39 cd             	cmp    %rcx,%rbp
   f1019:	0f 85 62 ff ff ff    	jne    f0f81 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x661>
   f101f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f1024:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f1028:	4c 89 20             	mov    %r12,(%rax)
   f102b:	eb 18                	jmp    f1045 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f102d:	0f 1f 00             	nopl   (%rax)
   f1030:	49 8b bf b0 01 00 00 	mov    0x1b0(%r15),%rdi
   f1037:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f103c:	31 c9                	xor    %ecx,%ecx
   f103e:	31 f6                	xor    %esi,%esi
   f1040:	e8 9b ce 05 00       	call   14dee0 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f1045:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f104c:	48 83 44 24 08 01    	addq   $0x1,0x8(%rsp)
   f1052:	48 89 c2             	mov    %rax,%rdx
   f1055:	48 39 44 24 08       	cmp    %rax,0x8(%rsp)
   f105a:	0f 82 30 fd ff ff    	jb     f0d90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x470>
   f1060:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f1065:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f106d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f1075:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f107d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f1085:	41 c6 87 6c 02 00 00 00 	movb   $0x0,0x26c(%r15)
   f108d:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f1095:	e8 86 bf 00 00       	call   fd020 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f109a:	0f b6 94 24 90 00 00 00 	movzbl 0x90(%rsp),%edx
   f10a2:	66 0f 6f 84 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm0
   f10ab:	66 0f 6f 9c 24 90 00 00 00 	movdqa 0x90(%rsp),%xmm3
   f10b4:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f10bc:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f10c5:	0f 29 9c 24 d0 00 00 00 	movaps %xmm3,0xd0(%rsp)
   f10cd:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f10d5:	80 fa 0b             	cmp    $0xb,%dl
   f10d8:	74 08                	je     f10e2 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7c2>
   f10da:	84 d2                	test   %dl,%dl
   f10dc:	0f 85 97 f8 ff ff    	jne    f0979 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f10e2:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f10e9:	e9 98 fb ff ff       	jmp    f0c86 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x366>
   f10ee:	66 90                	xchg   %ax,%ax
   f10f0:	49 8b 6f 68          	mov    0x68(%r15),%rbp
   f10f4:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
   f10f9:	31 db                	xor    %ebx,%ebx
   f10fb:	eb 49                	jmp    f1146 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x826>
   f10fd:	0f 1f 00             	nopl   (%rax)
   f1100:	4c 89 e9             	mov    %r13,%rcx
   f1103:	44 89 f2             	mov    %r14d,%edx
   f1106:	4c 89 e7             	mov    %r12,%rdi
   f1109:	e8 12 09 f2 ff       	call   11a20 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_7ContextERT0_.isra.0>
   f110e:	84 c0                	test   %al,%al
   f1110:	74 19                	je     f112b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x80b>
   f1112:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   f1117:	48 8d 50 01          	lea    0x1(%rax),%rdx
   f111b:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f1120:	49 8b 97 b0 01 00 00 	mov    0x1b0(%r15),%rdx
   f1127:	44 89 34 82          	mov    %r14d,(%rdx,%rax,4)
   f112b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f1132:	48 83 c3 01          	add    $0x1,%rbx
   f1136:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f113e:	39 d3                	cmp    %edx,%ebx
   f1140:	0f 83 9a fd ff ff    	jae    f0ee0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f1146:	84 c0                	test   %al,%al
   f1148:	0f 85 12 ff ff ff    	jne    f1060 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f114e:	8b 44 24 44          	mov    0x44(%rsp),%eax
   f1152:	41 89 de             	mov    %ebx,%r14d
   f1155:	48 89 c6             	mov    %rax,%rsi
   f1158:	48 c1 e0 05          	shl    $0x5,%rax
   f115c:	48 01 e8             	add    %rbp,%rax
   f115f:	48 89 d9             	mov    %rbx,%rcx
   f1162:	48 c1 e1 05          	shl    $0x5,%rcx
   f1166:	48 8b 7c 0d 10       	mov    0x10(%rbp,%rcx,1),%rdi
   f116b:	48 39 78 10          	cmp    %rdi,0x10(%rax)
   f116f:	72 8f                	jb     f1100 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e0>
   f1171:	48 83 c3 01          	add    $0x1,%rbx
   f1175:	39 d3                	cmp    %edx,%ebx
   f1177:	0f 83 6b fd ff ff    	jae    f0ee8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c8>
   f117d:	41 89 de             	mov    %ebx,%r14d
   f1180:	eb dd                	jmp    f115f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x83f>
   f1182:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1188:	4c 8d 69 01          	lea    0x1(%rcx),%r13
   f118c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   f1191:	4c 39 ed             	cmp    %r13,%rbp
   f1194:	0f 84 85 fe ff ff    	je     f101f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x6ff>
   f119a:	4d 8b 74 13 10       	mov    0x10(%r11,%rdx,1),%r14
   f119f:	4c 89 ee             	mov    %r13,%rsi
   f11a2:	0f 1f 00             	nopl   (%rax)
   f11a5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f11b0:	8b 04 b3             	mov    (%rbx,%rsi,4),%eax
   f11b3:	48 89 c2             	mov    %rax,%rdx
   f11b6:	48 c1 e2 05          	shl    $0x5,%rdx
   f11ba:	4d 39 74 13 10       	cmp    %r14,0x10(%r11,%rdx,1)
   f11bf:	48 89 c2             	mov    %rax,%rdx
   f11c2:	49 0f 42 d0          	cmovb  %r8,%rdx
   f11c6:	49 0f 43 c0          	cmovae %r8,%rax
   f11ca:	45 8b 14 91          	mov    (%r9,%rdx,4),%r10d
   f11ce:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f11d2:	44 89 d2             	mov    %r10d,%edx
   f11d5:	44 39 d0             	cmp    %r10d,%eax
   f11d8:	0f 46 d0             	cmovbe %eax,%edx
   f11db:	48 c1 e2 20          	shl    $0x20,%rdx
   f11df:	44 39 d0             	cmp    %r10d,%eax
   f11e2:	41 0f 42 c2          	cmovb  %r10d,%eax
   f11e6:	48 83 c6 01          	add    $0x1,%rsi
   f11ea:	48 09 c2             	or     %rax,%rdx
   f11ed:	48 89 d0             	mov    %rdx,%rax
   f11f0:	48 c1 e8 1e          	shr    $0x1e,%rax
   f11f4:	48 31 d0             	xor    %rdx,%rax
   f11f7:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f1201:	48 0f af c2          	imul   %rdx,%rax
   f1205:	48 89 c2             	mov    %rax,%rdx
   f1208:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f120c:	48 31 c2             	xor    %rax,%rdx
   f120f:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f1219:	48 0f af d0          	imul   %rax,%rdx
   f121d:	48 89 d0             	mov    %rdx,%rax
   f1220:	48 c1 e8 1f          	shr    $0x1f,%rax
   f1224:	48 31 d0             	xor    %rdx,%rax
   f1227:	48 01 c7             	add    %rax,%rdi
   f122a:	48 39 ee             	cmp    %rbp,%rsi
   f122d:	72 81                	jb     f11b0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x890>
   f122f:	48 8d 45 ff          	lea    -0x1(%rbp),%rax
   f1233:	48 83 c1 02          	add    $0x2,%rcx
   f1237:	31 d2                	xor    %edx,%edx
   f1239:	4c 29 e8             	sub    %r13,%rax
   f123c:	48 39 cd             	cmp    %rcx,%rbp
   f123f:	48 0f 42 c2          	cmovb  %rdx,%rax
   f1243:	4d 8d 64 04 01       	lea    0x1(%r12,%rax,1),%r12
   f1248:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f124d:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f1251:	4c 89 20             	mov    %r12,(%rax)
   f1254:	e9 ec fd ff ff       	jmp    f1045 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f1259:	48 83 fd 01          	cmp    $0x1,%rbp
   f125d:	0f 86 d3 00 00 00    	jbe    f1336 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa16>
   f1263:	48 89 e8             	mov    %rbp,%rax
   f1266:	31 c9                	xor    %ecx,%ecx
   f1268:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1270:	48 d1 e8             	shr    $1,%rax
   f1273:	83 c1 02             	add    $0x2,%ecx
   f1276:	48 83 f8 01          	cmp    $0x1,%rax
   f127a:	75 f4                	jne    f1270 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x950>
   f127c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f1281:	48 89 ee             	mov    %rbp,%rsi
   f1284:	48 89 df             	mov    %rbx,%rdi
   f1287:	e8 54 cc 05 00       	call   14dee0 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f128c:	e9 b0 fc ff ff       	jmp    f0f41 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x621>
   f1291:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f1298:	c6 84 24 90 00 00 00 0b 	movb   $0xb,0x90(%rsp)
   f12a0:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f12a5:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f12ad:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f12b5:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f12bd:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f12c5:	e9 bb fd ff ff       	jmp    f1085 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f12ca:	e8 51 47 00 00       	call   f5a20 <_ZN8QuadTree15defaultResourceEv>
   f12cf:	41 8b b7 d0 00 00 00 	mov    0xd0(%r15),%esi
   f12d6:	48 89 f1             	mov    %rsi,%rcx
   f12d9:	e9 26 f7 ff ff       	jmp    f0a04 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xe4>
   f12de:	31 c9                	xor    %ecx,%ecx
   f12e0:	e9 57 fa ff ff       	jmp    f0d3c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x41c>
   f12e5:	31 c0                	xor    %eax,%eax
   f12e7:	e9 0f f9 ff ff       	jmp    f0bfb <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2db>
   f12ec:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f12f4:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f12fc:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f1304:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f130c:	e8 4f 5f f1 ff       	call   7260 <__stack_chk_fail@plt>
   f1311:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f1319:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f1321:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f1329:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f1331:	e8 ca 4d 00 00       	call   f6100 <_ZN8QuadTree6detail15activeWorkspaceEv>
   f1336:	31 c9                	xor    %ecx,%ecx
   f1338:	e9 3f ff ff ff       	jmp    f127c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x95c>

# candidate unordered_helper void QuadTree::Index<unsigned int, int, QuadTree::Unchecked, true>::unorderedPairTraversal<bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const::{lambda(auto:1 const&, auto:2 const&)#1}, QuadTree::detail::AcceptAll>(QuadTree::Index<unsigned int, int, QuadTree::Unchecked, true>::Context&, (anonymous namespace)::PairSink&, QuadTree::detail::AcceptAll&) const [clone .constprop.0]

/home/dima/.cache/quadtree-g1-unordered-traversal.4996Nq/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000cc2f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0>:
   cc2f0:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
   cc2f7:	48 89 f0             	mov    %rsi,%rax
   cc2fa:	4c 89 ac 24 e0 00 00 00 	mov    %r13,0xe0(%rsp)
   cc302:	49 89 fd             	mov    %rdi,%r13
   cc305:	48 89 14 24          	mov    %rdx,(%rsp)
   cc309:	64 48 8b 34 25 28 00 00 00 	mov    %fs:0x28,%rsi
   cc312:	48 89 b4 24 b8 00 00 00 	mov    %rsi,0xb8(%rsp)
   cc31a:	8b b7 5c 01 00 00    	mov    0x15c(%rdi),%esi
   cc320:	83 fe ff             	cmp    $0xffffffff,%esi
   cc323:	0f 85 07 03 00 00    	jne    cc630 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x340>
   cc329:	8b 8f c8 00 00 00    	mov    0xc8(%rdi),%ecx
   cc32f:	4c 89 b4 24 e8 00 00 00 	mov    %r14,0xe8(%rsp)
   cc337:	49 89 ce             	mov    %rcx,%r14
   cc33a:	83 f9 04             	cmp    $0x4,%ecx
   cc33d:	0f 86 c3 01 00 00    	jbe    cc506 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x216>
   cc343:	41 80 7d 19 01       	cmpb   $0x1,0x19(%r13)
   cc348:	41 ba 01 00 00 00    	mov    $0x1,%r10d
   cc34e:	49 8b 7d 60          	mov    0x60(%r13),%rdi
   cc352:	4c 89 bc 24 f0 00 00 00 	mov    %r15,0xf0(%rsp)
   cc35a:	48 89 9c 24 c8 00 00 00 	mov    %rbx,0xc8(%rsp)
   cc362:	4d 8b 7d 50          	mov    0x50(%r13),%r15
   cc366:	48 89 ac 24 d0 00 00 00 	mov    %rbp,0xd0(%rsp)
   cc36e:	4d 8b 6d 58          	mov    0x58(%r13),%r13
   cc372:	4c 89 a4 24 d8 00 00 00 	mov    %r12,0xd8(%rsp)
   cc37a:	0f 94 44 24 18       	sete   0x18(%rsp)
   cc37f:	45 39 f2             	cmp    %r14d,%r10d
   cc382:	0f 83 22 02 00 00    	jae    cc5aa <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x2ba>
   cc388:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
   cc38d:	48 89 fa             	mov    %rdi,%rdx
   cc390:	4c 89 d1             	mov    %r10,%rcx
   cc393:	4c 89 fe             	mov    %r15,%rsi
   cc396:	49 8d 6a ff          	lea    -0x1(%r10),%rbp
   cc39a:	e9 46 01 00 00       	jmp    cc4e5 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1f5>
   cc39f:	90                   	nop
   cc3a0:	4c 8b 47 08          	mov    0x8(%rdi),%r8
   cc3a4:	4c 85 42 20          	test   %r8,0x20(%rdx)
   cc3a8:	0f 84 44 01 00 00    	je     cc4f2 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x202>
   cc3ae:	4c 8b 40 30          	mov    0x30(%rax),%r8
   cc3b2:	4d 85 c0             	test   %r8,%r8
   cc3b5:	0f 84 7d 01 00 00    	je     cc538 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x248>
   cc3bb:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
   cc3bf:	74 08                	je     cc3c9 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0xd9>
   cc3c1:	49 83 e8 01          	sub    $0x1,%r8
   cc3c5:	4c 89 40 30          	mov    %r8,0x30(%rax)
   cc3c9:	4c 8b 40 10          	mov    0x10(%rax),%r8
   cc3cd:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
   cc3d1:	74 08                	je     cc3db <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0xeb>
   cc3d3:	49 83 c0 01          	add    $0x1,%r8
   cc3d7:	4c 89 40 10          	mov    %r8,0x10(%rax)
   cc3db:	45 8b 0f             	mov    (%r15),%r9d
   cc3de:	45 8b 57 08          	mov    0x8(%r15),%r10d
   cc3e2:	45 8b 47 04          	mov    0x4(%r15),%r8d
   cc3e6:	45 8b 5f 0c          	mov    0xc(%r15),%r11d
   cc3ea:	45 39 d1             	cmp    %r10d,%r9d
   cc3ed:	8b 5e 18             	mov    0x18(%rsi),%ebx
   cc3f0:	41 0f 94 c4          	sete   %r12b
   cc3f4:	45 39 d8             	cmp    %r11d,%r8d
   cc3f7:	44 89 44 24 0c       	mov    %r8d,0xc(%rsp)
   cc3fc:	41 0f 94 c0          	sete   %r8b
   cc400:	45 08 e0             	or     %r12b,%r8b
   cc403:	75 0b                	jne    cc410 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x120>
   cc405:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   cc40a:	0f 84 c0 01 00 00    	je     cc5d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x2e0>
   cc410:	41 39 d9             	cmp    %ebx,%r9d
   cc413:	0f 8f b7 00 00 00    	jg     cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc419:	44 3b 56 10          	cmp    0x10(%rsi),%r10d
   cc41d:	0f 8c ad 00 00 00    	jl     cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc423:	8b 5c 24 0c          	mov    0xc(%rsp),%ebx
   cc427:	3b 5e 1c             	cmp    0x1c(%rsi),%ebx
   cc42a:	0f 8f a0 00 00 00    	jg     cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc430:	44 3b 5e 14          	cmp    0x14(%rsi),%r11d
   cc434:	0f 8c 96 00 00 00    	jl     cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc43a:	8b 5f 18             	mov    0x18(%rdi),%ebx
   cc43d:	39 5a 38             	cmp    %ebx,0x38(%rdx)
   cc440:	0f 82 e2 00 00 00    	jb     cc528 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x238>
   cc446:	49 89 ea             	mov    %rbp,%r10
   cc449:	49 89 c8             	mov    %rcx,%r8
   cc44c:	48 8b 1c 24          	mov    (%rsp),%rbx
   cc450:	47 8b 44 85 00       	mov    0x0(%r13,%r8,4),%r8d
   cc455:	47 8b 5c 95 00       	mov    0x0(%r13,%r10,4),%r11d
   cc45a:	4c 8b 0b             	mov    (%rbx),%r9
   cc45d:	48 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rbx
   cc467:	45 89 da             	mov    %r11d,%r10d
   cc46a:	49 83 01 01          	addq   $0x1,(%r9)
   cc46e:	45 39 d8             	cmp    %r11d,%r8d
   cc471:	45 0f 46 d0          	cmovbe %r8d,%r10d
   cc475:	49 c1 e2 20          	shl    $0x20,%r10
   cc479:	45 39 d8             	cmp    %r11d,%r8d
   cc47c:	45 0f 42 c3          	cmovb  %r11d,%r8d
   cc480:	4d 09 c2             	or     %r8,%r10
   cc483:	4d 89 d0             	mov    %r10,%r8
   cc486:	49 c1 e8 1e          	shr    $0x1e,%r8
   cc48a:	4d 31 d0             	xor    %r10,%r8
   cc48d:	4c 0f af c3          	imul   %rbx,%r8
   cc491:	48 bb eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rbx
   cc49b:	4d 89 c2             	mov    %r8,%r10
   cc49e:	49 c1 ea 1b          	shr    $0x1b,%r10
   cc4a2:	4d 31 d0             	xor    %r10,%r8
   cc4a5:	4c 0f af c3          	imul   %rbx,%r8
   cc4a9:	4d 89 c2             	mov    %r8,%r10
   cc4ac:	49 c1 ea 1f          	shr    $0x1f,%r10
   cc4b0:	4d 31 d0             	xor    %r10,%r8
   cc4b3:	4d 01 41 08          	add    %r8,0x8(%r9)
   cc4b7:	4c 8b 40 28          	mov    0x28(%rax),%r8
   cc4bb:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
   cc4bf:	74 0f                	je     cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc4c1:	49 83 c0 01          	add    $0x1,%r8
   cc4c5:	4c 89 40 28          	mov    %r8,0x28(%rax)
   cc4c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   cc4d0:	48 83 c1 01          	add    $0x1,%rcx
   cc4d4:	48 83 c6 10          	add    $0x10,%rsi
   cc4d8:	48 83 c2 20          	add    $0x20,%rdx
   cc4dc:	44 39 f1             	cmp    %r14d,%ecx
   cc4df:	0f 83 ab 00 00 00    	jae    cc590 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x2a0>
   cc4e5:	4c 8b 07             	mov    (%rdi),%r8
   cc4e8:	4c 85 42 28          	test   %r8,0x28(%rdx)
   cc4ec:	0f 85 ae fe ff ff    	jne    cc3a0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0xb0>
   cc4f2:	4c 8b 40 18          	mov    0x18(%rax),%r8
   cc4f6:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
   cc4fa:	74 d4                	je     cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc4fc:	49 83 c0 01          	add    $0x1,%r8
   cc500:	4c 89 40 18          	mov    %r8,0x18(%rax)
   cc504:	eb ca                	jmp    cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc506:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
   cc50a:	48 0f af d1          	imul   %rcx,%rdx
   cc50e:	48 d1 ea             	shr    $1,%rdx
   cc511:	48 39 50 30          	cmp    %rdx,0x30(%rax)
   cc515:	0f 83 4a 01 00 00    	jae    cc665 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x375>
   cc51b:	85 c9                	test   %ecx,%ecx
   cc51d:	0f 85 20 fe ff ff    	jne    cc343 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x53>
   cc523:	eb 36                	jmp    cc55b <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x26b>
   cc525:	0f 1f 00             	nopl   (%rax)
   cc528:	49 89 ca             	mov    %rcx,%r10
   cc52b:	49 89 e8             	mov    %rbp,%r8
   cc52e:	e9 19 ff ff ff       	jmp    cc44c <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x15c>
   cc533:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   cc538:	c6 00 0b             	movb   $0xb,(%rax)
   cc53b:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   cc543:	48 8b ac 24 d0 00 00 00 	mov    0xd0(%rsp),%rbp
   cc54b:	4c 8b a4 24 d8 00 00 00 	mov    0xd8(%rsp),%r12
   cc553:	4c 8b bc 24 f0 00 00 00 	mov    0xf0(%rsp),%r15
   cc55b:	48 8b 84 24 b8 00 00 00 	mov    0xb8(%rsp),%rax
   cc563:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   cc56c:	0f 85 b5 03 00 00    	jne    cc927 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x637>
   cc572:	4c 8b b4 24 e8 00 00 00 	mov    0xe8(%rsp),%r14
   cc57a:	4c 8b ac 24 e0 00 00 00 	mov    0xe0(%rsp),%r13
   cc582:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
   cc589:	c3                   	ret
   cc58a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   cc590:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
   cc595:	49 83 c7 10          	add    $0x10,%r15
   cc599:	48 83 c7 20          	add    $0x20,%rdi
   cc59d:	49 83 c2 01          	add    $0x1,%r10
   cc5a1:	45 39 f2             	cmp    %r14d,%r10d
   cc5a4:	0f 82 de fd ff ff    	jb     cc388 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x98>
   cc5aa:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   cc5b2:	48 8b ac 24 d0 00 00 00 	mov    0xd0(%rsp),%rbp
   cc5ba:	4c 8b a4 24 d8 00 00 00 	mov    0xd8(%rsp),%r12
   cc5c2:	4c 8b bc 24 f0 00 00 00 	mov    0xf0(%rsp),%r15
   cc5ca:	eb 8f                	jmp    cc55b <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x26b>
   cc5cc:	0f 1f 40 00          	nopl   0x0(%rax)
   cc5d0:	44 8b 46 10          	mov    0x10(%rsi),%r8d
   cc5d4:	41 39 d8             	cmp    %ebx,%r8d
   cc5d7:	0f 84 33 fe ff ff    	je     cc410 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x120>
   cc5dd:	44 8b 66 14          	mov    0x14(%rsi),%r12d
   cc5e1:	44 89 64 24 1c       	mov    %r12d,0x1c(%rsp)
   cc5e6:	44 8b 66 1c          	mov    0x1c(%rsi),%r12d
   cc5ea:	44 39 64 24 1c       	cmp    %r12d,0x1c(%rsp)
   cc5ef:	0f 84 1b fe ff ff    	je     cc410 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x120>
   cc5f5:	41 39 d9             	cmp    %ebx,%r9d
   cc5f8:	41 0f 9c c1          	setl   %r9b
   cc5fc:	45 39 c2             	cmp    %r8d,%r10d
   cc5ff:	41 0f 9f c0          	setg   %r8b
   cc603:	45 21 c1             	and    %r8d,%r9d
   cc606:	44 39 64 24 0c       	cmp    %r12d,0xc(%rsp)
   cc60b:	41 0f 9c c0          	setl   %r8b
   cc60f:	45 84 c1             	test   %r8b,%r9b
   cc612:	0f 84 b8 fe ff ff    	je     cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc618:	44 3b 5c 24 1c       	cmp    0x1c(%rsp),%r11d
   cc61d:	0f 8e ad fe ff ff    	jle    cc4d0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x1e0>
   cc623:	e9 12 fe ff ff       	jmp    cc43a <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x14a>
   cc628:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   cc630:	48 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%rdx
   cc638:	64 48 2b 14 25 28 00 00 00 	sub    %fs:0x28,%rdx
   cc641:	0f 85 b3 02 00 00    	jne    cc8fa <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x60a>
   cc647:	4c 8b ac 24 e0 00 00 00 	mov    0xe0(%rsp),%r13
   cc64f:	49 89 c8             	mov    %rcx,%r8
   cc652:	48 8b 0c 24          	mov    (%rsp),%rcx
   cc656:	48 89 c2             	mov    %rax,%rdx
   cc659:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
   cc660:	e9 5b e7 ff ff       	jmp    cadc0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE9selfPairsIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvjRNS2_7ContextESC_RSF_>
   cc665:	83 f9 01             	cmp    $0x1,%ecx
   cc668:	0f 86 ed fe ff ff    	jbe    cc55b <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x26b>
   cc66e:	48 8b 77 60          	mov    0x60(%rdi),%rsi
   cc672:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   cc677:	49 89 c5             	mov    %rax,%r13
   cc67a:	41 be 01 00 00 00    	mov    $0x1,%r14d
   cc680:	48 89 9c 24 c8 00 00 00 	mov    %rbx,0xc8(%rsp)
   cc688:	89 c8                	mov    %ecx,%eax
   cc68a:	4c 8d 56 20          	lea    0x20(%rsi),%r10
   cc68e:	48 89 ac 24 d0 00 00 00 	mov    %rbp,0xd0(%rsp)
   cc696:	48 8b 77 50          	mov    0x50(%rdi),%rsi
   cc69a:	4c 89 a4 24 d8 00 00 00 	mov    %r12,0xd8(%rsp)
   cc6a2:	4c 89 bc 24 f0 00 00 00 	mov    %r15,0xf0(%rsp)
   cc6aa:	4c 8d 5e 10          	lea    0x10(%rsi),%r11
   cc6ae:	4d 89 d7             	mov    %r10,%r15
   cc6b1:	0f 1f 40 00          	nopl   0x0(%rax)
   cc6b5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   cc6c0:	41 39 c6             	cmp    %eax,%r14d
   cc6c3:	73 7b                	jae    cc740 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x450>
   cc6c5:	41 8d 76 ff          	lea    -0x1(%r14),%esi
   cc6c9:	44 89 74 24 0c       	mov    %r14d,0xc(%rsp)
   cc6ce:	4d 89 dc             	mov    %r11,%r12
   cc6d1:	4c 89 fb             	mov    %r15,%rbx
   cc6d4:	89 74 24 10          	mov    %esi,0x10(%rsp)
   cc6d8:	44 89 f5             	mov    %r14d,%ebp
   cc6db:	eb 33                	jmp    cc710 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x420>
   cc6dd:	0f 1f 00             	nopl   (%rax)
   cc6e0:	49 8b 57 e8          	mov    -0x18(%r15),%rdx
   cc6e4:	48 85 13             	test   %rdx,(%rbx)
   cc6e7:	74 31                	je     cc71a <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x42a>
   cc6e9:	41 8b 53 f0          	mov    -0x10(%r11),%edx
   cc6ed:	41 8b 4c 24 08       	mov    0x8(%r12),%ecx
   cc6f2:	49 83 45 10 01       	addq   $0x1,0x10(%r13)
   cc6f7:	39 ca                	cmp    %ecx,%edx
   cc6f9:	7c 65                	jl     cc760 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x470>
   cc6fb:	0f 84 5f 01 00 00    	je     cc860 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x570>
   cc701:	83 c5 01             	add    $0x1,%ebp
   cc704:	48 83 c3 20          	add    $0x20,%rbx
   cc708:	49 83 c4 10          	add    $0x10,%r12
   cc70c:	39 c5                	cmp    %eax,%ebp
   cc70e:	73 2b                	jae    cc73b <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x44b>
   cc710:	49 8b 57 e0          	mov    -0x20(%r15),%rdx
   cc714:	48 85 53 08          	test   %rdx,0x8(%rbx)
   cc718:	75 c6                	jne    cc6e0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x3f0>
   cc71a:	49 8b 55 18          	mov    0x18(%r13),%rdx
   cc71e:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
   cc722:	74 dd                	je     cc701 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x411>
   cc724:	48 83 c2 01          	add    $0x1,%rdx
   cc728:	83 c5 01             	add    $0x1,%ebp
   cc72b:	48 83 c3 20          	add    $0x20,%rbx
   cc72f:	49 83 c4 10          	add    $0x10,%r12
   cc733:	49 89 55 18          	mov    %rdx,0x18(%r13)
   cc737:	39 c5                	cmp    %eax,%ebp
   cc739:	72 d5                	jb     cc710 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x420>
   cc73b:	44 8b 74 24 0c       	mov    0xc(%rsp),%r14d
   cc740:	41 83 c6 01          	add    $0x1,%r14d
   cc744:	49 83 c7 20          	add    $0x20,%r15
   cc748:	49 83 c3 10          	add    $0x10,%r11
   cc74c:	44 39 f0             	cmp    %r14d,%eax
   cc74f:	0f 85 6b ff ff ff    	jne    cc6c0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x3d0>
   cc755:	e9 50 fe ff ff       	jmp    cc5aa <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x2ba>
   cc75a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   cc760:	41 8b 3c 24          	mov    (%r12),%edi
   cc764:	41 8b 73 f8          	mov    -0x8(%r11),%esi
   cc768:	39 f7                	cmp    %esi,%edi
   cc76a:	0f 8d 00 01 00 00    	jge    cc870 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x580>
   cc770:	45 8b 43 f4          	mov    -0xc(%r11),%r8d
   cc774:	45 3b 44 24 0c       	cmp    0xc(%r12),%r8d
   cc779:	0f 8d fd 00 00 00    	jge    cc87c <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x58c>
   cc77f:	45 8b 4b fc          	mov    -0x4(%r11),%r9d
   cc783:	45 39 4c 24 04       	cmp    %r9d,0x4(%r12)
   cc788:	0f 8d ee 00 00 00    	jge    cc87c <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x58c>
   cc78e:	41 8b 77 f8          	mov    -0x8(%r15),%esi
   cc792:	39 73 18             	cmp    %esi,0x18(%rbx)
   cc795:	0f 82 50 01 00 00    	jb     cc8eb <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x5fb>
   cc79b:	89 6c 24 18          	mov    %ebp,0x18(%rsp)
   cc79f:	8b 54 24 10          	mov    0x10(%rsp),%edx
   cc7a3:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   cc7a8:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   cc7ad:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
   cc7b2:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   cc7b6:	4c 89 f6             	mov    %r14,%rsi
   cc7b9:	e8 f2 9f 07 00       	call   1467b0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   cc7be:	8b 54 24 18          	mov    0x18(%rsp),%edx
   cc7c2:	4c 89 f6             	mov    %r14,%rsi
   cc7c5:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   cc7ca:	e8 e1 9f 07 00       	call   1467b0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   cc7cf:	48 8b 04 24          	mov    (%rsp),%rax
   cc7d3:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   cc7d8:	48 8b 94 24 88 00 00 00 	mov    0x88(%rsp),%rdx
   cc7e0:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
   cc7e5:	8b 3e                	mov    (%rsi),%edi
   cc7e7:	48 8b 08             	mov    (%rax),%rcx
   cc7ea:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   cc7f4:	8b 12                	mov    (%rdx),%edx
   cc7f6:	89 fe                	mov    %edi,%esi
   cc7f8:	48 83 01 01          	addq   $0x1,(%rcx)
   cc7fc:	39 fa                	cmp    %edi,%edx
   cc7fe:	0f 46 f2             	cmovbe %edx,%esi
   cc801:	48 c1 e6 20          	shl    $0x20,%rsi
   cc805:	39 fa                	cmp    %edi,%edx
   cc807:	0f 42 d7             	cmovb  %edi,%edx
   cc80a:	48 09 d6             	or     %rdx,%rsi
   cc80d:	48 89 f2             	mov    %rsi,%rdx
   cc810:	48 c1 ea 1e          	shr    $0x1e,%rdx
   cc814:	48 31 f2             	xor    %rsi,%rdx
   cc817:	48 0f af d0          	imul   %rax,%rdx
   cc81b:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   cc825:	48 89 d6             	mov    %rdx,%rsi
   cc828:	48 c1 ee 1b          	shr    $0x1b,%rsi
   cc82c:	48 31 f2             	xor    %rsi,%rdx
   cc82f:	48 0f af d0          	imul   %rax,%rdx
   cc833:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
   cc837:	48 89 d6             	mov    %rdx,%rsi
   cc83a:	48 c1 ee 1f          	shr    $0x1f,%rsi
   cc83e:	48 31 f2             	xor    %rsi,%rdx
   cc841:	48 01 51 08          	add    %rdx,0x8(%rcx)
   cc845:	49 8b 55 28          	mov    0x28(%r13),%rdx
   cc849:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
   cc84d:	0f 84 ae fe ff ff    	je     cc701 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x411>
   cc853:	48 83 c2 01          	add    $0x1,%rdx
   cc857:	49 89 55 28          	mov    %rdx,0x28(%r13)
   cc85b:	e9 a1 fe ff ff       	jmp    cc701 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x411>
   cc860:	41 8b 3c 24          	mov    (%r12),%edi
   cc864:	41 8b 73 f8          	mov    -0x8(%r11),%esi
   cc868:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   cc870:	39 f7                	cmp    %esi,%edi
   cc872:	0f 8f 89 fe ff ff    	jg     cc701 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x411>
   cc878:	45 8b 43 f4          	mov    -0xc(%r11),%r8d
   cc87c:	45 8b 4c 24 0c       	mov    0xc(%r12),%r9d
   cc881:	45 39 c8             	cmp    %r9d,%r8d
   cc884:	0f 8f 77 fe ff ff    	jg     cc701 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x411>
   cc88a:	45 8b 74 24 04       	mov    0x4(%r12),%r14d
   cc88f:	45 8b 53 fc          	mov    -0x4(%r11),%r10d
   cc893:	44 89 74 24 18       	mov    %r14d,0x18(%rsp)
   cc898:	45 39 d6             	cmp    %r10d,%r14d
   cc89b:	0f 8f 60 fe ff ff    	jg     cc701 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x411>
   cc8a1:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   cc8a6:	41 80 7e 19 01       	cmpb   $0x1,0x19(%r14)
   cc8ab:	0f 95 44 24 1c       	setne  0x1c(%rsp)
   cc8b0:	45 39 d0             	cmp    %r10d,%r8d
   cc8b3:	41 0f 95 c0          	setne  %r8b
   cc8b7:	44 22 44 24 1c       	and    0x1c(%rsp),%r8b
   cc8bc:	44 3b 4c 24 18       	cmp    0x18(%rsp),%r9d
   cc8c1:	41 0f 95 c1          	setne  %r9b
   cc8c5:	45 21 c8             	and    %r9d,%r8d
   cc8c8:	39 f2                	cmp    %esi,%edx
   cc8ca:	0f 95 c2             	setne  %dl
   cc8cd:	41 84 d0             	test   %dl,%r8b
   cc8d0:	0f 84 b8 fe ff ff    	je     cc78e <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x49e>
   cc8d6:	39 f9                	cmp    %edi,%ecx
   cc8d8:	0f 85 23 fe ff ff    	jne    cc701 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x411>
   cc8de:	41 8b 77 f8          	mov    -0x8(%r15),%esi
   cc8e2:	39 73 18             	cmp    %esi,0x18(%rbx)
   cc8e5:	0f 83 b0 fe ff ff    	jae    cc79b <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x4ab>
   cc8eb:	8b 74 24 10          	mov    0x10(%rsp),%esi
   cc8ef:	89 ea                	mov    %ebp,%edx
   cc8f1:	89 74 24 18          	mov    %esi,0x18(%rsp)
   cc8f5:	e9 a9 fe ff ff       	jmp    cc7a3 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE22unorderedPairTraversalIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvRNS2_7ContextESC_RSF_.constprop.0+0x4b3>
   cc8fa:	48 89 9c 24 c8 00 00 00 	mov    %rbx,0xc8(%rsp)
   cc902:	48 89 ac 24 d0 00 00 00 	mov    %rbp,0xd0(%rsp)
   cc90a:	4c 89 a4 24 d8 00 00 00 	mov    %r12,0xd8(%rsp)
   cc912:	4c 89 b4 24 e8 00 00 00 	mov    %r14,0xe8(%rsp)
   cc91a:	4c 89 bc 24 f0 00 00 00 	mov    %r15,0xf0(%rsp)
   cc922:	e8 39 a9 f3 ff       	call   7260 <__stack_chk_fail@plt>
   cc927:	48 89 9c 24 c8 00 00 00 	mov    %rbx,0xc8(%rsp)
   cc92f:	48 89 ac 24 d0 00 00 00 	mov    %rbp,0xd0(%rsp)
   cc937:	4c 89 a4 24 d8 00 00 00 	mov    %r12,0xd8(%rsp)
   cc93f:	4c 89 bc 24 f0 00 00 00 	mov    %r15,0xf0(%rsp)
   cc947:	e8 14 a9 f3 ff       	call   7260 <__stack_chk_fail@plt>
