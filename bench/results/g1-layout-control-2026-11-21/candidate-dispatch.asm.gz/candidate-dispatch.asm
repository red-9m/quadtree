
# candidate unordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, false>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-layout.0xp7gI/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f17c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f17c0:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f17c7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f17cb:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f17d3:	48 8b 2a             	mov    (%rdx),%rbp
   f17d6:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f17de:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f17e2:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f17ea:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f17f2:	49 89 ff             	mov    %rdi,%r15
   f17f5:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f17fd:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f1804:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f1809:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f1812:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f181a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f181e:	0f 11 07             	movups %xmm0,(%rdi)
   f1821:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f1825:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f1829:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f182d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f1831:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f1835:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f1839:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f183d:	48 89 14 24          	mov    %rdx,(%rsp)
   f1841:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f1845:	e8 f6 27 06 00       	call   154040 <_ZN5bench6memory11allocationsEv>
   f184a:	80 3d 27 2a 08 00 00 	cmpb   $0x0,0x82a27(%rip)        # 174278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1851:	4c 8b 1c 24          	mov    (%rsp),%r11
   f1855:	49 89 c6             	mov    %rax,%r14
   f1858:	0f 84 41 0e 00 00    	je     f269f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xedf>
   f185e:	0f 31                	rdtsc
   f1860:	48 c1 e2 20          	shl    $0x20,%rdx
   f1864:	48 09 d0             	or     %rdx,%rax
   f1867:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f186f:	49 8b 13             	mov    (%r11),%rdx
   f1872:	49 3b 53 08          	cmp    0x8(%r11),%rdx
   f1876:	0f 84 0f 09 00 00    	je     f218b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9cb>
   f187c:	49 29 ec             	sub    %rbp,%r12
   f187f:	48 c7 04 24 00 00 00 00 	movq   $0x0,(%rsp)
   f1887:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f188b:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f1893:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f189b:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f18a4:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f18ad:	c7 44 24 1c 00 00 00 00 	movl   $0x0,0x1c(%rsp)
   f18b5:	4c 89 9c 24 88 00 00 00 	mov    %r11,0x88(%rsp)
   f18bd:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f18c5:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f18cd:	45 31 ed             	xor    %r13d,%r13d
   f18d0:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   f18d8:	45 31 f6             	xor    %r14d,%r14d
   f18db:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f18e0:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f18e5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f18f0:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   f18f5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f18f9:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f18fd:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f1905:	48 8b 28             	mov    (%rax),%rbp
   f1908:	4c 8b 60 08          	mov    0x8(%rax),%r12
   f190c:	49 29 ec             	sub    %rbp,%r12
   f190f:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
   f1914:	49 c1 fc 04          	sar    $0x4,%r12
   f1918:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   f191f:	74 13                	je     f1934 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x174>
   f1921:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f1928:	3b 83 b8 02 00 00    	cmp    0x2b8(%rbx),%eax
   f192e:	0f 84 b8 05 00 00    	je     f1eec <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x72c>
   f1934:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f193c:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1940:	31 f6                	xor    %esi,%esi
   f1942:	66 0f 6f 3d 76 bf 06 00 	movdqa 0x6bf76(%rip),%xmm7        # 15d8c0 <C.66.5+0x2a0>
   f194a:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f1952:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f195a:	ba 88 01 00 00       	mov    $0x188,%edx
   f195f:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f1966:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f196b:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f1973:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f197b:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f1980:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f1988:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f198c:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f1995:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f199d:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f19a6:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f19ae:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f19b7:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f19bf:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f19c7:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f19cc:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f19d4:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f19d9:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f19e1:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f19e6:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f19ee:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f19fa:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f1a06:	e8 05 57 f1 ff       	call   7110 <memset@plt>
   f1a0b:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f1a11:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f1a15:	66 0f 6f 05 b3 be 06 00 	movdqa 0x6beb3(%rip),%xmm0        # 15d8d0 <C.66.5+0x2b0>
   f1a1d:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f1a23:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f1a29:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f1a2d:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1a34:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f1a3c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1a41:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f1a49:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f1a51:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f1a59:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f1a65:	48 89 9c 24 d8 01 00 00 	mov    %rbx,0x1d8(%rsp)
   f1a6d:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f1a79:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f1a85:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f1a91:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f1a9d:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f1aa9:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f1ab4:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f1abc:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f1ac7:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f1ad3:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f1adb:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f1ae7:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f1af2:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f1afa:	48 89 9c 24 78 02 00 00 	mov    %rbx,0x278(%rsp)
   f1b02:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f1b0e:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f1b1a:	48 89 9c 24 90 02 00 00 	mov    %rbx,0x290(%rsp)
   f1b22:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f1b2e:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f1b36:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f1b3e:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f1b46:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f1b4e:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f1b56:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f1b62:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f1b6a:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f1b73:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f1b7b:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f1b83:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f1b8c:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f1b94:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f1b9c:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f1ba5:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f1bad:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1bb4:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f1bbc:	48 89 9c 24 a8 02 00 00 	mov    %rbx,0x2a8(%rsp)
   f1bc4:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f1bd0:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f1bdc:	48 89 9c 24 c0 02 00 00 	mov    %rbx,0x2c0(%rsp)
   f1be4:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f1bf0:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f1bfc:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f1c08:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f1c13:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f1c1f:	48 89 9c 24 60 03 00 00 	mov    %rbx,0x360(%rsp)
   f1c27:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f1c32:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f1c3d:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f1c49:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f1c51:	48 89 9c 24 00 04 00 00 	mov    %rbx,0x400(%rsp)
   f1c59:	48 89 9c 24 18 04 00 00 	mov    %rbx,0x418(%rsp)
   f1c61:	48 89 9c 24 30 04 00 00 	mov    %rbx,0x430(%rsp)
   f1c69:	48 89 9c 24 48 04 00 00 	mov    %rbx,0x448(%rsp)
   f1c71:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f1c79:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f1c81:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f1c89:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f1c91:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f1c99:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f1ca0:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f1ca9:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f1cb4:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f1cbb:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f1cc2:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f1ccd:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f1cd4:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f1cdc:	e8 5f 0b 01 00       	call   102840 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1ce1:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   f1ce8:	0f 85 82 06 00 00    	jne    f2370 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbb0>
   f1cee:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f1cf7:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f1cff:	48 89 5b 50          	mov    %rbx,0x50(%rbx)
   f1d03:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f1d0b:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f1d14:	c6 83 ec 00 00 00 00 	movb   $0x0,0xec(%rbx)
   f1d1b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
   f1d1f:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f1d28:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f1d30:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   f1d34:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f1d3d:	48 89 43 48          	mov    %rax,0x48(%rbx)
   f1d41:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1d48:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
   f1d4c:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f1d55:	48 89 83 98 00 00 00 	mov    %rax,0x98(%rbx)
   f1d5c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1d61:	0f 11 43 38          	movups %xmm0,0x38(%rbx)
   f1d65:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1d69:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
   f1d70:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f1d79:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
   f1d80:	0f 11 83 a8 00 00 00 	movups %xmm0,0xa8(%rbx)
   f1d87:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f1d8f:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f1d98:	48 c7 43 58 00 00 00 00 	movq   $0x0,0x58(%rbx)
   f1da0:	0f 11 83 b1 00 00 00 	movups %xmm0,0xb1(%rbx)
   f1da7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1dab:	0f 11 83 d0 00 00 00 	movups %xmm0,0xd0(%rbx)
   f1db2:	48 c7 43 60 00 00 00 00 	movq   $0x0,0x60(%rbx)
   f1dba:	48 c7 43 68 00 00 00 00 	movq   $0x0,0x68(%rbx)
   f1dc2:	48 c7 43 70 00 00 00 00 	movq   $0x0,0x70(%rbx)
   f1dca:	48 c7 43 78 00 00 00 00 	movq   $0x0,0x78(%rbx)
   f1dd2:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   f1ddc:	c6 83 94 00 00 00 00 	movb   $0x0,0x94(%rbx)
   f1de3:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   f1ded:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   f1df8:	c7 83 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%rbx)
   f1e02:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f1e09:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f1e12:	48 89 9b f0 00 00 00 	mov    %rbx,0xf0(%rbx)
   f1e19:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
   f1e1f:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f1e26:	48 c7 83 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rbx)
   f1e31:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f1e38:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1e3d:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   f1e44:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f1e4b:	48 c7 83 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rbx)
   f1e56:	48 89 9b 08 01 00 00 	mov    %rbx,0x108(%rbx)
   f1e5d:	48 c7 83 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rbx)
   f1e68:	48 c7 83 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rbx)
   f1e73:	48 89 9b 20 01 00 00 	mov    %rbx,0x120(%rbx)
   f1e7a:	48 c7 83 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rbx)
   f1e85:	48 c7 83 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rbx)
   f1e90:	48 89 9b 38 01 00 00 	mov    %rbx,0x138(%rbx)
   f1e97:	48 c7 83 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rbx)
   f1ea2:	48 c7 83 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rbx)
   f1ead:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   f1eb8:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   f1ec2:	c6 83 80 01 00 00 01 	movb   $0x1,0x180(%rbx)
   f1ec9:	89 83 b8 02 00 00    	mov    %eax,0x2b8(%rbx)
   f1ecf:	0f 11 83 50 01 00 00 	movups %xmm0,0x150(%rbx)
   f1ed6:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f1edf:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f1ee7:	e8 54 09 01 00       	call   102840 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1eec:	4c 39 a3 c0 02 00 00 	cmp    %r12,0x2c0(%rbx)
   f1ef3:	0f 82 37 04 00 00    	jb     f2330 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb70>
   f1ef9:	48 8b 93 78 02 00 00 	mov    0x278(%rbx),%rdx
   f1f00:	4c 8b 93 70 02 00 00 	mov    0x270(%rbx),%r10
   f1f07:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   f1f11:	48 89 d1             	mov    %rdx,%rcx
   f1f14:	4c 29 d1             	sub    %r10,%rcx
   f1f17:	48 89 c8             	mov    %rcx,%rax
   f1f1a:	48 c1 f8 03          	sar    $0x3,%rax
   f1f1e:	48 0f af c7          	imul   %rdi,%rax
   f1f22:	4c 39 e0             	cmp    %r12,%rax
   f1f25:	0f 82 95 03 00 00    	jb     f22c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb00>
   f1f2b:	49 39 c4             	cmp    %rax,%r12
   f1f2e:	73 16                	jae    f1f46 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   f1f30:	49 6b c4 38          	imul   $0x38,%r12,%rax
   f1f34:	49 01 c2             	add    %rax,%r10
   f1f37:	4c 39 d2             	cmp    %r10,%rdx
   f1f3a:	74 07                	je     f1f43 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x783>
   f1f3c:	4c 89 93 78 02 00 00 	mov    %r10,0x278(%rbx)
   f1f43:	4c 89 d2             	mov    %r10,%rdx
   f1f46:	48 8b b3 70 02 00 00 	mov    0x270(%rbx),%rsi
   f1f4d:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   f1f53:	74 5c                	je     f1fb1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7f1>
   f1f55:	48 89 f0             	mov    %rsi,%rax
   f1f58:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1f5c:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   f1f60:	31 c9                	xor    %ecx,%ecx
   f1f62:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1f6a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1f75:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1f80:	f3 0f 6f 4d 00       	movdqu 0x0(%rbp),%xmm1
   f1f85:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f1f89:	48 83 c5 10          	add    $0x10,%rbp
   f1f8d:	48 83 c0 38          	add    $0x38,%rax
   f1f91:	89 48 d8             	mov    %ecx,-0x28(%rax)
   f1f94:	48 83 c1 01          	add    $0x1,%rcx
   f1f98:	0f 11 40 e8          	movups %xmm0,-0x18(%rax)
   f1f9c:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f1fa4:	0f 11 48 c8          	movups %xmm1,-0x38(%rax)
   f1fa8:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
   f1fac:	4c 39 e1             	cmp    %r12,%rcx
   f1faf:	72 cf                	jb     f1f80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f1fb1:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f1fbd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1fc1:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f1fc9:	48 39 d6             	cmp    %rdx,%rsi
   f1fcc:	0f 84 b6 03 00 00    	je     f2388 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbc8>
   f1fd2:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f1fdc:	48 29 f2             	sub    %rsi,%rdx
   f1fdf:	48 c1 fa 03          	sar    $0x3,%rdx
   f1fe3:	48 0f af d0          	imul   %rax,%rdx
   f1fe7:	48 39 53 38          	cmp    %rdx,0x38(%rbx)
   f1feb:	0f 82 1f 04 00 00    	jb     f2410 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc50>
   f1ff1:	48 83 ec 20          	sub    $0x20,%rsp
   f1ff5:	48 8d 8b 88 01 00 00 	lea    0x188(%rbx),%rcx
   f1ffc:	48 8d b3 70 02 00 00 	lea    0x270(%rbx),%rsi
   f2003:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f200c:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   f2010:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f2019:	0f 11 04 24          	movups %xmm0,(%rsp)
   f201d:	e8 de 2f fe ff       	call   d5000 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f2022:	48 83 c4 20          	add    $0x20,%rsp
   f2026:	84 c0                	test   %al,%al
   f2028:	0f 85 bc 06 00 00    	jne    f26ea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf2a>
   f202e:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f2037:	0f 84 e3 01 00 00    	je     f2220 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa60>
   f203d:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f2042:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f204a:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f2052:	48 89 de             	mov    %rbx,%rsi
   f2055:	e8 e6 f0 ff ff       	call   f1140 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f205a:	8b 74 24 1c          	mov    0x1c(%rsp),%esi
   f205e:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f2065:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f206f:	48 8b bc 24 38 03 00 00 	mov    0x338(%rsp),%rdi
   f2077:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f207d:	39 c6                	cmp    %eax,%esi
   f207f:	48 8b 94 24 c8 00 00 00 	mov    0xc8(%rsp),%rdx
   f2087:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f2090:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f2099:	0f 43 c6             	cmovae %esi,%eax
   f209c:	48 01 3c 24          	add    %rdi,(%rsp)
   f20a0:	48 8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%rdi
   f20a8:	48 01 7c 24 08       	add    %rdi,0x8(%rsp)
   f20ad:	4c 01 ea             	add    %r13,%rdx
   f20b0:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   f20b4:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f20b8:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f20c1:	41 89 47 38          	mov    %eax,0x38(%r15)
   f20c5:	48 8b 04 24          	mov    (%rsp),%rax
   f20c9:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f20cd:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f20d3:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f20d8:	49 89 47 40          	mov    %rax,0x40(%r15)
   f20dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f20e1:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f20e6:	49 89 47 48          	mov    %rax,0x48(%r15)
   f20ea:	48 89 d0             	mov    %rdx,%rax
   f20ed:	48 c1 e8 1e          	shr    $0x1e,%rax
   f20f1:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f20f6:	48 31 d0             	xor    %rdx,%rax
   f20f9:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f20fe:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f2108:	48 0f af c2          	imul   %rdx,%rax
   f210c:	48 89 c2             	mov    %rax,%rdx
   f210f:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f2113:	48 31 d0             	xor    %rdx,%rax
   f2116:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f2120:	48 0f af c2          	imul   %rdx,%rax
   f2124:	48 89 c2             	mov    %rax,%rdx
   f2127:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f212b:	48 31 d0             	xor    %rdx,%rax
   f212e:	48 01 44 24 10       	add    %rax,0x10(%rsp)
   f2133:	45 84 f6             	test   %r14b,%r14b
   f2136:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   f213b:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f2143:	49 89 77 50          	mov    %rsi,0x50(%r15)
   f2147:	44 0f 44 f0          	cmove  %eax,%r14d
   f214b:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f2153:	49 83 c5 01          	add    $0x1,%r13
   f2157:	48 8b 10             	mov    (%rax),%rdx
   f215a:	45 88 77 68          	mov    %r14b,0x68(%r15)
   f215e:	48 8b 40 08          	mov    0x8(%rax),%rax
   f2162:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   f2167:	48 29 d0             	sub    %rdx,%rax
   f216a:	48 c1 f8 03          	sar    $0x3,%rax
   f216e:	48 0f af c1          	imul   %rcx,%rax
   f2172:	49 39 c5             	cmp    %rax,%r13
   f2175:	0f 82 75 f7 ff ff    	jb     f18f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f217b:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   f2183:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f218b:	80 3d e6 20 08 00 00 	cmpb   $0x0,0x820e6(%rip)        # 174278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f2192:	0f 84 21 05 00 00    	je     f26b9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef9>
   f2198:	0f 31                	rdtsc
   f219a:	48 c1 e2 20          	shl    $0x20,%rdx
   f219e:	48 09 d0             	or     %rdx,%rax
   f21a1:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f21a9:	0f 88 d2 04 00 00    	js     f2681 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xec1>
   f21af:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f21b3:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f21b8:	f2 0f 59 05 70 20 08 00 	mulsd  0x82070(%rip),%xmm0        # 174230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f21c0:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f21c5:	49 89 07             	mov    %rax,(%r15)
   f21c8:	e8 73 1e 06 00       	call   154040 <_ZN5bench6memory11allocationsEv>
   f21cd:	4c 29 f0             	sub    %r14,%rax
   f21d0:	49 89 47 58          	mov    %rax,0x58(%r15)
   f21d4:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f21dc:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f21e5:	0f 85 f2 04 00 00    	jne    f26dd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf1d>
   f21eb:	4c 89 f8             	mov    %r15,%rax
   f21ee:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f21f6:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f21fe:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f2206:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f220e:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f2216:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f221d:	c3                   	ret
   f221e:	66 90                	xchg   %ax,%ax
   f2220:	80 3d 51 20 08 00 00 	cmpb   $0x0,0x82051(%rip)        # 174278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f2227:	0f 84 db 03 00 00    	je     f2608 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe48>
   f222d:	0f 31                	rdtsc
   f222f:	48 c1 e2 20          	shl    $0x20,%rdx
   f2233:	48 09 d0             	or     %rdx,%rax
   f2236:	48 89 c5             	mov    %rax,%rbp
   f2239:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f223e:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f2246:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f224e:	48 89 de             	mov    %rbx,%rsi
   f2251:	e8 ea ee ff ff       	call   f1140 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f2256:	f2 0f 10 0d d2 1f 08 00 	movsd  0x81fd2(%rip),%xmm1        # 174230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f225e:	48 89 e8             	mov    %rbp,%rax
   f2261:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f2269:	0f 88 61 03 00 00    	js     f25d0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe10>
   f226f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2273:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f2278:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f227c:	80 3d f5 1f 08 00 00 	cmpb   $0x0,0x81ff5(%rip)        # 174278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f2283:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f2288:	49 89 47 08          	mov    %rax,0x8(%r15)
   f228c:	0f 84 5e 03 00 00    	je     f25f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe30>
   f2292:	0f 31                	rdtsc
   f2294:	48 c1 e2 20          	shl    $0x20,%rdx
   f2298:	48 09 d0             	or     %rdx,%rax
   f229b:	48 29 e8             	sub    %rbp,%rax
   f229e:	0f 88 0c 03 00 00    	js     f25b0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdf0>
   f22a4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f22a8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f22ad:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f22b1:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f22b6:	49 89 47 10          	mov    %rax,0x10(%r15)
   f22ba:	e9 9b fd ff ff       	jmp    f205a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x89a>
   f22bf:	90                   	nop
   f22c0:	48 8b b3 80 02 00 00 	mov    0x280(%rbx),%rsi
   f22c7:	4d 89 e3             	mov    %r12,%r11
   f22ca:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   f22d4:	49 29 c3             	sub    %rax,%r11
   f22d7:	48 89 f7             	mov    %rsi,%rdi
   f22da:	48 29 d7             	sub    %rdx,%rdi
   f22dd:	48 c1 ff 03          	sar    $0x3,%rdi
   f22e1:	49 0f af f9          	imul   %r9,%rdi
   f22e5:	4c 39 df             	cmp    %r11,%rdi
   f22e8:	0f 82 42 01 00 00    	jb     f2430 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc70>
   f22ee:	4c 89 d9             	mov    %r11,%rcx
   f22f1:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f22f5:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f22f9:	48 89 d0             	mov    %rdx,%rax
   f22fc:	0f 1f 40 00          	nopl   0x0(%rax)
   f2300:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f2304:	48 83 c0 38          	add    $0x38,%rax
   f2308:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f230c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f2310:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f2314:	48 83 e9 01          	sub    $0x1,%rcx
   f2318:	75 e6                	jne    f2300 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb40>
   f231a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f231e:	4c 01 da             	add    %r11,%rdx
   f2321:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   f2328:	e9 19 fc ff ff       	jmp    f1f46 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   f232d:	0f 1f 00             	nopl   (%rax)
   f2330:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2334:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f233c:	48 8d bb 88 01 00 00 	lea    0x188(%rbx),%rdi
   f2343:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   f234b:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f2353:	e8 a8 54 02 00       	call   117800 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f2358:	84 c0                	test   %al,%al
   f235a:	0f 85 8a 03 00 00    	jne    f26ea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf2a>
   f2360:	4c 89 a3 c0 02 00 00 	mov    %r12,0x2c0(%rbx)
   f2367:	e9 8d fb ff ff       	jmp    f1ef9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x739>
   f236c:	0f 1f 40 00          	nopl   0x0(%rax)
   f2370:	c6 83 80 01 00 00 00 	movb   $0x0,0x180(%rbx)
   f2377:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   f237b:	e8 c0 04 01 00       	call   102840 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f2380:	e9 69 f9 ff ff       	jmp    f1cee <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x52e>
   f2385:	0f 1f 00             	nopl   (%rax)
   f2388:	48 83 bb c8 00 00 00 00 	cmpq   $0x0,0xc8(%rbx)
   f2390:	74 55                	je     f23e7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc27>
   f2392:	48 8b 93 80 00 00 00 	mov    0x80(%rbx),%rdx
   f2399:	48 85 d2             	test   %rdx,%rdx
   f239c:	0f 85 73 02 00 00    	jne    f2615 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe55>
   f23a2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f23a7:	66 0f 6f 05 d1 b4 06 00 	movdqa 0x6b4d1(%rip),%xmm0        # 15d880 <C.66.5+0x260>
   f23af:	c7 83 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%rbx)
   f23b9:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   f23c4:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   f23cb:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   f23d6:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   f23e0:	0f 11 83 dc 00 00 00 	movups %xmm0,0xdc(%rbx)
   f23e7:	80 7b 08 00          	cmpb   $0x0,0x8(%rbx)
   f23eb:	0f 84 3d fc ff ff    	je     f202e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x86e>
   f23f1:	80 bb 60 01 00 00 00 	cmpb   $0x0,0x160(%rbx)
   f23f8:	0f 84 30 fc ff ff    	je     f202e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x86e>
   f23fe:	c6 83 60 01 00 00 00 	movb   $0x0,0x160(%rbx)
   f2405:	e9 24 fc ff ff       	jmp    f202e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x86e>
   f240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f2410:	ba 10 00 00 00       	mov    $0x10,%edx
   f2415:	48 8b 3d 44 1e 08 00 	mov    0x81e44(%rip),%rdi        # 174260 <stderr@GLIBC_2.2.5>
   f241c:	48 8d 35 7d 95 06 00 	lea    0x6957d(%rip),%rsi        # 15b9a0 <_IO_stdin_used+0x19a0>
   f2423:	31 c0                	xor    %eax,%eax
   f2425:	e8 16 4f f1 ff       	call   7340 <fprintf@plt>
   f242a:	e8 f1 4c f1 ff       	call   7120 <abort@plt>
   f242f:	90                   	nop
   f2430:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f243a:	48 29 c7             	sub    %rax,%rdi
   f243d:	4c 39 df             	cmp    %r11,%rdi
   f2440:	0f 82 a8 a9 f1 ff    	jb     cdee <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f2446:	4c 39 d8             	cmp    %r11,%rax
   f2449:	4c 89 df             	mov    %r11,%rdi
   f244c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f2454:	48 0f 43 f8          	cmovae %rax,%rdi
   f2458:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   f2460:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f2468:	48 01 c7             	add    %rax,%rdi
   f246b:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   f2470:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f247a:	48 39 c7             	cmp    %rax,%rdi
   f247d:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f2482:	48 0f 47 f8          	cmova  %rax,%rdi
   f2486:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   f248a:	48 89 c7             	mov    %rax,%rdi
   f248d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f2492:	e8 69 1d 06 00       	call   154200 <_Znwm>
   f2497:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f249d:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   f24a5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f24a9:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   f24ae:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f24b6:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f24ba:	48 01 c1             	add    %rax,%rcx
   f24bd:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f24c5:	49 01 cb             	add    %rcx,%r11
   f24c8:	66 90                	xchg   %ax,%ax
   f24ca:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f24d5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f24e0:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   f24e4:	48 83 c1 38          	add    $0x38,%rcx
   f24e8:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f24ec:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f24f0:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   f24f4:	4c 39 d9             	cmp    %r11,%rcx
   f24f7:	75 e7                	jne    f24e0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd20>
   f24f9:	4c 39 d2             	cmp    %r10,%rdx
   f24fc:	74 71                	je     f256f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdaf>
   f24fe:	4c 89 d1             	mov    %r10,%rcx
   f2501:	48 89 c7             	mov    %rax,%rdi
   f2504:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f2509:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2514:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f251f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f252a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2535:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2540:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   f2544:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   f2548:	48 83 c1 38          	add    $0x38,%rcx
   f254c:	48 83 c7 38          	add    $0x38,%rdi
   f2550:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f2554:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   f2559:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   f255d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f2561:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   f2566:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f256a:	48 39 ca             	cmp    %rcx,%rdx
   f256d:	75 d1                	jne    f2540 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f256f:	4d 85 d2             	test   %r10,%r10
   f2572:	74 15                	je     f2589 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdc9>
   f2574:	4c 29 d6             	sub    %r10,%rsi
   f2577:	4c 89 d7             	mov    %r10,%rdi
   f257a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f257f:	e8 fc 1d 06 00       	call   154380 <_ZdlPvm>
   f2584:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f2589:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   f258d:	48 89 83 70 02 00 00 	mov    %rax,0x270(%rbx)
   f2594:	48 01 c2             	add    %rax,%rdx
   f2597:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f259c:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   f25a3:	48 89 83 80 02 00 00 	mov    %rax,0x280(%rbx)
   f25aa:	e9 97 f9 ff ff       	jmp    f1f46 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   f25af:	90                   	nop
   f25b0:	48 89 c2             	mov    %rax,%rdx
   f25b3:	83 e0 01             	and    $0x1,%eax
   f25b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f25ba:	48 d1 ea             	shr    $1,%rdx
   f25bd:	48 09 c2             	or     %rax,%rdx
   f25c0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f25c5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f25c9:	e9 df fc ff ff       	jmp    f22ad <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaed>
   f25ce:	66 90                	xchg   %ax,%ax
   f25d0:	48 89 c2             	mov    %rax,%rdx
   f25d3:	83 e0 01             	and    $0x1,%eax
   f25d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f25da:	48 d1 ea             	shr    $1,%rdx
   f25dd:	48 09 c2             	or     %rax,%rdx
   f25e0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f25e5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f25e9:	e9 8a fc ff ff       	jmp    f2278 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab8>
   f25ee:	66 90                	xchg   %ax,%ax
   f25f0:	e8 db 4c f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f25f5:	f2 0f 10 0d 33 1c 08 00 	movsd  0x81c33(%rip),%xmm1        # 174230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f25fd:	e9 99 fc ff ff       	jmp    f229b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xadb>
   f2602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f2608:	e8 c3 4c f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f260d:	48 89 c5             	mov    %rax,%rbp
   f2610:	e9 24 fc ff ff       	jmp    f2239 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa79>
   f2615:	48 c7 83 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%rbx)
   f2620:	80 bb 94 00 00 00 00 	cmpb   $0x0,0x94(%rbx)
   f2627:	0f 85 96 00 00 00    	jne    f26c3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf03>
   f262d:	8b 83 90 00 00 00    	mov    0x90(%rbx),%eax
   f2633:	83 c0 01             	add    $0x1,%eax
   f2636:	89 83 90 00 00 00    	mov    %eax,0x90(%rbx)
   f263c:	83 f8 ff             	cmp    $0xffffffff,%eax
   f263f:	0f 85 5d fd ff ff    	jne    f23a2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbe2>
   f2645:	48 8b 43 78          	mov    0x78(%rbx),%rax
   f2649:	48 89 d1             	mov    %rdx,%rcx
   f264c:	48 c1 e1 04          	shl    $0x4,%rcx
   f2650:	48 01 c1             	add    %rax,%rcx
   f2653:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f265a:	48 83 c0 10          	add    $0x10,%rax
   f265e:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f2666:	48 39 c8             	cmp    %rcx,%rax
   f2669:	75 e8                	jne    f2653 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe93>
   f266b:	48 01 93 b0 00 00 00 	add    %rdx,0xb0(%rbx)
   f2672:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   f267c:	e9 21 fd ff ff       	jmp    f23a2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbe2>
   f2681:	48 89 c2             	mov    %rax,%rdx
   f2684:	83 e0 01             	and    $0x1,%eax
   f2687:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f268b:	48 d1 ea             	shr    $1,%rdx
   f268e:	48 09 c2             	or     %rax,%rdx
   f2691:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f2696:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f269a:	e9 19 fb ff ff       	jmp    f21b8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9f8>
   f269f:	4c 89 1c 24          	mov    %r11,(%rsp)
   f26a3:	e8 18 f7 f1 ff       	call   11dc0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f26a8:	4c 8b 1c 24          	mov    (%rsp),%r11
   f26ac:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f26b4:	e9 b6 f1 ff ff       	jmp    f186f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf>
   f26b9:	e8 02 f7 f1 ff       	call   11dc0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f26be:	e9 de fa ff ff       	jmp    f21a1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9e1>
   f26c3:	48 c7 83 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rbx)
   f26ce:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   f26d8:	e9 c5 fc ff ff       	jmp    f23a2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbe2>
   f26dd:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f26e5:	e8 76 4b f1 ff       	call   7260 <__stack_chk_fail@plt>
   f26ea:	0f b6 d0             	movzbl %al,%edx
   f26ed:	e9 23 fd ff ff       	jmp    f2415 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc55>

# candidate ordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, true>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-layout.0xp7gI/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f56c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f56c0:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f56c7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f56cb:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f56d3:	48 8b 2a             	mov    (%rdx),%rbp
   f56d6:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f56de:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f56e2:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f56ea:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f56f2:	49 89 ff             	mov    %rdi,%r15
   f56f5:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f56fd:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f5704:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f5709:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f5712:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f571a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f571e:	0f 11 07             	movups %xmm0,(%rdi)
   f5721:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f5725:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f5729:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f572d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f5731:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f5735:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f5739:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f573d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   f5742:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f5746:	e8 f5 e8 05 00       	call   154040 <_ZN5bench6memory11allocationsEv>
   f574b:	80 3d 26 eb 07 00 00 	cmpb   $0x0,0x7eb26(%rip)        # 174278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f5752:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f5757:	49 89 c6             	mov    %rax,%r14
   f575a:	0f 84 83 0e 00 00    	je     f65e3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf23>
   f5760:	0f 31                	rdtsc
   f5762:	48 c1 e2 20          	shl    $0x20,%rdx
   f5766:	48 09 d0             	or     %rdx,%rax
   f5769:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f5771:	49 8b 11             	mov    (%r9),%rdx
   f5774:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   f5778:	0f 84 4b 09 00 00    	je     f60c9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa09>
   f577e:	49 29 ec             	sub    %rbp,%r12
   f5781:	c6 44 24 77 00       	movb   $0x0,0x77(%rsp)
   f5786:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f578e:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f5792:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f579a:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   f57a3:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f57ac:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f57b5:	c7 44 24 70 00 00 00 00 	movl   $0x0,0x70(%rsp)
   f57bd:	4c 89 8c 24 88 00 00 00 	mov    %r9,0x88(%rsp)
   f57c5:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f57cd:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   f57d5:	49 89 de             	mov    %rbx,%r14
   f57d8:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f57e0:	45 31 ed             	xor    %r13d,%r13d
   f57e3:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f57e8:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f57ed:	0f 1f 00             	nopl   (%rax)
   f57f0:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   f57f5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f57f9:	48 8b 28             	mov    (%rax),%rbp
   f57fc:	48 8b 58 08          	mov    0x8(%rax),%rbx
   f5800:	48 29 eb             	sub    %rbp,%rbx
   f5803:	49 89 dc             	mov    %rbx,%r12
   f5806:	49 c1 fc 04          	sar    $0x4,%r12
   f580a:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f5812:	74 14                	je     f5828 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x168>
   f5814:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f581b:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   f5822:	0f 84 cb 05 00 00    	je     f5df3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x733>
   f5828:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f5830:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5834:	31 f6                	xor    %esi,%esi
   f5836:	66 0f 6f 3d 82 80 06 00 	movdqa 0x68082(%rip),%xmm7        # 15d8c0 <C.66.5+0x2a0>
   f583e:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f5846:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f584e:	ba 88 01 00 00       	mov    $0x188,%edx
   f5853:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f585a:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f585f:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f5867:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f586f:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f5874:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f587c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f5880:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f5889:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f5891:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f589a:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f58a2:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f58ab:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f58b3:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f58bb:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f58c0:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f58c8:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f58cd:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f58d5:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f58da:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f58e2:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f58ee:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f58fa:	e8 11 18 f1 ff       	call   7110 <memset@plt>
   f58ff:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f5905:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f5909:	66 0f 6f 05 bf 7f 06 00 	movdqa 0x67fbf(%rip),%xmm0        # 15d8d0 <C.66.5+0x2b0>
   f5911:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f5917:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f591d:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f5921:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f5928:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f5930:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f5935:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f593d:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f5945:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f594d:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f5959:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   f5961:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f596d:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f5979:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f5985:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f5991:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f599d:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f59a8:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f59b0:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f59bb:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f59c7:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f59cf:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f59db:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f59e6:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f59ee:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   f59f6:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f5a02:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f5a0e:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   f5a16:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f5a22:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f5a2a:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f5a32:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f5a3a:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f5a42:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f5a4a:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f5a56:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f5a5e:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f5a67:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f5a6f:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f5a77:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f5a80:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f5a88:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f5a90:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f5a99:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f5aa1:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f5aa8:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f5ab0:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   f5ab8:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f5ac4:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f5ad0:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   f5ad8:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f5ae4:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f5af0:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f5afc:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f5b07:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f5b13:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   f5b1b:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f5b26:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f5b31:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f5b3d:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f5b45:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   f5b4d:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   f5b55:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   f5b5d:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   f5b65:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f5b6d:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f5b75:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f5b7d:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f5b85:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f5b8d:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f5b94:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f5b9d:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f5ba8:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f5baf:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f5bb6:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f5bc1:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f5bc8:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f5bd0:	e8 6b cc 00 00       	call   102840 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f5bd5:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f5bdd:	0f 85 f5 06 00 00    	jne    f62d8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc18>
   f5be3:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f5bec:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f5bf4:	4d 89 76 50          	mov    %r14,0x50(%r14)
   f5bf8:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f5c00:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f5c09:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   f5c11:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   f5c16:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f5c1f:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f5c27:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   f5c2c:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f5c35:	49 89 46 48          	mov    %rax,0x48(%r14)
   f5c39:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f5c40:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   f5c45:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f5c4e:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   f5c55:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f5c5a:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   f5c5f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5c63:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   f5c6b:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f5c74:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   f5c7b:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   f5c83:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f5c8b:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f5c94:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   f5c9c:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   f5ca4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5ca8:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   f5cb0:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   f5cb8:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   f5cc0:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   f5cc8:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   f5cd0:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f5cdb:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   f5ce3:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f5cee:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f5cf9:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   f5d04:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f5d0b:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f5d14:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   f5d1b:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   f5d22:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f5d29:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   f5d34:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f5d3b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f5d40:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f5d47:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f5d4e:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   f5d59:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   f5d60:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   f5d6b:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   f5d76:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   f5d7d:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   f5d88:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   f5d93:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   f5d9a:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   f5da5:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   f5db0:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f5dbb:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f5dc6:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   f5dce:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   f5dd5:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   f5ddd:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f5de6:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f5dee:	e8 4d ca 00 00       	call   102840 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f5df3:	4d 39 a6 c0 02 00 00 	cmp    %r12,0x2c0(%r14)
   f5dfa:	0f 82 90 04 00 00    	jb     f6290 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd0>
   f5e00:	49 8b 96 78 02 00 00 	mov    0x278(%r14),%rdx
   f5e07:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f5e0e:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   f5e18:	48 89 d1             	mov    %rdx,%rcx
   f5e1b:	4c 29 d1             	sub    %r10,%rcx
   f5e1e:	48 89 c8             	mov    %rcx,%rax
   f5e21:	48 c1 f8 03          	sar    $0x3,%rax
   f5e25:	48 0f af c7          	imul   %rdi,%rax
   f5e29:	4c 39 e0             	cmp    %r12,%rax
   f5e2c:	0f 82 ee 03 00 00    	jb     f6220 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb60>
   f5e32:	49 39 c4             	cmp    %rax,%r12
   f5e35:	73 16                	jae    f5e4d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f5e37:	49 6b c4 38          	imul   $0x38,%r12,%rax
   f5e3b:	49 01 c2             	add    %rax,%r10
   f5e3e:	4c 39 d2             	cmp    %r10,%rdx
   f5e41:	74 07                	je     f5e4a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   f5e43:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f5e4a:	4c 89 d2             	mov    %r10,%rdx
   f5e4d:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f5e54:	48 85 db             	test   %rbx,%rbx
   f5e57:	0f 84 7c 00 00 00    	je     f5ed9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x819>
   f5e5d:	4c 89 d1             	mov    %r10,%rcx
   f5e60:	31 f6                	xor    %esi,%esi
   f5e62:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f5e66:	49 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%r11
   f5e70:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   f5e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f5e80:	41 89 f0             	mov    %esi,%r8d
   f5e83:	f3 0f 6f 45 00       	movdqu 0x0(%rbp),%xmm0
   f5e88:	89 71 10             	mov    %esi,0x10(%rcx)
   f5e8b:	48 83 c6 01          	add    $0x1,%rsi
   f5e8f:	41 81 f0 6b 6e 61 72 	xor    $0x72616e6b,%r8d
   f5e96:	c6 41 30 01          	movb   $0x1,0x30(%rcx)
   f5e9a:	48 83 c5 10          	add    $0x10,%rbp
   f5e9e:	48 83 c1 38          	add    $0x38,%rcx
   f5ea2:	4c 89 c0             	mov    %r8,%rax
   f5ea5:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f5ea9:	48 c1 e8 1e          	shr    $0x1e,%rax
   f5ead:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f5eb1:	4c 31 c0             	xor    %r8,%rax
   f5eb4:	49 0f af c3          	imul   %r11,%rax
   f5eb8:	49 89 c0             	mov    %rax,%r8
   f5ebb:	49 c1 e8 1b          	shr    $0x1b,%r8
   f5ebf:	4c 31 c0             	xor    %r8,%rax
   f5ec2:	48 0f af c7          	imul   %rdi,%rax
   f5ec6:	49 89 c0             	mov    %rax,%r8
   f5ec9:	49 c1 e8 1f          	shr    $0x1f,%r8
   f5ecd:	4c 31 c0             	xor    %r8,%rax
   f5ed0:	48 89 41 f0          	mov    %rax,-0x10(%rcx)
   f5ed4:	4c 39 e6             	cmp    %r12,%rsi
   f5ed7:	72 a7                	jb     f5e80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f5ed9:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f5ee5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5ee9:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f5ef1:	4c 39 d2             	cmp    %r10,%rdx
   f5ef4:	0f 84 f6 03 00 00    	je     f62f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc30>
   f5efa:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f5f04:	4c 29 d2             	sub    %r10,%rdx
   f5f07:	48 c1 fa 03          	sar    $0x3,%rdx
   f5f0b:	48 0f af d0          	imul   %rax,%rdx
   f5f0f:	49 39 56 38          	cmp    %rdx,0x38(%r14)
   f5f13:	0f 82 67 04 00 00    	jb     f6380 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc0>
   f5f19:	48 83 ec 20          	sub    $0x20,%rsp
   f5f1d:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   f5f24:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   f5f2b:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f5f34:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f5f38:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f5f41:	0f 11 04 24          	movups %xmm0,(%rsp)
   f5f45:	e8 b6 f0 fd ff       	call   d5000 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f5f4a:	48 83 c4 20          	add    $0x20,%rsp
   f5f4e:	84 c0                	test   %al,%al
   f5f50:	0f 85 db 06 00 00    	jne    f6631 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf71>
   f5f56:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f5f5f:	0f 84 fb 01 00 00    	je     f6160 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa0>
   f5f65:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f5f6a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5f6e:	4c 89 f6             	mov    %r14,%rsi
   f5f71:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f5f79:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f5f81:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f5f89:	e8 f2 ec ff ff       	call   f4c80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f5f8e:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f5f96:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f5f9e:	8b 7c 24 70          	mov    0x70(%rsp),%edi
   f5fa2:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f5fa9:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   f5fad:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f5fb7:	48 8b b4 24 38 03 00 00 	mov    0x338(%rsp),%rsi
   f5fbf:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f5fc5:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f5fce:	39 c7                	cmp    %eax,%edi
   f5fd0:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f5fd9:	0f 43 c7             	cmovae %edi,%eax
   f5fdc:	48 01 74 24 08       	add    %rsi,0x8(%rsp)
   f5fe1:	4c 01 64 24 10       	add    %r12,0x10(%rsp)
   f5fe6:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f5fea:	89 44 24 70          	mov    %eax,0x70(%rsp)
   f5fee:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f5ff2:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f5ffb:	41 89 47 38          	mov    %eax,0x38(%r15)
   f5fff:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f6004:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f600a:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f600f:	49 89 47 40          	mov    %rax,0x40(%r15)
   f6013:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f6018:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f601d:	49 89 47 48          	mov    %rax,0x48(%r15)
   f6021:	48 89 d0             	mov    %rdx,%rax
   f6024:	48 c1 e8 1e          	shr    $0x1e,%rax
   f6028:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f602d:	48 31 d0             	xor    %rdx,%rax
   f6030:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f6035:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f603f:	48 0f af c2          	imul   %rdx,%rax
   f6043:	48 89 c2             	mov    %rax,%rdx
   f6046:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f604a:	48 31 d0             	xor    %rdx,%rax
   f604d:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f6057:	48 0f af c2          	imul   %rdx,%rax
   f605b:	48 89 c2             	mov    %rax,%rdx
   f605e:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f6062:	48 31 d0             	xor    %rdx,%rax
   f6065:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   f606a:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   f606f:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f6077:	49 89 5f 50          	mov    %rbx,0x50(%r15)
   f607b:	0f b6 5c 24 77       	movzbl 0x77(%rsp),%ebx
   f6080:	84 db                	test   %bl,%bl
   f6082:	0f 44 d8             	cmove  %eax,%ebx
   f6085:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f608d:	49 83 c5 01          	add    $0x1,%r13
   f6091:	48 8b 10             	mov    (%rax),%rdx
   f6094:	88 5c 24 77          	mov    %bl,0x77(%rsp)
   f6098:	41 88 5f 68          	mov    %bl,0x68(%r15)
   f609c:	48 8b 40 08          	mov    0x8(%rax),%rax
   f60a0:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f60a5:	48 29 d0             	sub    %rdx,%rax
   f60a8:	48 c1 f8 03          	sar    $0x3,%rax
   f60ac:	48 0f af c1          	imul   %rcx,%rax
   f60b0:	49 39 c5             	cmp    %rax,%r13
   f60b3:	0f 82 37 f7 ff ff    	jb     f57f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f60b9:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   f60c1:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f60c9:	80 3d a8 e1 07 00 00 	cmpb   $0x0,0x7e1a8(%rip)        # 174278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f60d0:	0f 84 29 05 00 00    	je     f65ff <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf3f>
   f60d6:	0f 31                	rdtsc
   f60d8:	48 c1 e2 20          	shl    $0x20,%rdx
   f60dc:	48 09 d0             	or     %rdx,%rax
   f60df:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f60e7:	0f 88 d8 04 00 00    	js     f65c5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf05>
   f60ed:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f60f1:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f60f6:	f2 0f 59 05 32 e1 07 00 	mulsd  0x7e132(%rip),%xmm0        # 174230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f60fe:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f6103:	49 89 07             	mov    %rax,(%r15)
   f6106:	e8 35 df 05 00       	call   154040 <_ZN5bench6memory11allocationsEv>
   f610b:	4c 29 f0             	sub    %r14,%rax
   f610e:	49 89 47 58          	mov    %rax,0x58(%r15)
   f6112:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f611a:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f6123:	0f 85 fb 04 00 00    	jne    f6624 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf64>
   f6129:	4c 89 f8             	mov    %r15,%rax
   f612c:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f6134:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f613c:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f6144:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f614c:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f6154:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f615b:	c3                   	ret
   f615c:	0f 1f 40 00          	nopl   0x0(%rax)
   f6160:	80 3d 11 e1 07 00 00 	cmpb   $0x0,0x7e111(%rip)        # 174278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f6167:	0f 84 db 03 00 00    	je     f6548 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe88>
   f616d:	0f 31                	rdtsc
   f616f:	48 c1 e2 20          	shl    $0x20,%rdx
   f6173:	48 09 d0             	or     %rdx,%rax
   f6176:	48 89 c5             	mov    %rax,%rbp
   f6179:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f617e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f6182:	4c 89 f6             	mov    %r14,%rsi
   f6185:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f618d:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f6195:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f619d:	e8 de ea ff ff       	call   f4c80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f61a2:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f61aa:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f61b2:	48 89 e8             	mov    %rbp,%rax
   f61b5:	f2 0f 10 0d 73 e0 07 00 	movsd  0x7e073(%rip),%xmm1        # 174230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f61bd:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f61c5:	0f 88 45 03 00 00    	js     f6510 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe50>
   f61cb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f61cf:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f61d4:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f61d8:	80 3d 99 e0 07 00 00 	cmpb   $0x0,0x7e099(%rip)        # 174278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f61df:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f61e4:	49 89 47 08          	mov    %rax,0x8(%r15)
   f61e8:	0f 84 42 03 00 00    	je     f6530 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   f61ee:	0f 31                	rdtsc
   f61f0:	48 c1 e2 20          	shl    $0x20,%rdx
   f61f4:	48 09 d0             	or     %rdx,%rax
   f61f7:	48 29 e8             	sub    %rbp,%rax
   f61fa:	0f 88 f0 02 00 00    	js     f64f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe30>
   f6200:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f6204:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f6209:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f620d:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f6212:	49 89 47 10          	mov    %rax,0x10(%r15)
   f6216:	e9 83 fd ff ff       	jmp    f5f9e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8de>
   f621b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f6220:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   f6227:	4d 89 e3             	mov    %r12,%r11
   f622a:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   f6234:	49 29 c3             	sub    %rax,%r11
   f6237:	48 89 f7             	mov    %rsi,%rdi
   f623a:	48 29 d7             	sub    %rdx,%rdi
   f623d:	48 c1 ff 03          	sar    $0x3,%rdi
   f6241:	49 0f af f9          	imul   %r9,%rdi
   f6245:	4c 39 df             	cmp    %r11,%rdi
   f6248:	0f 82 52 01 00 00    	jb     f63a0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xce0>
   f624e:	4c 89 d9             	mov    %r11,%rcx
   f6251:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f6255:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f6259:	48 89 d0             	mov    %rdx,%rax
   f625c:	0f 1f 40 00          	nopl   0x0(%rax)
   f6260:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f6264:	48 83 c0 38          	add    $0x38,%rax
   f6268:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f626c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f6270:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f6274:	48 83 e9 01          	sub    $0x1,%rcx
   f6278:	75 e6                	jne    f6260 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   f627a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f627e:	4c 01 da             	add    %r11,%rdx
   f6281:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f6288:	e9 c0 fb ff ff       	jmp    f5e4d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f628d:	0f 1f 00             	nopl   (%rax)
   f6290:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f6298:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   f629f:	4c 89 a4 24 10 03 00 00 	mov    %r12,0x310(%rsp)
   f62a7:	48 c7 84 24 18 03 00 00 00 00 00 00 	movq   $0x0,0x318(%rsp)
   f62b3:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   f62bb:	e8 40 15 02 00       	call   117800 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f62c0:	84 c0                	test   %al,%al
   f62c2:	0f 85 69 03 00 00    	jne    f6631 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf71>
   f62c8:	4d 89 a6 c0 02 00 00 	mov    %r12,0x2c0(%r14)
   f62cf:	e9 2c fb ff ff       	jmp    f5e00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x740>
   f62d4:	0f 1f 40 00          	nopl   0x0(%rax)
   f62d8:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   f62e0:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f62e4:	e8 57 c5 00 00       	call   102840 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f62e9:	e9 f5 f8 ff ff       	jmp    f5be3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x523>
   f62ee:	66 90                	xchg   %ax,%ax
   f62f0:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   f62f8:	74 58                	je     f6352 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   f62fa:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   f6301:	48 85 d2             	test   %rdx,%rdx
   f6304:	0f 85 4b 02 00 00    	jne    f6555 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe95>
   f630a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f630f:	66 0f 6f 05 69 75 06 00 	movdqa 0x67569(%rip),%xmm0        # 15d880 <C.66.5+0x260>
   f6317:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   f6322:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f632d:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f6334:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f633f:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f634a:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   f6352:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f6357:	0f 84 f9 fb ff ff    	je     f5f56 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f635d:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   f6365:	0f 84 eb fb ff ff    	je     f5f56 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f636b:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   f6373:	e9 de fb ff ff       	jmp    f5f56 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f6378:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f6380:	ba 10 00 00 00       	mov    $0x10,%edx
   f6385:	48 8b 3d d4 de 07 00 	mov    0x7ded4(%rip),%rdi        # 174260 <stderr@GLIBC_2.2.5>
   f638c:	48 8d 35 0d 56 06 00 	lea    0x6560d(%rip),%rsi        # 15b9a0 <_IO_stdin_used+0x19a0>
   f6393:	31 c0                	xor    %eax,%eax
   f6395:	e8 a6 0f f1 ff       	call   7340 <fprintf@plt>
   f639a:	e8 81 0d f1 ff       	call   7120 <abort@plt>
   f639f:	90                   	nop
   f63a0:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f63aa:	48 29 c7             	sub    %rax,%rdi
   f63ad:	4c 39 df             	cmp    %r11,%rdi
   f63b0:	0f 82 38 6b f1 ff    	jb     ceee <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f63b6:	4c 39 d8             	cmp    %r11,%rax
   f63b9:	4c 89 df             	mov    %r11,%rdi
   f63bc:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f63c4:	48 0f 43 f8          	cmovae %rax,%rdi
   f63c8:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   f63d0:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f63d8:	48 01 c7             	add    %rax,%rdi
   f63db:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   f63e0:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f63ea:	48 39 c7             	cmp    %rax,%rdi
   f63ed:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f63f2:	48 0f 47 f8          	cmova  %rax,%rdi
   f63f6:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   f63fa:	48 89 c7             	mov    %rax,%rdi
   f63fd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f6402:	e8 f9 dd 05 00       	call   154200 <_Znwm>
   f6407:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f640d:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   f6415:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f6419:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   f641e:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f6426:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f642a:	48 01 c1             	add    %rax,%rcx
   f642d:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f6435:	49 01 cb             	add    %rcx,%r11
   f6438:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f6440:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   f6444:	48 83 c1 38          	add    $0x38,%rcx
   f6448:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f644c:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f6450:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   f6454:	4c 39 d9             	cmp    %r11,%rcx
   f6457:	75 e7                	jne    f6440 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f6459:	4c 39 d2             	cmp    %r10,%rdx
   f645c:	74 51                	je     f64af <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdef>
   f645e:	4c 89 d1             	mov    %r10,%rcx
   f6461:	48 89 c7             	mov    %rax,%rdi
   f6464:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f646a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f6475:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f6480:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   f6484:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   f6488:	48 83 c1 38          	add    $0x38,%rcx
   f648c:	48 83 c7 38          	add    $0x38,%rdi
   f6490:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f6494:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   f6499:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   f649d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f64a1:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   f64a6:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f64aa:	48 39 ca             	cmp    %rcx,%rdx
   f64ad:	75 d1                	jne    f6480 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdc0>
   f64af:	4d 85 d2             	test   %r10,%r10
   f64b2:	74 15                	je     f64c9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe09>
   f64b4:	4c 29 d6             	sub    %r10,%rsi
   f64b7:	4c 89 d7             	mov    %r10,%rdi
   f64ba:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f64bf:	e8 bc de 05 00       	call   154380 <_ZdlPvm>
   f64c4:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f64c9:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   f64cd:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   f64d4:	48 01 c2             	add    %rax,%rdx
   f64d7:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f64dc:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f64e3:	49 89 86 80 02 00 00 	mov    %rax,0x280(%r14)
   f64ea:	e9 5e f9 ff ff       	jmp    f5e4d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f64ef:	90                   	nop
   f64f0:	48 89 c2             	mov    %rax,%rdx
   f64f3:	83 e0 01             	and    $0x1,%eax
   f64f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f64fa:	48 d1 ea             	shr    $1,%rdx
   f64fd:	48 09 c2             	or     %rax,%rdx
   f6500:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f6505:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f6509:	e9 fb fc ff ff       	jmp    f6209 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb49>
   f650e:	66 90                	xchg   %ax,%ax
   f6510:	48 89 c2             	mov    %rax,%rdx
   f6513:	83 e0 01             	and    $0x1,%eax
   f6516:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f651a:	48 d1 ea             	shr    $1,%rdx
   f651d:	48 09 c2             	or     %rax,%rdx
   f6520:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f6525:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f6529:	e9 a6 fc ff ff       	jmp    f61d4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb14>
   f652e:	66 90                	xchg   %ax,%ax
   f6530:	e8 9b 0d f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f6535:	f2 0f 10 0d f3 dc 07 00 	movsd  0x7dcf3(%rip),%xmm1        # 174230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f653d:	e9 b5 fc ff ff       	jmp    f61f7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb37>
   f6542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f6548:	e8 83 0d f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f654d:	48 89 c5             	mov    %rax,%rbp
   f6550:	e9 24 fc ff ff       	jmp    f6179 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab9>
   f6555:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   f6560:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   f6568:	0f 85 9b 00 00 00    	jne    f6609 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf49>
   f656e:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   f6575:	83 c0 01             	add    $0x1,%eax
   f6578:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   f657f:	83 f8 ff             	cmp    $0xffffffff,%eax
   f6582:	0f 85 82 fd ff ff    	jne    f630a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f6588:	49 8b 46 78          	mov    0x78(%r14),%rax
   f658c:	48 89 d1             	mov    %rdx,%rcx
   f658f:	48 c1 e1 04          	shl    $0x4,%rcx
   f6593:	48 01 c1             	add    %rax,%rcx
   f6596:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f659d:	48 83 c0 10          	add    $0x10,%rax
   f65a1:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f65a9:	48 39 c8             	cmp    %rcx,%rax
   f65ac:	75 e8                	jne    f6596 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xed6>
   f65ae:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   f65b5:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f65c0:	e9 45 fd ff ff       	jmp    f630a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f65c5:	48 89 c2             	mov    %rax,%rdx
   f65c8:	83 e0 01             	and    $0x1,%eax
   f65cb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f65cf:	48 d1 ea             	shr    $1,%rdx
   f65d2:	48 09 c2             	or     %rax,%rdx
   f65d5:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f65da:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f65de:	e9 13 fb ff ff       	jmp    f60f6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa36>
   f65e3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f65e8:	e8 d3 b7 f1 ff       	call   11dc0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f65ed:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f65f2:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f65fa:	e9 72 f1 ff ff       	jmp    f5771 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb1>
   f65ff:	e8 bc b7 f1 ff       	call   11dc0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f6604:	e9 d6 fa ff ff       	jmp    f60df <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa1f>
   f6609:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   f6614:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f661f:	e9 e6 fc ff ff       	jmp    f630a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f6624:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f662c:	e8 2f 0c f1 ff       	call   7260 <__stack_chk_fail@plt>
   f6631:	0f b6 d0             	movzbl %al,%edx
   f6634:	e9 4c fd ff ff       	jmp    f6385 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc5>

# candidate unordered_pairs bench::Counters bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-layout.0xp7gI/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f1140 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f1140:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
   f1147:	44 8b 8e d0 00 00 00 	mov    0xd0(%rsi),%r9d
   f114e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1152:	48 89 ac 24 80 01 00 00 	mov    %rbp,0x180(%rsp)
   f115a:	48 89 fd             	mov    %rdi,%rbp
   f115d:	4c 89 a4 24 88 01 00 00 	mov    %r12,0x188(%rsp)
   f1165:	4d 89 cc             	mov    %r9,%r12
   f1168:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
   f116d:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
   f1176:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f117e:	31 c0                	xor    %eax,%eax
   f1180:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   f1185:	41 83 f9 01          	cmp    $0x1,%r9d
   f1189:	0f 86 31 03 00 00    	jbe    f14c0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x380>
   f118f:	48 89 9c 24 78 01 00 00 	mov    %rbx,0x178(%rsp)
   f1197:	66 48 0f 6e c8       	movq   %rax,%xmm1
   f119c:	48 89 f3             	mov    %rsi,%rbx
   f119f:	66 48 0f 6e d1       	movq   %rcx,%xmm2
   f11a4:	4c 89 b4 24 98 01 00 00 	mov    %r14,0x198(%rsp)
   f11ac:	4c 8d 76 08          	lea    0x8(%rsi),%r14
   f11b0:	8b b6 64 01 00 00    	mov    0x164(%rsi),%esi
   f11b6:	66 0f 6c ca          	punpcklqdq %xmm2,%xmm1
   f11ba:	c6 84 24 a0 00 00 00 00 	movb   $0x0,0xa0(%rsp)
   f11c2:	48 c7 84 24 d8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xd8(%rsp)
   f11ce:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f11d6:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f11de:	0f 11 8c 24 c8 00 00 00 	movups %xmm1,0xc8(%rsp)
   f11e6:	83 fe ff             	cmp    $0xffffffff,%esi
   f11e9:	0f 85 e1 01 00 00    	jne    f13d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x290>
   f11ef:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   f11f7:	49 89 d7             	mov    %rdx,%r15
   f11fa:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   f1202:	49 83 f9 04          	cmp    $0x4,%r9
   f1206:	0f 86 c0 02 00 00    	jbe    f14cc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x38c>
   f120c:	41 8d 44 24 ff       	lea    -0x1(%r12),%eax
   f1211:	44 89 64 24 28       	mov    %r12d,0x28(%rsp)
   f1216:	45 31 ed             	xor    %r13d,%r13d
   f1219:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   f121e:	31 c0                	xor    %eax,%eax
   f1220:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
   f1225:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
   f122a:	84 c0                	test   %al,%al
   f122c:	0f 85 77 01 00 00    	jne    f13a9 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x269>
   f1232:	0f 1f 00             	nopl   (%rax)
   f1235:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1240:	4c 39 6c 24 30       	cmp    %r13,0x30(%rsp)
   f1245:	0f 84 5e 01 00 00    	je     f13a9 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x269>
   f124b:	4c 89 ef             	mov    %r13,%rdi
   f124e:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   f1253:	44 89 ed             	mov    %r13d,%ebp
   f1256:	44 8b 64 24 28       	mov    0x28(%rsp),%r12d
   f125b:	48 c1 e7 05          	shl    $0x5,%rdi
   f125f:	41 83 c5 01          	add    $0x1,%r13d
   f1263:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   f1268:	48 8d 5f 20          	lea    0x20(%rdi),%rbx
   f126c:	eb 21                	jmp    f128f <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x14f>
   f126e:	66 90                	xchg   %ax,%ax
   f1270:	41 83 c5 01          	add    $0x1,%r13d
   f1274:	45 39 e5             	cmp    %r12d,%r13d
   f1277:	0f 83 13 01 00 00    	jae    f1390 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x250>
   f127d:	48 83 c3 20          	add    $0x20,%rbx
   f1281:	80 bc 24 a0 00 00 00 00 	cmpb   $0x0,0xa0(%rsp)
   f1289:	0f 85 01 01 00 00    	jne    f1390 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x250>
   f128f:	48 8d 8c 24 a0 00 00 00 	lea    0xa0(%rsp),%rcx
   f1297:	44 89 ea             	mov    %r13d,%edx
   f129a:	89 ee                	mov    %ebp,%esi
   f129c:	4c 89 f7             	mov    %r14,%rdi
   f129f:	e8 5c 14 f2 ff       	call   12700 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_12QueryContextINS_11QueryResultEEERT0_.isra.0>
   f12a4:	84 c0                	test   %al,%al
   f12a6:	74 c8                	je     f1270 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x130>
   f12a8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f12ad:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   f12b2:	48 8b 40 68          	mov    0x68(%rax),%rax
   f12b6:	8b 7c 30 18          	mov    0x18(%rax,%rsi,1),%edi
   f12ba:	39 7c 18 18          	cmp    %edi,0x18(%rax,%rbx,1)
   f12be:	0f 82 ec 01 00 00    	jb     f14b0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x370>
   f12c4:	44 89 6c 24 08       	mov    %r13d,0x8(%rsp)
   f12c9:	89 ea                	mov    %ebp,%edx
   f12cb:	4c 89 f6             	mov    %r14,%rsi
   f12ce:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   f12d6:	e8 a5 b0 05 00       	call   14c380 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f12db:	8b 54 24 08          	mov    0x8(%rsp),%edx
   f12df:	4c 89 f6             	mov    %r14,%rsi
   f12e2:	48 8d bc 24 20 01 00 00 	lea    0x120(%rsp),%rdi
   f12ea:	e8 91 b0 05 00       	call   14c380 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f12ef:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   f12f7:	48 8b 84 24 38 01 00 00 	mov    0x138(%rsp),%rax
   f12ff:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   f1309:	8b 00                	mov    (%rax),%eax
   f130b:	8b 0a                	mov    (%rdx),%ecx
   f130d:	49 83 07 01          	addq   $0x1,(%r15)
   f1311:	89 ca                	mov    %ecx,%edx
   f1313:	39 c8                	cmp    %ecx,%eax
   f1315:	0f 46 d0             	cmovbe %eax,%edx
   f1318:	48 c1 e2 20          	shl    $0x20,%rdx
   f131c:	39 c8                	cmp    %ecx,%eax
   f131e:	0f 42 c1             	cmovb  %ecx,%eax
   f1321:	48 09 c2             	or     %rax,%rdx
   f1324:	48 89 d0             	mov    %rdx,%rax
   f1327:	48 c1 e8 1e          	shr    $0x1e,%rax
   f132b:	48 31 d0             	xor    %rdx,%rax
   f132e:	48 0f af c6          	imul   %rsi,%rax
   f1332:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   f133c:	48 89 c2             	mov    %rax,%rdx
   f133f:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f1343:	48 31 d0             	xor    %rdx,%rax
   f1346:	48 0f af c6          	imul   %rsi,%rax
   f134a:	48 89 c2             	mov    %rax,%rdx
   f134d:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f1351:	48 31 d0             	xor    %rdx,%rax
   f1354:	49 01 47 08          	add    %rax,0x8(%r15)
   f1358:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f1360:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f1364:	0f 84 06 ff ff ff    	je     f1270 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x130>
   f136a:	48 83 c0 01          	add    $0x1,%rax
   f136e:	41 83 c5 01          	add    $0x1,%r13d
   f1372:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f137a:	45 39 e5             	cmp    %r12d,%r13d
   f137d:	0f 82 fa fe ff ff    	jb     f127d <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x13d>
   f1383:	66 90                	xchg   %ax,%ax
   f1385:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1390:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   f1395:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f139d:	49 83 c5 01          	add    $0x1,%r13
   f13a1:	84 c0                	test   %al,%al
   f13a3:	0f 84 97 fe ff ff    	je     f1240 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x100>
   f13a9:	44 8b 64 24 28       	mov    0x28(%rsp),%r12d
   f13ae:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
   f13b3:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
   f13b8:	4c 8b ac 24 90 01 00 00 	mov    0x190(%rsp),%r13
   f13c0:	4c 8b bc 24 a0 01 00 00 	mov    0x1a0(%rsp),%r15
   f13c8:	eb 2d                	jmp    f13f7 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2b7>
   f13ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f13d0:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
   f13d5:	48 8d 94 24 a0 00 00 00 	lea    0xa0(%rsp),%rdx
   f13dd:	4c 89 f7             	mov    %r14,%rdi
   f13e0:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f13e5:	4c 8d 84 24 20 01 00 00 	lea    0x120(%rsp),%r8
   f13ed:	e8 ce db fd ff       	call   cefc0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE9selfPairsIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvjRNS2_12QueryContextINS_11QueryResultEEESC_RSF_>
   f13f2:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f13f7:	66 0f 6f 9c 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm3
   f1400:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f1408:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f1411:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
   f1416:	0f 29 84 24 80 00 00 00 	movaps %xmm0,0x80(%rsp)
   f141e:	84 c0                	test   %al,%al
   f1420:	74 08                	je     f142a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2ea>
   f1422:	3c 0b                	cmp    $0xb,%al
   f1424:	0f 85 32 03 00 00    	jne    f175c <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x61c>
   f142a:	48 8b 9c 24 78 01 00 00 	mov    0x178(%rsp),%rbx
   f1432:	4c 8b b4 24 98 01 00 00 	mov    0x198(%rsp),%r14
   f143a:	48 8b 94 24 80 00 00 00 	mov    0x80(%rsp),%rdx
   f1442:	48 c7 45 18 00 00 00 00 	movq   $0x0,0x18(%rbp)
   f144a:	48 c7 45 28 00 00 00 00 	movq   $0x0,0x28(%rbp)
   f1452:	48 89 55 00          	mov    %rdx,0x0(%rbp)
   f1456:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   f145b:	4c 89 4d 08          	mov    %r9,0x8(%rbp)
   f145f:	48 89 55 10          	mov    %rdx,0x10(%rbp)
   f1463:	31 d2                	xor    %edx,%edx
   f1465:	45 85 e4             	test   %r12d,%r12d
   f1468:	0f 95 c2             	setne  %dl
   f146b:	3c 0b                	cmp    $0xb,%al
   f146d:	89 55 20             	mov    %edx,0x20(%rbp)
   f1470:	0f 94 45 30          	sete   0x30(%rbp)
   f1474:	48 8b 84 24 68 01 00 00 	mov    0x168(%rsp),%rax
   f147c:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f1485:	0f 85 fe 02 00 00    	jne    f1789 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x649>
   f148b:	48 89 e8             	mov    %rbp,%rax
   f148e:	4c 8b a4 24 88 01 00 00 	mov    0x188(%rsp),%r12
   f1496:	48 8b ac 24 80 01 00 00 	mov    0x180(%rsp),%rbp
   f149e:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
   f14a5:	c3                   	ret
   f14a6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f14b0:	89 6c 24 08          	mov    %ebp,0x8(%rsp)
   f14b4:	44 89 ea             	mov    %r13d,%edx
   f14b7:	e9 0f fe ff ff       	jmp    f12cb <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x18b>
   f14bc:	0f 1f 40 00          	nopl   0x0(%rax)
   f14c0:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   f14c5:	31 c0                	xor    %eax,%eax
   f14c7:	e9 6e ff ff ff       	jmp    f143a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2fa>
   f14cc:	49 8d 41 ff          	lea    -0x1(%r9),%rax
   f14d0:	49 0f af c1          	imul   %r9,%rax
   f14d4:	48 d1 e8             	shr    $1,%rax
   f14d7:	48 39 c1             	cmp    %rax,%rcx
   f14da:	0f 82 2c fd ff ff    	jb     f120c <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xcc>
   f14e0:	48 89 d8             	mov    %rbx,%rax
   f14e3:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   f14e8:	48 8b 5b 68          	mov    0x68(%rbx),%rbx
   f14ec:	48 8b 40 58          	mov    0x58(%rax),%rax
   f14f0:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
   f14f5:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
   f14fa:	4c 8d 5b 20          	lea    0x20(%rbx),%r11
   f14fe:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f1503:	4c 8d 68 10          	lea    0x10(%rax),%r13
   f1507:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   f150c:	41 8d 41 ff          	lea    -0x1(%r9),%eax
   f1510:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   f1515:	4c 89 e8             	mov    %r13,%rax
   f1518:	45 31 ed             	xor    %r13d,%r13d
   f151b:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   f1520:	4d 8b 53 e8          	mov    -0x18(%r11),%r10
   f1524:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   f1529:	41 8d 6d 01          	lea    0x1(%r13),%ebp
   f152d:	4c 89 db             	mov    %r11,%rbx
   f1530:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   f1535:	4d 8b 7b e0          	mov    -0x20(%r11),%r15
   f1539:	4d 89 d9             	mov    %r11,%r9
   f153c:	49 89 c6             	mov    %rax,%r14
   f153f:	4d 89 d3             	mov    %r10,%r11
   f1542:	49 89 c5             	mov    %rax,%r13
   f1545:	e9 0a 01 00 00       	jmp    f1654 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x514>
   f154a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1550:	41 8b 36             	mov    (%r14),%esi
   f1553:	41 8b 4d f8          	mov    -0x8(%r13),%ecx
   f1557:	39 ce                	cmp    %ecx,%esi
   f1559:	0f 8d 31 01 00 00    	jge    f1690 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x550>
   f155f:	41 8b 7d f4          	mov    -0xc(%r13),%edi
   f1563:	41 3b 7e 0c          	cmp    0xc(%r14),%edi
   f1567:	0f 8d 2b 01 00 00    	jge    f1698 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x558>
   f156d:	45 8b 45 fc          	mov    -0x4(%r13),%r8d
   f1571:	45 39 46 04          	cmp    %r8d,0x4(%r14)
   f1575:	0f 8d 1d 01 00 00    	jge    f1698 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x558>
   f157b:	41 8b 41 f8          	mov    -0x8(%r9),%eax
   f157f:	39 43 18             	cmp    %eax,0x18(%rbx)
   f1582:	0f 82 c5 01 00 00    	jb     f174d <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x60d>
   f1588:	89 6c 24 08          	mov    %ebp,0x8(%rsp)
   f158c:	8b 54 24 20          	mov    0x20(%rsp),%edx
   f1590:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   f1595:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   f159d:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   f15a2:	4c 89 5c 24 28       	mov    %r11,0x28(%rsp)
   f15a7:	e8 d4 ad 05 00       	call   14c380 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f15ac:	8b 54 24 08          	mov    0x8(%rsp),%edx
   f15b0:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   f15b5:	48 8d bc 24 20 01 00 00 	lea    0x120(%rsp),%rdi
   f15bd:	e8 be ad 05 00       	call   14c380 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f15c2:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   f15c7:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
   f15cc:	48 bf b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdi
   f15d6:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   f15de:	48 8b 84 24 38 01 00 00 	mov    0x138(%rsp),%rax
   f15e6:	4c 8b 5c 24 28       	mov    0x28(%rsp),%r11
   f15eb:	8b 00                	mov    (%rax),%eax
   f15ed:	8b 0a                	mov    (%rdx),%ecx
   f15ef:	48 83 06 01          	addq   $0x1,(%rsi)
   f15f3:	89 ca                	mov    %ecx,%edx
   f15f5:	39 c8                	cmp    %ecx,%eax
   f15f7:	0f 46 d0             	cmovbe %eax,%edx
   f15fa:	48 c1 e2 20          	shl    $0x20,%rdx
   f15fe:	39 c8                	cmp    %ecx,%eax
   f1600:	0f 42 c1             	cmovb  %ecx,%eax
   f1603:	48 09 c2             	or     %rax,%rdx
   f1606:	48 89 d0             	mov    %rdx,%rax
   f1609:	48 c1 e8 1e          	shr    $0x1e,%rax
   f160d:	48 31 d0             	xor    %rdx,%rax
   f1610:	48 0f af c7          	imul   %rdi,%rax
   f1614:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   f161e:	48 89 c2             	mov    %rax,%rdx
   f1621:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f1625:	48 31 d0             	xor    %rdx,%rax
   f1628:	48 0f af c7          	imul   %rdi,%rax
   f162c:	48 89 c2             	mov    %rax,%rdx
   f162f:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f1633:	48 31 d0             	xor    %rdx,%rax
   f1636:	48 01 46 08          	add    %rax,0x8(%rsi)
   f163a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1640:	83 c5 01             	add    $0x1,%ebp
   f1643:	48 83 c3 20          	add    $0x20,%rbx
   f1647:	49 83 c6 10          	add    $0x10,%r14
   f164b:	44 39 e5             	cmp    %r12d,%ebp
   f164e:	0f 83 ac 00 00 00    	jae    f1700 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f1654:	4c 85 7b 08          	test   %r15,0x8(%rbx)
   f1658:	74 e6                	je     f1640 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f165a:	4c 85 1b             	test   %r11,(%rbx)
   f165d:	74 e1                	je     f1640 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f165f:	41 8b 45 f0          	mov    -0x10(%r13),%eax
   f1663:	41 8b 56 08          	mov    0x8(%r14),%edx
   f1667:	48 83 84 24 80 00 00 00 01 	addq   $0x1,0x80(%rsp)
   f1670:	39 d0                	cmp    %edx,%eax
   f1672:	0f 8c d8 fe ff ff    	jl     f1550 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f1678:	75 c6                	jne    f1640 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f167a:	41 8b 36             	mov    (%r14),%esi
   f167d:	41 8b 4d f8          	mov    -0x8(%r13),%ecx
   f1681:	0f 1f 40 00          	nopl   0x0(%rax)
   f1685:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1690:	39 f1                	cmp    %esi,%ecx
   f1692:	7c ac                	jl     f1640 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f1694:	41 8b 7d f4          	mov    -0xc(%r13),%edi
   f1698:	45 8b 46 0c          	mov    0xc(%r14),%r8d
   f169c:	44 89 44 24 08       	mov    %r8d,0x8(%rsp)
   f16a1:	44 39 c7             	cmp    %r8d,%edi
   f16a4:	7f 9a                	jg     f1640 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f16a6:	45 8b 56 04          	mov    0x4(%r14),%r10d
   f16aa:	45 8b 45 fc          	mov    -0x4(%r13),%r8d
   f16ae:	44 89 54 24 28       	mov    %r10d,0x28(%rsp)
   f16b3:	45 39 c2             	cmp    %r8d,%r10d
   f16b6:	7f 88                	jg     f1640 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f16b8:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   f16bd:	41 80 7a 21 01       	cmpb   $0x1,0x21(%r10)
   f16c2:	41 0f 95 c2          	setne  %r10b
   f16c6:	44 39 c7             	cmp    %r8d,%edi
   f16c9:	40 0f 95 c7          	setne  %dil
   f16cd:	41 21 fa             	and    %edi,%r10d
   f16d0:	8b 7c 24 28          	mov    0x28(%rsp),%edi
   f16d4:	39 7c 24 08          	cmp    %edi,0x8(%rsp)
   f16d8:	40 0f 95 c7          	setne  %dil
   f16dc:	44 21 d7             	and    %r10d,%edi
   f16df:	39 c1                	cmp    %eax,%ecx
   f16e1:	0f 95 c0             	setne  %al
   f16e4:	40 84 c7             	test   %al,%dil
   f16e7:	0f 84 8e fe ff ff    	je     f157b <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x43b>
   f16ed:	39 d6                	cmp    %edx,%esi
   f16ef:	0f 84 86 fe ff ff    	je     f157b <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x43b>
   f16f5:	e9 46 ff ff ff       	jmp    f1640 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f16fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1700:	49 8d 45 10          	lea    0x10(%r13),%rax
   f1704:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
   f1709:	4d 8d 59 20          	lea    0x20(%r9),%r11
   f170d:	49 83 c5 01          	add    $0x1,%r13
   f1711:	4c 39 6c 24 38       	cmp    %r13,0x38(%rsp)
   f1716:	0f 85 04 fe ff ff    	jne    f1520 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f171c:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
   f1721:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
   f1726:	31 c0                	xor    %eax,%eax
   f1728:	48 8b 9c 24 78 01 00 00 	mov    0x178(%rsp),%rbx
   f1730:	4c 8b ac 24 90 01 00 00 	mov    0x190(%rsp),%r13
   f1738:	4c 8b b4 24 98 01 00 00 	mov    0x198(%rsp),%r14
   f1740:	4c 8b bc 24 a0 01 00 00 	mov    0x1a0(%rsp),%r15
   f1748:	e9 ed fc ff ff       	jmp    f143a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2fa>
   f174d:	8b 44 24 20          	mov    0x20(%rsp),%eax
   f1751:	89 ea                	mov    %ebp,%edx
   f1753:	89 44 24 08          	mov    %eax,0x8(%rsp)
   f1757:	e9 34 fe ff ff       	jmp    f1590 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x450>
   f175c:	48 8b 3d fd 2a 08 00 	mov    0x82afd(%rip),%rdi        # 174260 <stderr@GLIBC_2.2.5>
   f1763:	0f b6 d0             	movzbl %al,%edx
   f1766:	48 8d 35 33 a2 06 00 	lea    0x6a233(%rip),%rsi        # 15b9a0 <_IO_stdin_used+0x19a0>
   f176d:	31 c0                	xor    %eax,%eax
   f176f:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   f1777:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   f177f:	e8 bc 5b f1 ff       	call   7340 <fprintf@plt>
   f1784:	e8 97 59 f1 ff       	call   7120 <abort@plt>
   f1789:	48 89 9c 24 78 01 00 00 	mov    %rbx,0x178(%rsp)
   f1791:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   f1799:	4c 89 b4 24 98 01 00 00 	mov    %r14,0x198(%rsp)
   f17a1:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   f17a9:	e8 b2 5a f1 ff       	call   7260 <__stack_chk_fail@plt>

# candidate ordered_pairs bench::Counters bench::LibraryIndex<int, true>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-layout.0xp7gI/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f4c80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f4c80:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
   f4c87:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f4c8b:	48 89 9c 24 c8 01 00 00 	mov    %rbx,0x1c8(%rsp)
   f4c93:	48 89 fb             	mov    %rdi,%rbx
   f4c96:	4c 89 bc 24 f0 01 00 00 	mov    %r15,0x1f0(%rsp)
   f4c9e:	49 89 f7             	mov    %rsi,%r15
   f4ca1:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   f4ca6:	8b 96 d0 00 00 00    	mov    0xd0(%rsi),%edx
   f4cac:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
   f4cb3:	64 48 8b 3c 25 28 00 00 00 	mov    %fs:0x28,%rdi
   f4cbc:	48 89 bc 24 b8 01 00 00 	mov    %rdi,0x1b8(%rsp)
   f4cc4:	31 ff                	xor    %edi,%edi
   f4cc6:	83 fa 01             	cmp    $0x1,%edx
   f4cc9:	0f 86 01 03 00 00    	jbe    f4fd0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x350>
   f4ccf:	48 39 f2             	cmp    %rsi,%rdx
   f4cd2:	74 44                	je     f4d18 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x98>
   f4cd4:	ba 07 00 00 00       	mov    $0x7,%edx
   f4cd9:	48 8b 3d 80 f5 07 00 	mov    0x7f580(%rip),%rdi        # 174260 <stderr@GLIBC_2.2.5>
   f4ce0:	48 8d 35 b9 6c 06 00 	lea    0x66cb9(%rip),%rsi        # 15b9a0 <_IO_stdin_used+0x19a0>
   f4ce7:	31 c0                	xor    %eax,%eax
   f4ce9:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f4cf1:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f4cf9:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f4d01:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f4d09:	e8 32 26 f1 ff       	call   7340 <fprintf@plt>
   f4d0e:	e8 0d 24 f1 ff       	call   7120 <abort@plt>
   f4d13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f4d18:	49 89 c8             	mov    %rcx,%r8
   f4d1b:	0f 11 84 24 98 00 00 00 	movups %xmm0,0x98(%rsp)
   f4d23:	49 8b 47 50          	mov    0x50(%r15),%rax
   f4d27:	89 d1                	mov    %edx,%ecx
   f4d29:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f4d31:	66 49 0f 6e d0       	movq   %r8,%xmm2
   f4d36:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   f4d3b:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
   f4d3f:	c6 84 24 90 00 00 00 00 	movb   $0x0,0x90(%rsp)
   f4d47:	48 c7 84 24 c8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xc8(%rsp)
   f4d53:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f4d5b:	48 85 c0             	test   %rax,%rax
   f4d5e:	0f 84 c6 08 00 00    	je     f562a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9aa>
   f4d64:	48 89 84 24 d0 00 00 00 	mov    %rax,0xd0(%rsp)
   f4d6c:	48 89 84 24 d8 00 00 00 	mov    %rax,0xd8(%rsp)
   f4d74:	48 c7 84 24 e0 00 00 00 00 00 00 00 	movq   $0x0,0xe0(%rsp)
   f4d80:	48 c7 84 24 e8 00 00 00 00 00 00 00 	movq   $0x0,0xe8(%rsp)
   f4d8c:	48 89 84 24 f0 00 00 00 	mov    %rax,0xf0(%rsp)
   f4d94:	48 c7 84 24 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rsp)
   f4da0:	48 c7 84 24 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rsp)
   f4dac:	48 89 84 24 08 01 00 00 	mov    %rax,0x108(%rsp)
   f4db4:	48 c7 84 24 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rsp)
   f4dc0:	48 c7 84 24 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rsp)
   f4dcc:	48 89 84 24 20 01 00 00 	mov    %rax,0x120(%rsp)
   f4dd4:	48 c7 84 24 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rsp)
   f4de0:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f4dec:	48 89 84 24 38 01 00 00 	mov    %rax,0x138(%rsp)
   f4df4:	48 c7 84 24 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rsp)
   f4e00:	48 c7 84 24 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rsp)
   f4e0c:	48 89 84 24 50 01 00 00 	mov    %rax,0x150(%rsp)
   f4e14:	48 c7 84 24 58 01 00 00 00 00 00 00 	movq   $0x0,0x158(%rsp)
   f4e20:	48 c7 84 24 60 01 00 00 00 00 00 00 	movq   $0x0,0x160(%rsp)
   f4e2c:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f4e34:	48 c7 84 24 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rsp)
   f4e40:	48 c7 84 24 78 01 00 00 00 00 00 00 	movq   $0x0,0x178(%rsp)
   f4e4c:	48 89 84 24 80 01 00 00 	mov    %rax,0x180(%rsp)
   f4e54:	48 c7 84 24 88 01 00 00 00 00 00 00 	movq   $0x0,0x188(%rsp)
   f4e60:	48 c7 84 24 90 01 00 00 00 00 00 00 	movq   $0x0,0x190(%rsp)
   f4e6c:	48 89 84 24 98 01 00 00 	mov    %rax,0x198(%rsp)
   f4e74:	48 c7 84 24 a0 01 00 00 00 00 00 00 	movq   $0x0,0x1a0(%rsp)
   f4e80:	48 c7 84 24 a8 01 00 00 00 00 00 00 	movq   $0x0,0x1a8(%rsp)
   f4e8c:	c7 84 24 b0 01 00 00 00 00 00 00 	movl   $0x0,0x1b0(%rsp)
   f4e97:	c6 84 24 b4 01 00 00 00 	movb   $0x0,0x1b4(%rsp)
   f4e9f:	49 39 b7 a0 01 00 00 	cmp    %rsi,0x1a0(%r15)
   f4ea6:	0f 82 b4 01 00 00    	jb     f5060 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f4eac:	49 39 b7 b8 01 00 00 	cmp    %rsi,0x1b8(%r15)
   f4eb3:	0f 82 a7 01 00 00    	jb     f5060 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f4eb9:	41 80 bf 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r15)
   f4ec1:	0f 85 aa 07 00 00    	jne    f5671 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9f1>
   f4ec7:	49 8d 47 08          	lea    0x8(%r15),%rax
   f4ecb:	4d 8b 9f 98 01 00 00 	mov    0x198(%r15),%r11
   f4ed2:	c6 44 24 43 00       	movb   $0x0,0x43(%rsp)
   f4ed7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   f4edc:	49 8d 87 88 01 00 00 	lea    0x188(%r15),%rax
   f4ee3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f4ee8:	41 c6 87 6c 02 00 00 01 	movb   $0x1,0x26c(%r15)
   f4ef0:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
   f4ef5:	85 c9                	test   %ecx,%ecx
   f4ef7:	0f 84 7a 01 00 00    	je     f5077 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f4efd:	8d 41 ff             	lea    -0x1(%rcx),%eax
   f4f00:	83 f8 02             	cmp    $0x2,%eax
   f4f03:	0f 86 3c 07 00 00    	jbe    f5645 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9c5>
   f4f09:	89 cf                	mov    %ecx,%edi
   f4f0b:	4c 89 d8             	mov    %r11,%rax
   f4f0e:	66 0f 6f 05 7a 89 06 00 	movdqa 0x6897a(%rip),%xmm0        # 15d890 <C.66.5+0x270>
   f4f16:	c1 ef 02             	shr    $0x2,%edi
   f4f19:	89 fa                	mov    %edi,%edx
   f4f1b:	48 c1 e2 04          	shl    $0x4,%rdx
   f4f1f:	4c 01 da             	add    %r11,%rdx
   f4f22:	41 bb 04 00 00 00    	mov    $0x4,%r11d
   f4f28:	66 41 0f 6e cb       	movd   %r11d,%xmm1
   f4f2d:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   f4f32:	0f 1f 00             	nopl   (%rax)
   f4f35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f4f40:	0f 11 00             	movups %xmm0,(%rax)
   f4f43:	48 83 c0 10          	add    $0x10,%rax
   f4f47:	66 0f fe c1          	paddd  %xmm1,%xmm0
   f4f4b:	48 39 d0             	cmp    %rdx,%rax
   f4f4e:	75 f0                	jne    f4f40 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2c0>
   f4f50:	8d 04 bd 00 00 00 00 	lea    0x0(,%rdi,4),%eax
   f4f57:	39 c8                	cmp    %ecx,%eax
   f4f59:	74 25                	je     f4f80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f4f5b:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
   f4f60:	89 c2                	mov    %eax,%edx
   f4f62:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f4f66:	8d 50 01             	lea    0x1(%rax),%edx
   f4f69:	39 ca                	cmp    %ecx,%edx
   f4f6b:	73 13                	jae    f4f80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f4f6d:	89 d7                	mov    %edx,%edi
   f4f6f:	83 c0 02             	add    $0x2,%eax
   f4f72:	41 89 14 bb          	mov    %edx,(%r11,%rdi,4)
   f4f76:	39 c8                	cmp    %ecx,%eax
   f4f78:	73 06                	jae    f4f80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f4f7a:	89 c2                	mov    %eax,%edx
   f4f7c:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f4f80:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
   f4f87:	0f 86 ea 00 00 00    	jbe    f5077 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f4f8d:	49 39 b7 48 02 00 00 	cmp    %rsi,0x248(%r15)
   f4f94:	0f 82 e7 00 00 00    	jb     f5081 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f4f9a:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f4fa4:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f4fab:	48 c1 ea 04          	shr    $0x4,%rdx
   f4faf:	48 39 f2             	cmp    %rsi,%rdx
   f4fb2:	0f 82 c9 00 00 00    	jb     f5081 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f4fb8:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f4fbc:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   f4fc1:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f4fc6:	e8 f5 e1 f1 ff       	call   131c0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f4fcb:	e9 db 00 00 00       	jmp    f50ab <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x42b>
   f4fd0:	48 39 f2             	cmp    %rsi,%rdx
   f4fd3:	0f 85 fb fc ff ff    	jne    f4cd4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54>
   f4fd9:	48 89 d0             	mov    %rdx,%rax
   f4fdc:	0f 11 84 24 d8 00 00 00 	movups %xmm0,0xd8(%rsp)
   f4fe4:	31 d2                	xor    %edx,%edx
   f4fe6:	48 8b 8c 24 e0 00 00 00 	mov    0xe0(%rsp),%rcx
   f4fee:	85 c0                	test   %eax,%eax
   f4ff0:	89 c7                	mov    %eax,%edi
   f4ff2:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   f4ffa:	0f 95 c0             	setne  %al
   f4ffd:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   f5005:	80 fa 0b             	cmp    $0xb,%dl
   f5008:	48 89 0b             	mov    %rcx,(%rbx)
   f500b:	48 8b 8c 24 d8 00 00 00 	mov    0xd8(%rsp),%rcx
   f5013:	0f b6 c0             	movzbl %al,%eax
   f5016:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
   f501a:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   f501e:	89 43 20             	mov    %eax,0x20(%rbx)
   f5021:	0f 94 43 30          	sete   0x30(%rbx)
   f5025:	48 8b 84 24 b8 01 00 00 	mov    0x1b8(%rsp),%rax
   f502d:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f5036:	0f 85 10 06 00 00    	jne    f564c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9cc>
   f503c:	48 89 d8             	mov    %rbx,%rax
   f503f:	4c 8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%r15
   f5047:	48 8b 9c 24 c8 01 00 00 	mov    0x1c8(%rsp),%rbx
   f504f:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
   f5056:	c3                   	ret
   f5057:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   f5060:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f5068:	e8 d3 c9 00 00       	call   101a40 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f506d:	ba 05 00 00 00       	mov    $0x5,%edx
   f5072:	e9 62 fc ff ff       	jmp    f4cd9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f5077:	48 83 fe 01          	cmp    $0x1,%rsi
   f507b:	0f 86 bd 05 00 00    	jbe    f563e <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9be>
   f5081:	48 89 f0             	mov    %rsi,%rax
   f5084:	31 c9                	xor    %ecx,%ecx
   f5086:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f5090:	48 d1 e8             	shr    $1,%rax
   f5093:	83 c1 02             	add    $0x2,%ecx
   f5096:	48 83 f8 01          	cmp    $0x1,%rax
   f509a:	75 f4                	jne    f5090 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f509c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f50a1:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f50a6:	e8 55 eb 05 00       	call   153c00 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f50ab:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f50b2:	83 fa 01             	cmp    $0x1,%edx
   f50b5:	0f 86 2a 03 00 00    	jbe    f53e5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f50bb:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f50c3:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f50cb:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f50d3:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f50db:	48 c7 44 24 08 01 00 00 00 	movq   $0x1,0x8(%rsp)
   f50e4:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   f50e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f50f0:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f50f8:	84 c0                	test   %al,%al
   f50fa:	0f 85 c0 02 00 00    	jne    f53c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f5100:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   f5105:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f510a:	48 8d 4c 24 43       	lea    0x43(%rsp),%rcx
   f510f:	4c 8d ac 24 90 00 00 00 	lea    0x90(%rsp),%r13
   f5117:	8b 7c 9f fc          	mov    -0x4(%rdi,%rbx,4),%edi
   f511b:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   f5120:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   f5125:	48 8d 4c 24 42       	lea    0x42(%rsp),%rcx
   f512a:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   f512f:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   f5134:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   f5139:	48 8d 5c 24 44       	lea    0x44(%rsp),%rbx
   f513e:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   f5143:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
   f5148:	48 89 8c 24 80 00 00 00 	mov    %rcx,0x80(%rsp)
   f5150:	41 8b 8f 64 01 00 00 	mov    0x164(%r15),%ecx
   f5157:	89 7c 24 44          	mov    %edi,0x44(%rsp)
   f515b:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
   f5164:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
   f5169:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   f516e:	83 f9 ff             	cmp    $0xffffffff,%ecx
   f5171:	0f 84 d9 02 00 00    	je     f5450 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7d0>
   f5177:	89 ce                	mov    %ecx,%esi
   f5179:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   f517d:	49 03 b7 f8 00 00 00 	add    0xf8(%r15),%rsi
   f5184:	44 8b 46 64          	mov    0x64(%rsi),%r8d
   f5188:	45 85 c0             	test   %r8d,%r8d
   f518b:	0f 84 ff 01 00 00    	je     f5390 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f5191:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f5199:	48 85 c0             	test   %rax,%rax
   f519c:	0f 84 56 04 00 00    	je     f55f8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x978>
   f51a2:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f51a6:	74 0c                	je     f51b4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x534>
   f51a8:	48 83 e8 01          	sub    $0x1,%rax
   f51ac:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f51b4:	48 8b 84 24 98 00 00 00 	mov    0x98(%rsp),%rax
   f51bc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f51c0:	74 0c                	je     f51ce <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54e>
   f51c2:	48 83 c0 01          	add    $0x1,%rax
   f51c6:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f51ce:	48 89 fa             	mov    %rdi,%rdx
   f51d1:	8b 46 1c             	mov    0x1c(%rsi),%eax
   f51d4:	48 c1 e2 04          	shl    $0x4,%rdx
   f51d8:	49 03 57 58          	add    0x58(%r15),%rdx
   f51dc:	39 02                	cmp    %eax,(%rdx)
   f51de:	0f 8f ac 01 00 00    	jg     f5390 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f51e4:	8b 42 08             	mov    0x8(%rdx),%eax
   f51e7:	39 46 14             	cmp    %eax,0x14(%rsi)
   f51ea:	0f 8f a0 01 00 00    	jg     f5390 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f51f0:	8b 46 20             	mov    0x20(%rsi),%eax
   f51f3:	39 42 04             	cmp    %eax,0x4(%rdx)
   f51f6:	0f 8f 94 01 00 00    	jg     f5390 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f51fc:	8b 42 0c             	mov    0xc(%rdx),%eax
   f51ff:	39 46 18             	cmp    %eax,0x18(%rsi)
   f5202:	0f 8f 88 01 00 00    	jg     f5390 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f5208:	49 8b 47 68          	mov    0x68(%r15),%rax
   f520c:	48 c1 e7 05          	shl    $0x5,%rdi
   f5210:	48 83 ec 08          	sub    $0x8,%rsp
   f5214:	4d 89 e9             	mov    %r13,%r9
   f5217:	48 01 f8             	add    %rdi,%rax
   f521a:	48 8b 08             	mov    (%rax),%rcx
   f521d:	4c 8b 40 08          	mov    0x8(%rax),%r8
   f5221:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   f5226:	50                   	push   %rax
   f5227:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f522c:	e8 0f a2 f2 ff       	call   1f440 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE11walkOrderedIZNKS2_11orderedSelfIZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS5_8CountersERT_mEUlRKSC_RKT0_E_NS_6detail9AcceptAllEEEvRNS_9WorkspaceIiEEbRNS2_12QueryContextINS_11QueryResultEEESD_RSG_EUljE_EEvRKNS2_4NodeERKNS_3BoxIiEENS_6FilterESS_SD_>
   f5231:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f5239:	5a                   	pop    %rdx
   f523a:	59                   	pop    %rcx
   f523b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f5240:	84 c0                	test   %al,%al
   f5242:	0f 85 78 01 00 00    	jne    f53c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f5248:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f524d:	49 8b 9f b0 01 00 00 	mov    0x1b0(%r15),%rbx
   f5254:	48 83 fd 7f          	cmp    $0x7f,%rbp
   f5258:	0f 86 5b 03 00 00    	jbe    f55b9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x939>
   f525e:	49 39 af 48 02 00 00 	cmp    %rbp,0x248(%r15)
   f5265:	0f 82 58 03 00 00    	jb     f55c3 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f526b:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f5275:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f527c:	48 c1 ea 04          	shr    $0x4,%rdx
   f5280:	48 39 ea             	cmp    %rbp,%rdx
   f5283:	0f 82 3a 03 00 00    	jb     f55c3 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f5289:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f528d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f5292:	89 e9                	mov    %ebp,%ecx
   f5294:	48 89 da             	mov    %rbx,%rdx
   f5297:	e8 24 df f1 ff       	call   131c0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f529c:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f52a1:	48 85 ed             	test   %rbp,%rbp
   f52a4:	0f 84 fb 00 00 00    	je     f53a5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f52aa:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
   f52af:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   f52b4:	31 c9                	xor    %ecx,%ecx
   f52b6:	4d 8b 5f 68          	mov    0x68(%r15),%r11
   f52ba:	4d 8b 4f 60          	mov    0x60(%r15),%r9
   f52be:	4c 89 c2             	mov    %r8,%rdx
   f52c1:	48 8b 07             	mov    (%rdi),%rax
   f52c4:	4c 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%r10
   f52cc:	48 c1 e2 05          	shl    $0x5,%rdx
   f52d0:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
   f52d4:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   f52d9:	4d 8d 34 13          	lea    (%r11,%rdx,1),%r14
   f52dd:	4c 8d 68 01          	lea    0x1(%rax),%r13
   f52e1:	8b 14 8b             	mov    (%rbx,%rcx,4),%edx
   f52e4:	49 8b 76 10          	mov    0x10(%r14),%rsi
   f52e8:	4d 8d 64 0d 00       	lea    0x0(%r13,%rcx,1),%r12
   f52ed:	48 89 d0             	mov    %rdx,%rax
   f52f0:	48 c1 e0 05          	shl    $0x5,%rax
   f52f4:	49 39 74 03 10       	cmp    %rsi,0x10(%r11,%rax,1)
   f52f9:	48 89 d0             	mov    %rdx,%rax
   f52fc:	49 0f 42 c0          	cmovb  %r8,%rax
   f5300:	49 0f 43 d0          	cmovae %r8,%rdx
   f5304:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f5308:	41 8b 34 91          	mov    (%r9,%rdx,4),%esi
   f530c:	39 f0                	cmp    %esi,%eax
   f530e:	89 f2                	mov    %esi,%edx
   f5310:	0f 46 d0             	cmovbe %eax,%edx
   f5313:	48 c1 e2 20          	shl    $0x20,%rdx
   f5317:	39 f0                	cmp    %esi,%eax
   f5319:	0f 42 c6             	cmovb  %esi,%eax
   f531c:	48 09 d0             	or     %rdx,%rax
   f531f:	48 89 c2             	mov    %rax,%rdx
   f5322:	48 c1 ea 1e          	shr    $0x1e,%rdx
   f5326:	48 31 c2             	xor    %rax,%rdx
   f5329:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   f5333:	48 0f af d0          	imul   %rax,%rdx
   f5337:	48 89 d0             	mov    %rdx,%rax
   f533a:	48 c1 e8 1b          	shr    $0x1b,%rax
   f533e:	48 31 c2             	xor    %rax,%rdx
   f5341:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f534b:	48 0f af d0          	imul   %rax,%rdx
   f534f:	48 89 d0             	mov    %rdx,%rax
   f5352:	48 c1 e8 1f          	shr    $0x1f,%rax
   f5356:	48 31 c2             	xor    %rax,%rdx
   f5359:	48 01 d7             	add    %rdx,%rdi
   f535c:	49 83 fa ff          	cmp    $0xffffffffffffffff,%r10
   f5360:	0f 84 82 01 00 00    	je     f54e8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x868>
   f5366:	49 83 c2 01          	add    $0x1,%r10
   f536a:	48 83 c1 01          	add    $0x1,%rcx
   f536e:	4c 89 94 24 b8 00 00 00 	mov    %r10,0xb8(%rsp)
   f5376:	48 39 cd             	cmp    %rcx,%rbp
   f5379:	0f 85 62 ff ff ff    	jne    f52e1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x661>
   f537f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f5384:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f5388:	4c 89 20             	mov    %r12,(%rax)
   f538b:	eb 18                	jmp    f53a5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f538d:	0f 1f 00             	nopl   (%rax)
   f5390:	49 8b bf b0 01 00 00 	mov    0x1b0(%r15),%rdi
   f5397:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f539c:	31 c9                	xor    %ecx,%ecx
   f539e:	31 f6                	xor    %esi,%esi
   f53a0:	e8 5b e8 05 00       	call   153c00 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f53a5:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f53ac:	48 83 44 24 08 01    	addq   $0x1,0x8(%rsp)
   f53b2:	48 89 c2             	mov    %rax,%rdx
   f53b5:	48 39 44 24 08       	cmp    %rax,0x8(%rsp)
   f53ba:	0f 82 30 fd ff ff    	jb     f50f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x470>
   f53c0:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f53c5:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f53cd:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f53d5:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f53dd:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f53e5:	41 c6 87 6c 02 00 00 00 	movb   $0x0,0x26c(%r15)
   f53ed:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f53f5:	e8 46 c6 00 00       	call   101a40 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f53fa:	0f b6 94 24 90 00 00 00 	movzbl 0x90(%rsp),%edx
   f5402:	66 0f 6f 84 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm0
   f540b:	66 0f 6f 9c 24 90 00 00 00 	movdqa 0x90(%rsp),%xmm3
   f5414:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f541c:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f5425:	0f 29 9c 24 d0 00 00 00 	movaps %xmm3,0xd0(%rsp)
   f542d:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f5435:	80 fa 0b             	cmp    $0xb,%dl
   f5438:	74 08                	je     f5442 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7c2>
   f543a:	84 d2                	test   %dl,%dl
   f543c:	0f 85 97 f8 ff ff    	jne    f4cd9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f5442:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f5449:	e9 98 fb ff ff       	jmp    f4fe6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x366>
   f544e:	66 90                	xchg   %ax,%ax
   f5450:	49 8b 6f 68          	mov    0x68(%r15),%rbp
   f5454:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
   f5459:	31 db                	xor    %ebx,%ebx
   f545b:	eb 49                	jmp    f54a6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x826>
   f545d:	0f 1f 00             	nopl   (%rax)
   f5460:	4c 89 e9             	mov    %r13,%rcx
   f5463:	44 89 f2             	mov    %r14d,%edx
   f5466:	4c 89 e7             	mov    %r12,%rdi
   f5469:	e8 92 d2 f1 ff       	call   12700 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_12QueryContextINS_11QueryResultEEERT0_.isra.0>
   f546e:	84 c0                	test   %al,%al
   f5470:	74 19                	je     f548b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x80b>
   f5472:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   f5477:	48 8d 50 01          	lea    0x1(%rax),%rdx
   f547b:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f5480:	49 8b 97 b0 01 00 00 	mov    0x1b0(%r15),%rdx
   f5487:	44 89 34 82          	mov    %r14d,(%rdx,%rax,4)
   f548b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f5492:	48 83 c3 01          	add    $0x1,%rbx
   f5496:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f549e:	39 d3                	cmp    %edx,%ebx
   f54a0:	0f 83 9a fd ff ff    	jae    f5240 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f54a6:	84 c0                	test   %al,%al
   f54a8:	0f 85 12 ff ff ff    	jne    f53c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f54ae:	8b 44 24 44          	mov    0x44(%rsp),%eax
   f54b2:	41 89 de             	mov    %ebx,%r14d
   f54b5:	48 89 c6             	mov    %rax,%rsi
   f54b8:	48 c1 e0 05          	shl    $0x5,%rax
   f54bc:	48 01 e8             	add    %rbp,%rax
   f54bf:	48 89 d9             	mov    %rbx,%rcx
   f54c2:	48 c1 e1 05          	shl    $0x5,%rcx
   f54c6:	48 8b 7c 0d 10       	mov    0x10(%rbp,%rcx,1),%rdi
   f54cb:	48 39 78 10          	cmp    %rdi,0x10(%rax)
   f54cf:	72 8f                	jb     f5460 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e0>
   f54d1:	48 83 c3 01          	add    $0x1,%rbx
   f54d5:	39 d3                	cmp    %edx,%ebx
   f54d7:	0f 83 6b fd ff ff    	jae    f5248 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c8>
   f54dd:	41 89 de             	mov    %ebx,%r14d
   f54e0:	eb dd                	jmp    f54bf <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x83f>
   f54e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f54e8:	4c 8d 69 01          	lea    0x1(%rcx),%r13
   f54ec:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   f54f1:	4c 39 ed             	cmp    %r13,%rbp
   f54f4:	0f 84 85 fe ff ff    	je     f537f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x6ff>
   f54fa:	4d 8b 74 13 10       	mov    0x10(%r11,%rdx,1),%r14
   f54ff:	4c 89 ee             	mov    %r13,%rsi
   f5502:	0f 1f 00             	nopl   (%rax)
   f5505:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f5510:	8b 04 b3             	mov    (%rbx,%rsi,4),%eax
   f5513:	48 89 c2             	mov    %rax,%rdx
   f5516:	48 c1 e2 05          	shl    $0x5,%rdx
   f551a:	4d 39 74 13 10       	cmp    %r14,0x10(%r11,%rdx,1)
   f551f:	48 89 c2             	mov    %rax,%rdx
   f5522:	49 0f 42 d0          	cmovb  %r8,%rdx
   f5526:	49 0f 43 c0          	cmovae %r8,%rax
   f552a:	45 8b 14 91          	mov    (%r9,%rdx,4),%r10d
   f552e:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f5532:	44 89 d2             	mov    %r10d,%edx
   f5535:	44 39 d0             	cmp    %r10d,%eax
   f5538:	0f 46 d0             	cmovbe %eax,%edx
   f553b:	48 c1 e2 20          	shl    $0x20,%rdx
   f553f:	44 39 d0             	cmp    %r10d,%eax
   f5542:	41 0f 42 c2          	cmovb  %r10d,%eax
   f5546:	48 83 c6 01          	add    $0x1,%rsi
   f554a:	48 09 c2             	or     %rax,%rdx
   f554d:	48 89 d0             	mov    %rdx,%rax
   f5550:	48 c1 e8 1e          	shr    $0x1e,%rax
   f5554:	48 31 d0             	xor    %rdx,%rax
   f5557:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f5561:	48 0f af c2          	imul   %rdx,%rax
   f5565:	48 89 c2             	mov    %rax,%rdx
   f5568:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f556c:	48 31 c2             	xor    %rax,%rdx
   f556f:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f5579:	48 0f af d0          	imul   %rax,%rdx
   f557d:	48 89 d0             	mov    %rdx,%rax
   f5580:	48 c1 e8 1f          	shr    $0x1f,%rax
   f5584:	48 31 d0             	xor    %rdx,%rax
   f5587:	48 01 c7             	add    %rax,%rdi
   f558a:	48 39 ee             	cmp    %rbp,%rsi
   f558d:	72 81                	jb     f5510 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x890>
   f558f:	48 8d 45 ff          	lea    -0x1(%rbp),%rax
   f5593:	48 83 c1 02          	add    $0x2,%rcx
   f5597:	31 d2                	xor    %edx,%edx
   f5599:	4c 29 e8             	sub    %r13,%rax
   f559c:	48 39 cd             	cmp    %rcx,%rbp
   f559f:	48 0f 42 c2          	cmovb  %rdx,%rax
   f55a3:	4d 8d 64 04 01       	lea    0x1(%r12,%rax,1),%r12
   f55a8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f55ad:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f55b1:	4c 89 20             	mov    %r12,(%rax)
   f55b4:	e9 ec fd ff ff       	jmp    f53a5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f55b9:	48 83 fd 01          	cmp    $0x1,%rbp
   f55bd:	0f 86 d3 00 00 00    	jbe    f5696 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa16>
   f55c3:	48 89 e8             	mov    %rbp,%rax
   f55c6:	31 c9                	xor    %ecx,%ecx
   f55c8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f55d0:	48 d1 e8             	shr    $1,%rax
   f55d3:	83 c1 02             	add    $0x2,%ecx
   f55d6:	48 83 f8 01          	cmp    $0x1,%rax
   f55da:	75 f4                	jne    f55d0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x950>
   f55dc:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f55e1:	48 89 ee             	mov    %rbp,%rsi
   f55e4:	48 89 df             	mov    %rbx,%rdi
   f55e7:	e8 14 e6 05 00       	call   153c00 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f55ec:	e9 b0 fc ff ff       	jmp    f52a1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x621>
   f55f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f55f8:	c6 84 24 90 00 00 00 0b 	movb   $0xb,0x90(%rsp)
   f5600:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f5605:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f560d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f5615:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f561d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f5625:	e9 bb fd ff ff       	jmp    f53e5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f562a:	e8 51 4c 00 00       	call   fa280 <_ZN8QuadTree15defaultResourceEv>
   f562f:	41 8b b7 d0 00 00 00 	mov    0xd0(%r15),%esi
   f5636:	48 89 f1             	mov    %rsi,%rcx
   f5639:	e9 26 f7 ff ff       	jmp    f4d64 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xe4>
   f563e:	31 c9                	xor    %ecx,%ecx
   f5640:	e9 57 fa ff ff       	jmp    f509c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x41c>
   f5645:	31 c0                	xor    %eax,%eax
   f5647:	e9 0f f9 ff ff       	jmp    f4f5b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2db>
   f564c:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f5654:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f565c:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f5664:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f566c:	e8 ef 1b f1 ff       	call   7260 <__stack_chk_fail@plt>
   f5671:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f5679:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f5681:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f5689:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f5691:	e8 aa 52 00 00       	call   fa940 <_ZN8QuadTree6detail15activeWorkspaceEv>
   f5696:	31 c9                	xor    %ecx,%ecx
   f5698:	e9 3f ff ff ff       	jmp    f55dc <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x95c>
