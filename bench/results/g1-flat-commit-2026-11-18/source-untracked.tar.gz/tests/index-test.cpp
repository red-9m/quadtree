// Independent edge-comparison oracle, mutation/build, numeric and failure tests.
#include "quadtree-index.h"

#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <forward_list>
#include <iterator>
#include <memory>
#include <set>
#include <thread>
#include <unordered_map>
#include <vector>

using QuadTree::Box;
using QuadTree::Rect;
using QuadTree::Status;
using QuadTree::Boundary;
using QuadTree::Filter;
using QuadTree::Continue;
using QuadTree::Stop;

using MultiTuIndex = QuadTree::Index<int, int, QuadTree::Checked>;
MultiTuIndex::HandleType indexTu2Insert(MultiTuIndex& tree);
bool indexTu2Valid(const MultiTuIndex& tree, MultiTuIndex::HandleType handle);

namespace
{
int failures = 0;
#define CHECK(condition) do { if (!(condition)) { \
    std::fprintf(stderr, "%s:%d: %s\n", __FILE__, __LINE__, #condition); ++failures; } } while (false)
#define REQUIRE(condition) do { if (!(condition)) { CHECK(condition); std::exit(2); } } while (false)

class TestResource final: public QuadTree::Resource
{
public:
    std::size_t allocations = 0, failAt = 0, bytes = 0, peak = 0;
    bool failAll = false;
    std::unordered_map<void*, std::size_t> owned;

    void* allocate(std::size_t count, std::size_t alignment) noexcept override
    {
        CHECK(count != 0);
        ++allocations;
        if (failAll || allocations == failAt)
            return nullptr;
        void* ptr = QuadTree::defaultResource()->allocate(count, alignment);
        if (ptr)
        {
            CHECK(reinterpret_cast<std::uintptr_t>(ptr) % alignment == 0);
            owned.emplace(ptr, count);
            bytes += count;
            peak = std::max(peak, bytes);
        }
        return ptr;
    }
    void deallocate(void* ptr) noexcept override
    {
        if (!ptr) return;
        const auto it = owned.find(ptr);
        REQUIRE(it != owned.end());
        bytes -= it->second;
        owned.erase(it);
        QuadTree::defaultResource()->deallocate(ptr);
    }
    ~TestResource() override { CHECK(owned.empty()); CHECK(bytes == 0); }
};

struct Rng
{
    std::uint64_t state = 1;
    std::uint64_t next() noexcept
    {
        std::uint64_t z = (state += 0x9e3779b97f4a7c15u);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9u;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebu;
        return z ^ (z >> 31);
    }
    std::size_t below(std::size_t n) noexcept { return static_cast<std::size_t>(next() % n); }
    int range(int low, int high) noexcept { return low + static_cast<int>(below(static_cast<std::size_t>(high - low + 1))); }
};

// Does not use any library overlap, conversion, filter, or traversal helper.
template<typename T>
bool overlap(const Box<T>& a, const Box<T>& b, Boundary mode) noexcept
{
    const bool closed = mode == Boundary::TouchInclusive || a.minX == a.maxX || a.minY == a.maxY ||
        b.minX == b.maxX || b.minY == b.maxY;
    if (closed)
        return !(a.maxX < b.minX || b.maxX < a.minX || a.maxY < b.minY || b.maxY < a.minY);
    return !(a.maxX <= b.minX || b.maxX <= a.minX || a.maxY <= b.minY || b.maxY <= a.minY);
}

bool accepts(Filter a, Filter b) noexcept
{
    return (a.mask & b.category) > 0 && (b.mask & a.category) > 0;
}

template<typename T>
using Tree = QuadTree::Index<int, T, QuadTree::Checked>;

template<typename T>
struct Record
{
    Box<T> box;
    int id;
    Filter filter;
    std::uint64_t rank;
    typename Tree<T>::HandleType handle;
};

using Pair = std::pair<int, int>;
using RankPair = std::pair<std::uint64_t, std::uint64_t>;

template<typename T>
std::vector<Pair> expectedPairs(const std::vector<Record<T>>& records, Boundary boundary,
    const std::set<int>* moved = nullptr, bool predicate = false)
{
    std::vector<Pair> result;
    for (std::size_t i = 0; i < records.size(); ++i)
        for (std::size_t j = i + 1; j < records.size(); ++j)
        {
            const auto& a = records[i];
            const auto& b = records[j];
            if (overlap(a.box, b.box, boundary) && accepts(a.filter, b.filter) &&
                (!moved || moved->contains(a.id) || moved->contains(b.id)) &&
                (!predicate || (a.id + b.id) % 3 != 0))
                result.emplace_back(std::min(a.id, b.id), std::max(a.id, b.id));
        }
    std::sort(result.begin(), result.end());
    return result;
}

template<typename T>
void verify(const Tree<T>& tree, const std::vector<Record<T>>& records, QuadTree::Workspace<T>& workspace,
    bool detailed = true)
{
    CHECK(tree.size() == records.size());
    CHECK(tree.empty() == records.empty());
    std::vector<int> entries;
    const auto iterated = tree.forEachEntry([&](const auto& entry) noexcept
    {
        entries.push_back(entry.payload);
        const auto found = std::find_if(records.begin(), records.end(), [&](const auto& r) { return r.id == entry.payload; });
        REQUIRE(found != records.end());
        CHECK(entry.handle == found->handle);
        CHECK(entry.rect == found->box);
        CHECK(entry.filter == found->filter);
        CHECK(entry.rank == found->rank);
        return Continue;
    });
    CHECK(iterated.complete());
    CHECK(entries.size() == records.size());
    std::size_t nodes = 0;
    CHECK(tree.forEachNode([&](const auto& node) noexcept
    {
        ++nodes;
        CHECK(node.ownEntries <= node.entries);
        CHECK(node.depth <= tree.config().maxDepth);
        return Continue;
    }).complete());
    CHECK(nodes == tree.stats().nodes);
    const Boundary boundary = tree.config().boundary;
    const auto expected = expectedPairs(records, boundary);
    std::vector<Pair> actual;
    auto visitor = [&](const auto& a, const auto& b) noexcept
    {
        CHECK(QuadTree::detail::HandleAccess::slot(a.handle) < QuadTree::detail::HandleAccess::slot(b.handle));
        actual.emplace_back(std::min(a.payload, b.payload), std::max(a.payload, b.payload));
        return Continue;
    };
    const auto result = tree.forEachPair(visitor, {.workspace = &workspace});
    CHECK(result.complete());
    CHECK(result.counters.reports == actual.size());
    std::sort(actual.begin(), actual.end());
    CHECK(actual == expected); // A multiset comparison also detects duplicate reports.
    for (const auto& record : records)
    {
        CHECK(tree.valid(record.handle));
        CHECK(tree.rect(record.handle) == record.box);
        CHECK(tree.filter(record.handle) == record.filter);
        CHECK(tree.rank(record.handle) == record.rank);
    }
    if (!detailed) return;
    actual.clear();
    std::vector<RankPair> sequence;
    const auto ordered = tree.forEachPair([&](const auto& a, const auto& b) noexcept
    {
        CHECK(*a.rank < *b.rank);
        sequence.emplace_back(*a.rank, *b.rank);
        actual.emplace_back(std::min(a.payload, b.payload), std::max(a.payload, b.payload));
        return Continue;
    }, {.ordered = true, .workspace = &workspace});
    CHECK(ordered.complete());
    CHECK(std::is_sorted(sequence.begin(), sequence.end()));
    std::sort(actual.begin(), actual.end());
    CHECK(actual == expected);

    std::vector<typename Tree<T>::HandleType> moved;
    std::set<int> moved_ids;
    for (std::size_t i = 0; i < records.size(); i += 3)
    {
        moved.push_back(records[i].handle);
        moved_ids.insert(records[i].id);
    }
    for (bool in_order : {false, true})
    {
        actual.clear(); sequence.clear();
        const auto changed = tree.forEachPairInvolving(moved, [&](const auto& a, const auto& b) noexcept
        {
            actual.emplace_back(std::min(a.payload, b.payload), std::max(a.payload, b.payload));
            if (in_order) sequence.emplace_back(*a.rank, *b.rank);
            return Continue;
        }, {.ordered = in_order, .workspace = &workspace}, [](const auto& a, const auto& b) noexcept
            { return (a.payload + b.payload) % 3 != 0; });
        CHECK(changed.complete());
        CHECK(std::is_sorted(sequence.begin(), sequence.end()));
        std::sort(actual.begin(), actual.end());
        CHECK(actual == expectedPairs(records, boundary, &moved_ids, true));
    }
    const Box<T> query{T(-50), T(-30), T(40), T(60)};
    for (bool filtered : {false, true})
    {
        std::vector<int> hits, expected_hits;
        const Filter filter{3, 6};
        for (const auto& entry : records)
            if (overlap(query, entry.box, boundary) && (!filtered || accepts(filter, entry.filter)))
                expected_hits.push_back(entry.id);
        auto hit = [&](const auto& entry) noexcept { hits.push_back(entry.payload); return Continue; };
        const auto queried = filtered ? tree.query(query, filter, hit) : tree.query(query, hit);
        CHECK(queried.complete());
        std::sort(hits.begin(), hits.end());
        std::sort(expected_hits.begin(), expected_hits.end());
        CHECK(hits == expected_hits);
    }
    if (!records.empty())
    {
        const auto& a = records.back();
        std::vector<int> hits, expected_hits;
        for (const auto& b : records)
            if (a.id != b.id && accepts(a.filter, b.filter) && overlap(a.box, b.box, boundary) && b.rank > 17)
                expected_hits.push_back(b.id);
        CHECK(tree.queryPartners(a.handle, [&](const auto& b) noexcept
            { hits.push_back(b.payload); return Continue; }, {.workspace = &workspace, .greaterRank = 17}).complete());
        std::sort(hits.begin(), hits.end());
        std::sort(expected_hits.begin(), expected_hits.end());
        CHECK(hits == expected_hits);
    }
}

template<typename T>
Box<T> randomBox(Rng& rng)
{
    const int x = rng.range(-120, 120), y = rng.range(-120, 120);
    return {T(x), T(y), T(x + rng.range(0, 28)), T(y + rng.range(0, 28))};
}

template<typename T>
void randomized(Boundary boundary, QuadTree::Extent extent)
{
    QuadTree::Config<T> config;
    config.boundary = boundary;
    config.extent = extent;
    config.smallSetThreshold = 4;
    config.splitThreshold = 3;
    config.mergeThreshold = 1;
    if (extent == QuadTree::Extent::Fixed) config.root = Box<T>{T(-256), T(-256), T(256), T(256)};
    if (extent == QuadTree::Extent::Snapshot) config.snapshotGrowth = QuadTree::SnapshotGrowth::Adaptive;
    auto created = Tree<T>::create(config);
    REQUIRE(created.ok());
    auto tree = std::move(created).value();
    QuadTree::Workspace<T> workspace;
    REQUIRE(workspace.reserve(256) == Status::Ok);
    std::vector<Record<T>> records;
    std::vector<typename Tree<T>::HandleType> dead;
    Rng rng{0x625f42};
    int next_id = 0;
    for (unsigned step = 0; step < 650; ++step)
    {
        const std::size_t op = rng.below(10);
        if (records.empty() || (op < 4 && records.size() < 160))
        {
            const Box<T> box = randomBox<T>(rng);
            const Filter filter{rng.next() & 7, rng.next() & 7};
            const auto rank = std::uint64_t(next_id) * 37;
            const auto inserted = tree.insert(box, next_id, filter, rank);
            REQUIRE(inserted.ok());
            records.push_back({box, next_id++, filter, rank, inserted.handle});
        }
        else if (op < 6)
        {
            auto& record = records[rng.below(records.size())];
            const Box<T> box = randomBox<T>(rng);
            CHECK(tree.update(record.handle, box) == Status::Ok);
            record.box = box;
        }
        else if (op == 6)
        {
            auto& record = records[rng.below(records.size())];
            record.filter = Filter{rng.next() & 7, rng.next() & 7};
            CHECK(tree.setFilter(record.handle, record.filter) == Status::Ok);
        }
        else if (op == 7)
        {
            const std::size_t index = rng.below(records.size());
            dead.push_back(records[index].handle);
            CHECK(tree.remove(records[index].handle) == Status::Ok);
            records[index] = records.back();
            records.pop_back();
        }
        else if (op == 8 && step % 5 == 0)
        {
            std::vector<QuadTree::BuildEntry<int, T>> input;
            for (const auto& record : records)
                input.push_back({record.box, record.id, record.filter, record.rank});
            std::vector<typename Tree<T>::HandleType> output(input.size());
            CHECK(tree.build(input, output, {.workspace = &workspace, .transactional = step % 2 == 0}) == Status::Ok);
            for (std::size_t i = 0; i < records.size(); ++i)
            {
                CHECK(!tree.valid(records[i].handle));
                dead.push_back(records[i].handle);
                records[i].handle = output[i];
            }
        }
        else if (step % 17 == 0)
            CHECK(tree.shrink() == Status::Ok);
        verify(tree, records, workspace, step % 19 == 0);
        for (auto handle : dead) CHECK(!tree.valid(handle));
    }
    verify(tree, records, workspace);
    tree.clear();
    CHECK(tree.empty());
    CHECK(tree.stats().nodes == 0);
    for (const auto& record : records) CHECK(!tree.valid(record.handle));
}

template<typename T>
void numeric()
{
    auto created = Tree<T>::create({.splitThreshold = 2, .mergeThreshold = 0, .smallSetThreshold = 0});
    REQUIRE(created.ok());
    auto tree = std::move(created).value();
    QuadTree::Workspace<T> workspace;
    REQUIRE(workspace.reserve(256) == Status::Ok);
    const T low = std::numeric_limits<T>::lowest(), high = std::numeric_limits<T>::max();
    const std::array<Box<T>, 9> boxes{{{low, low, high, high}, {low, T(0), low, T(0)},
        {high, T(0), high, T(0)}, {T(-1), T(-1), T(1), T(1)}, {T(0), T(0), T(0), T(0)},
        {T(0), T(0), T(1), T(0)}, {T(1), T(0), T(1), T(1)}, {T(1), T(1), T(2), T(2)},
        {T(0), T(-1), T(0), T(1)}}};
    std::vector<Record<T>> records;
    for (std::size_t i = 0; i < boxes.size(); ++i)
    {
        const int id = static_cast<int>(i);
        const auto inserted = tree.insert(boxes[i], id, {}, i);
        REQUIRE(inserted.ok());
        records.push_back({boxes[i], id, {}, i, inserted.handle});
    }
    verify(tree, records, workspace);
    CHECK(tree.insert(Rect<T>{high, T(0), T(1), T(1)}, 99).status == Status::InvalidGeometry);
    CHECK(tree.insert(Rect<T>{T(0), T(0), T(-1), T(1)}, 99).status == Status::InvalidGeometry);
    CHECK(tree.insert(Box<T>{T(1), T(0), T(0), T(1)}, 99).status == Status::InvalidGeometry);
    std::size_t callbacks = 0;
    CHECK(tree.query(Rect<T>{high, T(0), high, T(1)}, [&](const auto&) noexcept
        { ++callbacks; return Continue; }).status == Status::InvalidGeometry);
    CHECK(callbacks == 0);
    if constexpr (QuadTree::FloatCoordinate<T>)
    {
        const T infinity = std::numeric_limits<T>::infinity(), nan = std::numeric_limits<T>::quiet_NaN();
        CHECK(tree.insert(Box<T>{T(0), T(0), infinity, T(1)}, 99).status == Status::InvalidGeometry);
        CHECK(tree.update(records[0].handle, Box<T>{nan, T(0), T(1), T(1)}) == Status::InvalidGeometry);
        CHECK(tree.insert(Rect<T>{T(1), T(0), std::numeric_limits<T>::denorm_min(), T(1)}, 99).status == Status::InvalidGeometry);
        const T tiny = std::numeric_limits<T>::denorm_min();
        const auto subnormal = tree.insert(Rect<T>{T(0), T(0), tiny, tiny}, 99);
        REQUIRE(subnormal.ok());
        CHECK(tree.rect(subnormal.handle).maxX == tiny);
        const auto zero = tree.insert(Box<T>{-T(0), -T(0), T(0), T(0)}, 100);
        REQUIRE(zero.ok());
        CHECK(!std::signbit(tree.rect(zero.handle).minX));
        // QT-FIX-10: query and pair reproductions in separate trees.
        const T u = std::nextafter(T(1), T(2)) - T(1);
        QuadTree::Config<T> config;
        config.extent = QuadTree::Extent::Fixed;
        config.root = Box<T>{T(1), T(0), T(1) + T(5) * u, T(8)};
        config.smallSetThreshold = 0; config.splitThreshold = 1; config.mergeThreshold = 0;
        auto made = Tree<T>::create(config);
        REQUIRE(made.ok());
        auto probe = std::move(made).value();
        REQUIRE(probe.insert(Rect<T>{T(1) + T(4) * u, T(1), u, T(1)}, 1).ok());
        REQUIRE(probe.insert(Box<T>{T(1), T(6), T(1), T(6)}, 2).ok());
        std::size_t hits = 0;
        CHECK(probe.query(Rect<T>{T(1) + T(5) * u, T(1.5), T(0), T(0)}, [&](const auto& entry) noexcept
            { CHECK(entry.payload == 1); ++hits; return Continue; }).complete());
        CHECK(hits == 1);
        made = Tree<T>::create(config);
        probe = std::move(made).value();
        REQUIRE(probe.insert(Rect<T>{T(1) + T(4) * u, T(1), u, T(1)}, 1).ok());
        REQUIRE(probe.insert(Rect<T>{T(1) + T(5) * u, T(0), T(0), T(8)}, 2).ok());
        hits = 0;
        CHECK(probe.forEachPair([&](const auto&, const auto&) noexcept { ++hits; return Continue; }).complete());
        CHECK(hits == 1);
    }
}

void contracts()
{
    using I = Tree<int>;
    CHECK(I::create({.extent = QuadTree::Extent::Fixed}).status == Status::InvalidConfiguration);
    CHECK(I::create({.extent = QuadTree::Extent::Snapshot}).status == Status::InvalidConfiguration);
    CHECK(I::create({.maxDepth = 65}).status == Status::InvalidConfiguration);
    CHECK(I::create({.splitThreshold = 0}).status == Status::InvalidConfiguration);
    CHECK(I::create({.extent = QuadTree::Extent::Fixed, .root = Box<int>{0, 0, 0, 1}}).status == Status::InvalidGeometry);
    auto created = I::create({.extent = QuadTree::Extent::Fixed, .root = Box<int>{0, 0, 10, 10}});
    REQUIRE(created.ok());
    auto tree = std::move(created).value();
    auto a = tree.insert(Box<int>{0, 0, 10, 10}, 1, {}, 0);
    REQUIRE(a.ok());
    CHECK(tree.insert(Box<int>{0, 0, 10, 10}, 1, {}, 0).status == Status::DuplicateRank);
    auto b = tree.insert(Box<int>{0, 0, 10, 10}, 1, {}, UINT64_MAX);
    REQUIRE(b.ok());
    CHECK(a.handle != b.handle); // Equal payload values are independent identities.
    CHECK(tree.update(a.handle, Box<int>{-1, 0, 1, 1}) == Status::OutOfBounds);
    CHECK((tree.rect(a.handle) == Box<int>{0, 0, 10, 10}));
    std::size_t count = 0;
    CHECK(tree.query(Box<int>{-100, -100, 100, 100}, [&](const auto&) noexcept { ++count; return Continue; }).complete());
    CHECK(count == 2);
    CHECK(tree.setFilter(a.handle, {0, 0}) == Status::Ok);
    CHECK(tree.forEachPair([](const auto&, const auto&) noexcept { return Stop; }).complete());
    CHECK(tree.setFilter(a.handle, {}) == Status::Ok);
    QuadTree::Workspace<int> workspace;
    REQUIRE(workspace.reserve(10) == Status::Ok);
    workspace.resetMovedMembership();
    const std::array duplicates{a.handle, a.handle};
    CHECK(tree.forEachPairInvolving(duplicates, [](const auto&, const auto&) noexcept { return Stop; },
        {.workspace = &workspace}).status == Status::DuplicateHandle);
    QuadTree::Workspace<int> unprepared;
    CHECK(tree.forEachPairInvolving(std::array{a.handle}, [](const auto&, const auto&) noexcept { return Stop; },
        {.workspace = &unprepared}).status == Status::InsufficientWorkspace);
    CHECK(tree.forEachPairInvolving({}, [](const auto&, const auto&) noexcept { return Stop; },
        {.ordered = true, .workspace = &unprepared}).complete());
    CHECK(tree.forEachPair([](const auto&, const auto&) noexcept { return Stop; }).status == Status::Stopped);
    std::vector<std::pair<I::HandleType, I::HandleType>> pairs(1);
    CHECK(tree.pairsTo(std::back_inserter(pairs)).complete());
    CHECK(pairs.size() == 2); // Append, never clear caller output.
    std::vector<I::HandleType> hits(1);
    CHECK(tree.queryTo(Box<int>{0, 0, 10, 10}, std::back_inserter(hits)).complete());
    CHECK(hits.size() == 3);
    auto missing = tree.insert(Box<int>{0, 0, 1, 1}, 3);
    REQUIRE(missing.ok());
    CHECK(tree.forEachPair([](const auto&, const auto&) noexcept { return Stop; }, {.ordered = true}).status == Status::MissingRank);
    CHECK(tree.queryPartners(a.handle, [](const auto&) noexcept { return Stop; }, {.greaterRank = 0}).status == Status::MissingRank);
    CHECK(tree.remove(missing.handle) == Status::Ok);
    std::array<QuadTree::BuildEntry<int, int>, 2> input{{{{0, 0, 3, 3}, 3, {}, 8}, {{1, 1, 2, 2}, 4, {}, 8}}};
    std::array<I::HandleType, 2> output{a.handle, b.handle};
    CHECK(tree.build(input, output, {.workspace = &workspace}) == Status::DuplicateRank);
    CHECK(tree.valid(a.handle) && tree.valid(b.handle));
    CHECK(output[0] == a.handle && output[1] == b.handle);
    input[1].rank = 9;
    CHECK(tree.build(input, std::span<I::HandleType>(output).first(1)) == Status::InsufficientOutput);
    input[1].rect = {0, 0, 11, 1};
    CHECK(tree.build(input) == Status::OutOfBounds);
    CHECK(tree.valid(a.handle));
    std::array<QuadTree::BuildEntry<int, int>, 0> empty{};
    CHECK(tree.build(empty, {.workspace = &workspace}) == Status::Ok);
    CHECK(!tree.valid(a.handle) && tree.empty());
    for (auto growth : {QuadTree::SnapshotGrowth::Adaptive, QuadTree::SnapshotGrowth::Reject})
    {
        auto made = I::create({.extent = QuadTree::Extent::Snapshot, .snapshotGrowth = growth});
        REQUIRE(made.ok());
        auto snapshot = std::move(made).value();
        CHECK(snapshot.build(empty) == Status::Ok);
        CHECK(!snapshot.extent());
        const auto inserted = snapshot.insert(Box<int>{0, 0, 0, 0}, 0);
        CHECK(inserted.status == (growth == QuadTree::SnapshotGrowth::Reject ? Status::OutOfBounds : Status::Ok));
        std::array<QuadTree::BuildEntry<int, int>, 1> point{{{{2, 2, 2, 2}, 1}}};
        CHECK(snapshot.build(point) == Status::Ok);
        CHECK(snapshot.extent() == point[0].rect);
    }
}

void budgets()
{
    auto made = Tree<int>::create({.splitThreshold = 2, .mergeThreshold = 0, .smallSetThreshold = 0});
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    std::vector<Tree<int>::HandleType> moved;
    for (int i = 0; i < 13; ++i)
    {
        auto inserted = tree.insert(Box<int>{i % 4, i % 5, i % 4 + 10, i % 5 + 10}, int(i), {}, 100 - std::uint64_t(i * 7));
        REQUIRE(inserted.ok());
        if (i % 2 == 0) moved.push_back(inserted.handle);
    }
    QuadTree::Workspace<int> workspace;
    REQUIRE(workspace.reserve(20) == Status::Ok);
    for (bool moved_only : {false, true})
    {
        std::vector<RankPair> complete;
        auto full = [&](const auto& a, const auto& b) noexcept { complete.emplace_back(*a.rank, *b.rank); return Continue; };
        const auto unlimited = moved_only ? tree.forEachPairInvolving(moved, full, {.ordered = true, .workspace = &workspace}) :
            tree.forEachPair(full, {.ordered = true, .workspace = &workspace});
        REQUIRE(unlimited.complete());
        for (bool nodes : {false, true})
        {
            const std::uint64_t total = nodes ? unlimited.counters.nodeVisits : unlimited.counters.candidateTests;
            for (std::uint64_t limit = 0; limit <= total + 1; ++limit)
            {
                std::vector<RankPair> partial;
                auto visitor = [&](const auto& a, const auto& b) noexcept { partial.emplace_back(*a.rank, *b.rank); return Continue; };
                QuadTree::QueryOptions<int> options{.ordered = true, .workspace = &workspace};
                if (nodes) options.budget.nodeVisits = limit;
                else options.budget.candidateTests = limit;
                const auto result = moved_only ? tree.forEachPairInvolving(moved, visitor, options) : tree.forEachPair(visitor, options);
                CHECK(result.status == (limit >= total ? Status::Ok : Status::BudgetExhausted));
                CHECK(partial.size() <= complete.size());
                CHECK(std::equal(partial.begin(), partial.end(), complete.begin()));
                CHECK((nodes ? result.counters.nodeVisits : result.counters.candidateTests) <= limit);
                CHECK(result.counters.reports == partial.size());
            }
        }
        for (std::size_t stop = 1; stop <= complete.size(); ++stop)
        {
            std::vector<RankPair> partial;
            auto visitor = [&](const auto& a, const auto& b) noexcept
            { partial.emplace_back(*a.rank, *b.rank); return partial.size() == stop ? Stop : Continue; };
            const auto result = moved_only ? tree.forEachPairInvolving(moved, visitor, {.ordered = true, .workspace = &workspace}) :
                tree.forEachPair(visitor, {.ordered = true, .workspace = &workspace});
            CHECK(result.status == Status::Stopped);
            CHECK(partial.size() == stop);
            CHECK(std::equal(partial.begin(), partial.end(), complete.begin()));
        }
    }
    auto pair_result = tree.forEachPair([](const auto&, const auto&) noexcept { return Continue; });
    CHECK(pair_result.counters.candidateTests == 78);
    pair_result = tree.forEachPair([](const auto&, const auto&) noexcept { return Continue; }, {.budget = {.candidateTests = 78}});
    CHECK(pair_result.complete());
    CHECK(tree.forEachPair([](const auto&, const auto&) noexcept { return Continue; },
        {.budget = {.candidateTests = 0}}).status == Status::BudgetExhausted);
}

void crossAndSelections()
{
    auto made = Tree<int>::create({.smallSetThreshold = 0});
    auto other_made = QuadTree::Index<long, int>::create({.smallSetThreshold = 0});
    REQUIRE(made.ok() && other_made.ok());
    auto tree = std::move(made).value();
    auto other = std::move(other_made).value();
    for (int i = 0; i < 40; ++i)
    {
        REQUIRE(tree.insert(Box<int>{i, i, i + 4, i + 4}, int(i), {}, std::uint64_t(40 - i)).ok());
        REQUIRE(other.insert(Box<int>{i, i, i + 2, i + 2}, long(i), {}, std::uint64_t(i)).ok());
    }
    QuadTree::Workspace<int> workspace;
    REQUIRE(workspace.reserve(80) == Status::Ok);
    for (bool ordered : {false, true})
    {
        std::vector<std::pair<int, long>> found, expected;
        std::vector<RankPair> ranks;
        for (int a = 0; a < 40; ++a)
            for (long b = 0; b < 40; ++b)
                if (overlap(Box<int>{a, a, a + 4, a + 4}, Box<int>{int(b), int(b), int(b) + 2, int(b) + 2}, Boundary::Default) && a < b)
                    expected.emplace_back(a, b);
        const auto result = tree.forEachPair(other, [&](const auto& a, const auto& b) noexcept
        { found.emplace_back(a.payload, b.payload); ranks.emplace_back(*a.rank, *b.rank); return Continue; },
            {.ordered = ordered, .workspace = &workspace}, [](const auto& a, const auto& b) noexcept { return a.payload < b.payload; });
        CHECK(result.complete());
        if (ordered) CHECK(std::is_sorted(ranks.begin(), ranks.end()));
        std::sort(found.begin(), found.end());
        CHECK(found == expected);
        std::size_t left_calls = 0, right_calls = 0;
        found.clear(); expected.clear(); ranks.clear();
        for (int a = 0; a < 40; a += 2)
            for (long b = 1; b < 40; b += 2)
                if (overlap(Box<int>{a, a, a + 4, a + 4}, Box<int>{int(b), int(b), int(b) + 4, int(b) + 4}, Boundary::Default))
                    expected.emplace_back(a, b);
        CHECK(tree.forEachPairSelected([&](const auto& a) noexcept { ++left_calls; return a.payload % 2 == 0; },
            [&](const auto& a) noexcept { ++right_calls; return a.payload % 2 == 1; },
            [&](const auto& a, const auto& b) noexcept
            { found.emplace_back(a.payload, b.payload); ranks.emplace_back(*a.rank, *b.rank); return Continue; },
            {.ordered = ordered, .workspace = &workspace}).complete());
        CHECK(left_calls == tree.size() && right_calls == tree.size());
        if (ordered) CHECK(std::is_sorted(ranks.begin(), ranks.end()));
        std::sort(found.begin(), found.end());
        CHECK(found == expected);
    }
    CHECK(tree.forEachPair(tree, [](const auto&, const auto&) noexcept { return Stop; }).status == Status::InvalidArgument);
    CHECK(tree.forEachPairSelected([](const auto&) noexcept { return true; }, [](const auto&) noexcept { return true; },
        [](const auto&, const auto&) noexcept { return Stop; }, {.workspace = &workspace}).status == Status::InvalidArgument);
    auto mismatch = QuadTree::Index<long, int>::create({.boundary = Boundary::TouchInclusive});
    REQUIRE(mismatch.ok());
    CHECK(tree.forEachPair(mismatch.value(), [](const auto&, const auto&) noexcept { return Stop; }).status == Status::IncompatiblePolicy);
    auto other_coords = QuadTree::Index<long, double>::create();
    REQUIRE(other_coords.ok());
    CHECK(tree.forEachPair(other_coords.value(), [](const auto&, const auto&) noexcept { return Stop; }).status == Status::IncompatiblePolicy);
}

void hardCapacity()
{
    TestResource resource;
    auto made = Tree<int>::create({.smallSetThreshold = 4, .hardCapacity = true}, &resource);
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    REQUIRE(tree.reserve({.entries = 256, .rankedEntries = 256, .nodes = 8193, .descriptors = 256}) == Status::Ok);
    QuadTree::Workspace<int> workspace(&resource);
    REQUIRE(workspace.reserve(256) == Status::Ok);
    std::vector<Record<int>> records;
    Rng rng{555};
    const auto allocations = resource.allocations;
    resource.failAll = true;
    for (int i = 0; i < 160; ++i)
    {
        const auto box = randomBox<int>(rng);
        auto inserted = tree.insert(box, int(i), {}, std::uint64_t(i));
        REQUIRE(inserted.ok());
        records.push_back({box, i, {}, std::uint64_t(i), inserted.handle});
    }
    for (int round = 0; round < 10; ++round)
    {
        for (auto& record : records)
        {
            record.box = randomBox<int>(rng);
            CHECK(tree.update(record.handle, record.box) == Status::Ok);
        }
        verify(tree, records, workspace);
        std::vector<QuadTree::BuildEntry<int, int>> input;
        std::vector<Tree<int>::HandleType> output(records.size());
        for (const auto& record : records) input.push_back({record.box, record.id, {}, record.rank});
        CHECK(tree.build(input, output, {.workspace = &workspace, .transactional = round % 2 == 0}) == Status::Ok);
        for (std::size_t i = 0; i < records.size(); ++i) records[i].handle = output[i];
    }
    CHECK(resource.allocations == allocations);
    CHECK(tree.shrink() == Status::AllocationFailed);
    verify(tree, records, workspace);
    tree.clear();
    CHECK(resource.allocations == allocations + 1); // Only the deliberately failed shrink.
    CHECK(tree.stats().nodeCapacity == 8193);
    resource.failAll = false;

    auto limited = Tree<int>::create({.smallSetThreshold = 0, .hardCapacity = true}, &resource);
    REQUIRE(limited.ok());
    auto small = std::move(limited).value();
    REQUIRE(small.reserve({.entries = 1, .nodes = 1, .descriptors = 1}) == Status::Ok);
    const auto old = small.insert(Box<int>{0, 0, 1, 1}, 1);
    REQUIRE(old.ok());
    std::array<QuadTree::BuildEntry<int, int>, 2> input{{{{0, 0, 1, 1}, 1}, {{5, 5, 6, 6}, 2}}};
    CHECK(small.build(input, {.workspace = &workspace}) == Status::CapacityExhausted);
    CHECK(small.valid(old.handle) && small.size() == 1);
}

void failureInjection()
{
    for (int operation = 0; operation < 6; ++operation)
    {
        bool succeeded = false;
        for (std::size_t failure = 1; failure < 40 && !succeeded; ++failure)
        {
            TestResource resource;
            {
                auto made = Tree<int>::create({.smallSetThreshold = 0}, &resource);
                REQUIRE(made.ok());
                auto tree = std::move(made).value();
                std::vector<Record<int>> old;
                for (int i = 0; i < 8; ++i)
                {
                    const Box<int> box{i * 8, 0, i * 8 + 4, 4};
                    const auto added = tree.insert(box, int(i), {}, std::uint64_t(i));
                    REQUIRE(added.ok());
                    old.push_back({box, i, {}, std::uint64_t(i), added.handle});
                }
                QuadTree::Workspace<int> workspace;
                REQUIRE(workspace.reserve(100) == Status::Ok);
                std::vector<QuadTree::BuildEntry<int, int>> input;
                for (int i = 0; i < 50; ++i) input.push_back({{i * 2, i * 2, i * 2 + 3, i * 2 + 3}, i, {}, std::uint64_t(i)});
                std::vector<Tree<int>::HandleType> output(input.size(), old[0].handle);
                resource.failAt = resource.allocations + failure;
                Status status = Status::Ok;
                if (operation == 0) status = tree.insert(Box<int>{50000, 50000, 50003, 50003}, 9, {}, 9).status;
                if (operation == 1) status = tree.update(old[0].handle, Box<int>{-50000, -50000, -49997, -49997});
                if (operation == 2) status = tree.reserve({.entries = 200, .rankedEntries = 200, .nodes = 5000, .descriptors = 200});
                if (operation == 3) status = tree.shrink();
                if (operation == 4) status = tree.build(input, output, {.transactional = failure % 2 == 0});
                if (operation == 5)
                {
                    const auto query = tree.forEachPairInvolving(std::array{old[0].handle},
                        [](const auto&, const auto&) noexcept { return Continue; }, {.ordered = true});
                    status = query.status;
                }
                resource.failAt = 0;
                CHECK(status == Status::Ok || status == Status::AllocationFailed);
                if (status == Status::AllocationFailed)
                {
                    verify(tree, old, workspace);
                    for (auto handle : output) CHECK(handle == old[0].handle);
                }
                else succeeded = true;
            }
        }
        CHECK(succeeded);
    }
}

void preparedSmallBuild()
{
    TestResource resource;
    auto made = Tree<int>::create({.extent = QuadTree::Extent::Snapshot,
        .snapshotGrowth = QuadTree::SnapshotGrowth::Adaptive, .smallSetThreshold = 2,
        .maxEntries = 3, .hardCapacity = true}, &resource);
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    REQUIRE(tree.reserve({.entries = 3, .rankedEntries = 3, .nodes = 1}) == Status::Ok);
    QuadTree::Workspace<int> scratch(&resource);
    REQUIRE(scratch.reserve({0, 0, 3}) == Status::Ok);
    const auto allocations = resource.allocations;
    resource.failAll = true;

    using E = QuadTree::BuildEntry<int, int>;
    std::array<E, 3> entries{{{{0, 0, 3, 3}, 1, {}, 7}, {{1, 1, 2, 2}, 2, {2, 3}, 8},
        {{9, 9, 10, 10}, 3, {}, 9}}};
    std::array<Tree<int>::HandleType, 4> output{};
    REQUIRE(tree.build(entries, output, {.workspace = &scratch}) == Status::Ok);
    const auto previous = output;
    CHECK(tree.payload(output[0]) == 1 && tree.payload(output[1]) == 2 && tree.payload(output[2]) == 3);
    CHECK(output[3] == Tree<int>::HandleType{});
    CHECK(tree.stats().references == 3);

    std::forward_list<E> replacement{entries[1]};
    REQUIRE(tree.build(replacement, output, {.workspace = &scratch, .transactional = true}) == Status::Ok);
    CHECK(!tree.valid(previous[0]) && !tree.valid(previous[1]) && !tree.valid(previous[2]));
    CHECK(tree.valid(output[0]) && tree.payload(output[0]) == 2 && output[1] == previous[1]);
    CHECK(tree.rank(output[0]) == 8 && tree.filter(output[0]) == entries[1].filter);
    CHECK(tree.extent() == entries[1].rect && tree.stats().references == 0);
    const auto ranked = output[0];
    replacement.front().rank.reset();
    REQUIRE(tree.build(replacement, output, {.workspace = &scratch}) == Status::Ok);
    CHECK(!tree.valid(ranked) && !tree.rank(output[0]));
    const auto noPair = [](const auto&, const auto&) noexcept { CHECK(false); return Continue; };
    CHECK(tree.forEachPair(noPair, {.ordered = true}).status == Status::MissingRank);
    CHECK(tree.forEachPair(noPair, {.budget = {.candidateTests = 0}}).complete());

    entries[0].rank.reset();
    replacement.push_front(entries[0]);
    const auto single = output[0];
    REQUIRE(tree.build(replacement, output, {.workspace = &scratch}) == Status::Ok);
    CHECK(!tree.valid(single) && tree.size() == 2);
    CHECK(tree.payload(output[0]) == 1 && tree.payload(output[1]) == 2 && output[2] == previous[2]);
    int pairs = 0;
    CHECK(tree.forEachPair([&](const auto& a, const auto& b) noexcept
        {
            CHECK(a.handle == output[0] && b.handle == output[1]);
            ++pairs;
            return Continue;
        }).complete());
    CHECK(pairs == 1);
    replacement.push_front(entries[0]);
    replacement.push_front(entries[0]);
    CHECK(tree.build(replacement, output, {.workspace = &scratch}) == Status::SizeLimitExceeded);
    CHECK(tree.valid(output[0]) && tree.size() == 2);
    replacement.clear();
    REQUIRE(tree.build(replacement, output, {.workspace = &scratch}) == Status::Ok);
    CHECK(!tree.valid(output[0]) && !tree.valid(output[1]) && tree.empty() && !tree.extent());
    CHECK(tree.forEachPair(noPair, {.ordered = true}).complete());
    CHECK(tree.build(replacement, {.workspace = &scratch}) == Status::Ok);
    CHECK(resource.allocations == allocations);
}

struct LimitedIdentities
{
    static constexpr bool checkHandles = true;
    static inline bool exhausted = false;
    static std::uint64_t acquireIdentity() noexcept
    {
        return exhausted ? 0 : QuadTree::detail::acquireModuleIdentity();
    }
};

void identities()
{
    using I = QuadTree::Index<int, int, LimitedIdentities>;
    auto made = I::create();
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    const auto old = tree.insert(Box<int>{0, 0, 1, 1}, 1);
    REQUIRE(old.ok());
    std::array<QuadTree::BuildEntry<int, int>, 1> input{{{{0, 0, 2, 2}, 2}}};
    std::array<I::HandleType, 1> output{old.handle};
    LimitedIdentities::exhausted = true;
    CHECK(tree.build(input, output) == Status::IdentityExhausted);
    CHECK(tree.valid(old.handle) && output[0] == old.handle && tree.payload(old.handle) == 1);
    REQUIRE(tree.reserve({.entries = 1}) == Status::Ok);
    QuadTree::Workspace<int> scratch;
    REQUIRE(scratch.reserve({0, 0, 1}) == Status::Ok);
    CHECK(tree.build(input, output, {.workspace = &scratch}) == Status::IdentityExhausted);
    CHECK(tree.valid(old.handle) && output[0] == old.handle && tree.payload(old.handle) == 1);
    tree.clear();
    CHECK(tree.insert(Box<int>{0, 0, 1, 1}, 1).status == Status::IdentityExhausted);
    LimitedIdentities::exhausted = false;
    auto first = MultiTuIndex::create(), second = MultiTuIndex::create();
    REQUIRE(first.ok() && second.ok());
    const auto a = indexTu2Insert(first.value());
    const auto b = indexTu2Insert(second.value());
    CHECK(indexTu2Valid(first.value(), a) && !indexTu2Valid(first.value(), b));
    CHECK(second.value().valid(b) && !second.value().valid(a));
}

struct MoveOnly
{
    std::unique_ptr<int> value;
    explicit MoveOnly(int i): value(std::make_unique<int>(i)) {}
    MoveOnly(MoveOnly&&) noexcept = default;
    MoveOnly& operator=(MoveOnly&&) noexcept = default;
};

void payloadsAndMoves()
{
    TestResource first, second;
    auto a = QuadTree::Index<MoveOnly, int>::create({.smallSetThreshold = 0}, &first);
    auto b = QuadTree::Index<MoveOnly, int>::create({}, &second);
    REQUIRE(a.ok() && b.ok());
    auto tree = std::move(a).value();
    auto other = std::move(b).value();
    std::array<QuadTree::BuildEntry<MoveOnly, int>, 2> input{{{{0, 0, 3, 3}, MoveOnly(1)}, {{4, 4, 2, 2}, MoveOnly(2)}}};
    REQUIRE(tree.insert(Box<int>{0, 0, 1, 1}, MoveOnly(5)).ok());
    CHECK(tree.buildConsume(input) == Status::InvalidGeometry);
    CHECK(input[0].payload.value && input[1].payload.value);
    input[1].rect = {1, 1, 2, 2};
    std::array<decltype(tree)::HandleType, 2> handles;
    CHECK(tree.buildConsume(input, handles, {.transactional = true}) == Status::Ok);
    CHECK(!input[0].payload.value && !input[1].payload.value);
    CHECK(*tree.payload(handles[0]).value == 1 && *tree.payload(handles[1]).value == 2);
    const auto stale = other.insert(Box<int>{0, 0, 1, 1}, MoveOnly(3));
    REQUIRE(stale.ok());
    const auto allocations = first.allocations + second.allocations;
    other = std::move(tree);
    CHECK(other.resource() == &first && tree.resource() == &first);
    CHECK(other.valid(handles[0]) && !tree.valid(handles[0]) && !other.valid(stale.handle));
    CHECK(first.allocations + second.allocations == allocations);
    CHECK(tree.empty());
    CHECK(tree.query(Box<int>{0, 0, 10, 10}, [](const auto&) noexcept { return Stop; }).complete());
    REQUIRE(tree.insert(Box<int>{0, 0, 1, 1}, MoveOnly(6)).ok());
    auto& alias = other;
    other = std::move(alias);
    CHECK(other.valid(handles[0]));
    QuadTree::Workspace<int> wa(&first), wb(&second);
    REQUIRE(wa.reserve(50) == Status::Ok && wb.reserve(20) == Status::Ok);
    const auto work_allocations = first.allocations + second.allocations;
    wb = std::move(wa);
    CHECK(wb.resource() == &first && wa.resource() == &first);
    CHECK(wa.retainedBytes() == 0);
    CHECK(first.allocations + second.allocations == work_allocations);
    REQUIRE(wa.reserve(3) == Status::Ok);

    auto projected = Tree<int>::create();
    REQUIRE(projected.ok());
    std::array<int, 3> payloads{1, 2, 3};
    int calls = 0, offset = 7;
    auto accessor = [&](const int& value) noexcept { ++calls; return Rect<int>{value + offset, 0, 2, 2}; };
    CHECK(projected.value().buildWith(payloads, accessor) == Status::Ok);
    CHECK(calls == 3);
    auto inserted = projected.value().insertWith(4, accessor);
    REQUIRE(inserted.ok());
    CHECK(calls == 4 && projected.value().rect(inserted.handle).minX == 11);
    offset = 100;
    CHECK(projected.value().rect(inserted.handle).minX == 11);
}

void cacheAndChurn()
{
    auto made = Tree<int>::create({.splitThreshold = 2, .mergeThreshold = 0, .smallSetThreshold = 0});
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    std::array<Tree<int>::HandleType, 3> handles;
    for (int i = 0; i < 3; ++i)
    {
        auto added = tree.insert(Box<int>{0, 0, 3, 3}, int(i));
        REQUIRE(added.ok()); handles[static_cast<std::size_t>(i)] = added.handle;
    }
    std::set<Pair> cache;
    auto predicate = [](const auto& a, const auto& b) noexcept { return a.payload >= 0 && b.payload >= 0; };
    auto collect = [&](const auto& a, const auto& b) noexcept
        { cache.emplace(std::min(a.payload, b.payload), std::max(a.payload, b.payload)); return Continue; };
    REQUIRE(tree.forEachPair(collect, {}, predicate).complete());
    QuadTree::Workspace<int> workspace;
    REQUIRE(workspace.reserve(10) == Status::Ok);
    const auto refresh = [&](int dirty) noexcept
    {
        std::set<Pair> delta;
        const auto result = tree.forEachPairInvolving(std::span(handles).subspan(static_cast<std::size_t>(dirty), 1),
            [&](const auto& a, const auto& b) noexcept
            { delta.emplace(std::min(a.payload, b.payload), std::max(a.payload, b.payload)); return Continue; },
            {.workspace = &workspace}, predicate);
        REQUIRE(result.complete());
        for (auto it = cache.begin(); it != cache.end();)
            if (it->first == dirty || it->second == dirty) it = cache.erase(it);
            else ++it;
        cache.insert(delta.begin(), delta.end());
        std::set<Pair> full;
        REQUIRE(tree.forEachPair([&](const auto& a, const auto& b) noexcept
            { full.emplace(std::min(a.payload, b.payload), std::max(a.payload, b.payload)); return Continue; }, {}, predicate).complete());
        CHECK(cache == full);
    };
    CHECK(tree.update(handles[0], Box<int>{10, 10, 13, 13}) == Status::Ok); refresh(0);
    CHECK(tree.setFilter(handles[1], {0, 0}) == Status::Ok); refresh(1);
    CHECK(tree.setFilter(handles[1], {}) == Status::Ok); refresh(1);
    tree.payload(handles[2]) = -2;
    // Identity rather than payload is the cache key in real clients. Restore the
    // ID here after suppressing eligibility through an external predicate.
    CHECK(tree.forEachPairInvolving(std::array{handles[2]}, [](const auto&, const auto&) noexcept { return Stop; },
        {.workspace = &workspace}, predicate).complete());
    tree.payload(handles[2]) = 2; refresh(2);
    CHECK(tree.remove(handles[1]) == Status::Ok);
    for (auto it = cache.begin(); it != cache.end();)
        if (it->first == 1 || it->second == 1) it = cache.erase(it);
        else ++it;
    CHECK(cache.empty());
    // Dense swap removal, pooling, split/merge, adaptive growth and contraction.
    for (int round = 0; round < 80; ++round)
    {
        std::vector<Tree<int>::HandleType> spawned;
        for (int i = 0; i < 80; ++i)
        {
            const int x = (round % 2 == 0 ? 1000000 : -1000000) + i * 8;
            const auto added = tree.insert(Box<int>{x, i, x + 4, i + 4}, int(i + 10));
            REQUIRE(added.ok()); spawned.push_back(added.handle);
        }
        for (auto handle : spawned) CHECK(tree.remove(handle) == Status::Ok);
        CHECK(tree.size() == 2);
        CHECK(tree.stats().nodes < 200);
        if (round % 9 == 0) CHECK(tree.shrink() == Status::Ok);
    }
}

struct MutationProbe : QuadTree::Checked
{
    static inline std::size_t splitAttempts = 0, splitEntries = 0, refitEntries = 0;
    static void onSplitPreparation(std::size_t entries) noexcept { ++splitAttempts; splitEntries += entries; }
    static void onItemRefit(std::size_t entries) noexcept { refitEntries += entries; }
    static void reset() noexcept { splitAttempts = 0; splitEntries = 0; refitEntries = 0; }
};

void mutationWork()
{
    using I = QuadTree::Index<int, int, MutationProbe>;
    constexpr int count = 4096;
    for (bool oversized : {false, true})
    {
        TestResource resource;
        auto made = I::create({.extent = QuadTree::Extent::Fixed, .root = Box<int>{0, 0, 16384, 16384},
            .smallSetThreshold = 0}, &resource);
        REQUIRE(made.ok());
        auto tree = std::move(made).value();
        const Box<int> original = oversized ? Box<int>{0, 0, 16384, 16384} : Box<int>{16, 16, 24, 24};
        const Box<int> moved = oversized ? Box<int>{1, 0, 16384, 16384} : Box<int>{17, 16, 24, 24};
        std::vector<I::HandleType> handles;
        MutationProbe::reset();
        for (int i = 0; i < count; ++i)
        {
            const auto added = tree.insert(original, int(i));
            REQUIRE(added.ok());
            handles.push_back(added.handle);
        }
        CHECK(tree.stats().nodes == 1);
        CHECK(MutationProbe::splitAttempts > 0);
        CHECK(MutationProbe::splitEntries < 8 * std::size_t(count));
        CHECK(MutationProbe::refitEntries == 0); // Insertion extends cached own summaries.
        REQUIRE(tree.reserve({.entries = count, .descriptors = count}) == Status::Ok);
        const auto allocations = resource.allocations;
        resource.failAll = true;
        MutationProbe::reset();
        constexpr int changes = 4 * count;
        for (int i = 0; i < changes; ++i)
            CHECK(tree.update(handles[0], i % 2 == 0 ? moved : original) == Status::Ok);
        CHECK(MutationProbe::splitAttempts > 0 && MutationProbe::splitAttempts < 16);
        CHECK(MutationProbe::splitEntries < 4 * std::size_t(changes));
        CHECK(MutationProbe::refitEntries > 0 && MutationProbe::refitEntries < 4 * std::size_t(changes));
        CHECK(tree.stats().nodes == 1);
        CHECK(tree.setFilter(handles[0], {0, 0}) == Status::Ok);
        std::size_t reports = 0;
        CHECK(tree.queryPartners(handles[0], [&](const auto&) noexcept { ++reports; return Continue; }).complete());
        CHECK(reports == 0);
        CHECK(tree.query(Box<int>{20, 20, 20, 20}, [&](const auto&) noexcept { ++reports; return Continue; }).complete());
        CHECK(reports == std::size_t(count));
        MutationProbe::reset();
        for (std::size_t i = 1; i < handles.size(); ++i)
            CHECK(tree.remove(handles[i]) == Status::Ok);
        CHECK(MutationProbe::refitEntries < 4 * std::size_t(count) + 64);
        CHECK(tree.size() == 1 && tree.valid(handles[0]));
        CHECK(tree.setFilter(handles[0], {}) == Status::Ok);
        reports = 0;
        CHECK(tree.query(original, Filter{1, 1}, [&](const auto& entry) noexcept
            { CHECK(entry.handle == handles[0]); ++reports; return Continue; }).complete());
        CHECK(reports == 1);
        CHECK(resource.allocations == allocations);
    }

    // Failed preparation must not consume the retry counter or change caches.
    auto made = I::create({.extent = QuadTree::Extent::Fixed, .root = Box<int>{0, 0, 64, 64},
        .splitThreshold = 2, .mergeThreshold = 0, .smallSetThreshold = 0, .hardCapacity = true});
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    REQUIRE(tree.reserve({.entries = 6, .nodes = 1, .descriptors = 6}) == Status::Ok);
    std::array<I::HandleType, 6> handles;
    for (std::size_t i = 0; i < handles.size(); ++i)
    {
        const auto added = tree.insert(Box<int>{1, 1, 2, 2}, static_cast<int>(i));
        REQUIRE(added.ok()); handles[i] = added.handle;
    }
    for (int i = 0; i < 32; ++i)
    {
        CHECK(tree.update(handles[0], Box<int>{1, 1, 2, 2}) == Status::Ok);
        CHECK(tree.setFilter(handles[0], {}) == Status::Ok);
    }
    CHECK(tree.update(handles[0], Box<int>{33, 33, 34, 34}) == Status::Ok);
    MutationProbe::reset();
    for (int i = 0; i < 3; ++i)
        CHECK(tree.update(handles[1], Box<int>{49, 49, 50, 50}) == Status::CapacityExhausted);
    CHECK(MutationProbe::splitAttempts == 3);
    CHECK((tree.rect(handles[1]) == Box<int>{1, 1, 2, 2}));
    REQUIRE(tree.reserve({.nodes = 64}) == Status::Ok);
    CHECK(tree.update(handles[1], Box<int>{49, 49, 50, 50}) == Status::Ok);
    CHECK(tree.stats().nodes > 1);
    for (auto handle : handles) CHECK(tree.valid(handle));
}

void coarseAncestorCaches()
{
    using I = QuadTree::Index<int, int, MutationProbe>;
    constexpr int coarse = 2000, small = 64;
    TestResource resource;
    auto made = I::create({.extent = QuadTree::Extent::Fixed, .root = Box<int>{0, 0, 1024, 1024},
        .smallSetThreshold = 0}, &resource);
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    std::vector<QuadTree::BuildEntry<int, int>> input;
    for (int i = 0; i < coarse; ++i)
        input.push_back({{0, 0, 1024, 1024}, i, {2, 2}});
    for (int i = 0; i < small; ++i)
    {
        const int x = 32 + (i % 8) * 112, y = 32 + (i / 8) * 112;
        input.push_back({{x, y, x + 8, y + 8}, coarse + i, {1, 1}});
    }
    QuadTree::Workspace<int> scratch(&resource);
    REQUIRE(scratch.reserve(input.size()) == Status::Ok);
    std::vector<I::HandleType> handles(input.size());
    REQUIRE(tree.build(input, handles, {.workspace = &scratch}) == Status::Ok);
    CHECK(tree.stats().nodes > 1);
    const auto allocations = resource.allocations;
    resource.failAll = true;
    MutationProbe::reset();
    for (int i = 0; i < 4000; ++i)
        CHECK(tree.update(handles[coarse], Box<int>{32 + i % 2, 32, 40, 40}) == Status::Ok);
    CHECK(MutationProbe::splitEntries == 0);
    CHECK(MutationProbe::refitEntries <= 8 * 4000);
    CHECK(tree.setFilter(handles[0], {4, 4}) == Status::Ok);
    CHECK(tree.update(handles[coarse], Box<int>{33, 32, 40, 40}) == Status::Ok);
    const auto query_unique = [&](Filter f, const Box<int>& box, int expected) noexcept
    {
        int reports = 0;
        CHECK(tree.query(box, f, [&](const auto&) noexcept { ++reports; return Continue; }).complete());
        CHECK(reports == expected);
    };
    query_unique({4, 4}, {800, 800, 801, 801}, 1);
    CHECK(tree.setFilter(handles[0], {2, 2}) == Status::Ok);
    query_unique({4, 4}, {800, 800, 801, 801}, 0);
    // Both changed own caches must stay conservative when moving between a
    // child and its coarse ancestor, not just between disjoint leaf paths.
    CHECK(tree.setFilter(handles[coarse], {8, 8}) == Status::Ok);
    CHECK(tree.update(handles[coarse], Box<int>{0, 0, 1024, 1024}) == Status::Ok);
    query_unique({8, 8}, {800, 800, 801, 801}, 1);
    CHECK(tree.update(handles[coarse], Box<int>{32, 32, 40, 40}) == Status::Ok);
    query_unique({8, 8}, {36, 36, 36, 36}, 1);
    query_unique({8, 8}, {800, 800, 801, 801}, 0);
    CHECK(resource.allocations == allocations);
}

void orderedMovedSources()
{
    auto made = Tree<int>::create({.smallSetThreshold = 0});
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    const std::array<std::uint64_t, 7> ranks{10, 50, 20, 90, 30, 70, 60};
    std::vector<Tree<int>::HandleType> handles;
    for (std::size_t i = 0; i < ranks.size(); ++i)
    {
        const auto added = tree.insert(Box<int>{0, 0, 3, 3}, static_cast<int>(i), {}, ranks[i]);
        REQUIRE(added.ok()); handles.push_back(added.handle);
    }
    QuadTree::Workspace<int> workspace;
    REQUIRE(workspace.reserve(7) == Status::Ok);
    const std::vector<RankPair> expected{{10, 50}, {20, 50}, {30, 50}, {50, 60}, {50, 70}, {50, 90}};
    const std::array<std::size_t, 11> prefix{0, 0, 0, 0, 1, 2, 3, 3, 3, 6, 6};
    for (std::size_t limit = 0; limit < prefix.size(); ++limit)
    {
        std::vector<RankPair> pairs;
        const auto result = tree.forEachPairInvolving(std::array{handles[1]}, [&](const auto& a, const auto& b) noexcept
            { pairs.emplace_back(*a.rank, *b.rank); return Continue; },
            {.ordered = true, .workspace = &workspace, .budget = {.candidateTests = limit}},
            [](const auto& a, const auto& b) noexcept { CHECK(*a.rank < *b.rank); return true; });
        CHECK(result.status == (limit >= 9 ? Status::Ok : Status::BudgetExhausted));
        CHECK(result.counters.candidateTests == std::min<std::size_t>(limit, 9));
        CHECK(result.counters.predicateCalls == (limit > 3 ? std::min<std::size_t>(limit, 9) - 3 : 0));
        CHECK(pairs.size() == prefix[limit] && result.counters.reports == pairs.size());
        CHECK(std::equal(pairs.begin(), pairs.end(), expected.begin()));
    }
    for (std::uint64_t limit = 0; limit <= 3; ++limit)
    {
        std::vector<RankPair> pairs;
        const auto result = tree.forEachPairInvolving(std::array{handles[1]}, [&](const auto& a, const auto& b) noexcept
            { pairs.emplace_back(*a.rank, *b.rank); return Continue; },
            {.ordered = true, .workspace = &workspace, .budget = {.nodeVisits = limit}});
        CHECK(result.status == (limit >= 2 ? Status::Ok : Status::BudgetExhausted));
        CHECK(pairs.size() == (limit == 0 ? 0u : limit == 1 ? 3u : 6u));
        CHECK(std::equal(pairs.begin(), pairs.end(), expected.begin()));
    }
    for (std::size_t stop = 1; stop <= expected.size(); ++stop)
    {
        std::vector<RankPair> pairs;
        const auto result = tree.forEachPairInvolving(std::array{handles[1]}, [&](const auto& a, const auto& b) noexcept
            { pairs.emplace_back(*a.rank, *b.rank); return pairs.size() == stop ? Stop : Continue; },
            {.ordered = true, .workspace = &workspace});
        CHECK(result.status == Status::Stopped && result.counters.reports == stop);
        CHECK(std::equal(pairs.begin(), pairs.end(), expected.begin()));
    }
    // Source-only epoch marks must not become dirty entries on the next call.
    for (bool ordered : {false, true})
    {
        std::size_t reports = 0;
        CHECK(tree.forEachPairInvolving(std::array{handles[0]}, [&](const auto& a, const auto& b) noexcept
        {
            CHECK(a.payload == 0 || b.payload == 0);
            ++reports; return Continue;
        }, {.ordered = ordered, .workspace = &workspace}).complete());
        CHECK(reports == 6);
    }
    CHECK(tree.forEachPairSelected([](const auto& a) noexcept { return a.payload == 0; },
        [](const auto& a) noexcept { return a.payload != 0; },
        [](const auto&, const auto&) noexcept { return Continue; }, {.workspace = &workspace}).complete());
    std::size_t reports = 0;
    CHECK(tree.forEachPairInvolving(std::array{handles[1]}, [&](const auto&, const auto&) noexcept
        { ++reports; return Continue; }, {.ordered = true, .workspace = &workspace}).complete());
    CHECK(reports == 6);
    REQUIRE(tree.insert(Box<int>{0, 0, 3, 3}, 7, {0, 0}).ok());
    REQUIRE(workspace.reserve(8) == Status::Ok);
    std::size_t callbacks = 0;
    const auto missing = tree.forEachPairInvolving(std::array{handles[1]},
        [&](const auto&, const auto&) noexcept { ++callbacks; return Stop; },
        {.ordered = true, .workspace = &workspace},
        [&](const auto&, const auto&) noexcept { ++callbacks; return true; });
    CHECK(missing.status == Status::MissingRank && callbacks == 0);
}

void orderedMovedWork()
{
    constexpr int count = 8192;
    TestResource resource;
    auto made = Tree<int>::create({.smallSetThreshold = 0}, &resource);
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    QuadTree::Workspace<int> workspace(&resource);
    REQUIRE(workspace.reserve(count) == Status::Ok);
    std::vector<QuadTree::BuildEntry<int, int>> input;
    for (int i = 0; i < count; ++i)
    {
        const int x = (i % 128) * 16, y = (i / 128) * 16;
        input.push_back({{x, y, x + 20, y + 20}, i, {}, i == 0 ? UINT64_MAX : std::uint64_t(count - i - 1)});
    }
    std::vector<Tree<int>::HandleType> handles(input.size());
    REQUIRE(tree.build(input, handles, {.workspace = &workspace}) == Status::Ok);
    const auto allocations = resource.allocations;
    resource.failAll = true;
    std::vector<RankPair> pairs, expected;
    for (std::size_t i = 1; i < input.size(); ++i)
        if (overlap(input[0].rect, input[i].rect, Boundary::Default))
            expected.emplace_back(*input[i].rank, *input[0].rank);
    std::sort(expected.begin(), expected.end());
    const auto result = tree.forEachPairInvolving(std::array{handles[0]}, [&](const auto& a, const auto& b) noexcept
        { pairs.emplace_back(*a.rank, *b.rank); return Continue; }, {.ordered = true, .workspace = &workspace});
    CHECK(result.complete() && pairs == expected);
    CHECK(result.counters.nodeVisits < 512 && result.counters.candidateTests < 256);
    CHECK(resource.allocations == allocations);
    resource.failAll = false;
    // A highest-ranked mover in a pile needs n-1 rows, but each clean row can
    // query S directly rather than scan all n entries again.
    input.resize(2048);
    handles.resize(input.size());
    for (std::size_t i = 0; i < input.size(); ++i)
        input[i] = {{0, 0, 1, 1}, static_cast<int>(i), {}, i};
    REQUIRE(tree.build(input, handles, {.workspace = &workspace}) == Status::Ok);
    resource.failAll = true;
    pairs.clear();
    const auto pile = tree.forEachPairInvolving(std::array{handles.back()}, [&](const auto& a, const auto& b) noexcept
        { pairs.emplace_back(*a.rank, *b.rank); return Continue; }, {.ordered = true, .workspace = &workspace});
    CHECK(pile.complete() && pairs.size() == input.size() - 1);
    CHECK(std::is_sorted(pairs.begin(), pairs.end()));
    CHECK(pile.counters.nodeVisits == 1 && pile.counters.candidateTests == 2 * (input.size() - 1));
}

void coincidentMotion()
{
    auto made = Tree<int>::create({.extent = QuadTree::Extent::Fixed, .root = Box<int>{0, 0, 1024, 1024},
        .smallSetThreshold = 0});
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    std::vector<Tree<int>::HandleType> handles;
    for (int i = 0; i < 128; ++i)
    {
        const auto added = tree.insert(Box<int>{0, 0, 1, 1}, int(i));
        REQUIRE(added.ok()); handles.push_back(added.handle);
    }
    CHECK(tree.stats().nodes == 1);
    auto result = tree.forEachPair([](const auto&, const auto&) noexcept { return Continue; });
    CHECK(result.counters.candidateTests == 8128 && result.counters.reports == 8128);
    for (std::size_t i = 0; i < handles.size(); ++i)
    {
        const int x = static_cast<int>(i % 16) * 64, y = static_cast<int>(i / 16) * 64;
        CHECK(tree.update(handles[i], Box<int>{x, y, x + 1, y + 1}) == Status::Ok);
    }
    CHECK(tree.stats().nodes > 1);
    result = tree.forEachPair([](const auto&, const auto&) noexcept { return Continue; });
    CHECK(result.complete() && result.counters.reports == 0 && result.counters.candidateTests < 1024);
}

void concurrency()
{
    auto made = Tree<int>::create();
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    for (int i = 0; i < 80; ++i) REQUIRE(tree.insert(Box<int>{i, 0, i + 2, 2}, int(i), {}, std::uint64_t(i)).ok());
    const Tree<int>& read_only = tree;
    std::array<std::size_t, 4> reports{};
    std::array<std::thread, 4> threads;
    for (std::size_t t = 0; t < threads.size(); ++t)
        threads[t] = std::thread([&, t]
        {
            QuadTree::Workspace<int> outer, nested;
            if (outer.reserve(80) != Status::Ok || nested.reserve(80) != Status::Ok) std::abort();
            const auto result = read_only.forEachPair([&](const auto& a, const auto&) noexcept
            {
                ++reports[t];
                const auto queried = read_only.queryPartners(a.handle, [](const auto&) noexcept { return Continue; },
                    {.ordered = true, .workspace = &nested});
                if (!queried.complete()) std::abort();
                return Continue;
            }, {.ordered = true, .workspace = &outer});
            if (!result.complete()) std::abort();
        });
    for (auto& thread : threads) thread.join();
    for (auto count : reports) CHECK(count == 79);
}

void uninstrumented()
{
    using I = QuadTree::Index<int, int, QuadTree::Unchecked, false>;
    auto made = I::create();
    REQUIRE(made.ok());
    auto tree = std::move(made).value();
    REQUIRE(tree.insert(Box<int>{0, 0, 3, 3}, 1).ok());
    REQUIRE(tree.insert(Box<int>{1, 1, 2, 2}, 2).ok());
    struct BorrowedPredicate
    {
        BorrowedPredicate() = default;
        BorrowedPredicate(const BorrowedPredicate&) = delete;
        bool operator()(const I::View&, const I::View&) const noexcept { return true; }
    } predicate;
    std::size_t reports = 0;
    auto visitor = [&](const auto&, const auto&) noexcept { ++reports; return Continue; };
    const auto complete = tree.forEachPair(visitor, {}, predicate);
    CHECK(complete.complete() && reports == 1 && complete.counters.reports == 0 && complete.counters.candidateTests == 0);
    CHECK(tree.forEachPair(visitor, {.budget = {.candidateTests = 0}}, predicate).status == Status::BudgetExhausted);
    CHECK(reports == 1);
}

struct ConstPayloadEntry
{
    Box<int> rect;
    const int payload;
    Filter filter;
    std::optional<std::uint64_t> rank;
};
template<typename R>
concept CanConsume = requires(Tree<int>& tree, R& range) { tree.buildConsume(range); };
static_assert(!CanConsume<std::array<ConstPayloadEntry, 1>>);
static_assert(!CanConsume<const std::array<QuadTree::BuildEntry<int, int>, 1>>);
static_assert(CanConsume<std::array<QuadTree::BuildEntry<int, int>, 1>>);

struct ThrowVisitor { QuadTree::Visit operator()(const Tree<int>::View&, const Tree<int>::View&) const { return Continue; } };
struct BoolVisitor { bool operator()(const Tree<int>::View&, const Tree<int>::View&) const noexcept { return true; } };
template<typename V>
concept PairVisitor = requires(const Tree<int>& tree, V visitor) { tree.forEachPair(visitor); };
static_assert(!PairVisitor<ThrowVisitor> && !PairVisitor<BoolVisitor>);
static_assert(std::is_nothrow_move_constructible_v<Tree<int>> && !std::is_copy_constructible_v<Tree<int>>);
static_assert(std::is_nothrow_move_assignable_v<QuadTree::Workspace<int>>);
static_assert(!std::same_as<Tree<int>::HandleType, Tree<float>::HandleType>);
static_assert(!std::same_as<Tree<int>::HandleType, QuadTree::Index<int, int>::HandleType>);
static_assert(sizeof(Tree<int>::HandleType) == 16 && std::is_trivially_copyable_v<Tree<int>::HandleType>);
} // namespace

int main()
{
    contracts(); budgets(); crossAndSelections(); hardCapacity(); failureInjection(); preparedSmallBuild(); identities();
    payloadsAndMoves(); cacheAndChurn(); mutationWork(); coarseAncestorCaches();
    orderedMovedSources(); orderedMovedWork(); coincidentMotion(); concurrency(); uninstrumented();
    numeric<std::int32_t>(); numeric<std::int64_t>(); numeric<float>(); numeric<double>();
    for (auto boundary : {Boundary::Default, Boundary::TouchInclusive})
        for (auto extent : {QuadTree::Extent::Fixed, QuadTree::Extent::Adaptive, QuadTree::Extent::Snapshot})
        {
            randomized<std::int32_t>(boundary, extent);
            randomized<std::int64_t>(boundary, extent);
            randomized<float>(boundary, extent);
            randomized<double>(boundary, extent);
        }
    std::printf("index-test: %d failures\n", failures);
    return failures == 0 ? 0 : 1;
}
