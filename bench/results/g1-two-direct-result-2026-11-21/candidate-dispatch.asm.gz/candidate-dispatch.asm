
# candidate unordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, false>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-direct-two.wiJig0/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000edeb0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   edeb0:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   edeb7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edebb:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   edec3:	48 8b 2a             	mov    (%rdx),%rbp
   edec6:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   edece:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   eded2:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   ededa:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   edee2:	49 89 ff             	mov    %rdi,%r15
   edee5:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   edeed:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   edef4:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   edef9:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   edf02:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   edf0a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   edf0e:	0f 11 07             	movups %xmm0,(%rdi)
   edf11:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   edf15:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   edf19:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   edf1d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   edf21:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   edf25:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   edf29:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   edf2d:	48 89 14 24          	mov    %rdx,(%rsp)
   edf31:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   edf35:	e8 26 12 06 00       	call   14f160 <_ZN5bench6memory11allocationsEv>
   edf3a:	80 3d 37 13 08 00 00 	cmpb   $0x0,0x81337(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   edf41:	4c 8b 1c 24          	mov    (%rsp),%r11
   edf45:	49 89 c6             	mov    %rax,%r14
   edf48:	0f 84 51 0e 00 00    	je     eed9f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xeef>
   edf4e:	0f 31                	rdtsc
   edf50:	48 c1 e2 20          	shl    $0x20,%rdx
   edf54:	48 09 d0             	or     %rdx,%rax
   edf57:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   edf5f:	49 8b 13             	mov    (%r11),%rdx
   edf62:	49 3b 53 08          	cmp    0x8(%r11),%rdx
   edf66:	0f 84 1f 09 00 00    	je     ee88b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9db>
   edf6c:	49 29 ec             	sub    %rbp,%r12
   edf6f:	48 c7 04 24 00 00 00 00 	movq   $0x0,(%rsp)
   edf77:	66 0f ef ed          	pxor   %xmm5,%xmm5
   edf7b:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   edf83:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   edf8b:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   edf94:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   edf9d:	c7 44 24 1c 00 00 00 00 	movl   $0x0,0x1c(%rsp)
   edfa5:	4c 89 9c 24 88 00 00 00 	mov    %r11,0x88(%rsp)
   edfad:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   edfb5:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   edfbd:	45 31 ed             	xor    %r13d,%r13d
   edfc0:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   edfc8:	45 31 f6             	xor    %r14d,%r14d
   edfcb:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   edfd0:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   edfd5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edfe0:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   edfe5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   edfe9:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   edfed:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   edff5:	48 8b 28             	mov    (%rax),%rbp
   edff8:	4c 8b 60 08          	mov    0x8(%rax),%r12
   edffc:	49 29 ec             	sub    %rbp,%r12
   edfff:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
   ee004:	49 c1 fc 04          	sar    $0x4,%r12
   ee008:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   ee00f:	74 13                	je     ee024 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x174>
   ee011:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ee018:	3b 83 b8 02 00 00    	cmp    0x2b8(%rbx),%eax
   ee01e:	0f 84 b8 05 00 00    	je     ee5dc <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x72c>
   ee024:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   ee02c:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee030:	31 f6                	xor    %esi,%esi
   ee032:	66 0f 6f 3d 86 a8 06 00 	movdqa 0x6a886(%rip),%xmm7        # 1588c0 <C.66.5+0x2a0>
   ee03a:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   ee042:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ee04a:	ba 88 01 00 00       	mov    $0x188,%edx
   ee04f:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   ee056:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   ee05b:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   ee063:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   ee06b:	66 48 0f 6e c0       	movq   %rax,%xmm0
   ee070:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   ee078:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   ee07c:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   ee085:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   ee08d:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   ee096:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   ee09e:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   ee0a7:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   ee0af:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   ee0b7:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   ee0bc:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   ee0c4:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   ee0c9:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   ee0d1:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   ee0d6:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   ee0de:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   ee0ea:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   ee0f6:	e8 15 90 f1 ff       	call   7110 <memset@plt>
   ee0fb:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   ee101:	66 0f ef c9          	pxor   %xmm1,%xmm1
   ee105:	66 0f 6f 05 c3 a7 06 00 	movdqa 0x6a7c3(%rip),%xmm0        # 1588d0 <C.66.5+0x2b0>
   ee10d:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   ee113:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   ee119:	66 0f ef ed          	pxor   %xmm5,%xmm5
   ee11d:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ee124:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   ee12c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ee131:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   ee139:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   ee141:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   ee149:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   ee155:	48 89 9c 24 d8 01 00 00 	mov    %rbx,0x1d8(%rsp)
   ee15d:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   ee169:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   ee175:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   ee181:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   ee18d:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   ee199:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   ee1a4:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   ee1ac:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   ee1b7:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   ee1c3:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   ee1cb:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   ee1d7:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   ee1e2:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   ee1ea:	48 89 9c 24 78 02 00 00 	mov    %rbx,0x278(%rsp)
   ee1f2:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   ee1fe:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   ee20a:	48 89 9c 24 90 02 00 00 	mov    %rbx,0x290(%rsp)
   ee212:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   ee21e:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   ee226:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   ee22e:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   ee236:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   ee23e:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   ee246:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   ee252:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   ee25a:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   ee263:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   ee26b:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   ee273:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   ee27c:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   ee284:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   ee28c:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   ee295:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   ee29d:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ee2a4:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   ee2ac:	48 89 9c 24 a8 02 00 00 	mov    %rbx,0x2a8(%rsp)
   ee2b4:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   ee2c0:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   ee2cc:	48 89 9c 24 c0 02 00 00 	mov    %rbx,0x2c0(%rsp)
   ee2d4:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   ee2e0:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   ee2ec:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   ee2f8:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   ee303:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   ee30f:	48 89 9c 24 60 03 00 00 	mov    %rbx,0x360(%rsp)
   ee317:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   ee322:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   ee32d:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   ee339:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   ee341:	48 89 9c 24 00 04 00 00 	mov    %rbx,0x400(%rsp)
   ee349:	48 89 9c 24 18 04 00 00 	mov    %rbx,0x418(%rsp)
   ee351:	48 89 9c 24 30 04 00 00 	mov    %rbx,0x430(%rsp)
   ee359:	48 89 9c 24 48 04 00 00 	mov    %rbx,0x448(%rsp)
   ee361:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   ee369:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   ee371:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   ee379:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   ee381:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ee389:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   ee390:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   ee399:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   ee3a4:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   ee3ab:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   ee3b2:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   ee3bd:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   ee3c4:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   ee3cc:	e8 0f 07 01 00       	call   feae0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ee3d1:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   ee3d8:	0f 85 92 06 00 00    	jne    eea70 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbc0>
   ee3de:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   ee3e7:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   ee3ef:	48 89 5b 50          	mov    %rbx,0x50(%rbx)
   ee3f3:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   ee3fb:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   ee404:	c6 83 ec 00 00 00 00 	movb   $0x0,0xec(%rbx)
   ee40b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
   ee40f:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   ee418:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   ee420:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   ee424:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   ee42d:	48 89 43 48          	mov    %rax,0x48(%rbx)
   ee431:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   ee438:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
   ee43c:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   ee445:	48 89 83 98 00 00 00 	mov    %rax,0x98(%rbx)
   ee44c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ee451:	0f 11 43 38          	movups %xmm0,0x38(%rbx)
   ee455:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee459:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
   ee460:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   ee469:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
   ee470:	0f 11 83 a8 00 00 00 	movups %xmm0,0xa8(%rbx)
   ee477:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   ee47f:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   ee488:	48 c7 43 58 00 00 00 00 	movq   $0x0,0x58(%rbx)
   ee490:	0f 11 83 b1 00 00 00 	movups %xmm0,0xb1(%rbx)
   ee497:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee49b:	0f 11 83 d0 00 00 00 	movups %xmm0,0xd0(%rbx)
   ee4a2:	48 c7 43 60 00 00 00 00 	movq   $0x0,0x60(%rbx)
   ee4aa:	48 c7 43 68 00 00 00 00 	movq   $0x0,0x68(%rbx)
   ee4b2:	48 c7 43 70 00 00 00 00 	movq   $0x0,0x70(%rbx)
   ee4ba:	48 c7 43 78 00 00 00 00 	movq   $0x0,0x78(%rbx)
   ee4c2:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   ee4cc:	c6 83 94 00 00 00 00 	movb   $0x0,0x94(%rbx)
   ee4d3:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   ee4dd:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   ee4e8:	c7 83 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%rbx)
   ee4f2:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   ee4f9:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   ee502:	48 89 9b f0 00 00 00 	mov    %rbx,0xf0(%rbx)
   ee509:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
   ee50f:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   ee516:	48 c7 83 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rbx)
   ee521:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   ee528:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   ee52d:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   ee534:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   ee53b:	48 c7 83 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rbx)
   ee546:	48 89 9b 08 01 00 00 	mov    %rbx,0x108(%rbx)
   ee54d:	48 c7 83 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rbx)
   ee558:	48 c7 83 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rbx)
   ee563:	48 89 9b 20 01 00 00 	mov    %rbx,0x120(%rbx)
   ee56a:	48 c7 83 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rbx)
   ee575:	48 c7 83 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rbx)
   ee580:	48 89 9b 38 01 00 00 	mov    %rbx,0x138(%rbx)
   ee587:	48 c7 83 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rbx)
   ee592:	48 c7 83 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rbx)
   ee59d:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   ee5a8:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   ee5b2:	c6 83 80 01 00 00 01 	movb   $0x1,0x180(%rbx)
   ee5b9:	89 83 b8 02 00 00    	mov    %eax,0x2b8(%rbx)
   ee5bf:	0f 11 83 50 01 00 00 	movups %xmm0,0x150(%rbx)
   ee5c6:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   ee5cf:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   ee5d7:	e8 04 05 01 00       	call   feae0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   ee5dc:	4c 39 a3 c0 02 00 00 	cmp    %r12,0x2c0(%rbx)
   ee5e3:	0f 82 47 04 00 00    	jb     eea30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb80>
   ee5e9:	48 8b 93 78 02 00 00 	mov    0x278(%rbx),%rdx
   ee5f0:	4c 8b 93 70 02 00 00 	mov    0x270(%rbx),%r10
   ee5f7:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   ee601:	48 89 d1             	mov    %rdx,%rcx
   ee604:	4c 29 d1             	sub    %r10,%rcx
   ee607:	48 89 c8             	mov    %rcx,%rax
   ee60a:	48 c1 f8 03          	sar    $0x3,%rax
   ee60e:	48 0f af c7          	imul   %rdi,%rax
   ee612:	4c 39 e0             	cmp    %r12,%rax
   ee615:	0f 82 a5 03 00 00    	jb     ee9c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb10>
   ee61b:	49 39 c4             	cmp    %rax,%r12
   ee61e:	73 16                	jae    ee636 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   ee620:	49 6b c4 38          	imul   $0x38,%r12,%rax
   ee624:	49 01 c2             	add    %rax,%r10
   ee627:	4c 39 d2             	cmp    %r10,%rdx
   ee62a:	74 07                	je     ee633 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x783>
   ee62c:	4c 89 93 78 02 00 00 	mov    %r10,0x278(%rbx)
   ee633:	4c 89 d2             	mov    %r10,%rdx
   ee636:	48 8b b3 70 02 00 00 	mov    0x270(%rbx),%rsi
   ee63d:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   ee643:	74 6c                	je     ee6b1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x801>
   ee645:	48 89 f0             	mov    %rsi,%rax
   ee648:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee64c:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   ee650:	31 c9                	xor    %ecx,%ecx
   ee652:	66 90                	xchg   %ax,%ax
   ee654:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee65f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee66a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee675:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ee680:	f3 0f 6f 4d 00       	movdqu 0x0(%rbp),%xmm1
   ee685:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   ee689:	48 83 c5 10          	add    $0x10,%rbp
   ee68d:	48 83 c0 38          	add    $0x38,%rax
   ee691:	89 48 d8             	mov    %ecx,-0x28(%rax)
   ee694:	48 83 c1 01          	add    $0x1,%rcx
   ee698:	0f 11 40 e8          	movups %xmm0,-0x18(%rax)
   ee69c:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   ee6a4:	0f 11 48 c8          	movups %xmm1,-0x38(%rax)
   ee6a8:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
   ee6ac:	4c 39 e1             	cmp    %r12,%rcx
   ee6af:	72 cf                	jb     ee680 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7d0>
   ee6b1:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   ee6bd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee6c1:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   ee6c9:	48 39 d6             	cmp    %rdx,%rsi
   ee6cc:	0f 84 b6 03 00 00    	je     eea88 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd8>
   ee6d2:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   ee6dc:	48 29 f2             	sub    %rsi,%rdx
   ee6df:	48 c1 fa 03          	sar    $0x3,%rdx
   ee6e3:	48 0f af d0          	imul   %rax,%rdx
   ee6e7:	48 39 53 38          	cmp    %rdx,0x38(%rbx)
   ee6eb:	0f 82 1f 04 00 00    	jb     eeb10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc60>
   ee6f1:	48 83 ec 20          	sub    $0x20,%rsp
   ee6f5:	48 8d 8b 88 01 00 00 	lea    0x188(%rbx),%rcx
   ee6fc:	48 8d b3 70 02 00 00 	lea    0x270(%rbx),%rsi
   ee703:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   ee70c:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   ee710:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   ee719:	0f 11 04 24          	movups %xmm0,(%rsp)
   ee71d:	e8 0e 32 fe ff       	call   d1930 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   ee722:	48 83 c4 20          	add    $0x20,%rsp
   ee726:	84 c0                	test   %al,%al
   ee728:	0f 85 bc 06 00 00    	jne    eedea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf3a>
   ee72e:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   ee737:	0f 84 e3 01 00 00    	je     ee920 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa70>
   ee73d:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   ee742:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ee74a:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   ee752:	48 89 de             	mov    %rbx,%rsi
   ee755:	e8 d6 f0 ff ff       	call   ed830 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   ee75a:	8b 74 24 1c          	mov    0x1c(%rsp),%esi
   ee75e:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   ee765:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   ee76f:	48 8b bc 24 38 03 00 00 	mov    0x338(%rsp),%rdi
   ee777:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   ee77d:	39 c6                	cmp    %eax,%esi
   ee77f:	48 8b 94 24 c8 00 00 00 	mov    0xc8(%rsp),%rdx
   ee787:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   ee790:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   ee799:	0f 43 c6             	cmovae %esi,%eax
   ee79c:	48 01 3c 24          	add    %rdi,(%rsp)
   ee7a0:	48 8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%rdi
   ee7a8:	48 01 7c 24 08       	add    %rdi,0x8(%rsp)
   ee7ad:	4c 01 ea             	add    %r13,%rdx
   ee7b0:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   ee7b4:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   ee7b8:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   ee7c1:	41 89 47 38          	mov    %eax,0x38(%r15)
   ee7c5:	48 8b 04 24          	mov    (%rsp),%rax
   ee7c9:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   ee7cd:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   ee7d3:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   ee7d8:	49 89 47 40          	mov    %rax,0x40(%r15)
   ee7dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ee7e1:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   ee7e6:	49 89 47 48          	mov    %rax,0x48(%r15)
   ee7ea:	48 89 d0             	mov    %rdx,%rax
   ee7ed:	48 c1 e8 1e          	shr    $0x1e,%rax
   ee7f1:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   ee7f6:	48 31 d0             	xor    %rdx,%rax
   ee7f9:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   ee7fe:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   ee808:	48 0f af c2          	imul   %rdx,%rax
   ee80c:	48 89 c2             	mov    %rax,%rdx
   ee80f:	48 c1 ea 1b          	shr    $0x1b,%rdx
   ee813:	48 31 d0             	xor    %rdx,%rax
   ee816:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   ee820:	48 0f af c2          	imul   %rdx,%rax
   ee824:	48 89 c2             	mov    %rax,%rdx
   ee827:	48 c1 ea 1f          	shr    $0x1f,%rdx
   ee82b:	48 31 d0             	xor    %rdx,%rax
   ee82e:	48 01 44 24 10       	add    %rax,0x10(%rsp)
   ee833:	45 84 f6             	test   %r14b,%r14b
   ee836:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   ee83b:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   ee843:	49 89 77 50          	mov    %rsi,0x50(%r15)
   ee847:	44 0f 44 f0          	cmove  %eax,%r14d
   ee84b:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   ee853:	49 83 c5 01          	add    $0x1,%r13
   ee857:	48 8b 10             	mov    (%rax),%rdx
   ee85a:	45 88 77 68          	mov    %r14b,0x68(%r15)
   ee85e:	48 8b 40 08          	mov    0x8(%rax),%rax
   ee862:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   ee867:	48 29 d0             	sub    %rdx,%rax
   ee86a:	48 c1 f8 03          	sar    $0x3,%rax
   ee86e:	48 0f af c1          	imul   %rcx,%rax
   ee872:	49 39 c5             	cmp    %rax,%r13
   ee875:	0f 82 65 f7 ff ff    	jb     edfe0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   ee87b:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   ee883:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   ee88b:	80 3d e6 09 08 00 00 	cmpb   $0x0,0x809e6(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ee892:	0f 84 21 05 00 00    	je     eedb9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf09>
   ee898:	0f 31                	rdtsc
   ee89a:	48 c1 e2 20          	shl    $0x20,%rdx
   ee89e:	48 09 d0             	or     %rdx,%rax
   ee8a1:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   ee8a9:	0f 88 d2 04 00 00    	js     eed81 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xed1>
   ee8af:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee8b3:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ee8b8:	f2 0f 59 05 70 09 08 00 	mulsd  0x80970(%rip),%xmm0        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ee8c0:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ee8c5:	49 89 07             	mov    %rax,(%r15)
   ee8c8:	e8 93 08 06 00       	call   14f160 <_ZN5bench6memory11allocationsEv>
   ee8cd:	4c 29 f0             	sub    %r14,%rax
   ee8d0:	49 89 47 58          	mov    %rax,0x58(%r15)
   ee8d4:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   ee8dc:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   ee8e5:	0f 85 f2 04 00 00    	jne    eeddd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf2d>
   ee8eb:	4c 89 f8             	mov    %r15,%rax
   ee8ee:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   ee8f6:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   ee8fe:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   ee906:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   ee90e:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   ee916:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   ee91d:	c3                   	ret
   ee91e:	66 90                	xchg   %ax,%ax
   ee920:	80 3d 51 09 08 00 00 	cmpb   $0x0,0x80951(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ee927:	0f 84 db 03 00 00    	je     eed08 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe58>
   ee92d:	0f 31                	rdtsc
   ee92f:	48 c1 e2 20          	shl    $0x20,%rdx
   ee933:	48 09 d0             	or     %rdx,%rax
   ee936:	48 89 c5             	mov    %rax,%rbp
   ee939:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   ee93e:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   ee946:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   ee94e:	48 89 de             	mov    %rbx,%rsi
   ee951:	e8 da ee ff ff       	call   ed830 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   ee956:	f2 0f 10 0d d2 08 08 00 	movsd  0x808d2(%rip),%xmm1        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   ee95e:	48 89 e8             	mov    %rbp,%rax
   ee961:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   ee969:	0f 88 61 03 00 00    	js     eecd0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe20>
   ee96f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee973:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ee978:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   ee97c:	80 3d f5 08 08 00 00 	cmpb   $0x0,0x808f5(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   ee983:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ee988:	49 89 47 08          	mov    %rax,0x8(%r15)
   ee98c:	0f 84 5e 03 00 00    	je     eecf0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe40>
   ee992:	0f 31                	rdtsc
   ee994:	48 c1 e2 20          	shl    $0x20,%rdx
   ee998:	48 09 d0             	or     %rdx,%rax
   ee99b:	48 29 e8             	sub    %rbp,%rax
   ee99e:	0f 88 0c 03 00 00    	js     eecb0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe00>
   ee9a4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee9a8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   ee9ad:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   ee9b1:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   ee9b6:	49 89 47 10          	mov    %rax,0x10(%r15)
   ee9ba:	e9 9b fd ff ff       	jmp    ee75a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8aa>
   ee9bf:	90                   	nop
   ee9c0:	48 8b b3 80 02 00 00 	mov    0x280(%rbx),%rsi
   ee9c7:	4d 89 e3             	mov    %r12,%r11
   ee9ca:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   ee9d4:	49 29 c3             	sub    %rax,%r11
   ee9d7:	48 89 f7             	mov    %rsi,%rdi
   ee9da:	48 29 d7             	sub    %rdx,%rdi
   ee9dd:	48 c1 ff 03          	sar    $0x3,%rdi
   ee9e1:	49 0f af f9          	imul   %r9,%rdi
   ee9e5:	4c 39 df             	cmp    %r11,%rdi
   ee9e8:	0f 82 42 01 00 00    	jb     eeb30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc80>
   ee9ee:	4c 89 d9             	mov    %r11,%rcx
   ee9f1:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ee9f5:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   ee9f9:	48 89 d0             	mov    %rdx,%rax
   ee9fc:	0f 1f 40 00          	nopl   0x0(%rax)
   eea00:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   eea04:	48 83 c0 38          	add    $0x38,%rax
   eea08:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   eea0c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   eea10:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   eea14:	48 83 e9 01          	sub    $0x1,%rcx
   eea18:	75 e6                	jne    eea00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb50>
   eea1a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   eea1e:	4c 01 da             	add    %r11,%rdx
   eea21:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   eea28:	e9 09 fc ff ff       	jmp    ee636 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   eea2d:	0f 1f 00             	nopl   (%rax)
   eea30:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eea34:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   eea3c:	48 8d bb 88 01 00 00 	lea    0x188(%rbx),%rdi
   eea43:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   eea4b:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   eea53:	e8 a8 4a 02 00       	call   113500 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   eea58:	84 c0                	test   %al,%al
   eea5a:	0f 85 8a 03 00 00    	jne    eedea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf3a>
   eea60:	4c 89 a3 c0 02 00 00 	mov    %r12,0x2c0(%rbx)
   eea67:	e9 7d fb ff ff       	jmp    ee5e9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x739>
   eea6c:	0f 1f 40 00          	nopl   0x0(%rax)
   eea70:	c6 83 80 01 00 00 00 	movb   $0x0,0x180(%rbx)
   eea77:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   eea7b:	e8 60 00 01 00       	call   feae0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   eea80:	e9 59 f9 ff ff       	jmp    ee3de <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x52e>
   eea85:	0f 1f 00             	nopl   (%rax)
   eea88:	48 83 bb c8 00 00 00 00 	cmpq   $0x0,0xc8(%rbx)
   eea90:	74 55                	je     eeae7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc37>
   eea92:	48 8b 93 80 00 00 00 	mov    0x80(%rbx),%rdx
   eea99:	48 85 d2             	test   %rdx,%rdx
   eea9c:	0f 85 73 02 00 00    	jne    eed15 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe65>
   eeaa2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   eeaa7:	66 0f 6f 05 d1 9d 06 00 	movdqa 0x69dd1(%rip),%xmm0        # 158880 <C.66.5+0x260>
   eeaaf:	c7 83 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%rbx)
   eeab9:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   eeac4:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   eeacb:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   eead6:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   eeae0:	0f 11 83 dc 00 00 00 	movups %xmm0,0xdc(%rbx)
   eeae7:	80 7b 08 00          	cmpb   $0x0,0x8(%rbx)
   eeaeb:	0f 84 3d fc ff ff    	je     ee72e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x87e>
   eeaf1:	80 bb 60 01 00 00 00 	cmpb   $0x0,0x160(%rbx)
   eeaf8:	0f 84 30 fc ff ff    	je     ee72e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x87e>
   eeafe:	c6 83 60 01 00 00 00 	movb   $0x0,0x160(%rbx)
   eeb05:	e9 24 fc ff ff       	jmp    ee72e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x87e>
   eeb0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   eeb10:	ba 10 00 00 00       	mov    $0x10,%edx
   eeb15:	48 8b 3d 44 07 08 00 	mov    0x80744(%rip),%rdi        # 16f260 <stderr@GLIBC_2.2.5>
   eeb1c:	48 8d 35 7d 7e 06 00 	lea    0x67e7d(%rip),%rsi        # 1569a0 <_IO_stdin_used+0x19a0>
   eeb23:	31 c0                	xor    %eax,%eax
   eeb25:	e8 16 88 f1 ff       	call   7340 <fprintf@plt>
   eeb2a:	e8 f1 85 f1 ff       	call   7120 <abort@plt>
   eeb2f:	90                   	nop
   eeb30:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   eeb3a:	48 29 c7             	sub    %rax,%rdi
   eeb3d:	4c 39 df             	cmp    %r11,%rdi
   eeb40:	0f 82 a8 e2 f1 ff    	jb     cdee <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   eeb46:	4c 39 d8             	cmp    %r11,%rax
   eeb49:	4c 89 df             	mov    %r11,%rdi
   eeb4c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   eeb54:	48 0f 43 f8          	cmovae %rax,%rdi
   eeb58:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   eeb60:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   eeb68:	48 01 c7             	add    %rax,%rdi
   eeb6b:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   eeb70:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   eeb7a:	48 39 c7             	cmp    %rax,%rdi
   eeb7d:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   eeb82:	48 0f 47 f8          	cmova  %rax,%rdi
   eeb86:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   eeb8a:	48 89 c7             	mov    %rax,%rdi
   eeb8d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   eeb92:	e8 a9 06 06 00       	call   14f240 <_Znwm>
   eeb97:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   eeb9d:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   eeba5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eeba9:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   eebae:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   eebb6:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   eebba:	48 01 c1             	add    %rax,%rcx
   eebbd:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   eebc5:	49 01 cb             	add    %rcx,%r11
   eebc8:	66 90                	xchg   %ax,%ax
   eebca:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eebd5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eebe0:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   eebe4:	48 83 c1 38          	add    $0x38,%rcx
   eebe8:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   eebec:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   eebf0:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   eebf4:	4c 39 d9             	cmp    %r11,%rcx
   eebf7:	75 e7                	jne    eebe0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd30>
   eebf9:	4c 39 d2             	cmp    %r10,%rdx
   eebfc:	74 71                	je     eec6f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdbf>
   eebfe:	4c 89 d1             	mov    %r10,%rcx
   eec01:	48 89 c7             	mov    %rax,%rdi
   eec04:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   eec09:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eec14:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eec1f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eec2a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eec35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eec40:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   eec44:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   eec48:	48 83 c1 38          	add    $0x38,%rcx
   eec4c:	48 83 c7 38          	add    $0x38,%rdi
   eec50:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   eec54:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   eec59:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   eec5d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   eec61:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   eec66:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   eec6a:	48 39 ca             	cmp    %rcx,%rdx
   eec6d:	75 d1                	jne    eec40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd90>
   eec6f:	4d 85 d2             	test   %r10,%r10
   eec72:	74 15                	je     eec89 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdd9>
   eec74:	4c 29 d6             	sub    %r10,%rsi
   eec77:	4c 89 d7             	mov    %r10,%rdi
   eec7a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   eec7f:	e8 bc 06 06 00       	call   14f340 <_ZdlPvm>
   eec84:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   eec89:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   eec8d:	48 89 83 70 02 00 00 	mov    %rax,0x270(%rbx)
   eec94:	48 01 c2             	add    %rax,%rdx
   eec97:	48 03 44 24 40       	add    0x40(%rsp),%rax
   eec9c:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   eeca3:	48 89 83 80 02 00 00 	mov    %rax,0x280(%rbx)
   eecaa:	e9 87 f9 ff ff       	jmp    ee636 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   eecaf:	90                   	nop
   eecb0:	48 89 c2             	mov    %rax,%rdx
   eecb3:	83 e0 01             	and    $0x1,%eax
   eecb6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eecba:	48 d1 ea             	shr    $1,%rdx
   eecbd:	48 09 c2             	or     %rax,%rdx
   eecc0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   eecc5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   eecc9:	e9 df fc ff ff       	jmp    ee9ad <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xafd>
   eecce:	66 90                	xchg   %ax,%ax
   eecd0:	48 89 c2             	mov    %rax,%rdx
   eecd3:	83 e0 01             	and    $0x1,%eax
   eecd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eecda:	48 d1 ea             	shr    $1,%rdx
   eecdd:	48 09 c2             	or     %rax,%rdx
   eece0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   eece5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   eece9:	e9 8a fc ff ff       	jmp    ee978 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xac8>
   eecee:	66 90                	xchg   %ax,%ax
   eecf0:	e8 db 85 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   eecf5:	f2 0f 10 0d 33 05 08 00 	movsd  0x80533(%rip),%xmm1        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   eecfd:	e9 99 fc ff ff       	jmp    ee99b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaeb>
   eed02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   eed08:	e8 c3 85 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   eed0d:	48 89 c5             	mov    %rax,%rbp
   eed10:	e9 24 fc ff ff       	jmp    ee939 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa89>
   eed15:	48 c7 83 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%rbx)
   eed20:	80 bb 94 00 00 00 00 	cmpb   $0x0,0x94(%rbx)
   eed27:	0f 85 96 00 00 00    	jne    eedc3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf13>
   eed2d:	8b 83 90 00 00 00    	mov    0x90(%rbx),%eax
   eed33:	83 c0 01             	add    $0x1,%eax
   eed36:	89 83 90 00 00 00    	mov    %eax,0x90(%rbx)
   eed3c:	83 f8 ff             	cmp    $0xffffffff,%eax
   eed3f:	0f 85 5d fd ff ff    	jne    eeaa2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbf2>
   eed45:	48 8b 43 78          	mov    0x78(%rbx),%rax
   eed49:	48 89 d1             	mov    %rdx,%rcx
   eed4c:	48 c1 e1 04          	shl    $0x4,%rcx
   eed50:	48 01 c1             	add    %rax,%rcx
   eed53:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   eed5a:	48 83 c0 10          	add    $0x10,%rax
   eed5e:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   eed66:	48 39 c8             	cmp    %rcx,%rax
   eed69:	75 e8                	jne    eed53 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xea3>
   eed6b:	48 01 93 b0 00 00 00 	add    %rdx,0xb0(%rbx)
   eed72:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   eed7c:	e9 21 fd ff ff       	jmp    eeaa2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbf2>
   eed81:	48 89 c2             	mov    %rax,%rdx
   eed84:	83 e0 01             	and    $0x1,%eax
   eed87:	66 0f ef c0          	pxor   %xmm0,%xmm0
   eed8b:	48 d1 ea             	shr    $1,%rdx
   eed8e:	48 09 c2             	or     %rax,%rdx
   eed91:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   eed96:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   eed9a:	e9 19 fb ff ff       	jmp    ee8b8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa08>
   eed9f:	4c 89 1c 24          	mov    %r11,(%rsp)
   eeda3:	e8 f8 23 f2 ff       	call   111a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   eeda8:	4c 8b 1c 24          	mov    (%rsp),%r11
   eedac:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   eedb4:	e9 a6 f1 ff ff       	jmp    edf5f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf>
   eedb9:	e8 e2 23 f2 ff       	call   111a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   eedbe:	e9 de fa ff ff       	jmp    ee8a1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9f1>
   eedc3:	48 c7 83 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rbx)
   eedce:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   eedd8:	e9 c5 fc ff ff       	jmp    eeaa2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbf2>
   eeddd:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   eede5:	e8 76 84 f1 ff       	call   7260 <__stack_chk_fail@plt>
   eedea:	0f b6 d0             	movzbl %al,%edx
   eeded:	e9 23 fd ff ff       	jmp    eeb15 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc65>

# candidate ordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, true>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-direct-two.wiJig0/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f1da0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f1da0:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f1da7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1dab:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f1db3:	48 8b 2a             	mov    (%rdx),%rbp
   f1db6:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f1dbe:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f1dc2:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f1dca:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f1dd2:	49 89 ff             	mov    %rdi,%r15
   f1dd5:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f1ddd:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f1de4:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f1de9:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f1df2:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f1dfa:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f1dfe:	0f 11 07             	movups %xmm0,(%rdi)
   f1e01:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f1e05:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f1e09:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f1e0d:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f1e11:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f1e15:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f1e19:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f1e1d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   f1e22:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f1e26:	e8 35 d3 05 00       	call   14f160 <_ZN5bench6memory11allocationsEv>
   f1e2b:	80 3d 46 d4 07 00 00 	cmpb   $0x0,0x7d446(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1e32:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f1e37:	49 89 c6             	mov    %rax,%r14
   f1e3a:	0f 84 a3 0e 00 00    	je     f2ce3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf43>
   f1e40:	0f 31                	rdtsc
   f1e42:	48 c1 e2 20          	shl    $0x20,%rdx
   f1e46:	48 09 d0             	or     %rdx,%rax
   f1e49:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f1e51:	49 8b 11             	mov    (%r9),%rdx
   f1e54:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   f1e58:	0f 84 4b 09 00 00    	je     f27a9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa09>
   f1e5e:	49 29 ec             	sub    %rbp,%r12
   f1e61:	c6 44 24 77 00       	movb   $0x0,0x77(%rsp)
   f1e66:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f1e6e:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f1e72:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f1e7a:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   f1e83:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f1e8c:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f1e95:	c7 44 24 70 00 00 00 00 	movl   $0x0,0x70(%rsp)
   f1e9d:	4c 89 8c 24 88 00 00 00 	mov    %r9,0x88(%rsp)
   f1ea5:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f1ead:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   f1eb5:	49 89 de             	mov    %rbx,%r14
   f1eb8:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f1ec0:	45 31 ed             	xor    %r13d,%r13d
   f1ec3:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f1ec8:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f1ecd:	0f 1f 00             	nopl   (%rax)
   f1ed0:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   f1ed5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f1ed9:	48 8b 28             	mov    (%rax),%rbp
   f1edc:	48 8b 58 08          	mov    0x8(%rax),%rbx
   f1ee0:	48 29 eb             	sub    %rbp,%rbx
   f1ee3:	49 89 dc             	mov    %rbx,%r12
   f1ee6:	49 c1 fc 04          	sar    $0x4,%r12
   f1eea:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f1ef2:	74 14                	je     f1f08 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x168>
   f1ef4:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f1efb:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   f1f02:	0f 84 cb 05 00 00    	je     f24d3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x733>
   f1f08:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f1f10:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1f14:	31 f6                	xor    %esi,%esi
   f1f16:	66 0f 6f 3d a2 69 06 00 	movdqa 0x669a2(%rip),%xmm7        # 1588c0 <C.66.5+0x2a0>
   f1f1e:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f1f26:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f1f2e:	ba 88 01 00 00       	mov    $0x188,%edx
   f1f33:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f1f3a:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f1f3f:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f1f47:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f1f4f:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f1f54:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f1f5c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f1f60:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f1f69:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f1f71:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f1f7a:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f1f82:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f1f8b:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f1f93:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f1f9b:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f1fa0:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f1fa8:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f1fad:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f1fb5:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f1fba:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f1fc2:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f1fce:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f1fda:	e8 31 51 f1 ff       	call   7110 <memset@plt>
   f1fdf:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f1fe5:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f1fe9:	66 0f 6f 05 df 68 06 00 	movdqa 0x668df(%rip),%xmm0        # 1588d0 <C.66.5+0x2b0>
   f1ff1:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f1ff7:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f1ffd:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f2001:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f2008:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f2010:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f2015:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f201d:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f2025:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f202d:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f2039:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   f2041:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f204d:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f2059:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f2065:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f2071:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f207d:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f2088:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f2090:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f209b:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f20a7:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f20af:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f20bb:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f20c6:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f20ce:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   f20d6:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f20e2:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f20ee:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   f20f6:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f2102:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f210a:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f2112:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f211a:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f2122:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f212a:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f2136:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f213e:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f2147:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f214f:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f2157:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f2160:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f2168:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f2170:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f2179:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f2181:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f2188:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f2190:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   f2198:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f21a4:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f21b0:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   f21b8:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f21c4:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f21d0:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f21dc:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f21e7:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f21f3:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   f21fb:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f2206:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f2211:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f221d:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f2225:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   f222d:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   f2235:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   f223d:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   f2245:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f224d:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f2255:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f225d:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f2265:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f226d:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f2274:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f227d:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f2288:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f228f:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f2296:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f22a1:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f22a8:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f22b0:	e8 2b c8 00 00       	call   feae0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f22b5:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f22bd:	0f 85 f5 06 00 00    	jne    f29b8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc18>
   f22c3:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f22cc:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f22d4:	4d 89 76 50          	mov    %r14,0x50(%r14)
   f22d8:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f22e0:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f22e9:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   f22f1:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   f22f6:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f22ff:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f2307:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   f230c:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f2315:	49 89 46 48          	mov    %rax,0x48(%r14)
   f2319:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f2320:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   f2325:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f232e:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   f2335:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f233a:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   f233f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2343:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   f234b:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f2354:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   f235b:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   f2363:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f236b:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f2374:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   f237c:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   f2384:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2388:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   f2390:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   f2398:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   f23a0:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   f23a8:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   f23b0:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f23bb:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   f23c3:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f23ce:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f23d9:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   f23e4:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f23eb:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f23f4:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   f23fb:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   f2402:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f2409:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   f2414:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f241b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f2420:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f2427:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f242e:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   f2439:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   f2440:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   f244b:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   f2456:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   f245d:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   f2468:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   f2473:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   f247a:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   f2485:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   f2490:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f249b:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f24a6:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   f24ae:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   f24b5:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   f24bd:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f24c6:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f24ce:	e8 0d c6 00 00       	call   feae0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f24d3:	4d 39 a6 c0 02 00 00 	cmp    %r12,0x2c0(%r14)
   f24da:	0f 82 90 04 00 00    	jb     f2970 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd0>
   f24e0:	49 8b 96 78 02 00 00 	mov    0x278(%r14),%rdx
   f24e7:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f24ee:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   f24f8:	48 89 d1             	mov    %rdx,%rcx
   f24fb:	4c 29 d1             	sub    %r10,%rcx
   f24fe:	48 89 c8             	mov    %rcx,%rax
   f2501:	48 c1 f8 03          	sar    $0x3,%rax
   f2505:	48 0f af c7          	imul   %rdi,%rax
   f2509:	4c 39 e0             	cmp    %r12,%rax
   f250c:	0f 82 ee 03 00 00    	jb     f2900 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb60>
   f2512:	49 39 c4             	cmp    %rax,%r12
   f2515:	73 16                	jae    f252d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f2517:	49 6b c4 38          	imul   $0x38,%r12,%rax
   f251b:	49 01 c2             	add    %rax,%r10
   f251e:	4c 39 d2             	cmp    %r10,%rdx
   f2521:	74 07                	je     f252a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   f2523:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f252a:	4c 89 d2             	mov    %r10,%rdx
   f252d:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f2534:	48 85 db             	test   %rbx,%rbx
   f2537:	0f 84 7c 00 00 00    	je     f25b9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x819>
   f253d:	4c 89 d1             	mov    %r10,%rcx
   f2540:	31 f6                	xor    %esi,%esi
   f2542:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f2546:	49 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%r11
   f2550:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   f255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f2560:	41 89 f0             	mov    %esi,%r8d
   f2563:	f3 0f 6f 45 00       	movdqu 0x0(%rbp),%xmm0
   f2568:	89 71 10             	mov    %esi,0x10(%rcx)
   f256b:	48 83 c6 01          	add    $0x1,%rsi
   f256f:	41 81 f0 6b 6e 61 72 	xor    $0x72616e6b,%r8d
   f2576:	c6 41 30 01          	movb   $0x1,0x30(%rcx)
   f257a:	48 83 c5 10          	add    $0x10,%rbp
   f257e:	48 83 c1 38          	add    $0x38,%rcx
   f2582:	4c 89 c0             	mov    %r8,%rax
   f2585:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f2589:	48 c1 e8 1e          	shr    $0x1e,%rax
   f258d:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f2591:	4c 31 c0             	xor    %r8,%rax
   f2594:	49 0f af c3          	imul   %r11,%rax
   f2598:	49 89 c0             	mov    %rax,%r8
   f259b:	49 c1 e8 1b          	shr    $0x1b,%r8
   f259f:	4c 31 c0             	xor    %r8,%rax
   f25a2:	48 0f af c7          	imul   %rdi,%rax
   f25a6:	49 89 c0             	mov    %rax,%r8
   f25a9:	49 c1 e8 1f          	shr    $0x1f,%r8
   f25ad:	4c 31 c0             	xor    %r8,%rax
   f25b0:	48 89 41 f0          	mov    %rax,-0x10(%rcx)
   f25b4:	4c 39 e6             	cmp    %r12,%rsi
   f25b7:	72 a7                	jb     f2560 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f25b9:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f25c5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f25c9:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f25d1:	4c 39 d2             	cmp    %r10,%rdx
   f25d4:	0f 84 f6 03 00 00    	je     f29d0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc30>
   f25da:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f25e4:	4c 29 d2             	sub    %r10,%rdx
   f25e7:	48 c1 fa 03          	sar    $0x3,%rdx
   f25eb:	48 0f af d0          	imul   %rax,%rdx
   f25ef:	49 39 56 38          	cmp    %rdx,0x38(%r14)
   f25f3:	0f 82 67 04 00 00    	jb     f2a60 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc0>
   f25f9:	48 83 ec 20          	sub    $0x20,%rsp
   f25fd:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   f2604:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   f260b:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f2614:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f2618:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f2621:	0f 11 04 24          	movups %xmm0,(%rsp)
   f2625:	e8 06 f3 fd ff       	call   d1930 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f262a:	48 83 c4 20          	add    $0x20,%rsp
   f262e:	84 c0                	test   %al,%al
   f2630:	0f 85 fb 06 00 00    	jne    f2d31 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf91>
   f2636:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f263f:	0f 84 fb 01 00 00    	je     f2840 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa0>
   f2645:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f264a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f264e:	4c 89 f6             	mov    %r14,%rsi
   f2651:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f2659:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f2661:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f2669:	e8 12 ed ff ff       	call   f1380 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f266e:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f2676:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f267e:	8b 7c 24 70          	mov    0x70(%rsp),%edi
   f2682:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f2689:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   f268d:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f2697:	48 8b b4 24 38 03 00 00 	mov    0x338(%rsp),%rsi
   f269f:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f26a5:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f26ae:	39 c7                	cmp    %eax,%edi
   f26b0:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f26b9:	0f 43 c7             	cmovae %edi,%eax
   f26bc:	48 01 74 24 08       	add    %rsi,0x8(%rsp)
   f26c1:	4c 01 64 24 10       	add    %r12,0x10(%rsp)
   f26c6:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f26ca:	89 44 24 70          	mov    %eax,0x70(%rsp)
   f26ce:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f26d2:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f26db:	41 89 47 38          	mov    %eax,0x38(%r15)
   f26df:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f26e4:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f26ea:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f26ef:	49 89 47 40          	mov    %rax,0x40(%r15)
   f26f3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f26f8:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f26fd:	49 89 47 48          	mov    %rax,0x48(%r15)
   f2701:	48 89 d0             	mov    %rdx,%rax
   f2704:	48 c1 e8 1e          	shr    $0x1e,%rax
   f2708:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f270d:	48 31 d0             	xor    %rdx,%rax
   f2710:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f2715:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f271f:	48 0f af c2          	imul   %rdx,%rax
   f2723:	48 89 c2             	mov    %rax,%rdx
   f2726:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f272a:	48 31 d0             	xor    %rdx,%rax
   f272d:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f2737:	48 0f af c2          	imul   %rdx,%rax
   f273b:	48 89 c2             	mov    %rax,%rdx
   f273e:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f2742:	48 31 d0             	xor    %rdx,%rax
   f2745:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   f274a:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   f274f:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f2757:	49 89 5f 50          	mov    %rbx,0x50(%r15)
   f275b:	0f b6 5c 24 77       	movzbl 0x77(%rsp),%ebx
   f2760:	84 db                	test   %bl,%bl
   f2762:	0f 44 d8             	cmove  %eax,%ebx
   f2765:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f276d:	49 83 c5 01          	add    $0x1,%r13
   f2771:	48 8b 10             	mov    (%rax),%rdx
   f2774:	88 5c 24 77          	mov    %bl,0x77(%rsp)
   f2778:	41 88 5f 68          	mov    %bl,0x68(%r15)
   f277c:	48 8b 40 08          	mov    0x8(%rax),%rax
   f2780:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f2785:	48 29 d0             	sub    %rdx,%rax
   f2788:	48 c1 f8 03          	sar    $0x3,%rax
   f278c:	48 0f af c1          	imul   %rcx,%rax
   f2790:	49 39 c5             	cmp    %rax,%r13
   f2793:	0f 82 37 f7 ff ff    	jb     f1ed0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f2799:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   f27a1:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f27a9:	80 3d c8 ca 07 00 00 	cmpb   $0x0,0x7cac8(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f27b0:	0f 84 49 05 00 00    	je     f2cff <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf5f>
   f27b6:	0f 31                	rdtsc
   f27b8:	48 c1 e2 20          	shl    $0x20,%rdx
   f27bc:	48 09 d0             	or     %rdx,%rax
   f27bf:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f27c7:	0f 88 f8 04 00 00    	js     f2cc5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf25>
   f27cd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f27d1:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f27d6:	f2 0f 59 05 52 ca 07 00 	mulsd  0x7ca52(%rip),%xmm0        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f27de:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f27e3:	49 89 07             	mov    %rax,(%r15)
   f27e6:	e8 75 c9 05 00       	call   14f160 <_ZN5bench6memory11allocationsEv>
   f27eb:	4c 29 f0             	sub    %r14,%rax
   f27ee:	49 89 47 58          	mov    %rax,0x58(%r15)
   f27f2:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f27fa:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f2803:	0f 85 1b 05 00 00    	jne    f2d24 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf84>
   f2809:	4c 89 f8             	mov    %r15,%rax
   f280c:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f2814:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f281c:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f2824:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f282c:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f2834:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f283b:	c3                   	ret
   f283c:	0f 1f 40 00          	nopl   0x0(%rax)
   f2840:	80 3d 31 ca 07 00 00 	cmpb   $0x0,0x7ca31(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f2847:	0f 84 fb 03 00 00    	je     f2c48 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xea8>
   f284d:	0f 31                	rdtsc
   f284f:	48 c1 e2 20          	shl    $0x20,%rdx
   f2853:	48 09 d0             	or     %rdx,%rax
   f2856:	48 89 c5             	mov    %rax,%rbp
   f2859:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f285e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2862:	4c 89 f6             	mov    %r14,%rsi
   f2865:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f286d:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f2875:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f287d:	e8 fe ea ff ff       	call   f1380 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f2882:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f288a:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f2892:	48 89 e8             	mov    %rbp,%rax
   f2895:	f2 0f 10 0d 93 c9 07 00 	movsd  0x7c993(%rip),%xmm1        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f289d:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f28a5:	0f 88 65 03 00 00    	js     f2c10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   f28ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f28af:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f28b4:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f28b8:	80 3d b9 c9 07 00 00 	cmpb   $0x0,0x7c9b9(%rip)        # 16f278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f28bf:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f28c4:	49 89 47 08          	mov    %rax,0x8(%r15)
   f28c8:	0f 84 62 03 00 00    	je     f2c30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe90>
   f28ce:	0f 31                	rdtsc
   f28d0:	48 c1 e2 20          	shl    $0x20,%rdx
   f28d4:	48 09 d0             	or     %rdx,%rax
   f28d7:	48 29 e8             	sub    %rbp,%rax
   f28da:	0f 88 10 03 00 00    	js     f2bf0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe50>
   f28e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f28e4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f28e9:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f28ed:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f28f2:	49 89 47 10          	mov    %rax,0x10(%r15)
   f28f6:	e9 83 fd ff ff       	jmp    f267e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8de>
   f28fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f2900:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   f2907:	4d 89 e3             	mov    %r12,%r11
   f290a:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   f2914:	49 29 c3             	sub    %rax,%r11
   f2917:	48 89 f7             	mov    %rsi,%rdi
   f291a:	48 29 d7             	sub    %rdx,%rdi
   f291d:	48 c1 ff 03          	sar    $0x3,%rdi
   f2921:	49 0f af f9          	imul   %r9,%rdi
   f2925:	4c 39 df             	cmp    %r11,%rdi
   f2928:	0f 82 52 01 00 00    	jb     f2a80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xce0>
   f292e:	4c 89 d9             	mov    %r11,%rcx
   f2931:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2935:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f2939:	48 89 d0             	mov    %rdx,%rax
   f293c:	0f 1f 40 00          	nopl   0x0(%rax)
   f2940:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f2944:	48 83 c0 38          	add    $0x38,%rax
   f2948:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f294c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f2950:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f2954:	48 83 e9 01          	sub    $0x1,%rcx
   f2958:	75 e6                	jne    f2940 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   f295a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f295e:	4c 01 da             	add    %r11,%rdx
   f2961:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f2968:	e9 c0 fb ff ff       	jmp    f252d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f296d:	0f 1f 00             	nopl   (%rax)
   f2970:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f2978:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   f297f:	4c 89 a4 24 10 03 00 00 	mov    %r12,0x310(%rsp)
   f2987:	48 c7 84 24 18 03 00 00 00 00 00 00 	movq   $0x0,0x318(%rsp)
   f2993:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   f299b:	e8 60 0b 02 00       	call   113500 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f29a0:	84 c0                	test   %al,%al
   f29a2:	0f 85 89 03 00 00    	jne    f2d31 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf91>
   f29a8:	4d 89 a6 c0 02 00 00 	mov    %r12,0x2c0(%r14)
   f29af:	e9 2c fb ff ff       	jmp    f24e0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x740>
   f29b4:	0f 1f 40 00          	nopl   0x0(%rax)
   f29b8:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   f29c0:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f29c4:	e8 17 c1 00 00       	call   feae0 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f29c9:	e9 f5 f8 ff ff       	jmp    f22c3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x523>
   f29ce:	66 90                	xchg   %ax,%ax
   f29d0:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   f29d8:	74 58                	je     f2a32 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   f29da:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   f29e1:	48 85 d2             	test   %rdx,%rdx
   f29e4:	0f 85 6b 02 00 00    	jne    f2c55 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xeb5>
   f29ea:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f29ef:	66 0f 6f 05 89 5e 06 00 	movdqa 0x65e89(%rip),%xmm0        # 158880 <C.66.5+0x260>
   f29f7:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   f2a02:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f2a0d:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f2a14:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f2a1f:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f2a2a:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   f2a32:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f2a37:	0f 84 f9 fb ff ff    	je     f2636 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f2a3d:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   f2a45:	0f 84 eb fb ff ff    	je     f2636 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f2a4b:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   f2a53:	e9 de fb ff ff       	jmp    f2636 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f2a58:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f2a60:	ba 10 00 00 00       	mov    $0x10,%edx
   f2a65:	48 8b 3d f4 c7 07 00 	mov    0x7c7f4(%rip),%rdi        # 16f260 <stderr@GLIBC_2.2.5>
   f2a6c:	48 8d 35 2d 3f 06 00 	lea    0x63f2d(%rip),%rsi        # 1569a0 <_IO_stdin_used+0x19a0>
   f2a73:	31 c0                	xor    %eax,%eax
   f2a75:	e8 c6 48 f1 ff       	call   7340 <fprintf@plt>
   f2a7a:	e8 a1 46 f1 ff       	call   7120 <abort@plt>
   f2a7f:	90                   	nop
   f2a80:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f2a8a:	48 29 c7             	sub    %rax,%rdi
   f2a8d:	4c 39 df             	cmp    %r11,%rdi
   f2a90:	0f 82 58 a4 f1 ff    	jb     ceee <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f2a96:	4c 39 d8             	cmp    %r11,%rax
   f2a99:	4c 89 df             	mov    %r11,%rdi
   f2a9c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f2aa4:	48 0f 43 f8          	cmovae %rax,%rdi
   f2aa8:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   f2ab0:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f2ab8:	48 01 c7             	add    %rax,%rdi
   f2abb:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   f2ac0:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f2aca:	48 39 c7             	cmp    %rax,%rdi
   f2acd:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f2ad2:	48 0f 47 f8          	cmova  %rax,%rdi
   f2ad6:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   f2ada:	48 89 c7             	mov    %rax,%rdi
   f2add:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f2ae2:	e8 59 c7 05 00       	call   14f240 <_Znwm>
   f2ae7:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f2aed:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   f2af5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2af9:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   f2afe:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f2b06:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f2b0a:	48 01 c1             	add    %rax,%rcx
   f2b0d:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f2b15:	49 01 cb             	add    %rcx,%r11
   f2b18:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f2b20:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   f2b24:	48 83 c1 38          	add    $0x38,%rcx
   f2b28:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f2b2c:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f2b30:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   f2b34:	4c 39 d9             	cmp    %r11,%rcx
   f2b37:	75 e7                	jne    f2b20 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f2b39:	4c 39 d2             	cmp    %r10,%rdx
   f2b3c:	74 71                	je     f2baf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe0f>
   f2b3e:	4c 89 d1             	mov    %r10,%rcx
   f2b41:	48 89 c7             	mov    %rax,%rdi
   f2b44:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f2b49:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2b54:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2b5f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2b6a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2b75:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f2b80:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   f2b84:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   f2b88:	48 83 c1 38          	add    $0x38,%rcx
   f2b8c:	48 83 c7 38          	add    $0x38,%rdi
   f2b90:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f2b94:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   f2b99:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   f2b9d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f2ba1:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   f2ba6:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f2baa:	48 39 ca             	cmp    %rcx,%rdx
   f2bad:	75 d1                	jne    f2b80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xde0>
   f2baf:	4d 85 d2             	test   %r10,%r10
   f2bb2:	74 15                	je     f2bc9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe29>
   f2bb4:	4c 29 d6             	sub    %r10,%rsi
   f2bb7:	4c 89 d7             	mov    %r10,%rdi
   f2bba:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f2bbf:	e8 7c c7 05 00       	call   14f340 <_ZdlPvm>
   f2bc4:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f2bc9:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   f2bcd:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   f2bd4:	48 01 c2             	add    %rax,%rdx
   f2bd7:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f2bdc:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f2be3:	49 89 86 80 02 00 00 	mov    %rax,0x280(%r14)
   f2bea:	e9 3e f9 ff ff       	jmp    f252d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f2bef:	90                   	nop
   f2bf0:	48 89 c2             	mov    %rax,%rdx
   f2bf3:	83 e0 01             	and    $0x1,%eax
   f2bf6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2bfa:	48 d1 ea             	shr    $1,%rdx
   f2bfd:	48 09 c2             	or     %rax,%rdx
   f2c00:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f2c05:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f2c09:	e9 db fc ff ff       	jmp    f28e9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb49>
   f2c0e:	66 90                	xchg   %ax,%ax
   f2c10:	48 89 c2             	mov    %rax,%rdx
   f2c13:	83 e0 01             	and    $0x1,%eax
   f2c16:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2c1a:	48 d1 ea             	shr    $1,%rdx
   f2c1d:	48 09 c2             	or     %rax,%rdx
   f2c20:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f2c25:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f2c29:	e9 86 fc ff ff       	jmp    f28b4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb14>
   f2c2e:	66 90                	xchg   %ax,%ax
   f2c30:	e8 9b 46 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f2c35:	f2 0f 10 0d f3 c5 07 00 	movsd  0x7c5f3(%rip),%xmm1        # 16f230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f2c3d:	e9 95 fc ff ff       	jmp    f28d7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb37>
   f2c42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f2c48:	e8 83 46 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f2c4d:	48 89 c5             	mov    %rax,%rbp
   f2c50:	e9 04 fc ff ff       	jmp    f2859 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab9>
   f2c55:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   f2c60:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   f2c68:	0f 85 9b 00 00 00    	jne    f2d09 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf69>
   f2c6e:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   f2c75:	83 c0 01             	add    $0x1,%eax
   f2c78:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   f2c7f:	83 f8 ff             	cmp    $0xffffffff,%eax
   f2c82:	0f 85 62 fd ff ff    	jne    f29ea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f2c88:	49 8b 46 78          	mov    0x78(%r14),%rax
   f2c8c:	48 89 d1             	mov    %rdx,%rcx
   f2c8f:	48 c1 e1 04          	shl    $0x4,%rcx
   f2c93:	48 01 c1             	add    %rax,%rcx
   f2c96:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f2c9d:	48 83 c0 10          	add    $0x10,%rax
   f2ca1:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f2ca9:	48 39 c8             	cmp    %rcx,%rax
   f2cac:	75 e8                	jne    f2c96 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef6>
   f2cae:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   f2cb5:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f2cc0:	e9 25 fd ff ff       	jmp    f29ea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f2cc5:	48 89 c2             	mov    %rax,%rdx
   f2cc8:	83 e0 01             	and    $0x1,%eax
   f2ccb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2ccf:	48 d1 ea             	shr    $1,%rdx
   f2cd2:	48 09 c2             	or     %rax,%rdx
   f2cd5:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f2cda:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f2cde:	e9 f3 fa ff ff       	jmp    f27d6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa36>
   f2ce3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f2ce8:	e8 b3 e4 f1 ff       	call   111a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f2ced:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f2cf2:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f2cfa:	e9 52 f1 ff ff       	jmp    f1e51 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb1>
   f2cff:	e8 9c e4 f1 ff       	call   111a0 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f2d04:	e9 b6 fa ff ff       	jmp    f27bf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa1f>
   f2d09:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   f2d14:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f2d1f:	e9 c6 fc ff ff       	jmp    f29ea <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f2d24:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f2d2c:	e8 2f 45 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f2d31:	0f b6 d0             	movzbl %al,%edx
   f2d34:	e9 2c fd ff ff       	jmp    f2a65 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc5>

# candidate unordered_pairs bench::Counters bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-direct-two.wiJig0/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000ed830 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   ed830:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
   ed837:	44 8b 8e d0 00 00 00 	mov    0xd0(%rsi),%r9d
   ed83e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   ed842:	48 89 ac 24 80 01 00 00 	mov    %rbp,0x180(%rsp)
   ed84a:	48 89 fd             	mov    %rdi,%rbp
   ed84d:	4c 89 a4 24 88 01 00 00 	mov    %r12,0x188(%rsp)
   ed855:	4d 89 cc             	mov    %r9,%r12
   ed858:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
   ed85d:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
   ed866:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   ed86e:	31 c0                	xor    %eax,%eax
   ed870:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   ed875:	41 83 f9 01          	cmp    $0x1,%r9d
   ed879:	0f 86 31 03 00 00    	jbe    edbb0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x380>
   ed87f:	48 89 9c 24 78 01 00 00 	mov    %rbx,0x178(%rsp)
   ed887:	66 48 0f 6e c8       	movq   %rax,%xmm1
   ed88c:	48 89 f3             	mov    %rsi,%rbx
   ed88f:	66 48 0f 6e d1       	movq   %rcx,%xmm2
   ed894:	4c 89 b4 24 98 01 00 00 	mov    %r14,0x198(%rsp)
   ed89c:	4c 8d 76 08          	lea    0x8(%rsi),%r14
   ed8a0:	8b b6 64 01 00 00    	mov    0x164(%rsi),%esi
   ed8a6:	66 0f 6c ca          	punpcklqdq %xmm2,%xmm1
   ed8aa:	c6 84 24 a0 00 00 00 00 	movb   $0x0,0xa0(%rsp)
   ed8b2:	48 c7 84 24 d8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xd8(%rsp)
   ed8be:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   ed8c6:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   ed8ce:	0f 11 8c 24 c8 00 00 00 	movups %xmm1,0xc8(%rsp)
   ed8d6:	83 fe ff             	cmp    $0xffffffff,%esi
   ed8d9:	0f 85 e1 01 00 00    	jne    edac0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x290>
   ed8df:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   ed8e7:	49 89 d7             	mov    %rdx,%r15
   ed8ea:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   ed8f2:	49 83 f9 04          	cmp    $0x4,%r9
   ed8f6:	0f 86 c0 02 00 00    	jbe    edbbc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x38c>
   ed8fc:	41 8d 44 24 ff       	lea    -0x1(%r12),%eax
   ed901:	44 89 64 24 28       	mov    %r12d,0x28(%rsp)
   ed906:	45 31 ed             	xor    %r13d,%r13d
   ed909:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   ed90e:	31 c0                	xor    %eax,%eax
   ed910:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
   ed915:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
   ed91a:	84 c0                	test   %al,%al
   ed91c:	0f 85 77 01 00 00    	jne    eda99 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x269>
   ed922:	0f 1f 00             	nopl   (%rax)
   ed925:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ed930:	4c 39 6c 24 30       	cmp    %r13,0x30(%rsp)
   ed935:	0f 84 5e 01 00 00    	je     eda99 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x269>
   ed93b:	4c 89 ef             	mov    %r13,%rdi
   ed93e:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   ed943:	44 89 ed             	mov    %r13d,%ebp
   ed946:	44 8b 64 24 28       	mov    0x28(%rsp),%r12d
   ed94b:	48 c1 e7 05          	shl    $0x5,%rdi
   ed94f:	41 83 c5 01          	add    $0x1,%r13d
   ed953:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   ed958:	48 8d 5f 20          	lea    0x20(%rdi),%rbx
   ed95c:	eb 21                	jmp    ed97f <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x14f>
   ed95e:	66 90                	xchg   %ax,%ax
   ed960:	41 83 c5 01          	add    $0x1,%r13d
   ed964:	45 39 e5             	cmp    %r12d,%r13d
   ed967:	0f 83 13 01 00 00    	jae    eda80 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x250>
   ed96d:	48 83 c3 20          	add    $0x20,%rbx
   ed971:	80 bc 24 a0 00 00 00 00 	cmpb   $0x0,0xa0(%rsp)
   ed979:	0f 85 01 01 00 00    	jne    eda80 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x250>
   ed97f:	48 8d 8c 24 a0 00 00 00 	lea    0xa0(%rsp),%rcx
   ed987:	44 89 ea             	mov    %r13d,%edx
   ed98a:	89 ee                	mov    %ebp,%esi
   ed98c:	4c 89 f7             	mov    %r14,%rdi
   ed98f:	e8 0c 40 f2 ff       	call   119a0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_12QueryContextINS_11QueryResultEEERT0_.isra.0>
   ed994:	84 c0                	test   %al,%al
   ed996:	74 c8                	je     ed960 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x130>
   ed998:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   ed99d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   ed9a2:	48 8b 40 68          	mov    0x68(%rax),%rax
   ed9a6:	8b 7c 30 18          	mov    0x18(%rax,%rsi,1),%edi
   ed9aa:	39 7c 18 18          	cmp    %edi,0x18(%rax,%rbx,1)
   ed9ae:	0f 82 ec 01 00 00    	jb     edba0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x370>
   ed9b4:	44 89 6c 24 08       	mov    %r13d,0x8(%rsp)
   ed9b9:	89 ea                	mov    %ebp,%edx
   ed9bb:	4c 89 f6             	mov    %r14,%rsi
   ed9be:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   ed9c6:	e8 25 9c 05 00       	call   1475f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ed9cb:	8b 54 24 08          	mov    0x8(%rsp),%edx
   ed9cf:	4c 89 f6             	mov    %r14,%rsi
   ed9d2:	48 8d bc 24 20 01 00 00 	lea    0x120(%rsp),%rdi
   ed9da:	e8 11 9c 05 00       	call   1475f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   ed9df:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   ed9e7:	48 8b 84 24 38 01 00 00 	mov    0x138(%rsp),%rax
   ed9ef:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   ed9f9:	8b 00                	mov    (%rax),%eax
   ed9fb:	8b 0a                	mov    (%rdx),%ecx
   ed9fd:	49 83 07 01          	addq   $0x1,(%r15)
   eda01:	89 ca                	mov    %ecx,%edx
   eda03:	39 c8                	cmp    %ecx,%eax
   eda05:	0f 46 d0             	cmovbe %eax,%edx
   eda08:	48 c1 e2 20          	shl    $0x20,%rdx
   eda0c:	39 c8                	cmp    %ecx,%eax
   eda0e:	0f 42 c1             	cmovb  %ecx,%eax
   eda11:	48 09 c2             	or     %rax,%rdx
   eda14:	48 89 d0             	mov    %rdx,%rax
   eda17:	48 c1 e8 1e          	shr    $0x1e,%rax
   eda1b:	48 31 d0             	xor    %rdx,%rax
   eda1e:	48 0f af c6          	imul   %rsi,%rax
   eda22:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   eda2c:	48 89 c2             	mov    %rax,%rdx
   eda2f:	48 c1 ea 1b          	shr    $0x1b,%rdx
   eda33:	48 31 d0             	xor    %rdx,%rax
   eda36:	48 0f af c6          	imul   %rsi,%rax
   eda3a:	48 89 c2             	mov    %rax,%rdx
   eda3d:	48 c1 ea 1f          	shr    $0x1f,%rdx
   eda41:	48 31 d0             	xor    %rdx,%rax
   eda44:	49 01 47 08          	add    %rax,0x8(%r15)
   eda48:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   eda50:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   eda54:	0f 84 06 ff ff ff    	je     ed960 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x130>
   eda5a:	48 83 c0 01          	add    $0x1,%rax
   eda5e:	41 83 c5 01          	add    $0x1,%r13d
   eda62:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   eda6a:	45 39 e5             	cmp    %r12d,%r13d
   eda6d:	0f 82 fa fe ff ff    	jb     ed96d <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x13d>
   eda73:	66 90                	xchg   %ax,%ax
   eda75:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   eda80:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   eda85:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   eda8d:	49 83 c5 01          	add    $0x1,%r13
   eda91:	84 c0                	test   %al,%al
   eda93:	0f 84 97 fe ff ff    	je     ed930 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x100>
   eda99:	44 8b 64 24 28       	mov    0x28(%rsp),%r12d
   eda9e:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
   edaa3:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
   edaa8:	4c 8b ac 24 90 01 00 00 	mov    0x190(%rsp),%r13
   edab0:	4c 8b bc 24 a0 01 00 00 	mov    0x1a0(%rsp),%r15
   edab8:	eb 2d                	jmp    edae7 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2b7>
   edaba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   edac0:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
   edac5:	48 8d 94 24 a0 00 00 00 	lea    0xa0(%rsp),%rdx
   edacd:	4c 89 f7             	mov    %r14,%rdi
   edad0:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   edad5:	4c 8d 84 24 20 01 00 00 	lea    0x120(%rsp),%r8
   edadd:	e8 4e de fd ff       	call   cb930 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE9selfPairsIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvjRNS2_12QueryContextINS_11QueryResultEEESC_RSF_>
   edae2:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   edae7:	66 0f 6f 9c 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm3
   edaf0:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   edaf8:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   edb01:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
   edb06:	0f 29 84 24 80 00 00 00 	movaps %xmm0,0x80(%rsp)
   edb0e:	84 c0                	test   %al,%al
   edb10:	74 08                	je     edb1a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2ea>
   edb12:	3c 0b                	cmp    $0xb,%al
   edb14:	0f 85 42 03 00 00    	jne    ede5c <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x62c>
   edb1a:	48 8b 9c 24 78 01 00 00 	mov    0x178(%rsp),%rbx
   edb22:	4c 8b b4 24 98 01 00 00 	mov    0x198(%rsp),%r14
   edb2a:	48 8b 94 24 80 00 00 00 	mov    0x80(%rsp),%rdx
   edb32:	48 c7 45 18 00 00 00 00 	movq   $0x0,0x18(%rbp)
   edb3a:	48 c7 45 28 00 00 00 00 	movq   $0x0,0x28(%rbp)
   edb42:	48 89 55 00          	mov    %rdx,0x0(%rbp)
   edb46:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   edb4b:	4c 89 4d 08          	mov    %r9,0x8(%rbp)
   edb4f:	48 89 55 10          	mov    %rdx,0x10(%rbp)
   edb53:	31 d2                	xor    %edx,%edx
   edb55:	45 85 e4             	test   %r12d,%r12d
   edb58:	0f 95 c2             	setne  %dl
   edb5b:	3c 0b                	cmp    $0xb,%al
   edb5d:	89 55 20             	mov    %edx,0x20(%rbp)
   edb60:	0f 94 45 30          	sete   0x30(%rbp)
   edb64:	48 8b 84 24 68 01 00 00 	mov    0x168(%rsp),%rax
   edb6c:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   edb75:	0f 85 0e 03 00 00    	jne    ede89 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x659>
   edb7b:	48 89 e8             	mov    %rbp,%rax
   edb7e:	4c 8b a4 24 88 01 00 00 	mov    0x188(%rsp),%r12
   edb86:	48 8b ac 24 80 01 00 00 	mov    0x180(%rsp),%rbp
   edb8e:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
   edb95:	c3                   	ret
   edb96:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   edba0:	89 6c 24 08          	mov    %ebp,0x8(%rsp)
   edba4:	44 89 ea             	mov    %r13d,%edx
   edba7:	e9 0f fe ff ff       	jmp    ed9bb <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x18b>
   edbac:	0f 1f 40 00          	nopl   0x0(%rax)
   edbb0:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   edbb5:	31 c0                	xor    %eax,%eax
   edbb7:	e9 6e ff ff ff       	jmp    edb2a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2fa>
   edbbc:	49 8d 41 ff          	lea    -0x1(%r9),%rax
   edbc0:	49 0f af c1          	imul   %r9,%rax
   edbc4:	48 d1 e8             	shr    $1,%rax
   edbc7:	48 39 c1             	cmp    %rax,%rcx
   edbca:	0f 82 2c fd ff ff    	jb     ed8fc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xcc>
   edbd0:	48 89 d8             	mov    %rbx,%rax
   edbd3:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   edbd8:	48 8b 5b 68          	mov    0x68(%rbx),%rbx
   edbdc:	48 8b 40 58          	mov    0x58(%rax),%rax
   edbe0:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
   edbe5:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
   edbea:	4c 8d 5b 20          	lea    0x20(%rbx),%r11
   edbee:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   edbf3:	4c 8d 68 10          	lea    0x10(%rax),%r13
   edbf7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   edbfc:	41 8d 41 ff          	lea    -0x1(%r9),%eax
   edc00:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   edc05:	4c 89 e8             	mov    %r13,%rax
   edc08:	45 31 ed             	xor    %r13d,%r13d
   edc0b:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   edc10:	4d 8b 53 e8          	mov    -0x18(%r11),%r10
   edc14:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   edc19:	41 8d 6d 01          	lea    0x1(%r13),%ebp
   edc1d:	4c 89 db             	mov    %r11,%rbx
   edc20:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   edc25:	4d 8b 7b e0          	mov    -0x20(%r11),%r15
   edc29:	4d 89 d9             	mov    %r11,%r9
   edc2c:	49 89 c6             	mov    %rax,%r14
   edc2f:	4d 89 d3             	mov    %r10,%r11
   edc32:	49 89 c5             	mov    %rax,%r13
   edc35:	e9 1a 01 00 00       	jmp    edd54 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x524>
   edc3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   edc40:	41 8b 36             	mov    (%r14),%esi
   edc43:	41 8b 4d f8          	mov    -0x8(%r13),%ecx
   edc47:	39 ce                	cmp    %ecx,%esi
   edc49:	0f 8d 41 01 00 00    	jge    edd90 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x560>
   edc4f:	41 8b 7d f4          	mov    -0xc(%r13),%edi
   edc53:	41 3b 7e 0c          	cmp    0xc(%r14),%edi
   edc57:	0f 8d 3b 01 00 00    	jge    edd98 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x568>
   edc5d:	45 8b 45 fc          	mov    -0x4(%r13),%r8d
   edc61:	45 39 46 04          	cmp    %r8d,0x4(%r14)
   edc65:	0f 8d 2d 01 00 00    	jge    edd98 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x568>
   edc6b:	41 8b 41 f8          	mov    -0x8(%r9),%eax
   edc6f:	39 43 18             	cmp    %eax,0x18(%rbx)
   edc72:	0f 82 d5 01 00 00    	jb     ede4d <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x61d>
   edc78:	89 6c 24 08          	mov    %ebp,0x8(%rsp)
   edc7c:	8b 54 24 20          	mov    0x20(%rsp),%edx
   edc80:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   edc85:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   edc8d:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   edc92:	4c 89 5c 24 28       	mov    %r11,0x28(%rsp)
   edc97:	e8 54 99 05 00       	call   1475f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   edc9c:	8b 54 24 08          	mov    0x8(%rsp),%edx
   edca0:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   edca5:	48 8d bc 24 20 01 00 00 	lea    0x120(%rsp),%rdi
   edcad:	e8 3e 99 05 00       	call   1475f0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   edcb2:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   edcb7:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
   edcbc:	48 bf b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdi
   edcc6:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   edcce:	48 8b 84 24 38 01 00 00 	mov    0x138(%rsp),%rax
   edcd6:	4c 8b 5c 24 28       	mov    0x28(%rsp),%r11
   edcdb:	8b 00                	mov    (%rax),%eax
   edcdd:	8b 0a                	mov    (%rdx),%ecx
   edcdf:	48 83 06 01          	addq   $0x1,(%rsi)
   edce3:	89 ca                	mov    %ecx,%edx
   edce5:	39 c8                	cmp    %ecx,%eax
   edce7:	0f 46 d0             	cmovbe %eax,%edx
   edcea:	48 c1 e2 20          	shl    $0x20,%rdx
   edcee:	39 c8                	cmp    %ecx,%eax
   edcf0:	0f 42 c1             	cmovb  %ecx,%eax
   edcf3:	48 09 c2             	or     %rax,%rdx
   edcf6:	48 89 d0             	mov    %rdx,%rax
   edcf9:	48 c1 e8 1e          	shr    $0x1e,%rax
   edcfd:	48 31 d0             	xor    %rdx,%rax
   edd00:	48 0f af c7          	imul   %rdi,%rax
   edd04:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   edd0e:	48 89 c2             	mov    %rax,%rdx
   edd11:	48 c1 ea 1b          	shr    $0x1b,%rdx
   edd15:	48 31 d0             	xor    %rdx,%rax
   edd18:	48 0f af c7          	imul   %rdi,%rax
   edd1c:	48 89 c2             	mov    %rax,%rdx
   edd1f:	48 c1 ea 1f          	shr    $0x1f,%rdx
   edd23:	48 31 d0             	xor    %rdx,%rax
   edd26:	48 01 46 08          	add    %rax,0x8(%rsi)
   edd2a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edd35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edd40:	83 c5 01             	add    $0x1,%ebp
   edd43:	48 83 c3 20          	add    $0x20,%rbx
   edd47:	49 83 c6 10          	add    $0x10,%r14
   edd4b:	44 39 e5             	cmp    %r12d,%ebp
   edd4e:	0f 83 ac 00 00 00    	jae    ede00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5d0>
   edd54:	4c 85 7b 08          	test   %r15,0x8(%rbx)
   edd58:	74 e6                	je     edd40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x510>
   edd5a:	4c 85 1b             	test   %r11,(%rbx)
   edd5d:	74 e1                	je     edd40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x510>
   edd5f:	41 8b 45 f0          	mov    -0x10(%r13),%eax
   edd63:	41 8b 56 08          	mov    0x8(%r14),%edx
   edd67:	48 83 84 24 80 00 00 00 01 	addq   $0x1,0x80(%rsp)
   edd70:	39 d0                	cmp    %edx,%eax
   edd72:	0f 8c c8 fe ff ff    	jl     edc40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   edd78:	75 c6                	jne    edd40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x510>
   edd7a:	41 8b 36             	mov    (%r14),%esi
   edd7d:	41 8b 4d f8          	mov    -0x8(%r13),%ecx
   edd81:	0f 1f 40 00          	nopl   0x0(%rax)
   edd85:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   edd90:	39 f1                	cmp    %esi,%ecx
   edd92:	7c ac                	jl     edd40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x510>
   edd94:	41 8b 7d f4          	mov    -0xc(%r13),%edi
   edd98:	45 8b 46 0c          	mov    0xc(%r14),%r8d
   edd9c:	44 89 44 24 08       	mov    %r8d,0x8(%rsp)
   edda1:	44 39 c7             	cmp    %r8d,%edi
   edda4:	7f 9a                	jg     edd40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x510>
   edda6:	45 8b 56 04          	mov    0x4(%r14),%r10d
   eddaa:	45 8b 45 fc          	mov    -0x4(%r13),%r8d
   eddae:	44 89 54 24 28       	mov    %r10d,0x28(%rsp)
   eddb3:	45 39 c2             	cmp    %r8d,%r10d
   eddb6:	7f 88                	jg     edd40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x510>
   eddb8:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   eddbd:	41 80 7a 21 01       	cmpb   $0x1,0x21(%r10)
   eddc2:	41 0f 95 c2          	setne  %r10b
   eddc6:	44 39 c7             	cmp    %r8d,%edi
   eddc9:	40 0f 95 c7          	setne  %dil
   eddcd:	41 21 fa             	and    %edi,%r10d
   eddd0:	8b 7c 24 28          	mov    0x28(%rsp),%edi
   eddd4:	39 7c 24 08          	cmp    %edi,0x8(%rsp)
   eddd8:	40 0f 95 c7          	setne  %dil
   edddc:	44 21 d7             	and    %r10d,%edi
   edddf:	39 c1                	cmp    %eax,%ecx
   edde1:	0f 95 c0             	setne  %al
   edde4:	40 84 c7             	test   %al,%dil
   edde7:	0f 84 7e fe ff ff    	je     edc6b <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x43b>
   edded:	39 d6                	cmp    %edx,%esi
   eddef:	0f 84 76 fe ff ff    	je     edc6b <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x43b>
   eddf5:	e9 46 ff ff ff       	jmp    edd40 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x510>
   eddfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   ede00:	49 8d 45 10          	lea    0x10(%r13),%rax
   ede04:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
   ede09:	4d 8d 59 20          	lea    0x20(%r9),%r11
   ede0d:	49 83 c5 01          	add    $0x1,%r13
   ede11:	4c 39 6c 24 38       	cmp    %r13,0x38(%rsp)
   ede16:	0f 85 f4 fd ff ff    	jne    edc10 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   ede1c:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
   ede21:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
   ede26:	31 c0                	xor    %eax,%eax
   ede28:	48 8b 9c 24 78 01 00 00 	mov    0x178(%rsp),%rbx
   ede30:	4c 8b ac 24 90 01 00 00 	mov    0x190(%rsp),%r13
   ede38:	4c 8b b4 24 98 01 00 00 	mov    0x198(%rsp),%r14
   ede40:	4c 8b bc 24 a0 01 00 00 	mov    0x1a0(%rsp),%r15
   ede48:	e9 dd fc ff ff       	jmp    edb2a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2fa>
   ede4d:	8b 44 24 20          	mov    0x20(%rsp),%eax
   ede51:	89 ea                	mov    %ebp,%edx
   ede53:	89 44 24 08          	mov    %eax,0x8(%rsp)
   ede57:	e9 24 fe ff ff       	jmp    edc80 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x450>
   ede5c:	48 8b 3d fd 13 08 00 	mov    0x813fd(%rip),%rdi        # 16f260 <stderr@GLIBC_2.2.5>
   ede63:	0f b6 d0             	movzbl %al,%edx
   ede66:	48 8d 35 33 8b 06 00 	lea    0x68b33(%rip),%rsi        # 1569a0 <_IO_stdin_used+0x19a0>
   ede6d:	31 c0                	xor    %eax,%eax
   ede6f:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   ede77:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   ede7f:	e8 bc 94 f1 ff       	call   7340 <fprintf@plt>
   ede84:	e8 97 92 f1 ff       	call   7120 <abort@plt>
   ede89:	48 89 9c 24 78 01 00 00 	mov    %rbx,0x178(%rsp)
   ede91:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   ede99:	4c 89 b4 24 98 01 00 00 	mov    %r14,0x198(%rsp)
   edea1:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   edea9:	e8 b2 93 f1 ff       	call   7260 <__stack_chk_fail@plt>

# candidate ordered_pairs bench::Counters bench::LibraryIndex<int, true>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-direct-two.wiJig0/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f1380 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f1380:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
   f1387:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f138b:	48 89 9c 24 c8 01 00 00 	mov    %rbx,0x1c8(%rsp)
   f1393:	48 89 fb             	mov    %rdi,%rbx
   f1396:	4c 89 bc 24 f0 01 00 00 	mov    %r15,0x1f0(%rsp)
   f139e:	49 89 f7             	mov    %rsi,%r15
   f13a1:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   f13a6:	8b 96 d0 00 00 00    	mov    0xd0(%rsi),%edx
   f13ac:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
   f13b3:	64 48 8b 3c 25 28 00 00 00 	mov    %fs:0x28,%rdi
   f13bc:	48 89 bc 24 b8 01 00 00 	mov    %rdi,0x1b8(%rsp)
   f13c4:	31 ff                	xor    %edi,%edi
   f13c6:	83 fa 01             	cmp    $0x1,%edx
   f13c9:	0f 86 01 03 00 00    	jbe    f16d0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x350>
   f13cf:	48 39 f2             	cmp    %rsi,%rdx
   f13d2:	74 44                	je     f1418 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x98>
   f13d4:	ba 07 00 00 00       	mov    $0x7,%edx
   f13d9:	48 8b 3d 80 de 07 00 	mov    0x7de80(%rip),%rdi        # 16f260 <stderr@GLIBC_2.2.5>
   f13e0:	48 8d 35 b9 55 06 00 	lea    0x655b9(%rip),%rsi        # 1569a0 <_IO_stdin_used+0x19a0>
   f13e7:	31 c0                	xor    %eax,%eax
   f13e9:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f13f1:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f13f9:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f1401:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f1409:	e8 32 5f f1 ff       	call   7340 <fprintf@plt>
   f140e:	e8 0d 5d f1 ff       	call   7120 <abort@plt>
   f1413:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f1418:	49 89 c8             	mov    %rcx,%r8
   f141b:	0f 11 84 24 98 00 00 00 	movups %xmm0,0x98(%rsp)
   f1423:	49 8b 47 50          	mov    0x50(%r15),%rax
   f1427:	89 d1                	mov    %edx,%ecx
   f1429:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f1431:	66 49 0f 6e d0       	movq   %r8,%xmm2
   f1436:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   f143b:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
   f143f:	c6 84 24 90 00 00 00 00 	movb   $0x0,0x90(%rsp)
   f1447:	48 c7 84 24 c8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xc8(%rsp)
   f1453:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f145b:	48 85 c0             	test   %rax,%rax
   f145e:	0f 84 c6 08 00 00    	je     f1d2a <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9aa>
   f1464:	48 89 84 24 d0 00 00 00 	mov    %rax,0xd0(%rsp)
   f146c:	48 89 84 24 d8 00 00 00 	mov    %rax,0xd8(%rsp)
   f1474:	48 c7 84 24 e0 00 00 00 00 00 00 00 	movq   $0x0,0xe0(%rsp)
   f1480:	48 c7 84 24 e8 00 00 00 00 00 00 00 	movq   $0x0,0xe8(%rsp)
   f148c:	48 89 84 24 f0 00 00 00 	mov    %rax,0xf0(%rsp)
   f1494:	48 c7 84 24 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rsp)
   f14a0:	48 c7 84 24 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rsp)
   f14ac:	48 89 84 24 08 01 00 00 	mov    %rax,0x108(%rsp)
   f14b4:	48 c7 84 24 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rsp)
   f14c0:	48 c7 84 24 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rsp)
   f14cc:	48 89 84 24 20 01 00 00 	mov    %rax,0x120(%rsp)
   f14d4:	48 c7 84 24 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rsp)
   f14e0:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f14ec:	48 89 84 24 38 01 00 00 	mov    %rax,0x138(%rsp)
   f14f4:	48 c7 84 24 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rsp)
   f1500:	48 c7 84 24 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rsp)
   f150c:	48 89 84 24 50 01 00 00 	mov    %rax,0x150(%rsp)
   f1514:	48 c7 84 24 58 01 00 00 00 00 00 00 	movq   $0x0,0x158(%rsp)
   f1520:	48 c7 84 24 60 01 00 00 00 00 00 00 	movq   $0x0,0x160(%rsp)
   f152c:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f1534:	48 c7 84 24 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rsp)
   f1540:	48 c7 84 24 78 01 00 00 00 00 00 00 	movq   $0x0,0x178(%rsp)
   f154c:	48 89 84 24 80 01 00 00 	mov    %rax,0x180(%rsp)
   f1554:	48 c7 84 24 88 01 00 00 00 00 00 00 	movq   $0x0,0x188(%rsp)
   f1560:	48 c7 84 24 90 01 00 00 00 00 00 00 	movq   $0x0,0x190(%rsp)
   f156c:	48 89 84 24 98 01 00 00 	mov    %rax,0x198(%rsp)
   f1574:	48 c7 84 24 a0 01 00 00 00 00 00 00 	movq   $0x0,0x1a0(%rsp)
   f1580:	48 c7 84 24 a8 01 00 00 00 00 00 00 	movq   $0x0,0x1a8(%rsp)
   f158c:	c7 84 24 b0 01 00 00 00 00 00 00 	movl   $0x0,0x1b0(%rsp)
   f1597:	c6 84 24 b4 01 00 00 00 	movb   $0x0,0x1b4(%rsp)
   f159f:	49 39 b7 a0 01 00 00 	cmp    %rsi,0x1a0(%r15)
   f15a6:	0f 82 b4 01 00 00    	jb     f1760 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f15ac:	49 39 b7 b8 01 00 00 	cmp    %rsi,0x1b8(%r15)
   f15b3:	0f 82 a7 01 00 00    	jb     f1760 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f15b9:	41 80 bf 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r15)
   f15c1:	0f 85 aa 07 00 00    	jne    f1d71 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9f1>
   f15c7:	49 8d 47 08          	lea    0x8(%r15),%rax
   f15cb:	4d 8b 9f 98 01 00 00 	mov    0x198(%r15),%r11
   f15d2:	c6 44 24 43 00       	movb   $0x0,0x43(%rsp)
   f15d7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   f15dc:	49 8d 87 88 01 00 00 	lea    0x188(%r15),%rax
   f15e3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f15e8:	41 c6 87 6c 02 00 00 01 	movb   $0x1,0x26c(%r15)
   f15f0:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
   f15f5:	85 c9                	test   %ecx,%ecx
   f15f7:	0f 84 7a 01 00 00    	je     f1777 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f15fd:	8d 41 ff             	lea    -0x1(%rcx),%eax
   f1600:	83 f8 02             	cmp    $0x2,%eax
   f1603:	0f 86 3c 07 00 00    	jbe    f1d45 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9c5>
   f1609:	89 cf                	mov    %ecx,%edi
   f160b:	4c 89 d8             	mov    %r11,%rax
   f160e:	66 0f 6f 05 7a 72 06 00 	movdqa 0x6727a(%rip),%xmm0        # 158890 <C.66.5+0x270>
   f1616:	c1 ef 02             	shr    $0x2,%edi
   f1619:	89 fa                	mov    %edi,%edx
   f161b:	48 c1 e2 04          	shl    $0x4,%rdx
   f161f:	4c 01 da             	add    %r11,%rdx
   f1622:	41 bb 04 00 00 00    	mov    $0x4,%r11d
   f1628:	66 41 0f 6e cb       	movd   %r11d,%xmm1
   f162d:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   f1632:	0f 1f 00             	nopl   (%rax)
   f1635:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1640:	0f 11 00             	movups %xmm0,(%rax)
   f1643:	48 83 c0 10          	add    $0x10,%rax
   f1647:	66 0f fe c1          	paddd  %xmm1,%xmm0
   f164b:	48 39 d0             	cmp    %rdx,%rax
   f164e:	75 f0                	jne    f1640 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2c0>
   f1650:	8d 04 bd 00 00 00 00 	lea    0x0(,%rdi,4),%eax
   f1657:	39 c8                	cmp    %ecx,%eax
   f1659:	74 25                	je     f1680 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f165b:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
   f1660:	89 c2                	mov    %eax,%edx
   f1662:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f1666:	8d 50 01             	lea    0x1(%rax),%edx
   f1669:	39 ca                	cmp    %ecx,%edx
   f166b:	73 13                	jae    f1680 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f166d:	89 d7                	mov    %edx,%edi
   f166f:	83 c0 02             	add    $0x2,%eax
   f1672:	41 89 14 bb          	mov    %edx,(%r11,%rdi,4)
   f1676:	39 c8                	cmp    %ecx,%eax
   f1678:	73 06                	jae    f1680 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f167a:	89 c2                	mov    %eax,%edx
   f167c:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f1680:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
   f1687:	0f 86 ea 00 00 00    	jbe    f1777 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f168d:	49 39 b7 48 02 00 00 	cmp    %rsi,0x248(%r15)
   f1694:	0f 82 e7 00 00 00    	jb     f1781 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f169a:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f16a4:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f16ab:	48 c1 ea 04          	shr    $0x4,%rdx
   f16af:	48 39 f2             	cmp    %rsi,%rdx
   f16b2:	0f 82 c9 00 00 00    	jb     f1781 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f16b8:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f16bc:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   f16c1:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f16c6:	e8 15 0d f2 ff       	call   123e0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f16cb:	e9 db 00 00 00       	jmp    f17ab <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x42b>
   f16d0:	48 39 f2             	cmp    %rsi,%rdx
   f16d3:	0f 85 fb fc ff ff    	jne    f13d4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54>
   f16d9:	48 89 d0             	mov    %rdx,%rax
   f16dc:	0f 11 84 24 d8 00 00 00 	movups %xmm0,0xd8(%rsp)
   f16e4:	31 d2                	xor    %edx,%edx
   f16e6:	48 8b 8c 24 e0 00 00 00 	mov    0xe0(%rsp),%rcx
   f16ee:	85 c0                	test   %eax,%eax
   f16f0:	89 c7                	mov    %eax,%edi
   f16f2:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   f16fa:	0f 95 c0             	setne  %al
   f16fd:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   f1705:	80 fa 0b             	cmp    $0xb,%dl
   f1708:	48 89 0b             	mov    %rcx,(%rbx)
   f170b:	48 8b 8c 24 d8 00 00 00 	mov    0xd8(%rsp),%rcx
   f1713:	0f b6 c0             	movzbl %al,%eax
   f1716:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
   f171a:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   f171e:	89 43 20             	mov    %eax,0x20(%rbx)
   f1721:	0f 94 43 30          	sete   0x30(%rbx)
   f1725:	48 8b 84 24 b8 01 00 00 	mov    0x1b8(%rsp),%rax
   f172d:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f1736:	0f 85 10 06 00 00    	jne    f1d4c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9cc>
   f173c:	48 89 d8             	mov    %rbx,%rax
   f173f:	4c 8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%r15
   f1747:	48 8b 9c 24 c8 01 00 00 	mov    0x1c8(%rsp),%rbx
   f174f:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
   f1756:	c3                   	ret
   f1757:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   f1760:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f1768:	e8 f3 c5 00 00       	call   fdd60 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f176d:	ba 05 00 00 00       	mov    $0x5,%edx
   f1772:	e9 62 fc ff ff       	jmp    f13d9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f1777:	48 83 fe 01          	cmp    $0x1,%rsi
   f177b:	0f 86 bd 05 00 00    	jbe    f1d3e <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9be>
   f1781:	48 89 f0             	mov    %rsi,%rax
   f1784:	31 c9                	xor    %ecx,%ecx
   f1786:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f1790:	48 d1 e8             	shr    $1,%rax
   f1793:	83 c1 02             	add    $0x2,%ecx
   f1796:	48 83 f8 01          	cmp    $0x1,%rax
   f179a:	75 f4                	jne    f1790 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f179c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f17a1:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f17a6:	e8 75 d5 05 00       	call   14ed20 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f17ab:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f17b2:	83 fa 01             	cmp    $0x1,%edx
   f17b5:	0f 86 2a 03 00 00    	jbe    f1ae5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f17bb:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f17c3:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f17cb:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f17d3:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f17db:	48 c7 44 24 08 01 00 00 00 	movq   $0x1,0x8(%rsp)
   f17e4:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   f17e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f17f0:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f17f8:	84 c0                	test   %al,%al
   f17fa:	0f 85 c0 02 00 00    	jne    f1ac0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f1800:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   f1805:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f180a:	48 8d 4c 24 43       	lea    0x43(%rsp),%rcx
   f180f:	4c 8d ac 24 90 00 00 00 	lea    0x90(%rsp),%r13
   f1817:	8b 7c 9f fc          	mov    -0x4(%rdi,%rbx,4),%edi
   f181b:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   f1820:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   f1825:	48 8d 4c 24 42       	lea    0x42(%rsp),%rcx
   f182a:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   f182f:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   f1834:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   f1839:	48 8d 5c 24 44       	lea    0x44(%rsp),%rbx
   f183e:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   f1843:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
   f1848:	48 89 8c 24 80 00 00 00 	mov    %rcx,0x80(%rsp)
   f1850:	41 8b 8f 64 01 00 00 	mov    0x164(%r15),%ecx
   f1857:	89 7c 24 44          	mov    %edi,0x44(%rsp)
   f185b:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
   f1864:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
   f1869:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   f186e:	83 f9 ff             	cmp    $0xffffffff,%ecx
   f1871:	0f 84 d9 02 00 00    	je     f1b50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7d0>
   f1877:	89 ce                	mov    %ecx,%esi
   f1879:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   f187d:	49 03 b7 f8 00 00 00 	add    0xf8(%r15),%rsi
   f1884:	44 8b 46 64          	mov    0x64(%rsi),%r8d
   f1888:	45 85 c0             	test   %r8d,%r8d
   f188b:	0f 84 ff 01 00 00    	je     f1a90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f1891:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f1899:	48 85 c0             	test   %rax,%rax
   f189c:	0f 84 56 04 00 00    	je     f1cf8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x978>
   f18a2:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f18a6:	74 0c                	je     f18b4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x534>
   f18a8:	48 83 e8 01          	sub    $0x1,%rax
   f18ac:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f18b4:	48 8b 84 24 98 00 00 00 	mov    0x98(%rsp),%rax
   f18bc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f18c0:	74 0c                	je     f18ce <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54e>
   f18c2:	48 83 c0 01          	add    $0x1,%rax
   f18c6:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f18ce:	48 89 fa             	mov    %rdi,%rdx
   f18d1:	8b 46 1c             	mov    0x1c(%rsi),%eax
   f18d4:	48 c1 e2 04          	shl    $0x4,%rdx
   f18d8:	49 03 57 58          	add    0x58(%r15),%rdx
   f18dc:	39 02                	cmp    %eax,(%rdx)
   f18de:	0f 8f ac 01 00 00    	jg     f1a90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f18e4:	8b 42 08             	mov    0x8(%rdx),%eax
   f18e7:	39 46 14             	cmp    %eax,0x14(%rsi)
   f18ea:	0f 8f a0 01 00 00    	jg     f1a90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f18f0:	8b 46 20             	mov    0x20(%rsi),%eax
   f18f3:	39 42 04             	cmp    %eax,0x4(%rdx)
   f18f6:	0f 8f 94 01 00 00    	jg     f1a90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f18fc:	8b 42 0c             	mov    0xc(%rdx),%eax
   f18ff:	39 46 18             	cmp    %eax,0x18(%rsi)
   f1902:	0f 8f 88 01 00 00    	jg     f1a90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f1908:	49 8b 47 68          	mov    0x68(%r15),%rax
   f190c:	48 c1 e7 05          	shl    $0x5,%rdi
   f1910:	48 83 ec 08          	sub    $0x8,%rsp
   f1914:	4d 89 e9             	mov    %r13,%r9
   f1917:	48 01 f8             	add    %rdi,%rax
   f191a:	48 8b 08             	mov    (%rax),%rcx
   f191d:	4c 8b 40 08          	mov    0x8(%rax),%r8
   f1921:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   f1926:	50                   	push   %rax
   f1927:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f192c:	e8 6f c0 f2 ff       	call   1d9a0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE11walkOrderedIZNKS2_11orderedSelfIZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS5_8CountersERT_mEUlRKSC_RKT0_E_NS_6detail9AcceptAllEEEvRNS_9WorkspaceIiEEbRNS2_12QueryContextINS_11QueryResultEEESD_RSG_EUljE_EEvRKNS2_4NodeERKNS_3BoxIiEENS_6FilterESS_SD_>
   f1931:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f1939:	5a                   	pop    %rdx
   f193a:	59                   	pop    %rcx
   f193b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f1940:	84 c0                	test   %al,%al
   f1942:	0f 85 78 01 00 00    	jne    f1ac0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f1948:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f194d:	49 8b 9f b0 01 00 00 	mov    0x1b0(%r15),%rbx
   f1954:	48 83 fd 7f          	cmp    $0x7f,%rbp
   f1958:	0f 86 5b 03 00 00    	jbe    f1cb9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x939>
   f195e:	49 39 af 48 02 00 00 	cmp    %rbp,0x248(%r15)
   f1965:	0f 82 58 03 00 00    	jb     f1cc3 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f196b:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f1975:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f197c:	48 c1 ea 04          	shr    $0x4,%rdx
   f1980:	48 39 ea             	cmp    %rbp,%rdx
   f1983:	0f 82 3a 03 00 00    	jb     f1cc3 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f1989:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f198d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f1992:	89 e9                	mov    %ebp,%ecx
   f1994:	48 89 da             	mov    %rbx,%rdx
   f1997:	e8 44 0a f2 ff       	call   123e0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f199c:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f19a1:	48 85 ed             	test   %rbp,%rbp
   f19a4:	0f 84 fb 00 00 00    	je     f1aa5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f19aa:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
   f19af:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   f19b4:	31 c9                	xor    %ecx,%ecx
   f19b6:	4d 8b 5f 68          	mov    0x68(%r15),%r11
   f19ba:	4d 8b 4f 60          	mov    0x60(%r15),%r9
   f19be:	4c 89 c2             	mov    %r8,%rdx
   f19c1:	48 8b 07             	mov    (%rdi),%rax
   f19c4:	4c 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%r10
   f19cc:	48 c1 e2 05          	shl    $0x5,%rdx
   f19d0:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
   f19d4:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   f19d9:	4d 8d 34 13          	lea    (%r11,%rdx,1),%r14
   f19dd:	4c 8d 68 01          	lea    0x1(%rax),%r13
   f19e1:	8b 14 8b             	mov    (%rbx,%rcx,4),%edx
   f19e4:	49 8b 76 10          	mov    0x10(%r14),%rsi
   f19e8:	4d 8d 64 0d 00       	lea    0x0(%r13,%rcx,1),%r12
   f19ed:	48 89 d0             	mov    %rdx,%rax
   f19f0:	48 c1 e0 05          	shl    $0x5,%rax
   f19f4:	49 39 74 03 10       	cmp    %rsi,0x10(%r11,%rax,1)
   f19f9:	48 89 d0             	mov    %rdx,%rax
   f19fc:	49 0f 42 c0          	cmovb  %r8,%rax
   f1a00:	49 0f 43 d0          	cmovae %r8,%rdx
   f1a04:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f1a08:	41 8b 34 91          	mov    (%r9,%rdx,4),%esi
   f1a0c:	39 f0                	cmp    %esi,%eax
   f1a0e:	89 f2                	mov    %esi,%edx
   f1a10:	0f 46 d0             	cmovbe %eax,%edx
   f1a13:	48 c1 e2 20          	shl    $0x20,%rdx
   f1a17:	39 f0                	cmp    %esi,%eax
   f1a19:	0f 42 c6             	cmovb  %esi,%eax
   f1a1c:	48 09 d0             	or     %rdx,%rax
   f1a1f:	48 89 c2             	mov    %rax,%rdx
   f1a22:	48 c1 ea 1e          	shr    $0x1e,%rdx
   f1a26:	48 31 c2             	xor    %rax,%rdx
   f1a29:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   f1a33:	48 0f af d0          	imul   %rax,%rdx
   f1a37:	48 89 d0             	mov    %rdx,%rax
   f1a3a:	48 c1 e8 1b          	shr    $0x1b,%rax
   f1a3e:	48 31 c2             	xor    %rax,%rdx
   f1a41:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f1a4b:	48 0f af d0          	imul   %rax,%rdx
   f1a4f:	48 89 d0             	mov    %rdx,%rax
   f1a52:	48 c1 e8 1f          	shr    $0x1f,%rax
   f1a56:	48 31 c2             	xor    %rax,%rdx
   f1a59:	48 01 d7             	add    %rdx,%rdi
   f1a5c:	49 83 fa ff          	cmp    $0xffffffffffffffff,%r10
   f1a60:	0f 84 82 01 00 00    	je     f1be8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x868>
   f1a66:	49 83 c2 01          	add    $0x1,%r10
   f1a6a:	48 83 c1 01          	add    $0x1,%rcx
   f1a6e:	4c 89 94 24 b8 00 00 00 	mov    %r10,0xb8(%rsp)
   f1a76:	48 39 cd             	cmp    %rcx,%rbp
   f1a79:	0f 85 62 ff ff ff    	jne    f19e1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x661>
   f1a7f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f1a84:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f1a88:	4c 89 20             	mov    %r12,(%rax)
   f1a8b:	eb 18                	jmp    f1aa5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f1a8d:	0f 1f 00             	nopl   (%rax)
   f1a90:	49 8b bf b0 01 00 00 	mov    0x1b0(%r15),%rdi
   f1a97:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f1a9c:	31 c9                	xor    %ecx,%ecx
   f1a9e:	31 f6                	xor    %esi,%esi
   f1aa0:	e8 7b d2 05 00       	call   14ed20 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f1aa5:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f1aac:	48 83 44 24 08 01    	addq   $0x1,0x8(%rsp)
   f1ab2:	48 89 c2             	mov    %rax,%rdx
   f1ab5:	48 39 44 24 08       	cmp    %rax,0x8(%rsp)
   f1aba:	0f 82 30 fd ff ff    	jb     f17f0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x470>
   f1ac0:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f1ac5:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f1acd:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f1ad5:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f1add:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f1ae5:	41 c6 87 6c 02 00 00 00 	movb   $0x0,0x26c(%r15)
   f1aed:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f1af5:	e8 66 c2 00 00       	call   fdd60 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f1afa:	0f b6 94 24 90 00 00 00 	movzbl 0x90(%rsp),%edx
   f1b02:	66 0f 6f 84 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm0
   f1b0b:	66 0f 6f 9c 24 90 00 00 00 	movdqa 0x90(%rsp),%xmm3
   f1b14:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f1b1c:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f1b25:	0f 29 9c 24 d0 00 00 00 	movaps %xmm3,0xd0(%rsp)
   f1b2d:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f1b35:	80 fa 0b             	cmp    $0xb,%dl
   f1b38:	74 08                	je     f1b42 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7c2>
   f1b3a:	84 d2                	test   %dl,%dl
   f1b3c:	0f 85 97 f8 ff ff    	jne    f13d9 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f1b42:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f1b49:	e9 98 fb ff ff       	jmp    f16e6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x366>
   f1b4e:	66 90                	xchg   %ax,%ax
   f1b50:	49 8b 6f 68          	mov    0x68(%r15),%rbp
   f1b54:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
   f1b59:	31 db                	xor    %ebx,%ebx
   f1b5b:	eb 49                	jmp    f1ba6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x826>
   f1b5d:	0f 1f 00             	nopl   (%rax)
   f1b60:	4c 89 e9             	mov    %r13,%rcx
   f1b63:	44 89 f2             	mov    %r14d,%edx
   f1b66:	4c 89 e7             	mov    %r12,%rdi
   f1b69:	e8 32 fe f1 ff       	call   119a0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_12QueryContextINS_11QueryResultEEERT0_.isra.0>
   f1b6e:	84 c0                	test   %al,%al
   f1b70:	74 19                	je     f1b8b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x80b>
   f1b72:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   f1b77:	48 8d 50 01          	lea    0x1(%rax),%rdx
   f1b7b:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f1b80:	49 8b 97 b0 01 00 00 	mov    0x1b0(%r15),%rdx
   f1b87:	44 89 34 82          	mov    %r14d,(%rdx,%rax,4)
   f1b8b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f1b92:	48 83 c3 01          	add    $0x1,%rbx
   f1b96:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f1b9e:	39 d3                	cmp    %edx,%ebx
   f1ba0:	0f 83 9a fd ff ff    	jae    f1940 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f1ba6:	84 c0                	test   %al,%al
   f1ba8:	0f 85 12 ff ff ff    	jne    f1ac0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f1bae:	8b 44 24 44          	mov    0x44(%rsp),%eax
   f1bb2:	41 89 de             	mov    %ebx,%r14d
   f1bb5:	48 89 c6             	mov    %rax,%rsi
   f1bb8:	48 c1 e0 05          	shl    $0x5,%rax
   f1bbc:	48 01 e8             	add    %rbp,%rax
   f1bbf:	48 89 d9             	mov    %rbx,%rcx
   f1bc2:	48 c1 e1 05          	shl    $0x5,%rcx
   f1bc6:	48 8b 7c 0d 10       	mov    0x10(%rbp,%rcx,1),%rdi
   f1bcb:	48 39 78 10          	cmp    %rdi,0x10(%rax)
   f1bcf:	72 8f                	jb     f1b60 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e0>
   f1bd1:	48 83 c3 01          	add    $0x1,%rbx
   f1bd5:	39 d3                	cmp    %edx,%ebx
   f1bd7:	0f 83 6b fd ff ff    	jae    f1948 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c8>
   f1bdd:	41 89 de             	mov    %ebx,%r14d
   f1be0:	eb dd                	jmp    f1bbf <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x83f>
   f1be2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1be8:	4c 8d 69 01          	lea    0x1(%rcx),%r13
   f1bec:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   f1bf1:	4c 39 ed             	cmp    %r13,%rbp
   f1bf4:	0f 84 85 fe ff ff    	je     f1a7f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x6ff>
   f1bfa:	4d 8b 74 13 10       	mov    0x10(%r11,%rdx,1),%r14
   f1bff:	4c 89 ee             	mov    %r13,%rsi
   f1c02:	0f 1f 00             	nopl   (%rax)
   f1c05:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1c10:	8b 04 b3             	mov    (%rbx,%rsi,4),%eax
   f1c13:	48 89 c2             	mov    %rax,%rdx
   f1c16:	48 c1 e2 05          	shl    $0x5,%rdx
   f1c1a:	4d 39 74 13 10       	cmp    %r14,0x10(%r11,%rdx,1)
   f1c1f:	48 89 c2             	mov    %rax,%rdx
   f1c22:	49 0f 42 d0          	cmovb  %r8,%rdx
   f1c26:	49 0f 43 c0          	cmovae %r8,%rax
   f1c2a:	45 8b 14 91          	mov    (%r9,%rdx,4),%r10d
   f1c2e:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f1c32:	44 89 d2             	mov    %r10d,%edx
   f1c35:	44 39 d0             	cmp    %r10d,%eax
   f1c38:	0f 46 d0             	cmovbe %eax,%edx
   f1c3b:	48 c1 e2 20          	shl    $0x20,%rdx
   f1c3f:	44 39 d0             	cmp    %r10d,%eax
   f1c42:	41 0f 42 c2          	cmovb  %r10d,%eax
   f1c46:	48 83 c6 01          	add    $0x1,%rsi
   f1c4a:	48 09 c2             	or     %rax,%rdx
   f1c4d:	48 89 d0             	mov    %rdx,%rax
   f1c50:	48 c1 e8 1e          	shr    $0x1e,%rax
   f1c54:	48 31 d0             	xor    %rdx,%rax
   f1c57:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f1c61:	48 0f af c2          	imul   %rdx,%rax
   f1c65:	48 89 c2             	mov    %rax,%rdx
   f1c68:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f1c6c:	48 31 c2             	xor    %rax,%rdx
   f1c6f:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f1c79:	48 0f af d0          	imul   %rax,%rdx
   f1c7d:	48 89 d0             	mov    %rdx,%rax
   f1c80:	48 c1 e8 1f          	shr    $0x1f,%rax
   f1c84:	48 31 d0             	xor    %rdx,%rax
   f1c87:	48 01 c7             	add    %rax,%rdi
   f1c8a:	48 39 ee             	cmp    %rbp,%rsi
   f1c8d:	72 81                	jb     f1c10 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x890>
   f1c8f:	48 8d 45 ff          	lea    -0x1(%rbp),%rax
   f1c93:	48 83 c1 02          	add    $0x2,%rcx
   f1c97:	31 d2                	xor    %edx,%edx
   f1c99:	4c 29 e8             	sub    %r13,%rax
   f1c9c:	48 39 cd             	cmp    %rcx,%rbp
   f1c9f:	48 0f 42 c2          	cmovb  %rdx,%rax
   f1ca3:	4d 8d 64 04 01       	lea    0x1(%r12,%rax,1),%r12
   f1ca8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f1cad:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f1cb1:	4c 89 20             	mov    %r12,(%rax)
   f1cb4:	e9 ec fd ff ff       	jmp    f1aa5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f1cb9:	48 83 fd 01          	cmp    $0x1,%rbp
   f1cbd:	0f 86 d3 00 00 00    	jbe    f1d96 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa16>
   f1cc3:	48 89 e8             	mov    %rbp,%rax
   f1cc6:	31 c9                	xor    %ecx,%ecx
   f1cc8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1cd0:	48 d1 e8             	shr    $1,%rax
   f1cd3:	83 c1 02             	add    $0x2,%ecx
   f1cd6:	48 83 f8 01          	cmp    $0x1,%rax
   f1cda:	75 f4                	jne    f1cd0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x950>
   f1cdc:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f1ce1:	48 89 ee             	mov    %rbp,%rsi
   f1ce4:	48 89 df             	mov    %rbx,%rdi
   f1ce7:	e8 34 d0 05 00       	call   14ed20 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f1cec:	e9 b0 fc ff ff       	jmp    f19a1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x621>
   f1cf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f1cf8:	c6 84 24 90 00 00 00 0b 	movb   $0xb,0x90(%rsp)
   f1d00:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f1d05:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f1d0d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f1d15:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f1d1d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f1d25:	e9 bb fd ff ff       	jmp    f1ae5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f1d2a:	e8 f1 49 00 00       	call   f6720 <_ZN8QuadTree15defaultResourceEv>
   f1d2f:	41 8b b7 d0 00 00 00 	mov    0xd0(%r15),%esi
   f1d36:	48 89 f1             	mov    %rsi,%rcx
   f1d39:	e9 26 f7 ff ff       	jmp    f1464 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xe4>
   f1d3e:	31 c9                	xor    %ecx,%ecx
   f1d40:	e9 57 fa ff ff       	jmp    f179c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x41c>
   f1d45:	31 c0                	xor    %eax,%eax
   f1d47:	e9 0f f9 ff ff       	jmp    f165b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2db>
   f1d4c:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f1d54:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f1d5c:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f1d64:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f1d6c:	e8 ef 54 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f1d71:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f1d79:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f1d81:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f1d89:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f1d91:	e8 6a 50 00 00       	call   f6e00 <_ZN8QuadTree6detail15activeWorkspaceEv>
   f1d96:	31 c9                	xor    %ecx,%ecx
   f1d98:	e9 3f ff ff ff       	jmp    f1cdc <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x95c>
