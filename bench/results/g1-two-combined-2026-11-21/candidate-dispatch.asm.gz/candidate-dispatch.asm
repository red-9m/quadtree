
# candidate unordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, false>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-combined.ARqsxS/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f1080 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f1080:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f1087:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f108b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f1093:	48 8b 2a             	mov    (%rdx),%rbp
   f1096:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f109e:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f10a2:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f10aa:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f10b2:	49 89 ff             	mov    %rdi,%r15
   f10b5:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f10bd:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f10c4:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f10c9:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f10d2:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f10da:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f10de:	0f 11 07             	movups %xmm0,(%rdi)
   f10e1:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f10e5:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f10e9:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f10ed:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f10f1:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f10f5:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f10f9:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f10fd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   f1102:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f1106:	e8 35 32 06 00       	call   154340 <_ZN5bench6memory11allocationsEv>
   f110b:	80 3d 66 41 08 00 00 	cmpb   $0x0,0x84166(%rip)        # 175278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1112:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f1117:	49 89 c5             	mov    %rax,%r13
   f111a:	0f 84 18 0f 00 00    	je     f2038 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfb8>
   f1120:	0f 31                	rdtsc
   f1122:	48 c1 e2 20          	shl    $0x20,%rdx
   f1126:	48 09 d0             	or     %rdx,%rax
   f1129:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f1131:	49 8b 11             	mov    (%r9),%rdx
   f1134:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   f1138:	0f 84 58 09 00 00    	je     f1a96 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa16>
   f113e:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   f1147:	49 29 ec             	sub    %rbp,%r12
   f114a:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f114e:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f1156:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f115f:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f1168:	c7 44 24 70 00 00 00 00 	movl   $0x0,0x70(%rsp)
   f1170:	c6 44 24 77 00       	movb   $0x0,0x77(%rsp)
   f1175:	4c 89 8c 24 88 00 00 00 	mov    %r9,0x88(%rsp)
   f117d:	4c 89 ac 24 b8 00 00 00 	mov    %r13,0xb8(%rsp)
   f1185:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f118d:	49 89 de             	mov    %rbx,%r14
   f1190:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f1198:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f11a0:	45 31 e4             	xor    %r12d,%r12d
   f11a3:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f11a8:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f11ad:	0f 1f 00             	nopl   (%rax)
   f11b0:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
   f11b4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f11b8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f11bc:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f11c4:	48 8b 28             	mov    (%rax),%rbp
   f11c7:	4c 8b 68 08          	mov    0x8(%rax),%r13
   f11cb:	49 29 ed             	sub    %rbp,%r13
   f11ce:	4c 89 eb             	mov    %r13,%rbx
   f11d1:	48 c1 fb 04          	sar    $0x4,%rbx
   f11d5:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f11dd:	74 14                	je     f11f3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x173>
   f11df:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f11e6:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   f11ed:	0f 84 cb 05 00 00    	je     f17be <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x73e>
   f11f3:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f11fb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f11ff:	31 f6                	xor    %esi,%esi
   f1201:	66 0f 6f 3d d7 c6 06 00 	movdqa 0x6c6d7(%rip),%xmm7        # 15d8e0 <C.66.5+0x2c0>
   f1209:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f1211:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f1219:	ba 88 01 00 00       	mov    $0x188,%edx
   f121e:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f1225:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f122a:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f1232:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f123a:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f123f:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f1247:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f124b:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f1254:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f125c:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f1265:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f126d:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f1276:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f127e:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f1286:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f128b:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f1293:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f1298:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f12a0:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f12a5:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f12ad:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f12b9:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f12c5:	e8 46 5e f1 ff       	call   7110 <memset@plt>
   f12ca:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f12d0:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f12d4:	66 0f 6f 05 14 c6 06 00 	movdqa 0x6c614(%rip),%xmm0        # 15d8f0 <C.66.5+0x2d0>
   f12dc:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f12e2:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f12e8:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f12ec:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f12f3:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f12fb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1300:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f1308:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f1310:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f1318:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f1324:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   f132c:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f1338:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f1344:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f1350:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f135c:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f1368:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f1373:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f137b:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f1386:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f1392:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f139a:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f13a6:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f13b1:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f13b9:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   f13c1:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f13cd:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f13d9:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   f13e1:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f13ed:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f13f5:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f13fd:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f1405:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f140d:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f1415:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f1421:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f1429:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f1432:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f143a:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f1442:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f144b:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f1453:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f145b:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f1464:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f146c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f1473:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f147b:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   f1483:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f148f:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f149b:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   f14a3:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f14af:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f14bb:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f14c7:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f14d2:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f14de:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   f14e6:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f14f1:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f14fc:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f1508:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f1510:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   f1518:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   f1520:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   f1528:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   f1530:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f1538:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f1540:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f1548:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f1550:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f1558:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f155f:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f1568:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f1573:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f157a:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f1581:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f158c:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f1593:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f159b:	e8 60 0d 01 00       	call   102300 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f15a0:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f15a8:	0f 85 e2 06 00 00    	jne    f1c90 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc10>
   f15ae:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f15b7:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f15bf:	4d 89 76 50          	mov    %r14,0x50(%r14)
   f15c3:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f15cb:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f15d4:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   f15dc:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   f15e1:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f15ea:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f15f2:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   f15f7:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f1600:	49 89 46 48          	mov    %rax,0x48(%r14)
   f1604:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f160b:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   f1610:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f1619:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   f1620:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1625:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   f162a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f162e:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   f1636:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f163f:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   f1646:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   f164e:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f1656:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f165f:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   f1667:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   f166f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1673:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   f167b:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   f1683:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   f168b:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   f1693:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   f169b:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f16a6:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   f16ae:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f16b9:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f16c4:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   f16cf:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f16d6:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f16df:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   f16e6:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   f16ed:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f16f4:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   f16ff:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f1706:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f170b:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f1712:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f1719:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   f1724:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   f172b:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   f1736:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   f1741:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   f1748:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   f1753:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   f175e:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   f1765:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   f1770:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   f177b:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f1786:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f1791:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   f1799:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   f17a0:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   f17a8:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f17b1:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f17b9:	e8 42 0b 01 00       	call   102300 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f17be:	49 39 9e c0 02 00 00 	cmp    %rbx,0x2c0(%r14)
   f17c5:	0f 82 85 04 00 00    	jb     f1c50 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd0>
   f17cb:	4d 8b 86 78 02 00 00 	mov    0x278(%r14),%r8
   f17d2:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f17d9:	48 be b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rsi
   f17e3:	4c 89 c2             	mov    %r8,%rdx
   f17e6:	4c 29 d2             	sub    %r10,%rdx
   f17e9:	48 89 d0             	mov    %rdx,%rax
   f17ec:	48 c1 f8 03          	sar    $0x3,%rax
   f17f0:	48 0f af c6          	imul   %rsi,%rax
   f17f4:	48 39 d8             	cmp    %rbx,%rax
   f17f7:	0f 82 d3 03 00 00    	jb     f1bd0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb50>
   f17fd:	48 39 c3             	cmp    %rax,%rbx
   f1800:	73 16                	jae    f1818 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x798>
   f1802:	48 6b c3 38          	imul   $0x38,%rbx,%rax
   f1806:	49 01 c2             	add    %rax,%r10
   f1809:	4d 39 d0             	cmp    %r10,%r8
   f180c:	74 07                	je     f1815 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x795>
   f180e:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f1815:	4d 89 d0             	mov    %r10,%r8
   f1818:	49 8b b6 70 02 00 00 	mov    0x270(%r14),%rsi
   f181f:	4d 85 ed             	test   %r13,%r13
   f1822:	74 4d                	je     f1871 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7f1>
   f1824:	48 89 f0             	mov    %rsi,%rax
   f1827:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f182b:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   f182f:	31 d2                	xor    %edx,%edx
   f1831:	0f 1f 40 00          	nopl   0x0(%rax)
   f1835:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1840:	f3 0f 6f 4d 00       	movdqu 0x0(%rbp),%xmm1
   f1845:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f1849:	48 83 c5 10          	add    $0x10,%rbp
   f184d:	48 83 c0 38          	add    $0x38,%rax
   f1851:	89 50 d8             	mov    %edx,-0x28(%rax)
   f1854:	48 83 c2 01          	add    $0x1,%rdx
   f1858:	0f 11 40 e8          	movups %xmm0,-0x18(%rax)
   f185c:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f1864:	0f 11 48 c8          	movups %xmm1,-0x38(%rax)
   f1868:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
   f186c:	48 39 da             	cmp    %rbx,%rdx
   f186f:	72 cf                	jb     f1840 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f1871:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f187d:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1881:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f1889:	4c 39 c6             	cmp    %r8,%rsi
   f188c:	0f 84 1e 04 00 00    	je     f1cb0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc30>
   f1892:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f189c:	4c 89 c3             	mov    %r8,%rbx
   f189f:	48 29 f3             	sub    %rsi,%rbx
   f18a2:	48 c1 fb 03          	sar    $0x3,%rbx
   f18a6:	48 0f af d8          	imul   %rax,%rbx
   f18aa:	49 39 5e 38          	cmp    %rbx,0x38(%r14)
   f18ae:	0f 82 8c 04 00 00    	jb     f1d40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc0>
   f18b4:	41 8b 46 2c          	mov    0x2c(%r14),%eax
   f18b8:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f18bc:	48 39 d8             	cmp    %rbx,%rax
   f18bf:	72 2f                	jb     f18f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x870>
   f18c1:	41 8b 86 d4 00 00 00 	mov    0xd4(%r14),%eax
   f18c8:	48 39 d8             	cmp    %rbx,%rax
   f18cb:	72 23                	jb     f18f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x870>
   f18cd:	41 8b 86 d8 00 00 00 	mov    0xd8(%r14),%eax
   f18d4:	48 39 d8             	cmp    %rbx,%rax
   f18d7:	72 17                	jb     f18f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x870>
   f18d9:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f18de:	0f 85 31 06 00 00    	jne    f1f15 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe95>
   f18e4:	90                   	nop
   f18e5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f18f0:	48 83 ec 20          	sub    $0x20,%rsp
   f18f4:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   f18fb:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   f1902:	48 89 da             	mov    %rbx,%rdx
   f1905:	48 8b 84 24 40 03 00 00 	mov    0x340(%rsp),%rax
   f190d:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f1916:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   f191b:	0f 11 04 24          	movups %xmm0,(%rsp)
   f191f:	e8 5c 3f fe ff       	call   d5880 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f1924:	48 83 c4 20          	add    $0x20,%rsp
   f1928:	84 c0                	test   %al,%al
   f192a:	0f 85 49 07 00 00    	jne    f2079 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xff9>
   f1930:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f1939:	0f 84 f1 01 00 00    	je     f1b30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab0>
   f193f:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f1944:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f194c:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f1954:	4c 89 f6             	mov    %r14,%rsi
   f1957:	e8 a4 f0 ff ff       	call   f0a00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f195c:	8b 4c 24 70          	mov    0x70(%rsp),%ecx
   f1960:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f1967:	48 8b bc 24 38 03 00 00 	mov    0x338(%rsp),%rdi
   f196f:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f1975:	39 c1                	cmp    %eax,%ecx
   f1977:	48 8b 94 24 c8 00 00 00 	mov    0xc8(%rsp),%rdx
   f197f:	48 8b b4 24 c0 00 00 00 	mov    0xc0(%rsp),%rsi
   f1987:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f1990:	0f 43 c1             	cmovae %ecx,%eax
   f1993:	48 01 7c 24 08       	add    %rdi,0x8(%rsp)
   f1998:	48 01 74 24 10       	add    %rsi,0x10(%rsp)
   f199d:	4c 01 e2             	add    %r12,%rdx
   f19a0:	0f b6 4c 24 77       	movzbl 0x77(%rsp),%ecx
   f19a5:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f19ae:	89 44 24 70          	mov    %eax,0x70(%rsp)
   f19b2:	41 89 47 38          	mov    %eax,0x38(%r15)
   f19b6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f19bb:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f19bf:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f19c8:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f19ce:	49 89 47 40          	mov    %rax,0x40(%r15)
   f19d2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f19d7:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f19db:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f19e0:	49 89 47 48          	mov    %rax,0x48(%r15)
   f19e4:	48 89 d0             	mov    %rdx,%rax
   f19e7:	48 c1 e8 1e          	shr    $0x1e,%rax
   f19eb:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f19f0:	48 31 d0             	xor    %rdx,%rax
   f19f3:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f19f8:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f1a02:	48 0f af c2          	imul   %rdx,%rax
   f1a06:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f1a0b:	48 89 c2             	mov    %rax,%rdx
   f1a0e:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f1a12:	48 31 d0             	xor    %rdx,%rax
   f1a15:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f1a1f:	48 0f af c2          	imul   %rdx,%rax
   f1a23:	48 89 c2             	mov    %rax,%rdx
   f1a26:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f1a2a:	48 31 d0             	xor    %rdx,%rax
   f1a2d:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   f1a32:	84 c9                	test   %cl,%cl
   f1a34:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   f1a39:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f1a41:	49 89 77 50          	mov    %rsi,0x50(%r15)
   f1a45:	0f 44 c8             	cmove  %eax,%ecx
   f1a48:	49 83 c4 01          	add    $0x1,%r12
   f1a4c:	88 4c 24 77          	mov    %cl,0x77(%rsp)
   f1a50:	41 88 4f 68          	mov    %cl,0x68(%r15)
   f1a54:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f1a5c:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f1a66:	48 8b 10             	mov    (%rax),%rdx
   f1a69:	48 8b 40 08          	mov    0x8(%rax),%rax
   f1a6d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f1a72:	48 29 d0             	sub    %rdx,%rax
   f1a75:	48 c1 f8 03          	sar    $0x3,%rax
   f1a79:	48 0f af c1          	imul   %rcx,%rax
   f1a7d:	49 39 c4             	cmp    %rax,%r12
   f1a80:	0f 82 2a f7 ff ff    	jb     f11b0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f1a86:	4c 8b ac 24 b8 00 00 00 	mov    0xb8(%rsp),%r13
   f1a8e:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f1a96:	80 3d db 37 08 00 00 	cmpb   $0x0,0x837db(%rip)        # 175278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1a9d:	0f 84 b1 05 00 00    	je     f2054 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfd4>
   f1aa3:	0f 31                	rdtsc
   f1aa5:	48 c1 e2 20          	shl    $0x20,%rdx
   f1aa9:	48 09 d0             	or     %rdx,%rax
   f1aac:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f1ab4:	0f 88 60 05 00 00    	js     f201a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf9a>
   f1aba:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1abe:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1ac3:	f2 0f 59 05 65 37 08 00 	mulsd  0x83765(%rip),%xmm0        # 175230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1acb:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1ad0:	49 89 07             	mov    %rax,(%r15)
   f1ad3:	e8 68 28 06 00       	call   154340 <_ZN5bench6memory11allocationsEv>
   f1ad8:	4c 29 e8             	sub    %r13,%rax
   f1adb:	49 89 47 58          	mov    %rax,0x58(%r15)
   f1adf:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f1ae7:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f1af0:	0f 85 8b 05 00 00    	jne    f2081 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x1001>
   f1af6:	4c 89 f8             	mov    %r15,%rax
   f1af9:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f1b01:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f1b09:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f1b11:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f1b19:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f1b21:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f1b28:	c3                   	ret
   f1b29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f1b30:	80 3d 41 37 08 00 00 	cmpb   $0x0,0x83741(%rip)        # 175278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1b37:	0f 84 cb 03 00 00    	je     f1f08 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe88>
   f1b3d:	0f 31                	rdtsc
   f1b3f:	48 c1 e2 20          	shl    $0x20,%rdx
   f1b43:	48 09 d0             	or     %rdx,%rax
   f1b46:	48 89 c3             	mov    %rax,%rbx
   f1b49:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f1b4e:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f1b56:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f1b5e:	4c 89 f6             	mov    %r14,%rsi
   f1b61:	e8 9a ee ff ff       	call   f0a00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f1b66:	f2 0f 10 0d c2 36 08 00 	movsd  0x836c2(%rip),%xmm1        # 175230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1b6e:	48 89 d8             	mov    %rbx,%rax
   f1b71:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f1b79:	0f 88 51 03 00 00    	js     f1ed0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe50>
   f1b7f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1b83:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1b88:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1b8c:	80 3d e5 36 08 00 00 	cmpb   $0x0,0x836e5(%rip)        # 175278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1b93:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1b98:	49 89 47 08          	mov    %rax,0x8(%r15)
   f1b9c:	0f 84 4e 03 00 00    	je     f1ef0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   f1ba2:	0f 31                	rdtsc
   f1ba4:	48 c1 e2 20          	shl    $0x20,%rdx
   f1ba8:	48 09 d0             	or     %rdx,%rax
   f1bab:	48 29 d8             	sub    %rbx,%rax
   f1bae:	0f 88 fc 02 00 00    	js     f1eb0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe30>
   f1bb4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1bb8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1bbd:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1bc1:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1bc6:	49 89 47 10          	mov    %rax,0x10(%r15)
   f1bca:	e9 8d fd ff ff       	jmp    f195c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8dc>
   f1bcf:	90                   	nop
   f1bd0:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   f1bd7:	49 89 db             	mov    %rbx,%r11
   f1bda:	48 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rcx
   f1be4:	49 29 c3             	sub    %rax,%r11
   f1be7:	48 89 f7             	mov    %rsi,%rdi
   f1bea:	4c 29 c7             	sub    %r8,%rdi
   f1bed:	48 c1 ff 03          	sar    $0x3,%rdi
   f1bf1:	48 0f af f9          	imul   %rcx,%rdi
   f1bf5:	4c 39 df             	cmp    %r11,%rdi
   f1bf8:	0f 82 62 01 00 00    	jb     f1d60 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xce0>
   f1bfe:	4c 89 da             	mov    %r11,%rdx
   f1c01:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1c05:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1c09:	4c 89 c0             	mov    %r8,%rax
   f1c0c:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   f1c15:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1c20:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f1c24:	48 83 c0 38          	add    $0x38,%rax
   f1c28:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f1c2c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f1c30:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f1c34:	48 83 ea 01          	sub    $0x1,%rdx
   f1c38:	75 e6                	jne    f1c20 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   f1c3a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f1c3e:	4d 01 d8             	add    %r11,%r8
   f1c41:	4d 89 86 78 02 00 00 	mov    %r8,0x278(%r14)
   f1c48:	e9 cb fb ff ff       	jmp    f1818 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x798>
   f1c4d:	0f 1f 00             	nopl   (%rax)
   f1c50:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1c54:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f1c5c:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   f1c63:	48 89 9c 24 20 03 00 00 	mov    %rbx,0x320(%rsp)
   f1c6b:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f1c73:	e8 c8 3b 02 00       	call   115840 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f1c78:	84 c0                	test   %al,%al
   f1c7a:	0f 85 f9 03 00 00    	jne    f2079 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xff9>
   f1c80:	49 89 9e c0 02 00 00 	mov    %rbx,0x2c0(%r14)
   f1c87:	e9 3f fb ff ff       	jmp    f17cb <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x74b>
   f1c8c:	0f 1f 40 00          	nopl   0x0(%rax)
   f1c90:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   f1c98:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f1c9c:	e8 5f 06 01 00       	call   102300 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1ca1:	e9 08 f9 ff ff       	jmp    f15ae <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x52e>
   f1ca6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f1cb0:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   f1cb8:	74 58                	je     f1d12 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   f1cba:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   f1cc1:	48 85 d2             	test   %rdx,%rdx
   f1cc4:	0f 85 d6 02 00 00    	jne    f1fa0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf20>
   f1cca:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1ccf:	66 0f 6f 05 e9 bb 06 00 	movdqa 0x6bbe9(%rip),%xmm0        # 15d8c0 <C.66.5+0x2a0>
   f1cd7:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   f1ce2:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f1ced:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f1cf4:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f1cff:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f1d0a:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   f1d12:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f1d17:	0f 84 13 fc ff ff    	je     f1930 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8b0>
   f1d1d:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   f1d25:	0f 84 05 fc ff ff    	je     f1930 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8b0>
   f1d2b:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   f1d33:	e9 f8 fb ff ff       	jmp    f1930 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8b0>
   f1d38:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1d40:	ba 10 00 00 00       	mov    $0x10,%edx
   f1d45:	48 8b 3d 14 35 08 00 	mov    0x83514(%rip),%rdi        # 175260 <stderr@GLIBC_2.2.5>
   f1d4c:	48 8d 35 4d 9c 06 00 	lea    0x69c4d(%rip),%rsi        # 15b9a0 <_IO_stdin_used+0x19a0>
   f1d53:	31 c0                	xor    %eax,%eax
   f1d55:	e8 e6 55 f1 ff       	call   7340 <fprintf@plt>
   f1d5a:	e8 c1 53 f1 ff       	call   7120 <abort@plt>
   f1d5f:	90                   	nop
   f1d60:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f1d6a:	48 29 c7             	sub    %rax,%rdi
   f1d6d:	4c 39 df             	cmp    %r11,%rdi
   f1d70:	0f 82 e0 b0 f1 ff    	jb     ce56 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f1d76:	4c 39 d8             	cmp    %r11,%rax
   f1d79:	4c 89 d9             	mov    %r11,%rcx
   f1d7c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f1d84:	48 0f 43 c8          	cmovae %rax,%rcx
   f1d88:	48 89 94 24 a8 00 00 00 	mov    %rdx,0xa8(%rsp)
   f1d90:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f1d98:	48 01 c1             	add    %rax,%rcx
   f1d9b:	4c 89 44 24 60       	mov    %r8,0x60(%rsp)
   f1da0:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f1daa:	48 39 c1             	cmp    %rax,%rcx
   f1dad:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f1db2:	48 0f 47 c8          	cmova  %rax,%rcx
   f1db6:	48 6b c1 38          	imul   $0x38,%rcx,%rax
   f1dba:	48 89 c7             	mov    %rax,%rdi
   f1dbd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f1dc2:	e8 39 27 06 00       	call   154500 <_Znwm>
   f1dc7:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f1dcd:	48 8b 94 24 a8 00 00 00 	mov    0xa8(%rsp),%rdx
   f1dd5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1dd9:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
   f1dde:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f1de6:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1dea:	48 01 c2             	add    %rax,%rdx
   f1ded:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f1df5:	49 01 d3             	add    %rdx,%r11
   f1df8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f1e00:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
   f1e04:	48 83 c2 38          	add    $0x38,%rdx
   f1e08:	0f 11 42 c8          	movups %xmm0,-0x38(%rdx)
   f1e0c:	0f 11 4a e0          	movups %xmm1,-0x20(%rdx)
   f1e10:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
   f1e14:	4c 39 da             	cmp    %r11,%rdx
   f1e17:	75 e7                	jne    f1e00 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f1e19:	4d 39 d0             	cmp    %r10,%r8
   f1e1c:	74 51                	je     f1e6f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdef>
   f1e1e:	4c 89 d2             	mov    %r10,%rdx
   f1e21:	48 89 c7             	mov    %rax,%rdi
   f1e24:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1e2a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1e35:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1e40:	f3 0f 6f 02          	movdqu (%rdx),%xmm0
   f1e44:	48 8b 4a 30          	mov    0x30(%rdx),%rcx
   f1e48:	48 83 c2 38          	add    $0x38,%rdx
   f1e4c:	48 83 c7 38          	add    $0x38,%rdi
   f1e50:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f1e54:	f3 0f 6f 42 d8       	movdqu -0x28(%rdx),%xmm0
   f1e59:	48 89 4f f8          	mov    %rcx,-0x8(%rdi)
   f1e5d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f1e61:	f3 0f 6f 42 e8       	movdqu -0x18(%rdx),%xmm0
   f1e66:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f1e6a:	49 39 d0             	cmp    %rdx,%r8
   f1e6d:	75 d1                	jne    f1e40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdc0>
   f1e6f:	4d 85 d2             	test   %r10,%r10
   f1e72:	74 15                	je     f1e89 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe09>
   f1e74:	4c 29 d6             	sub    %r10,%rsi
   f1e77:	4c 89 d7             	mov    %r10,%rdi
   f1e7a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f1e7f:	e8 fc 27 06 00       	call   154680 <_ZdlPvm>
   f1e84:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f1e89:	4c 6b c3 38          	imul   $0x38,%rbx,%r8
   f1e8d:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   f1e94:	49 01 c0             	add    %rax,%r8
   f1e97:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f1e9c:	4d 89 86 78 02 00 00 	mov    %r8,0x278(%r14)
   f1ea3:	49 89 86 80 02 00 00 	mov    %rax,0x280(%r14)
   f1eaa:	e9 69 f9 ff ff       	jmp    f1818 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x798>
   f1eaf:	90                   	nop
   f1eb0:	48 89 c2             	mov    %rax,%rdx
   f1eb3:	83 e0 01             	and    $0x1,%eax
   f1eb6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1eba:	48 d1 ea             	shr    $1,%rdx
   f1ebd:	48 09 c2             	or     %rax,%rdx
   f1ec0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1ec5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1ec9:	e9 ef fc ff ff       	jmp    f1bbd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb3d>
   f1ece:	66 90                	xchg   %ax,%ax
   f1ed0:	48 89 c2             	mov    %rax,%rdx
   f1ed3:	83 e0 01             	and    $0x1,%eax
   f1ed6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1eda:	48 d1 ea             	shr    $1,%rdx
   f1edd:	48 09 c2             	or     %rax,%rdx
   f1ee0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1ee5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1ee9:	e9 9a fc ff ff       	jmp    f1b88 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb08>
   f1eee:	66 90                	xchg   %ax,%ax
   f1ef0:	e8 db 53 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f1ef5:	f2 0f 10 0d 33 33 08 00 	movsd  0x83333(%rip),%xmm1        # 175230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1efd:	e9 a9 fc ff ff       	jmp    f1bab <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb2b>
   f1f02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1f08:	e8 c3 53 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f1f0d:	48 89 c3             	mov    %rax,%rbx
   f1f10:	e9 34 fc ff ff       	jmp    f1b49 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xac9>
   f1f15:	49 39 9e 18 02 00 00 	cmp    %rbx,0x218(%r14)
   f1f1c:	0f 82 ee 00 00 00    	jb     f2010 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf90>
   f1f22:	49 39 9e 30 02 00 00 	cmp    %rbx,0x230(%r14)
   f1f29:	0f 82 e1 00 00 00    	jb     f2010 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf90>
   f1f2f:	49 39 9e 48 02 00 00 	cmp    %rbx,0x248(%r14)
   f1f36:	0f 82 d4 00 00 00    	jb     f2010 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf90>
   f1f3c:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f1f46:	49 f7 a6 60 02 00 00 	mulq   0x260(%r14)
   f1f4d:	48 c1 ea 04          	shr    $0x4,%rdx
   f1f51:	48 39 da             	cmp    %rbx,%rdx
   f1f54:	0f 82 b6 00 00 00    	jb     f2010 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf90>
   f1f5a:	41 80 be 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r14)
   f1f62:	0f 85 26 01 00 00    	jne    f208e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x100e>
   f1f68:	41 c6 86 6c 02 00 00 01 	movb   $0x1,0x26c(%r14)
   f1f70:	45 31 c0             	xor    %r8d,%r8d
   f1f73:	31 c9                	xor    %ecx,%ecx
   f1f75:	89 da                	mov    %ebx,%edx
   f1f77:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
   f1f7c:	e8 bf 07 f2 ff       	call   12740 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE16buildFlatIntegerEPKNS_10BuildEntryIjiNS_3BoxIiEEEEjSt8optionalISt4spanINS_6HandleINS_6detail10EntryStoreIijS1_S2_EEEELm18446744073709551615EEE.isra.0>
   f1f81:	41 c6 86 6c 02 00 00 00 	movb   $0x0,0x26c(%r14)
   f1f89:	89 c7                	mov    %eax,%edi
   f1f8b:	66 c1 ef 08          	shr    $0x8,%di
   f1f8f:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
   f1f94:	0f 84 56 f9 ff ff    	je     f18f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x870>
   f1f9a:	e9 89 f9 ff ff       	jmp    f1928 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8a8>
   f1f9f:	90                   	nop
   f1fa0:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   f1fab:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   f1fb3:	0f 85 a5 00 00 00    	jne    f205e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfde>
   f1fb9:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   f1fc0:	83 c0 01             	add    $0x1,%eax
   f1fc3:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   f1fca:	83 f8 ff             	cmp    $0xffffffff,%eax
   f1fcd:	0f 85 f7 fc ff ff    	jne    f1cca <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f1fd3:	49 8b 46 78          	mov    0x78(%r14),%rax
   f1fd7:	48 89 d1             	mov    %rdx,%rcx
   f1fda:	48 c1 e1 04          	shl    $0x4,%rcx
   f1fde:	48 01 c1             	add    %rax,%rcx
   f1fe1:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f1fe8:	48 83 c0 10          	add    $0x10,%rax
   f1fec:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f1ff4:	48 39 c8             	cmp    %rcx,%rax
   f1ff7:	75 e8                	jne    f1fe1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf61>
   f1ff9:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   f2000:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f200b:	e9 ba fc ff ff       	jmp    f1cca <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f2010:	ba 05 00 00 00       	mov    $0x5,%edx
   f2015:	e9 2b fd ff ff       	jmp    f1d45 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc5>
   f201a:	48 89 c2             	mov    %rax,%rdx
   f201d:	83 e0 01             	and    $0x1,%eax
   f2020:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f2024:	48 d1 ea             	shr    $1,%rdx
   f2027:	48 09 c2             	or     %rax,%rdx
   f202a:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f202f:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f2033:	e9 8b fa ff ff       	jmp    f1ac3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa43>
   f2038:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f203d:	e8 be fd f1 ff       	call   11e00 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f2042:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f2047:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f204f:	e9 dd f0 ff ff       	jmp    f1131 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb1>
   f2054:	e8 a7 fd f1 ff       	call   11e00 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f2059:	e9 4e fa ff ff       	jmp    f1aac <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa2c>
   f205e:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   f2069:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f2074:	e9 51 fc ff ff       	jmp    f1cca <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f2079:	0f b6 d0             	movzbl %al,%edx
   f207c:	e9 c4 fc ff ff       	jmp    f1d45 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc5>
   f2081:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f2089:	e8 d2 51 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f208e:	e8 6d 83 00 00       	call   fa400 <_ZN8QuadTree6detail15activeWorkspaceEv>

# candidate ordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, true>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-combined.ARqsxS/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f5080 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f5080:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f5087:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f508b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f5093:	48 8b 2a             	mov    (%rdx),%rbp
   f5096:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f509e:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f50a2:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f50aa:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f50b2:	49 89 ff             	mov    %rdi,%r15
   f50b5:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f50bd:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f50c4:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f50c9:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f50d2:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f50da:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f50de:	0f 11 07             	movups %xmm0,(%rdi)
   f50e1:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f50e5:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f50e9:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f50ed:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f50f1:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f50f5:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f50f9:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f50fd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   f5102:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f5106:	e8 35 f2 05 00       	call   154340 <_ZN5bench6memory11allocationsEv>
   f510b:	80 3d 66 01 08 00 00 	cmpb   $0x0,0x80166(%rip)        # 175278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f5112:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f5117:	49 89 c5             	mov    %rax,%r13
   f511a:	0f 84 58 0f 00 00    	je     f6078 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xff8>
   f5120:	0f 31                	rdtsc
   f5122:	48 c1 e2 20          	shl    $0x20,%rdx
   f5126:	48 09 d0             	or     %rdx,%rax
   f5129:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f5131:	49 8b 11             	mov    (%r9),%rdx
   f5134:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   f5138:	0f 84 85 09 00 00    	je     f5ac3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa43>
   f513e:	c6 44 24 77 00       	movb   $0x0,0x77(%rsp)
   f5143:	49 29 ec             	sub    %rbp,%r12
   f5146:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f514a:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f5152:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   f515b:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f5164:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f516d:	c7 44 24 70 00 00 00 00 	movl   $0x0,0x70(%rsp)
   f5175:	4c 89 8c 24 88 00 00 00 	mov    %r9,0x88(%rsp)
   f517d:	4c 89 ac 24 b8 00 00 00 	mov    %r13,0xb8(%rsp)
   f5185:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f518d:	49 89 de             	mov    %rbx,%r14
   f5190:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f5198:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f51a0:	45 31 e4             	xor    %r12d,%r12d
   f51a3:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f51a8:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f51ad:	0f 1f 00             	nopl   (%rax)
   f51b0:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
   f51b4:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f51b8:	48 8b 28             	mov    (%rax),%rbp
   f51bb:	48 8b 58 08          	mov    0x8(%rax),%rbx
   f51bf:	48 29 eb             	sub    %rbp,%rbx
   f51c2:	49 89 dd             	mov    %rbx,%r13
   f51c5:	49 c1 fd 04          	sar    $0x4,%r13
   f51c9:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f51d1:	74 14                	je     f51e7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x167>
   f51d3:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f51da:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   f51e1:	0f 84 cb 05 00 00    	je     f57b2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x732>
   f51e7:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f51ef:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f51f3:	31 f6                	xor    %esi,%esi
   f51f5:	66 0f 6f 3d e3 86 06 00 	movdqa 0x686e3(%rip),%xmm7        # 15d8e0 <C.66.5+0x2c0>
   f51fd:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f5205:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f520d:	ba 88 01 00 00       	mov    $0x188,%edx
   f5212:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f5219:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f521e:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f5226:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f522e:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f5233:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f523b:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f523f:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f5248:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f5250:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f5259:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f5261:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f526a:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f5272:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f527a:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f527f:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f5287:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f528c:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f5294:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f5299:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f52a1:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f52ad:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f52b9:	e8 52 1e f1 ff       	call   7110 <memset@plt>
   f52be:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f52c4:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f52c8:	66 0f 6f 05 20 86 06 00 	movdqa 0x68620(%rip),%xmm0        # 15d8f0 <C.66.5+0x2d0>
   f52d0:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f52d6:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f52dc:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f52e0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f52e7:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f52ef:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f52f4:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f52fc:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f5304:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f530c:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f5318:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   f5320:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f532c:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f5338:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f5344:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f5350:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f535c:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f5367:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f536f:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f537a:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f5386:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f538e:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f539a:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f53a5:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f53ad:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   f53b5:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f53c1:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f53cd:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   f53d5:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f53e1:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f53e9:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f53f1:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f53f9:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f5401:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f5409:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f5415:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f541d:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f5426:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f542e:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f5436:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f543f:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f5447:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f544f:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f5458:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f5460:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f5467:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f546f:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   f5477:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f5483:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f548f:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   f5497:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f54a3:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f54af:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f54bb:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f54c6:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f54d2:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   f54da:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f54e5:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f54f0:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f54fc:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f5504:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   f550c:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   f5514:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   f551c:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   f5524:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f552c:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f5534:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f553c:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f5544:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f554c:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f5553:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f555c:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f5567:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f556e:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f5575:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f5580:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f5587:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f558f:	e8 6c cd 00 00       	call   102300 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f5594:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f559c:	0f 85 36 07 00 00    	jne    f5cd8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc58>
   f55a2:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f55ab:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f55b3:	4d 89 76 50          	mov    %r14,0x50(%r14)
   f55b7:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f55bf:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f55c8:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   f55d0:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   f55d5:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f55de:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f55e6:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   f55eb:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f55f4:	49 89 46 48          	mov    %rax,0x48(%r14)
   f55f8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f55ff:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   f5604:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f560d:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   f5614:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f5619:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   f561e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5622:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   f562a:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f5633:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   f563a:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   f5642:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f564a:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f5653:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   f565b:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   f5663:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5667:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   f566f:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   f5677:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   f567f:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   f5687:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   f568f:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f569a:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   f56a2:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f56ad:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f56b8:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   f56c3:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f56ca:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f56d3:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   f56da:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   f56e1:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f56e8:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   f56f3:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f56fa:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f56ff:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f5706:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f570d:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   f5718:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   f571f:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   f572a:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   f5735:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   f573c:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   f5747:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   f5752:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   f5759:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   f5764:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   f576f:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f577a:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f5785:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   f578d:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   f5794:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   f579c:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f57a5:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f57ad:	e8 4e cb 00 00       	call   102300 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f57b2:	4d 39 ae c0 02 00 00 	cmp    %r13,0x2c0(%r14)
   f57b9:	0f 82 d1 04 00 00    	jb     f5c90 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc10>
   f57bf:	4d 8b 86 78 02 00 00 	mov    0x278(%r14),%r8
   f57c6:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f57cd:	48 be b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rsi
   f57d7:	4c 89 c2             	mov    %r8,%rdx
   f57da:	4c 29 d2             	sub    %r10,%rdx
   f57dd:	48 89 d0             	mov    %rdx,%rax
   f57e0:	48 c1 f8 03          	sar    $0x3,%rax
   f57e4:	48 0f af c6          	imul   %rsi,%rax
   f57e8:	4c 39 e8             	cmp    %r13,%rax
   f57eb:	0f 82 2f 04 00 00    	jb     f5c20 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   f57f1:	49 39 c5             	cmp    %rax,%r13
   f57f4:	73 16                	jae    f580c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78c>
   f57f6:	49 6b c5 38          	imul   $0x38,%r13,%rax
   f57fa:	49 01 c2             	add    %rax,%r10
   f57fd:	4d 39 d0             	cmp    %r10,%r8
   f5800:	74 07                	je     f5809 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x789>
   f5802:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f5809:	4d 89 d0             	mov    %r10,%r8
   f580c:	49 8b b6 70 02 00 00 	mov    0x270(%r14),%rsi
   f5813:	48 85 db             	test   %rbx,%rbx
   f5816:	74 7f                	je     f5897 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x817>
   f5818:	48 89 f2             	mov    %rsi,%rdx
   f581b:	31 ff                	xor    %edi,%edi
   f581d:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f5821:	49 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%r11
   f582b:	49 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%r10
   f5835:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f5840:	89 f9                	mov    %edi,%ecx
   f5842:	f3 0f 6f 45 00       	movdqu 0x0(%rbp),%xmm0
   f5847:	89 7a 10             	mov    %edi,0x10(%rdx)
   f584a:	48 83 c7 01          	add    $0x1,%rdi
   f584e:	81 f1 6b 6e 61 72    	xor    $0x72616e6b,%ecx
   f5854:	c6 42 30 01          	movb   $0x1,0x30(%rdx)
   f5858:	48 83 c5 10          	add    $0x10,%rbp
   f585c:	48 83 c2 38          	add    $0x38,%rdx
   f5860:	48 89 c8             	mov    %rcx,%rax
   f5863:	0f 11 42 c8          	movups %xmm0,-0x38(%rdx)
   f5867:	48 c1 e8 1e          	shr    $0x1e,%rax
   f586b:	0f 11 4a e0          	movups %xmm1,-0x20(%rdx)
   f586f:	48 31 c8             	xor    %rcx,%rax
   f5872:	49 0f af c3          	imul   %r11,%rax
   f5876:	48 89 c1             	mov    %rax,%rcx
   f5879:	48 c1 e9 1b          	shr    $0x1b,%rcx
   f587d:	48 31 c8             	xor    %rcx,%rax
   f5880:	49 0f af c2          	imul   %r10,%rax
   f5884:	48 89 c1             	mov    %rax,%rcx
   f5887:	48 c1 e9 1f          	shr    $0x1f,%rcx
   f588b:	48 31 c8             	xor    %rcx,%rax
   f588e:	48 89 42 f0          	mov    %rax,-0x10(%rdx)
   f5892:	4c 39 ef             	cmp    %r13,%rdi
   f5895:	72 a9                	jb     f5840 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f5897:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f58a3:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f58a7:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f58af:	49 39 f0             	cmp    %rsi,%r8
   f58b2:	0f 84 38 04 00 00    	je     f5cf0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc70>
   f58b8:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f58c2:	4c 89 c3             	mov    %r8,%rbx
   f58c5:	48 29 f3             	sub    %rsi,%rbx
   f58c8:	48 c1 fb 03          	sar    $0x3,%rbx
   f58cc:	48 0f af d8          	imul   %rax,%rbx
   f58d0:	49 39 5e 38          	cmp    %rbx,0x38(%r14)
   f58d4:	0f 82 a6 04 00 00    	jb     f5d80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd00>
   f58da:	41 8b 46 2c          	mov    0x2c(%r14),%eax
   f58de:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f58e2:	48 39 d8             	cmp    %rbx,%rax
   f58e5:	72 29                	jb     f5910 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x890>
   f58e7:	41 8b 86 d4 00 00 00 	mov    0xd4(%r14),%eax
   f58ee:	48 39 d8             	cmp    %rbx,%rax
   f58f1:	72 1d                	jb     f5910 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x890>
   f58f3:	41 8b 86 d8 00 00 00 	mov    0xd8(%r14),%eax
   f58fa:	48 39 d8             	cmp    %rbx,%rax
   f58fd:	72 11                	jb     f5910 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x890>
   f58ff:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f5904:	0f 85 4b 06 00 00    	jne    f5f55 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xed5>
   f590a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f5910:	48 83 ec 20          	sub    $0x20,%rsp
   f5914:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   f591b:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   f5922:	48 89 da             	mov    %rbx,%rdx
   f5925:	48 8b 84 24 40 03 00 00 	mov    0x340(%rsp),%rax
   f592d:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f5936:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   f593b:	0f 11 04 24          	movups %xmm0,(%rsp)
   f593f:	e8 3c ff fd ff       	call   d5880 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f5944:	48 83 c4 20          	add    $0x20,%rsp
   f5948:	84 c0                	test   %al,%al
   f594a:	0f 85 69 07 00 00    	jne    f60b9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x1039>
   f5950:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f5959:	0f 84 01 02 00 00    	je     f5b60 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xae0>
   f595f:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f5964:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5968:	4c 89 f6             	mov    %r14,%rsi
   f596b:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f5973:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f597b:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f5983:	e8 b8 ec ff ff       	call   f4640 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f5988:	4c 8b ac 24 c0 00 00 00 	mov    0xc0(%rsp),%r13
   f5990:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f5998:	8b 74 24 70          	mov    0x70(%rsp),%esi
   f599c:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f59a3:	49 8d 14 1c          	lea    (%r12,%rbx,1),%rdx
   f59a7:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f59b1:	0f b6 5c 24 77       	movzbl 0x77(%rsp),%ebx
   f59b6:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f59bc:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f59c5:	39 c6                	cmp    %eax,%esi
   f59c7:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f59d0:	0f 43 c6             	cmovae %esi,%eax
   f59d3:	48 8b b4 24 38 03 00 00 	mov    0x338(%rsp),%rsi
   f59db:	48 01 74 24 08       	add    %rsi,0x8(%rsp)
   f59e0:	4c 01 6c 24 10       	add    %r13,0x10(%rsp)
   f59e5:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f59e9:	89 44 24 70          	mov    %eax,0x70(%rsp)
   f59ed:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f59f1:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f59fa:	41 89 47 38          	mov    %eax,0x38(%r15)
   f59fe:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f5a03:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f5a09:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f5a0e:	49 89 47 40          	mov    %rax,0x40(%r15)
   f5a12:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f5a17:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f5a1c:	49 89 47 48          	mov    %rax,0x48(%r15)
   f5a20:	48 89 d0             	mov    %rdx,%rax
   f5a23:	48 c1 e8 1e          	shr    $0x1e,%rax
   f5a27:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f5a2c:	48 31 d0             	xor    %rdx,%rax
   f5a2f:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f5a34:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f5a3e:	48 0f af c2          	imul   %rdx,%rax
   f5a42:	48 89 c2             	mov    %rax,%rdx
   f5a45:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f5a49:	48 31 d0             	xor    %rdx,%rax
   f5a4c:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f5a56:	48 0f af c2          	imul   %rdx,%rax
   f5a5a:	48 89 c2             	mov    %rax,%rdx
   f5a5d:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f5a61:	48 31 d0             	xor    %rdx,%rax
   f5a64:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   f5a69:	84 db                	test   %bl,%bl
   f5a6b:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   f5a70:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f5a78:	49 89 77 50          	mov    %rsi,0x50(%r15)
   f5a7c:	0f 44 d8             	cmove  %eax,%ebx
   f5a7f:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f5a87:	49 83 c4 01          	add    $0x1,%r12
   f5a8b:	48 8b 10             	mov    (%rax),%rdx
   f5a8e:	88 5c 24 77          	mov    %bl,0x77(%rsp)
   f5a92:	41 88 5f 68          	mov    %bl,0x68(%r15)
   f5a96:	48 8b 40 08          	mov    0x8(%rax),%rax
   f5a9a:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f5a9f:	48 29 d0             	sub    %rdx,%rax
   f5aa2:	48 c1 f8 03          	sar    $0x3,%rax
   f5aa6:	48 0f af c1          	imul   %rcx,%rax
   f5aaa:	49 39 c4             	cmp    %rax,%r12
   f5aad:	0f 82 fd f6 ff ff    	jb     f51b0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f5ab3:	4c 8b ac 24 b8 00 00 00 	mov    0xb8(%rsp),%r13
   f5abb:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f5ac3:	80 3d ae f7 07 00 00 	cmpb   $0x0,0x7f7ae(%rip)        # 175278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f5aca:	0f 84 c4 05 00 00    	je     f6094 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x1014>
   f5ad0:	0f 31                	rdtsc
   f5ad2:	48 c1 e2 20          	shl    $0x20,%rdx
   f5ad6:	48 09 d0             	or     %rdx,%rax
   f5ad9:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f5ae1:	0f 88 73 05 00 00    	js     f605a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfda>
   f5ae7:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5aeb:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f5af0:	f2 0f 59 05 38 f7 07 00 	mulsd  0x7f738(%rip),%xmm0        # 175230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f5af8:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f5afd:	49 89 07             	mov    %rax,(%r15)
   f5b00:	e8 3b e8 05 00       	call   154340 <_ZN5bench6memory11allocationsEv>
   f5b05:	4c 29 e8             	sub    %r13,%rax
   f5b08:	49 89 47 58          	mov    %rax,0x58(%r15)
   f5b0c:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f5b14:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f5b1d:	0f 85 9e 05 00 00    	jne    f60c1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x1041>
   f5b23:	4c 89 f8             	mov    %r15,%rax
   f5b26:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f5b2e:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f5b36:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f5b3e:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f5b46:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f5b4e:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f5b55:	c3                   	ret
   f5b56:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f5b60:	80 3d 11 f7 07 00 00 	cmpb   $0x0,0x7f711(%rip)        # 175278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f5b67:	0f 84 db 03 00 00    	je     f5f48 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xec8>
   f5b6d:	0f 31                	rdtsc
   f5b6f:	48 c1 e2 20          	shl    $0x20,%rdx
   f5b73:	48 09 d0             	or     %rdx,%rax
   f5b76:	48 89 c5             	mov    %rax,%rbp
   f5b79:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f5b7e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5b82:	4c 89 f6             	mov    %r14,%rsi
   f5b85:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f5b8d:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f5b95:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f5b9d:	e8 9e ea ff ff       	call   f4640 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f5ba2:	4c 8b ac 24 c0 00 00 00 	mov    0xc0(%rsp),%r13
   f5baa:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f5bb2:	48 89 e8             	mov    %rbp,%rax
   f5bb5:	f2 0f 10 0d 73 f6 07 00 	movsd  0x7f673(%rip),%xmm1        # 175230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f5bbd:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f5bc5:	0f 88 45 03 00 00    	js     f5f10 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe90>
   f5bcb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5bcf:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f5bd4:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f5bd8:	80 3d 99 f6 07 00 00 	cmpb   $0x0,0x7f699(%rip)        # 175278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f5bdf:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f5be4:	49 89 47 08          	mov    %rax,0x8(%r15)
   f5be8:	0f 84 42 03 00 00    	je     f5f30 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xeb0>
   f5bee:	0f 31                	rdtsc
   f5bf0:	48 c1 e2 20          	shl    $0x20,%rdx
   f5bf4:	48 09 d0             	or     %rdx,%rax
   f5bf7:	48 29 e8             	sub    %rbp,%rax
   f5bfa:	0f 88 f0 02 00 00    	js     f5ef0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   f5c00:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5c04:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f5c09:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f5c0d:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f5c12:	49 89 47 10          	mov    %rax,0x10(%r15)
   f5c16:	e9 7d fd ff ff       	jmp    f5998 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x918>
   f5c1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f5c20:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   f5c27:	4d 89 eb             	mov    %r13,%r11
   f5c2a:	48 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rcx
   f5c34:	49 29 c3             	sub    %rax,%r11
   f5c37:	48 89 f7             	mov    %rsi,%rdi
   f5c3a:	4c 29 c7             	sub    %r8,%rdi
   f5c3d:	48 c1 ff 03          	sar    $0x3,%rdi
   f5c41:	48 0f af f9          	imul   %rcx,%rdi
   f5c45:	4c 39 df             	cmp    %r11,%rdi
   f5c48:	0f 82 52 01 00 00    	jb     f5da0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd20>
   f5c4e:	4c 89 da             	mov    %r11,%rdx
   f5c51:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5c55:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f5c59:	4c 89 c0             	mov    %r8,%rax
   f5c5c:	0f 1f 40 00          	nopl   0x0(%rax)
   f5c60:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f5c64:	48 83 c0 38          	add    $0x38,%rax
   f5c68:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f5c6c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f5c70:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f5c74:	48 83 ea 01          	sub    $0x1,%rdx
   f5c78:	75 e6                	jne    f5c60 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbe0>
   f5c7a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f5c7e:	4d 01 d8             	add    %r11,%r8
   f5c81:	4d 89 86 78 02 00 00 	mov    %r8,0x278(%r14)
   f5c88:	e9 7f fb ff ff       	jmp    f580c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78c>
   f5c8d:	0f 1f 00             	nopl   (%rax)
   f5c90:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f5c98:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   f5c9f:	4c 89 ac 24 10 03 00 00 	mov    %r13,0x310(%rsp)
   f5ca7:	48 c7 84 24 18 03 00 00 00 00 00 00 	movq   $0x0,0x318(%rsp)
   f5cb3:	4c 89 ac 24 20 03 00 00 	mov    %r13,0x320(%rsp)
   f5cbb:	e8 80 fb 01 00       	call   115840 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f5cc0:	84 c0                	test   %al,%al
   f5cc2:	0f 85 f1 03 00 00    	jne    f60b9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x1039>
   f5cc8:	4d 89 ae c0 02 00 00 	mov    %r13,0x2c0(%r14)
   f5ccf:	e9 eb fa ff ff       	jmp    f57bf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x73f>
   f5cd4:	0f 1f 40 00          	nopl   0x0(%rax)
   f5cd8:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   f5ce0:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f5ce4:	e8 17 c6 00 00       	call   102300 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f5ce9:	e9 b4 f8 ff ff       	jmp    f55a2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x522>
   f5cee:	66 90                	xchg   %ax,%ax
   f5cf0:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   f5cf8:	74 58                	je     f5d52 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcd2>
   f5cfa:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   f5d01:	48 85 d2             	test   %rdx,%rdx
   f5d04:	0f 85 d6 02 00 00    	jne    f5fe0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf60>
   f5d0a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f5d0f:	66 0f 6f 05 a9 7b 06 00 	movdqa 0x67ba9(%rip),%xmm0        # 15d8c0 <C.66.5+0x2a0>
   f5d17:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   f5d22:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f5d2d:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f5d34:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f5d3f:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f5d4a:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   f5d52:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f5d57:	0f 84 f3 fb ff ff    	je     f5950 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8d0>
   f5d5d:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   f5d65:	0f 84 e5 fb ff ff    	je     f5950 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8d0>
   f5d6b:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   f5d73:	e9 d8 fb ff ff       	jmp    f5950 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8d0>
   f5d78:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f5d80:	ba 10 00 00 00       	mov    $0x10,%edx
   f5d85:	48 8b 3d d4 f4 07 00 	mov    0x7f4d4(%rip),%rdi        # 175260 <stderr@GLIBC_2.2.5>
   f5d8c:	48 8d 35 0d 5c 06 00 	lea    0x65c0d(%rip),%rsi        # 15b9a0 <_IO_stdin_used+0x19a0>
   f5d93:	31 c0                	xor    %eax,%eax
   f5d95:	e8 a6 15 f1 ff       	call   7340 <fprintf@plt>
   f5d9a:	e8 81 13 f1 ff       	call   7120 <abort@plt>
   f5d9f:	90                   	nop
   f5da0:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f5daa:	48 29 c7             	sub    %rax,%rdi
   f5dad:	4c 39 df             	cmp    %r11,%rdi
   f5db0:	0f 82 a0 71 f1 ff    	jb     cf56 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f5db6:	4c 39 d8             	cmp    %r11,%rax
   f5db9:	4c 89 d9             	mov    %r11,%rcx
   f5dbc:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f5dc4:	48 0f 43 c8          	cmovae %rax,%rcx
   f5dc8:	48 89 94 24 a8 00 00 00 	mov    %rdx,0xa8(%rsp)
   f5dd0:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f5dd8:	48 01 c1             	add    %rax,%rcx
   f5ddb:	4c 89 44 24 60       	mov    %r8,0x60(%rsp)
   f5de0:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f5dea:	48 39 c1             	cmp    %rax,%rcx
   f5ded:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f5df2:	48 0f 47 c8          	cmova  %rax,%rcx
   f5df6:	48 6b c1 38          	imul   $0x38,%rcx,%rax
   f5dfa:	48 89 c7             	mov    %rax,%rdi
   f5dfd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f5e02:	e8 f9 e6 05 00       	call   154500 <_Znwm>
   f5e07:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f5e0d:	48 8b 94 24 a8 00 00 00 	mov    0xa8(%rsp),%rdx
   f5e15:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5e19:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
   f5e1e:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f5e26:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f5e2a:	48 01 c2             	add    %rax,%rdx
   f5e2d:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f5e35:	49 01 d3             	add    %rdx,%r11
   f5e38:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f5e40:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
   f5e44:	48 83 c2 38          	add    $0x38,%rdx
   f5e48:	0f 11 42 c8          	movups %xmm0,-0x38(%rdx)
   f5e4c:	0f 11 4a e0          	movups %xmm1,-0x20(%rdx)
   f5e50:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
   f5e54:	4c 39 da             	cmp    %r11,%rdx
   f5e57:	75 e7                	jne    f5e40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdc0>
   f5e59:	4d 39 d0             	cmp    %r10,%r8
   f5e5c:	74 51                	je     f5eaf <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe2f>
   f5e5e:	4c 89 d2             	mov    %r10,%rdx
   f5e61:	48 89 c7             	mov    %rax,%rdi
   f5e64:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f5e6a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f5e75:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f5e80:	f3 0f 6f 02          	movdqu (%rdx),%xmm0
   f5e84:	48 8b 4a 30          	mov    0x30(%rdx),%rcx
   f5e88:	48 83 c2 38          	add    $0x38,%rdx
   f5e8c:	48 83 c7 38          	add    $0x38,%rdi
   f5e90:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f5e94:	f3 0f 6f 42 d8       	movdqu -0x28(%rdx),%xmm0
   f5e99:	48 89 4f f8          	mov    %rcx,-0x8(%rdi)
   f5e9d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f5ea1:	f3 0f 6f 42 e8       	movdqu -0x18(%rdx),%xmm0
   f5ea6:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f5eaa:	49 39 d0             	cmp    %rdx,%r8
   f5ead:	75 d1                	jne    f5e80 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe00>
   f5eaf:	4d 85 d2             	test   %r10,%r10
   f5eb2:	74 15                	je     f5ec9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe49>
   f5eb4:	4c 29 d6             	sub    %r10,%rsi
   f5eb7:	4c 89 d7             	mov    %r10,%rdi
   f5eba:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f5ebf:	e8 bc e7 05 00       	call   154680 <_ZdlPvm>
   f5ec4:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f5ec9:	4d 6b c5 38          	imul   $0x38,%r13,%r8
   f5ecd:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   f5ed4:	49 01 c0             	add    %rax,%r8
   f5ed7:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f5edc:	4d 89 86 78 02 00 00 	mov    %r8,0x278(%r14)
   f5ee3:	49 89 86 80 02 00 00 	mov    %rax,0x280(%r14)
   f5eea:	e9 1d f9 ff ff       	jmp    f580c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78c>
   f5eef:	90                   	nop
   f5ef0:	48 89 c2             	mov    %rax,%rdx
   f5ef3:	83 e0 01             	and    $0x1,%eax
   f5ef6:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5efa:	48 d1 ea             	shr    $1,%rdx
   f5efd:	48 09 c2             	or     %rax,%rdx
   f5f00:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f5f05:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f5f09:	e9 fb fc ff ff       	jmp    f5c09 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb89>
   f5f0e:	66 90                	xchg   %ax,%ax
   f5f10:	48 89 c2             	mov    %rax,%rdx
   f5f13:	83 e0 01             	and    $0x1,%eax
   f5f16:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5f1a:	48 d1 ea             	shr    $1,%rdx
   f5f1d:	48 09 c2             	or     %rax,%rdx
   f5f20:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f5f25:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f5f29:	e9 a6 fc ff ff       	jmp    f5bd4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb54>
   f5f2e:	66 90                	xchg   %ax,%ax
   f5f30:	e8 9b 13 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f5f35:	f2 0f 10 0d f3 f2 07 00 	movsd  0x7f2f3(%rip),%xmm1        # 175230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f5f3d:	e9 b5 fc ff ff       	jmp    f5bf7 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb77>
   f5f42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f5f48:	e8 83 13 f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f5f4d:	48 89 c5             	mov    %rax,%rbp
   f5f50:	e9 24 fc ff ff       	jmp    f5b79 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf9>
   f5f55:	49 39 9e 18 02 00 00 	cmp    %rbx,0x218(%r14)
   f5f5c:	0f 82 ee 00 00 00    	jb     f6050 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfd0>
   f5f62:	49 39 9e 30 02 00 00 	cmp    %rbx,0x230(%r14)
   f5f69:	0f 82 e1 00 00 00    	jb     f6050 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfd0>
   f5f6f:	49 39 9e 48 02 00 00 	cmp    %rbx,0x248(%r14)
   f5f76:	0f 82 d4 00 00 00    	jb     f6050 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfd0>
   f5f7c:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f5f86:	49 f7 a6 60 02 00 00 	mulq   0x260(%r14)
   f5f8d:	48 c1 ea 04          	shr    $0x4,%rdx
   f5f91:	48 39 da             	cmp    %rbx,%rdx
   f5f94:	0f 82 b6 00 00 00    	jb     f6050 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfd0>
   f5f9a:	41 80 be 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r14)
   f5fa2:	0f 85 26 01 00 00    	jne    f60ce <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x104e>
   f5fa8:	41 c6 86 6c 02 00 00 01 	movb   $0x1,0x26c(%r14)
   f5fb0:	45 31 c0             	xor    %r8d,%r8d
   f5fb3:	31 c9                	xor    %ecx,%ecx
   f5fb5:	89 da                	mov    %ebx,%edx
   f5fb7:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
   f5fbc:	e8 7f c7 f1 ff       	call   12740 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE16buildFlatIntegerEPKNS_10BuildEntryIjiNS_3BoxIiEEEEjSt8optionalISt4spanINS_6HandleINS_6detail10EntryStoreIijS1_S2_EEEELm18446744073709551615EEE.isra.0>
   f5fc1:	41 c6 86 6c 02 00 00 00 	movb   $0x0,0x26c(%r14)
   f5fc9:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
   f5fce:	89 c6                	mov    %eax,%esi
   f5fd0:	66 c1 ee 08          	shr    $0x8,%si
   f5fd4:	0f 84 36 f9 ff ff    	je     f5910 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x890>
   f5fda:	e9 69 f9 ff ff       	jmp    f5948 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8c8>
   f5fdf:	90                   	nop
   f5fe0:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   f5feb:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   f5ff3:	0f 85 a5 00 00 00    	jne    f609e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x101e>
   f5ff9:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   f6000:	83 c0 01             	add    $0x1,%eax
   f6003:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   f600a:	83 f8 ff             	cmp    $0xffffffff,%eax
   f600d:	0f 85 f7 fc ff ff    	jne    f5d0a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc8a>
   f6013:	49 8b 46 78          	mov    0x78(%r14),%rax
   f6017:	48 89 d1             	mov    %rdx,%rcx
   f601a:	48 c1 e1 04          	shl    $0x4,%rcx
   f601e:	48 01 c1             	add    %rax,%rcx
   f6021:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f6028:	48 83 c0 10          	add    $0x10,%rax
   f602c:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f6034:	48 39 c8             	cmp    %rcx,%rax
   f6037:	75 e8                	jne    f6021 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xfa1>
   f6039:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   f6040:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f604b:	e9 ba fc ff ff       	jmp    f5d0a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc8a>
   f6050:	ba 05 00 00 00       	mov    $0x5,%edx
   f6055:	e9 2b fd ff ff       	jmp    f5d85 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd05>
   f605a:	48 89 c2             	mov    %rax,%rdx
   f605d:	83 e0 01             	and    $0x1,%eax
   f6060:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f6064:	48 d1 ea             	shr    $1,%rdx
   f6067:	48 09 c2             	or     %rax,%rdx
   f606a:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f606f:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f6073:	e9 78 fa ff ff       	jmp    f5af0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa70>
   f6078:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f607d:	e8 7e bd f1 ff       	call   11e00 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f6082:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f6087:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f608f:	e9 9d f0 ff ff       	jmp    f5131 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb1>
   f6094:	e8 67 bd f1 ff       	call   11e00 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f6099:	e9 3b fa ff ff       	jmp    f5ad9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa59>
   f609e:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   f60a9:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f60b4:	e9 51 fc ff ff       	jmp    f5d0a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc8a>
   f60b9:	0f b6 d0             	movzbl %al,%edx
   f60bc:	e9 c4 fc ff ff       	jmp    f5d85 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd05>
   f60c1:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f60c9:	e8 92 11 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f60ce:	e8 2d 43 00 00       	call   fa400 <_ZN8QuadTree6detail15activeWorkspaceEv>

# candidate unordered_pairs bench::Counters bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-combined.ARqsxS/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f0a00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f0a00:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
   f0a07:	44 8b 8e d0 00 00 00 	mov    0xd0(%rsi),%r9d
   f0a0e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f0a12:	48 89 ac 24 80 01 00 00 	mov    %rbp,0x180(%rsp)
   f0a1a:	48 89 fd             	mov    %rdi,%rbp
   f0a1d:	4c 89 a4 24 88 01 00 00 	mov    %r12,0x188(%rsp)
   f0a25:	4d 89 cc             	mov    %r9,%r12
   f0a28:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
   f0a2d:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
   f0a36:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f0a3e:	31 c0                	xor    %eax,%eax
   f0a40:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   f0a45:	41 83 f9 01          	cmp    $0x1,%r9d
   f0a49:	0f 86 31 03 00 00    	jbe    f0d80 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x380>
   f0a4f:	48 89 9c 24 78 01 00 00 	mov    %rbx,0x178(%rsp)
   f0a57:	66 48 0f 6e c8       	movq   %rax,%xmm1
   f0a5c:	48 89 f3             	mov    %rsi,%rbx
   f0a5f:	66 48 0f 6e d1       	movq   %rcx,%xmm2
   f0a64:	4c 89 b4 24 98 01 00 00 	mov    %r14,0x198(%rsp)
   f0a6c:	4c 8d 76 08          	lea    0x8(%rsi),%r14
   f0a70:	8b b6 64 01 00 00    	mov    0x164(%rsi),%esi
   f0a76:	66 0f 6c ca          	punpcklqdq %xmm2,%xmm1
   f0a7a:	c6 84 24 a0 00 00 00 00 	movb   $0x0,0xa0(%rsp)
   f0a82:	48 c7 84 24 d8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xd8(%rsp)
   f0a8e:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f0a96:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f0a9e:	0f 11 8c 24 c8 00 00 00 	movups %xmm1,0xc8(%rsp)
   f0aa6:	83 fe ff             	cmp    $0xffffffff,%esi
   f0aa9:	0f 85 e1 01 00 00    	jne    f0c90 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x290>
   f0aaf:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   f0ab7:	49 89 d7             	mov    %rdx,%r15
   f0aba:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   f0ac2:	49 83 f9 04          	cmp    $0x4,%r9
   f0ac6:	0f 86 c0 02 00 00    	jbe    f0d8c <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x38c>
   f0acc:	41 8d 44 24 ff       	lea    -0x1(%r12),%eax
   f0ad1:	44 89 64 24 28       	mov    %r12d,0x28(%rsp)
   f0ad6:	45 31 ed             	xor    %r13d,%r13d
   f0ad9:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   f0ade:	31 c0                	xor    %eax,%eax
   f0ae0:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
   f0ae5:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
   f0aea:	84 c0                	test   %al,%al
   f0aec:	0f 85 77 01 00 00    	jne    f0c69 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x269>
   f0af2:	0f 1f 00             	nopl   (%rax)
   f0af5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0b00:	4c 39 6c 24 30       	cmp    %r13,0x30(%rsp)
   f0b05:	0f 84 5e 01 00 00    	je     f0c69 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x269>
   f0b0b:	4c 89 ef             	mov    %r13,%rdi
   f0b0e:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   f0b13:	44 89 ed             	mov    %r13d,%ebp
   f0b16:	44 8b 64 24 28       	mov    0x28(%rsp),%r12d
   f0b1b:	48 c1 e7 05          	shl    $0x5,%rdi
   f0b1f:	41 83 c5 01          	add    $0x1,%r13d
   f0b23:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   f0b28:	48 8d 5f 20          	lea    0x20(%rdi),%rbx
   f0b2c:	eb 21                	jmp    f0b4f <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x14f>
   f0b2e:	66 90                	xchg   %ax,%ax
   f0b30:	41 83 c5 01          	add    $0x1,%r13d
   f0b34:	45 39 e5             	cmp    %r12d,%r13d
   f0b37:	0f 83 13 01 00 00    	jae    f0c50 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x250>
   f0b3d:	48 83 c3 20          	add    $0x20,%rbx
   f0b41:	80 bc 24 a0 00 00 00 00 	cmpb   $0x0,0xa0(%rsp)
   f0b49:	0f 85 01 01 00 00    	jne    f0c50 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x250>
   f0b4f:	48 8d 8c 24 a0 00 00 00 	lea    0xa0(%rsp),%rcx
   f0b57:	44 89 ea             	mov    %r13d,%edx
   f0b5a:	89 ee                	mov    %ebp,%esi
   f0b5c:	4c 89 f7             	mov    %r14,%rdi
   f0b5f:	e8 9c 29 f2 ff       	call   13500 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_12QueryContextINS_11QueryResultEEERT0_.isra.0>
   f0b64:	84 c0                	test   %al,%al
   f0b66:	74 c8                	je     f0b30 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x130>
   f0b68:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f0b6d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   f0b72:	48 8b 40 68          	mov    0x68(%rax),%rax
   f0b76:	8b 7c 30 18          	mov    0x18(%rax,%rsi,1),%edi
   f0b7a:	39 7c 18 18          	cmp    %edi,0x18(%rax,%rbx,1)
   f0b7e:	0f 82 ec 01 00 00    	jb     f0d70 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x370>
   f0b84:	44 89 6c 24 08       	mov    %r13d,0x8(%rsp)
   f0b89:	89 ea                	mov    %ebp,%edx
   f0b8b:	4c 89 f6             	mov    %r14,%rsi
   f0b8e:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   f0b96:	e8 25 8f 05 00       	call   149ac0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f0b9b:	8b 54 24 08          	mov    0x8(%rsp),%edx
   f0b9f:	4c 89 f6             	mov    %r14,%rsi
   f0ba2:	48 8d bc 24 20 01 00 00 	lea    0x120(%rsp),%rdi
   f0baa:	e8 11 8f 05 00       	call   149ac0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f0baf:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   f0bb7:	48 8b 84 24 38 01 00 00 	mov    0x138(%rsp),%rax
   f0bbf:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   f0bc9:	8b 00                	mov    (%rax),%eax
   f0bcb:	8b 0a                	mov    (%rdx),%ecx
   f0bcd:	49 83 07 01          	addq   $0x1,(%r15)
   f0bd1:	89 ca                	mov    %ecx,%edx
   f0bd3:	39 c8                	cmp    %ecx,%eax
   f0bd5:	0f 46 d0             	cmovbe %eax,%edx
   f0bd8:	48 c1 e2 20          	shl    $0x20,%rdx
   f0bdc:	39 c8                	cmp    %ecx,%eax
   f0bde:	0f 42 c1             	cmovb  %ecx,%eax
   f0be1:	48 09 c2             	or     %rax,%rdx
   f0be4:	48 89 d0             	mov    %rdx,%rax
   f0be7:	48 c1 e8 1e          	shr    $0x1e,%rax
   f0beb:	48 31 d0             	xor    %rdx,%rax
   f0bee:	48 0f af c6          	imul   %rsi,%rax
   f0bf2:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   f0bfc:	48 89 c2             	mov    %rax,%rdx
   f0bff:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f0c03:	48 31 d0             	xor    %rdx,%rax
   f0c06:	48 0f af c6          	imul   %rsi,%rax
   f0c0a:	48 89 c2             	mov    %rax,%rdx
   f0c0d:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f0c11:	48 31 d0             	xor    %rdx,%rax
   f0c14:	49 01 47 08          	add    %rax,0x8(%r15)
   f0c18:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f0c20:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f0c24:	0f 84 06 ff ff ff    	je     f0b30 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x130>
   f0c2a:	48 83 c0 01          	add    $0x1,%rax
   f0c2e:	41 83 c5 01          	add    $0x1,%r13d
   f0c32:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f0c3a:	45 39 e5             	cmp    %r12d,%r13d
   f0c3d:	0f 82 fa fe ff ff    	jb     f0b3d <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x13d>
   f0c43:	66 90                	xchg   %ax,%ax
   f0c45:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0c50:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
   f0c55:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f0c5d:	49 83 c5 01          	add    $0x1,%r13
   f0c61:	84 c0                	test   %al,%al
   f0c63:	0f 84 97 fe ff ff    	je     f0b00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x100>
   f0c69:	44 8b 64 24 28       	mov    0x28(%rsp),%r12d
   f0c6e:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
   f0c73:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
   f0c78:	4c 8b ac 24 90 01 00 00 	mov    0x190(%rsp),%r13
   f0c80:	4c 8b bc 24 a0 01 00 00 	mov    0x1a0(%rsp),%r15
   f0c88:	eb 2d                	jmp    f0cb7 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2b7>
   f0c8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f0c90:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
   f0c95:	48 8d 94 24 a0 00 00 00 	lea    0xa0(%rsp),%rdx
   f0c9d:	4c 89 f7             	mov    %r14,%rdi
   f0ca0:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f0ca5:	4c 8d 84 24 20 01 00 00 	lea    0x120(%rsp),%r8
   f0cad:	e8 8e 11 fe ff       	call   d1e40 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE9selfPairsIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvjRNS2_12QueryContextINS_11QueryResultEEESC_RSF_>
   f0cb2:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f0cb7:	66 0f 6f 9c 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm3
   f0cc0:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f0cc8:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f0cd1:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
   f0cd6:	0f 29 84 24 80 00 00 00 	movaps %xmm0,0x80(%rsp)
   f0cde:	84 c0                	test   %al,%al
   f0ce0:	74 08                	je     f0cea <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2ea>
   f0ce2:	3c 0b                	cmp    $0xb,%al
   f0ce4:	0f 85 32 03 00 00    	jne    f101c <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x61c>
   f0cea:	48 8b 9c 24 78 01 00 00 	mov    0x178(%rsp),%rbx
   f0cf2:	4c 8b b4 24 98 01 00 00 	mov    0x198(%rsp),%r14
   f0cfa:	48 8b 94 24 80 00 00 00 	mov    0x80(%rsp),%rdx
   f0d02:	48 c7 45 18 00 00 00 00 	movq   $0x0,0x18(%rbp)
   f0d0a:	48 c7 45 28 00 00 00 00 	movq   $0x0,0x28(%rbp)
   f0d12:	48 89 55 00          	mov    %rdx,0x0(%rbp)
   f0d16:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   f0d1b:	4c 89 4d 08          	mov    %r9,0x8(%rbp)
   f0d1f:	48 89 55 10          	mov    %rdx,0x10(%rbp)
   f0d23:	31 d2                	xor    %edx,%edx
   f0d25:	45 85 e4             	test   %r12d,%r12d
   f0d28:	0f 95 c2             	setne  %dl
   f0d2b:	3c 0b                	cmp    $0xb,%al
   f0d2d:	89 55 20             	mov    %edx,0x20(%rbp)
   f0d30:	0f 94 45 30          	sete   0x30(%rbp)
   f0d34:	48 8b 84 24 68 01 00 00 	mov    0x168(%rsp),%rax
   f0d3c:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f0d45:	0f 85 fe 02 00 00    	jne    f1049 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x649>
   f0d4b:	48 89 e8             	mov    %rbp,%rax
   f0d4e:	4c 8b a4 24 88 01 00 00 	mov    0x188(%rsp),%r12
   f0d56:	48 8b ac 24 80 01 00 00 	mov    0x180(%rsp),%rbp
   f0d5e:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
   f0d65:	c3                   	ret
   f0d66:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f0d70:	89 6c 24 08          	mov    %ebp,0x8(%rsp)
   f0d74:	44 89 ea             	mov    %r13d,%edx
   f0d77:	e9 0f fe ff ff       	jmp    f0b8b <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x18b>
   f0d7c:	0f 1f 40 00          	nopl   0x0(%rax)
   f0d80:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   f0d85:	31 c0                	xor    %eax,%eax
   f0d87:	e9 6e ff ff ff       	jmp    f0cfa <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2fa>
   f0d8c:	49 8d 41 ff          	lea    -0x1(%r9),%rax
   f0d90:	49 0f af c1          	imul   %r9,%rax
   f0d94:	48 d1 e8             	shr    $1,%rax
   f0d97:	48 39 c1             	cmp    %rax,%rcx
   f0d9a:	0f 82 2c fd ff ff    	jb     f0acc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xcc>
   f0da0:	48 89 d8             	mov    %rbx,%rax
   f0da3:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   f0da8:	48 8b 5b 68          	mov    0x68(%rbx),%rbx
   f0dac:	48 8b 40 58          	mov    0x58(%rax),%rax
   f0db0:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
   f0db5:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
   f0dba:	4c 8d 5b 20          	lea    0x20(%rbx),%r11
   f0dbe:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f0dc3:	4c 8d 68 10          	lea    0x10(%rax),%r13
   f0dc7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   f0dcc:	41 8d 41 ff          	lea    -0x1(%r9),%eax
   f0dd0:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   f0dd5:	4c 89 e8             	mov    %r13,%rax
   f0dd8:	45 31 ed             	xor    %r13d,%r13d
   f0ddb:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   f0de0:	4d 8b 53 e8          	mov    -0x18(%r11),%r10
   f0de4:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   f0de9:	41 8d 6d 01          	lea    0x1(%r13),%ebp
   f0ded:	4c 89 db             	mov    %r11,%rbx
   f0df0:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   f0df5:	4d 8b 7b e0          	mov    -0x20(%r11),%r15
   f0df9:	4d 89 d9             	mov    %r11,%r9
   f0dfc:	49 89 c6             	mov    %rax,%r14
   f0dff:	4d 89 d3             	mov    %r10,%r11
   f0e02:	49 89 c5             	mov    %rax,%r13
   f0e05:	e9 0a 01 00 00       	jmp    f0f14 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x514>
   f0e0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f0e10:	41 8b 36             	mov    (%r14),%esi
   f0e13:	41 8b 4d f8          	mov    -0x8(%r13),%ecx
   f0e17:	39 ce                	cmp    %ecx,%esi
   f0e19:	0f 8d 31 01 00 00    	jge    f0f50 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x550>
   f0e1f:	41 8b 7d f4          	mov    -0xc(%r13),%edi
   f0e23:	41 3b 7e 0c          	cmp    0xc(%r14),%edi
   f0e27:	0f 8d 2b 01 00 00    	jge    f0f58 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x558>
   f0e2d:	45 8b 45 fc          	mov    -0x4(%r13),%r8d
   f0e31:	45 39 46 04          	cmp    %r8d,0x4(%r14)
   f0e35:	0f 8d 1d 01 00 00    	jge    f0f58 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x558>
   f0e3b:	41 8b 41 f8          	mov    -0x8(%r9),%eax
   f0e3f:	39 43 18             	cmp    %eax,0x18(%rbx)
   f0e42:	0f 82 c5 01 00 00    	jb     f100d <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x60d>
   f0e48:	89 6c 24 08          	mov    %ebp,0x8(%rsp)
   f0e4c:	8b 54 24 20          	mov    0x20(%rsp),%edx
   f0e50:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   f0e55:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   f0e5d:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   f0e62:	4c 89 5c 24 28       	mov    %r11,0x28(%rsp)
   f0e67:	e8 54 8c 05 00       	call   149ac0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f0e6c:	8b 54 24 08          	mov    0x8(%rsp),%edx
   f0e70:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   f0e75:	48 8d bc 24 20 01 00 00 	lea    0x120(%rsp),%rdi
   f0e7d:	e8 3e 8c 05 00       	call   149ac0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f0e82:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   f0e87:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
   f0e8c:	48 bf b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdi
   f0e96:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   f0e9e:	48 8b 84 24 38 01 00 00 	mov    0x138(%rsp),%rax
   f0ea6:	4c 8b 5c 24 28       	mov    0x28(%rsp),%r11
   f0eab:	8b 00                	mov    (%rax),%eax
   f0ead:	8b 0a                	mov    (%rdx),%ecx
   f0eaf:	48 83 06 01          	addq   $0x1,(%rsi)
   f0eb3:	89 ca                	mov    %ecx,%edx
   f0eb5:	39 c8                	cmp    %ecx,%eax
   f0eb7:	0f 46 d0             	cmovbe %eax,%edx
   f0eba:	48 c1 e2 20          	shl    $0x20,%rdx
   f0ebe:	39 c8                	cmp    %ecx,%eax
   f0ec0:	0f 42 c1             	cmovb  %ecx,%eax
   f0ec3:	48 09 c2             	or     %rax,%rdx
   f0ec6:	48 89 d0             	mov    %rdx,%rax
   f0ec9:	48 c1 e8 1e          	shr    $0x1e,%rax
   f0ecd:	48 31 d0             	xor    %rdx,%rax
   f0ed0:	48 0f af c7          	imul   %rdi,%rax
   f0ed4:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   f0ede:	48 89 c2             	mov    %rax,%rdx
   f0ee1:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f0ee5:	48 31 d0             	xor    %rdx,%rax
   f0ee8:	48 0f af c7          	imul   %rdi,%rax
   f0eec:	48 89 c2             	mov    %rax,%rdx
   f0eef:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f0ef3:	48 31 d0             	xor    %rdx,%rax
   f0ef6:	48 01 46 08          	add    %rax,0x8(%rsi)
   f0efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f0f00:	83 c5 01             	add    $0x1,%ebp
   f0f03:	48 83 c3 20          	add    $0x20,%rbx
   f0f07:	49 83 c6 10          	add    $0x10,%r14
   f0f0b:	44 39 e5             	cmp    %r12d,%ebp
   f0f0e:	0f 83 ac 00 00 00    	jae    f0fc0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f0f14:	4c 85 7b 08          	test   %r15,0x8(%rbx)
   f0f18:	74 e6                	je     f0f00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f0f1a:	4c 85 1b             	test   %r11,(%rbx)
   f0f1d:	74 e1                	je     f0f00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f0f1f:	41 8b 45 f0          	mov    -0x10(%r13),%eax
   f0f23:	41 8b 56 08          	mov    0x8(%r14),%edx
   f0f27:	48 83 84 24 80 00 00 00 01 	addq   $0x1,0x80(%rsp)
   f0f30:	39 d0                	cmp    %edx,%eax
   f0f32:	0f 8c d8 fe ff ff    	jl     f0e10 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f0f38:	75 c6                	jne    f0f00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f0f3a:	41 8b 36             	mov    (%r14),%esi
   f0f3d:	41 8b 4d f8          	mov    -0x8(%r13),%ecx
   f0f41:	0f 1f 40 00          	nopl   0x0(%rax)
   f0f45:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0f50:	39 f1                	cmp    %esi,%ecx
   f0f52:	7c ac                	jl     f0f00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f0f54:	41 8b 7d f4          	mov    -0xc(%r13),%edi
   f0f58:	45 8b 46 0c          	mov    0xc(%r14),%r8d
   f0f5c:	44 89 44 24 08       	mov    %r8d,0x8(%rsp)
   f0f61:	44 39 c7             	cmp    %r8d,%edi
   f0f64:	7f 9a                	jg     f0f00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f0f66:	45 8b 56 04          	mov    0x4(%r14),%r10d
   f0f6a:	45 8b 45 fc          	mov    -0x4(%r13),%r8d
   f0f6e:	44 89 54 24 28       	mov    %r10d,0x28(%rsp)
   f0f73:	45 39 c2             	cmp    %r8d,%r10d
   f0f76:	7f 88                	jg     f0f00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f0f78:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
   f0f7d:	41 80 7a 21 01       	cmpb   $0x1,0x21(%r10)
   f0f82:	41 0f 95 c2          	setne  %r10b
   f0f86:	44 39 c7             	cmp    %r8d,%edi
   f0f89:	40 0f 95 c7          	setne  %dil
   f0f8d:	41 21 fa             	and    %edi,%r10d
   f0f90:	8b 7c 24 28          	mov    0x28(%rsp),%edi
   f0f94:	39 7c 24 08          	cmp    %edi,0x8(%rsp)
   f0f98:	40 0f 95 c7          	setne  %dil
   f0f9c:	44 21 d7             	and    %r10d,%edi
   f0f9f:	39 c1                	cmp    %eax,%ecx
   f0fa1:	0f 95 c0             	setne  %al
   f0fa4:	40 84 c7             	test   %al,%dil
   f0fa7:	0f 84 8e fe ff ff    	je     f0e3b <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x43b>
   f0fad:	39 d6                	cmp    %edx,%esi
   f0faf:	0f 84 86 fe ff ff    	je     f0e3b <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x43b>
   f0fb5:	e9 46 ff ff ff       	jmp    f0f00 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x500>
   f0fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f0fc0:	49 8d 45 10          	lea    0x10(%r13),%rax
   f0fc4:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
   f0fc9:	4d 8d 59 20          	lea    0x20(%r9),%r11
   f0fcd:	49 83 c5 01          	add    $0x1,%r13
   f0fd1:	4c 39 6c 24 38       	cmp    %r13,0x38(%rsp)
   f0fd6:	0f 85 04 fe ff ff    	jne    f0de0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f0fdc:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
   f0fe1:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
   f0fe6:	31 c0                	xor    %eax,%eax
   f0fe8:	48 8b 9c 24 78 01 00 00 	mov    0x178(%rsp),%rbx
   f0ff0:	4c 8b ac 24 90 01 00 00 	mov    0x190(%rsp),%r13
   f0ff8:	4c 8b b4 24 98 01 00 00 	mov    0x198(%rsp),%r14
   f1000:	4c 8b bc 24 a0 01 00 00 	mov    0x1a0(%rsp),%r15
   f1008:	e9 ed fc ff ff       	jmp    f0cfa <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2fa>
   f100d:	8b 44 24 20          	mov    0x20(%rsp),%eax
   f1011:	89 ea                	mov    %ebp,%edx
   f1013:	89 44 24 08          	mov    %eax,0x8(%rsp)
   f1017:	e9 34 fe ff ff       	jmp    f0e50 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x450>
   f101c:	48 8b 3d 3d 42 08 00 	mov    0x8423d(%rip),%rdi        # 175260 <stderr@GLIBC_2.2.5>
   f1023:	0f b6 d0             	movzbl %al,%edx
   f1026:	48 8d 35 73 a9 06 00 	lea    0x6a973(%rip),%rsi        # 15b9a0 <_IO_stdin_used+0x19a0>
   f102d:	31 c0                	xor    %eax,%eax
   f102f:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   f1037:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   f103f:	e8 fc 62 f1 ff       	call   7340 <fprintf@plt>
   f1044:	e8 d7 60 f1 ff       	call   7120 <abort@plt>
   f1049:	48 89 9c 24 78 01 00 00 	mov    %rbx,0x178(%rsp)
   f1051:	4c 89 ac 24 90 01 00 00 	mov    %r13,0x190(%rsp)
   f1059:	4c 89 b4 24 98 01 00 00 	mov    %r14,0x198(%rsp)
   f1061:	4c 89 bc 24 a0 01 00 00 	mov    %r15,0x1a0(%rsp)
   f1069:	e8 f2 61 f1 ff       	call   7260 <__stack_chk_fail@plt>

# candidate ordered_pairs bench::Counters bench::LibraryIndex<int, true>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-combined.ARqsxS/candidate-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f4640 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f4640:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
   f4647:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f464b:	48 89 9c 24 c8 01 00 00 	mov    %rbx,0x1c8(%rsp)
   f4653:	48 89 fb             	mov    %rdi,%rbx
   f4656:	4c 89 bc 24 f0 01 00 00 	mov    %r15,0x1f0(%rsp)
   f465e:	49 89 f7             	mov    %rsi,%r15
   f4661:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   f4666:	8b 96 d0 00 00 00    	mov    0xd0(%rsi),%edx
   f466c:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
   f4673:	64 48 8b 3c 25 28 00 00 00 	mov    %fs:0x28,%rdi
   f467c:	48 89 bc 24 b8 01 00 00 	mov    %rdi,0x1b8(%rsp)
   f4684:	31 ff                	xor    %edi,%edi
   f4686:	83 fa 01             	cmp    $0x1,%edx
   f4689:	0f 86 01 03 00 00    	jbe    f4990 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x350>
   f468f:	48 39 f2             	cmp    %rsi,%rdx
   f4692:	74 44                	je     f46d8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x98>
   f4694:	ba 07 00 00 00       	mov    $0x7,%edx
   f4699:	48 8b 3d c0 0b 08 00 	mov    0x80bc0(%rip),%rdi        # 175260 <stderr@GLIBC_2.2.5>
   f46a0:	48 8d 35 f9 72 06 00 	lea    0x672f9(%rip),%rsi        # 15b9a0 <_IO_stdin_used+0x19a0>
   f46a7:	31 c0                	xor    %eax,%eax
   f46a9:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f46b1:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f46b9:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f46c1:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f46c9:	e8 72 2c f1 ff       	call   7340 <fprintf@plt>
   f46ce:	e8 4d 2a f1 ff       	call   7120 <abort@plt>
   f46d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f46d8:	49 89 c8             	mov    %rcx,%r8
   f46db:	0f 11 84 24 98 00 00 00 	movups %xmm0,0x98(%rsp)
   f46e3:	49 8b 47 50          	mov    0x50(%r15),%rax
   f46e7:	89 d1                	mov    %edx,%ecx
   f46e9:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f46f1:	66 49 0f 6e d0       	movq   %r8,%xmm2
   f46f6:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   f46fb:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
   f46ff:	c6 84 24 90 00 00 00 00 	movb   $0x0,0x90(%rsp)
   f4707:	48 c7 84 24 c8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xc8(%rsp)
   f4713:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f471b:	48 85 c0             	test   %rax,%rax
   f471e:	0f 84 c6 08 00 00    	je     f4fea <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9aa>
   f4724:	48 89 84 24 d0 00 00 00 	mov    %rax,0xd0(%rsp)
   f472c:	48 89 84 24 d8 00 00 00 	mov    %rax,0xd8(%rsp)
   f4734:	48 c7 84 24 e0 00 00 00 00 00 00 00 	movq   $0x0,0xe0(%rsp)
   f4740:	48 c7 84 24 e8 00 00 00 00 00 00 00 	movq   $0x0,0xe8(%rsp)
   f474c:	48 89 84 24 f0 00 00 00 	mov    %rax,0xf0(%rsp)
   f4754:	48 c7 84 24 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rsp)
   f4760:	48 c7 84 24 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rsp)
   f476c:	48 89 84 24 08 01 00 00 	mov    %rax,0x108(%rsp)
   f4774:	48 c7 84 24 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rsp)
   f4780:	48 c7 84 24 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rsp)
   f478c:	48 89 84 24 20 01 00 00 	mov    %rax,0x120(%rsp)
   f4794:	48 c7 84 24 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rsp)
   f47a0:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f47ac:	48 89 84 24 38 01 00 00 	mov    %rax,0x138(%rsp)
   f47b4:	48 c7 84 24 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rsp)
   f47c0:	48 c7 84 24 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rsp)
   f47cc:	48 89 84 24 50 01 00 00 	mov    %rax,0x150(%rsp)
   f47d4:	48 c7 84 24 58 01 00 00 00 00 00 00 	movq   $0x0,0x158(%rsp)
   f47e0:	48 c7 84 24 60 01 00 00 00 00 00 00 	movq   $0x0,0x160(%rsp)
   f47ec:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f47f4:	48 c7 84 24 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rsp)
   f4800:	48 c7 84 24 78 01 00 00 00 00 00 00 	movq   $0x0,0x178(%rsp)
   f480c:	48 89 84 24 80 01 00 00 	mov    %rax,0x180(%rsp)
   f4814:	48 c7 84 24 88 01 00 00 00 00 00 00 	movq   $0x0,0x188(%rsp)
   f4820:	48 c7 84 24 90 01 00 00 00 00 00 00 	movq   $0x0,0x190(%rsp)
   f482c:	48 89 84 24 98 01 00 00 	mov    %rax,0x198(%rsp)
   f4834:	48 c7 84 24 a0 01 00 00 00 00 00 00 	movq   $0x0,0x1a0(%rsp)
   f4840:	48 c7 84 24 a8 01 00 00 00 00 00 00 	movq   $0x0,0x1a8(%rsp)
   f484c:	c7 84 24 b0 01 00 00 00 00 00 00 	movl   $0x0,0x1b0(%rsp)
   f4857:	c6 84 24 b4 01 00 00 00 	movb   $0x0,0x1b4(%rsp)
   f485f:	49 39 b7 a0 01 00 00 	cmp    %rsi,0x1a0(%r15)
   f4866:	0f 82 b4 01 00 00    	jb     f4a20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f486c:	49 39 b7 b8 01 00 00 	cmp    %rsi,0x1b8(%r15)
   f4873:	0f 82 a7 01 00 00    	jb     f4a20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f4879:	41 80 bf 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r15)
   f4881:	0f 85 aa 07 00 00    	jne    f5031 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9f1>
   f4887:	49 8d 47 08          	lea    0x8(%r15),%rax
   f488b:	4d 8b 9f 98 01 00 00 	mov    0x198(%r15),%r11
   f4892:	c6 44 24 43 00       	movb   $0x0,0x43(%rsp)
   f4897:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   f489c:	49 8d 87 88 01 00 00 	lea    0x188(%r15),%rax
   f48a3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f48a8:	41 c6 87 6c 02 00 00 01 	movb   $0x1,0x26c(%r15)
   f48b0:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
   f48b5:	85 c9                	test   %ecx,%ecx
   f48b7:	0f 84 7a 01 00 00    	je     f4a37 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f48bd:	8d 41 ff             	lea    -0x1(%rcx),%eax
   f48c0:	83 f8 02             	cmp    $0x2,%eax
   f48c3:	0f 86 3c 07 00 00    	jbe    f5005 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9c5>
   f48c9:	89 cf                	mov    %ecx,%edi
   f48cb:	4c 89 d8             	mov    %r11,%rax
   f48ce:	66 0f 6f 05 5a 8d 06 00 	movdqa 0x68d5a(%rip),%xmm0        # 15d630 <C.66.5+0x10>
   f48d6:	c1 ef 02             	shr    $0x2,%edi
   f48d9:	89 fa                	mov    %edi,%edx
   f48db:	48 c1 e2 04          	shl    $0x4,%rdx
   f48df:	4c 01 da             	add    %r11,%rdx
   f48e2:	41 bb 04 00 00 00    	mov    $0x4,%r11d
   f48e8:	66 41 0f 6e cb       	movd   %r11d,%xmm1
   f48ed:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   f48f2:	0f 1f 00             	nopl   (%rax)
   f48f5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f4900:	0f 11 00             	movups %xmm0,(%rax)
   f4903:	48 83 c0 10          	add    $0x10,%rax
   f4907:	66 0f fe c1          	paddd  %xmm1,%xmm0
   f490b:	48 39 d0             	cmp    %rdx,%rax
   f490e:	75 f0                	jne    f4900 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2c0>
   f4910:	8d 04 bd 00 00 00 00 	lea    0x0(,%rdi,4),%eax
   f4917:	39 c8                	cmp    %ecx,%eax
   f4919:	74 25                	je     f4940 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f491b:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
   f4920:	89 c2                	mov    %eax,%edx
   f4922:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f4926:	8d 50 01             	lea    0x1(%rax),%edx
   f4929:	39 ca                	cmp    %ecx,%edx
   f492b:	73 13                	jae    f4940 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f492d:	89 d7                	mov    %edx,%edi
   f492f:	83 c0 02             	add    $0x2,%eax
   f4932:	41 89 14 bb          	mov    %edx,(%r11,%rdi,4)
   f4936:	39 c8                	cmp    %ecx,%eax
   f4938:	73 06                	jae    f4940 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f493a:	89 c2                	mov    %eax,%edx
   f493c:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f4940:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
   f4947:	0f 86 ea 00 00 00    	jbe    f4a37 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f494d:	49 39 b7 48 02 00 00 	cmp    %rsi,0x248(%r15)
   f4954:	0f 82 e7 00 00 00    	jb     f4a41 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f495a:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f4964:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f496b:	48 c1 ea 04          	shr    $0x4,%rdx
   f496f:	48 39 f2             	cmp    %rsi,%rdx
   f4972:	0f 82 c9 00 00 00    	jb     f4a41 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f4978:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f497c:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   f4981:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f4986:	e8 35 f6 f1 ff       	call   13fc0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f498b:	e9 db 00 00 00       	jmp    f4a6b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x42b>
   f4990:	48 39 f2             	cmp    %rsi,%rdx
   f4993:	0f 85 fb fc ff ff    	jne    f4694 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54>
   f4999:	48 89 d0             	mov    %rdx,%rax
   f499c:	0f 11 84 24 d8 00 00 00 	movups %xmm0,0xd8(%rsp)
   f49a4:	31 d2                	xor    %edx,%edx
   f49a6:	48 8b 8c 24 e0 00 00 00 	mov    0xe0(%rsp),%rcx
   f49ae:	85 c0                	test   %eax,%eax
   f49b0:	89 c7                	mov    %eax,%edi
   f49b2:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   f49ba:	0f 95 c0             	setne  %al
   f49bd:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   f49c5:	80 fa 0b             	cmp    $0xb,%dl
   f49c8:	48 89 0b             	mov    %rcx,(%rbx)
   f49cb:	48 8b 8c 24 d8 00 00 00 	mov    0xd8(%rsp),%rcx
   f49d3:	0f b6 c0             	movzbl %al,%eax
   f49d6:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
   f49da:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   f49de:	89 43 20             	mov    %eax,0x20(%rbx)
   f49e1:	0f 94 43 30          	sete   0x30(%rbx)
   f49e5:	48 8b 84 24 b8 01 00 00 	mov    0x1b8(%rsp),%rax
   f49ed:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f49f6:	0f 85 10 06 00 00    	jne    f500c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9cc>
   f49fc:	48 89 d8             	mov    %rbx,%rax
   f49ff:	4c 8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%r15
   f4a07:	48 8b 9c 24 c8 01 00 00 	mov    0x1c8(%rsp),%rbx
   f4a0f:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
   f4a16:	c3                   	ret
   f4a17:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   f4a20:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f4a28:	e8 d3 ca 00 00       	call   101500 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f4a2d:	ba 05 00 00 00       	mov    $0x5,%edx
   f4a32:	e9 62 fc ff ff       	jmp    f4699 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f4a37:	48 83 fe 01          	cmp    $0x1,%rsi
   f4a3b:	0f 86 bd 05 00 00    	jbe    f4ffe <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9be>
   f4a41:	48 89 f0             	mov    %rsi,%rax
   f4a44:	31 c9                	xor    %ecx,%ecx
   f4a46:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f4a50:	48 d1 e8             	shr    $1,%rax
   f4a53:	83 c1 02             	add    $0x2,%ecx
   f4a56:	48 83 f8 01          	cmp    $0x1,%rax
   f4a5a:	75 f4                	jne    f4a50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f4a5c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f4a61:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f4a66:	e8 95 f4 05 00       	call   153f00 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f4a6b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f4a72:	83 fa 01             	cmp    $0x1,%edx
   f4a75:	0f 86 2a 03 00 00    	jbe    f4da5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f4a7b:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f4a83:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f4a8b:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f4a93:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f4a9b:	48 c7 44 24 08 01 00 00 00 	movq   $0x1,0x8(%rsp)
   f4aa4:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   f4aa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f4ab0:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f4ab8:	84 c0                	test   %al,%al
   f4aba:	0f 85 c0 02 00 00    	jne    f4d80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f4ac0:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   f4ac5:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f4aca:	48 8d 4c 24 43       	lea    0x43(%rsp),%rcx
   f4acf:	4c 8d ac 24 90 00 00 00 	lea    0x90(%rsp),%r13
   f4ad7:	8b 7c 9f fc          	mov    -0x4(%rdi,%rbx,4),%edi
   f4adb:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   f4ae0:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   f4ae5:	48 8d 4c 24 42       	lea    0x42(%rsp),%rcx
   f4aea:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   f4aef:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   f4af4:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   f4af9:	48 8d 5c 24 44       	lea    0x44(%rsp),%rbx
   f4afe:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   f4b03:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
   f4b08:	48 89 8c 24 80 00 00 00 	mov    %rcx,0x80(%rsp)
   f4b10:	41 8b 8f 64 01 00 00 	mov    0x164(%r15),%ecx
   f4b17:	89 7c 24 44          	mov    %edi,0x44(%rsp)
   f4b1b:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
   f4b24:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
   f4b29:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   f4b2e:	83 f9 ff             	cmp    $0xffffffff,%ecx
   f4b31:	0f 84 d9 02 00 00    	je     f4e10 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7d0>
   f4b37:	89 ce                	mov    %ecx,%esi
   f4b39:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   f4b3d:	49 03 b7 f8 00 00 00 	add    0xf8(%r15),%rsi
   f4b44:	44 8b 46 64          	mov    0x64(%rsi),%r8d
   f4b48:	45 85 c0             	test   %r8d,%r8d
   f4b4b:	0f 84 ff 01 00 00    	je     f4d50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4b51:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f4b59:	48 85 c0             	test   %rax,%rax
   f4b5c:	0f 84 56 04 00 00    	je     f4fb8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x978>
   f4b62:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f4b66:	74 0c                	je     f4b74 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x534>
   f4b68:	48 83 e8 01          	sub    $0x1,%rax
   f4b6c:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f4b74:	48 8b 84 24 98 00 00 00 	mov    0x98(%rsp),%rax
   f4b7c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f4b80:	74 0c                	je     f4b8e <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54e>
   f4b82:	48 83 c0 01          	add    $0x1,%rax
   f4b86:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f4b8e:	48 89 fa             	mov    %rdi,%rdx
   f4b91:	8b 46 1c             	mov    0x1c(%rsi),%eax
   f4b94:	48 c1 e2 04          	shl    $0x4,%rdx
   f4b98:	49 03 57 58          	add    0x58(%r15),%rdx
   f4b9c:	39 02                	cmp    %eax,(%rdx)
   f4b9e:	0f 8f ac 01 00 00    	jg     f4d50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4ba4:	8b 42 08             	mov    0x8(%rdx),%eax
   f4ba7:	39 46 14             	cmp    %eax,0x14(%rsi)
   f4baa:	0f 8f a0 01 00 00    	jg     f4d50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4bb0:	8b 46 20             	mov    0x20(%rsi),%eax
   f4bb3:	39 42 04             	cmp    %eax,0x4(%rdx)
   f4bb6:	0f 8f 94 01 00 00    	jg     f4d50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4bbc:	8b 42 0c             	mov    0xc(%rdx),%eax
   f4bbf:	39 46 18             	cmp    %eax,0x18(%rsi)
   f4bc2:	0f 8f 88 01 00 00    	jg     f4d50 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4bc8:	49 8b 47 68          	mov    0x68(%r15),%rax
   f4bcc:	48 c1 e7 05          	shl    $0x5,%rdi
   f4bd0:	48 83 ec 08          	sub    $0x8,%rsp
   f4bd4:	4d 89 e9             	mov    %r13,%r9
   f4bd7:	48 01 f8             	add    %rdi,%rax
   f4bda:	48 8b 08             	mov    (%rax),%rcx
   f4bdd:	4c 8b 40 08          	mov    0x8(%rax),%r8
   f4be1:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   f4be6:	50                   	push   %rax
   f4be7:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f4bec:	e8 4f b6 f2 ff       	call   20240 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE11walkOrderedIZNKS2_11orderedSelfIZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS5_8CountersERT_mEUlRKSC_RKT0_E_NS_6detail9AcceptAllEEEvRNS_9WorkspaceIiEEbRNS2_12QueryContextINS_11QueryResultEEESD_RSG_EUljE_EEvRKNS2_4NodeERKNS_3BoxIiEENS_6FilterESS_SD_>
   f4bf1:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f4bf9:	5a                   	pop    %rdx
   f4bfa:	59                   	pop    %rcx
   f4bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f4c00:	84 c0                	test   %al,%al
   f4c02:	0f 85 78 01 00 00    	jne    f4d80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f4c08:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f4c0d:	49 8b 9f b0 01 00 00 	mov    0x1b0(%r15),%rbx
   f4c14:	48 83 fd 7f          	cmp    $0x7f,%rbp
   f4c18:	0f 86 5b 03 00 00    	jbe    f4f79 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x939>
   f4c1e:	49 39 af 48 02 00 00 	cmp    %rbp,0x248(%r15)
   f4c25:	0f 82 58 03 00 00    	jb     f4f83 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f4c2b:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f4c35:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f4c3c:	48 c1 ea 04          	shr    $0x4,%rdx
   f4c40:	48 39 ea             	cmp    %rbp,%rdx
   f4c43:	0f 82 3a 03 00 00    	jb     f4f83 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f4c49:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f4c4d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f4c52:	89 e9                	mov    %ebp,%ecx
   f4c54:	48 89 da             	mov    %rbx,%rdx
   f4c57:	e8 64 f3 f1 ff       	call   13fc0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f4c5c:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f4c61:	48 85 ed             	test   %rbp,%rbp
   f4c64:	0f 84 fb 00 00 00    	je     f4d65 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f4c6a:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
   f4c6f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   f4c74:	31 c9                	xor    %ecx,%ecx
   f4c76:	4d 8b 5f 68          	mov    0x68(%r15),%r11
   f4c7a:	4d 8b 4f 60          	mov    0x60(%r15),%r9
   f4c7e:	4c 89 c2             	mov    %r8,%rdx
   f4c81:	48 8b 07             	mov    (%rdi),%rax
   f4c84:	4c 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%r10
   f4c8c:	48 c1 e2 05          	shl    $0x5,%rdx
   f4c90:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
   f4c94:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   f4c99:	4d 8d 34 13          	lea    (%r11,%rdx,1),%r14
   f4c9d:	4c 8d 68 01          	lea    0x1(%rax),%r13
   f4ca1:	8b 14 8b             	mov    (%rbx,%rcx,4),%edx
   f4ca4:	49 8b 76 10          	mov    0x10(%r14),%rsi
   f4ca8:	4d 8d 64 0d 00       	lea    0x0(%r13,%rcx,1),%r12
   f4cad:	48 89 d0             	mov    %rdx,%rax
   f4cb0:	48 c1 e0 05          	shl    $0x5,%rax
   f4cb4:	49 39 74 03 10       	cmp    %rsi,0x10(%r11,%rax,1)
   f4cb9:	48 89 d0             	mov    %rdx,%rax
   f4cbc:	49 0f 42 c0          	cmovb  %r8,%rax
   f4cc0:	49 0f 43 d0          	cmovae %r8,%rdx
   f4cc4:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f4cc8:	41 8b 34 91          	mov    (%r9,%rdx,4),%esi
   f4ccc:	39 f0                	cmp    %esi,%eax
   f4cce:	89 f2                	mov    %esi,%edx
   f4cd0:	0f 46 d0             	cmovbe %eax,%edx
   f4cd3:	48 c1 e2 20          	shl    $0x20,%rdx
   f4cd7:	39 f0                	cmp    %esi,%eax
   f4cd9:	0f 42 c6             	cmovb  %esi,%eax
   f4cdc:	48 09 d0             	or     %rdx,%rax
   f4cdf:	48 89 c2             	mov    %rax,%rdx
   f4ce2:	48 c1 ea 1e          	shr    $0x1e,%rdx
   f4ce6:	48 31 c2             	xor    %rax,%rdx
   f4ce9:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   f4cf3:	48 0f af d0          	imul   %rax,%rdx
   f4cf7:	48 89 d0             	mov    %rdx,%rax
   f4cfa:	48 c1 e8 1b          	shr    $0x1b,%rax
   f4cfe:	48 31 c2             	xor    %rax,%rdx
   f4d01:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f4d0b:	48 0f af d0          	imul   %rax,%rdx
   f4d0f:	48 89 d0             	mov    %rdx,%rax
   f4d12:	48 c1 e8 1f          	shr    $0x1f,%rax
   f4d16:	48 31 c2             	xor    %rax,%rdx
   f4d19:	48 01 d7             	add    %rdx,%rdi
   f4d1c:	49 83 fa ff          	cmp    $0xffffffffffffffff,%r10
   f4d20:	0f 84 82 01 00 00    	je     f4ea8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x868>
   f4d26:	49 83 c2 01          	add    $0x1,%r10
   f4d2a:	48 83 c1 01          	add    $0x1,%rcx
   f4d2e:	4c 89 94 24 b8 00 00 00 	mov    %r10,0xb8(%rsp)
   f4d36:	48 39 cd             	cmp    %rcx,%rbp
   f4d39:	0f 85 62 ff ff ff    	jne    f4ca1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x661>
   f4d3f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f4d44:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f4d48:	4c 89 20             	mov    %r12,(%rax)
   f4d4b:	eb 18                	jmp    f4d65 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f4d4d:	0f 1f 00             	nopl   (%rax)
   f4d50:	49 8b bf b0 01 00 00 	mov    0x1b0(%r15),%rdi
   f4d57:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f4d5c:	31 c9                	xor    %ecx,%ecx
   f4d5e:	31 f6                	xor    %esi,%esi
   f4d60:	e8 9b f1 05 00       	call   153f00 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f4d65:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f4d6c:	48 83 44 24 08 01    	addq   $0x1,0x8(%rsp)
   f4d72:	48 89 c2             	mov    %rax,%rdx
   f4d75:	48 39 44 24 08       	cmp    %rax,0x8(%rsp)
   f4d7a:	0f 82 30 fd ff ff    	jb     f4ab0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x470>
   f4d80:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f4d85:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f4d8d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f4d95:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f4d9d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f4da5:	41 c6 87 6c 02 00 00 00 	movb   $0x0,0x26c(%r15)
   f4dad:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f4db5:	e8 46 c7 00 00       	call   101500 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f4dba:	0f b6 94 24 90 00 00 00 	movzbl 0x90(%rsp),%edx
   f4dc2:	66 0f 6f 84 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm0
   f4dcb:	66 0f 6f 9c 24 90 00 00 00 	movdqa 0x90(%rsp),%xmm3
   f4dd4:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f4ddc:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f4de5:	0f 29 9c 24 d0 00 00 00 	movaps %xmm3,0xd0(%rsp)
   f4ded:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f4df5:	80 fa 0b             	cmp    $0xb,%dl
   f4df8:	74 08                	je     f4e02 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7c2>
   f4dfa:	84 d2                	test   %dl,%dl
   f4dfc:	0f 85 97 f8 ff ff    	jne    f4699 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f4e02:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f4e09:	e9 98 fb ff ff       	jmp    f49a6 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x366>
   f4e0e:	66 90                	xchg   %ax,%ax
   f4e10:	49 8b 6f 68          	mov    0x68(%r15),%rbp
   f4e14:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
   f4e19:	31 db                	xor    %ebx,%ebx
   f4e1b:	eb 49                	jmp    f4e66 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x826>
   f4e1d:	0f 1f 00             	nopl   (%rax)
   f4e20:	4c 89 e9             	mov    %r13,%rcx
   f4e23:	44 89 f2             	mov    %r14d,%edx
   f4e26:	4c 89 e7             	mov    %r12,%rdi
   f4e29:	e8 d2 e6 f1 ff       	call   13500 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_12QueryContextINS_11QueryResultEEERT0_.isra.0>
   f4e2e:	84 c0                	test   %al,%al
   f4e30:	74 19                	je     f4e4b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x80b>
   f4e32:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   f4e37:	48 8d 50 01          	lea    0x1(%rax),%rdx
   f4e3b:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f4e40:	49 8b 97 b0 01 00 00 	mov    0x1b0(%r15),%rdx
   f4e47:	44 89 34 82          	mov    %r14d,(%rdx,%rax,4)
   f4e4b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f4e52:	48 83 c3 01          	add    $0x1,%rbx
   f4e56:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f4e5e:	39 d3                	cmp    %edx,%ebx
   f4e60:	0f 83 9a fd ff ff    	jae    f4c00 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f4e66:	84 c0                	test   %al,%al
   f4e68:	0f 85 12 ff ff ff    	jne    f4d80 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f4e6e:	8b 44 24 44          	mov    0x44(%rsp),%eax
   f4e72:	41 89 de             	mov    %ebx,%r14d
   f4e75:	48 89 c6             	mov    %rax,%rsi
   f4e78:	48 c1 e0 05          	shl    $0x5,%rax
   f4e7c:	48 01 e8             	add    %rbp,%rax
   f4e7f:	48 89 d9             	mov    %rbx,%rcx
   f4e82:	48 c1 e1 05          	shl    $0x5,%rcx
   f4e86:	48 8b 7c 0d 10       	mov    0x10(%rbp,%rcx,1),%rdi
   f4e8b:	48 39 78 10          	cmp    %rdi,0x10(%rax)
   f4e8f:	72 8f                	jb     f4e20 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e0>
   f4e91:	48 83 c3 01          	add    $0x1,%rbx
   f4e95:	39 d3                	cmp    %edx,%ebx
   f4e97:	0f 83 6b fd ff ff    	jae    f4c08 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c8>
   f4e9d:	41 89 de             	mov    %ebx,%r14d
   f4ea0:	eb dd                	jmp    f4e7f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x83f>
   f4ea2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f4ea8:	4c 8d 69 01          	lea    0x1(%rcx),%r13
   f4eac:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   f4eb1:	4c 39 ed             	cmp    %r13,%rbp
   f4eb4:	0f 84 85 fe ff ff    	je     f4d3f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x6ff>
   f4eba:	4d 8b 74 13 10       	mov    0x10(%r11,%rdx,1),%r14
   f4ebf:	4c 89 ee             	mov    %r13,%rsi
   f4ec2:	0f 1f 00             	nopl   (%rax)
   f4ec5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f4ed0:	8b 04 b3             	mov    (%rbx,%rsi,4),%eax
   f4ed3:	48 89 c2             	mov    %rax,%rdx
   f4ed6:	48 c1 e2 05          	shl    $0x5,%rdx
   f4eda:	4d 39 74 13 10       	cmp    %r14,0x10(%r11,%rdx,1)
   f4edf:	48 89 c2             	mov    %rax,%rdx
   f4ee2:	49 0f 42 d0          	cmovb  %r8,%rdx
   f4ee6:	49 0f 43 c0          	cmovae %r8,%rax
   f4eea:	45 8b 14 91          	mov    (%r9,%rdx,4),%r10d
   f4eee:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f4ef2:	44 89 d2             	mov    %r10d,%edx
   f4ef5:	44 39 d0             	cmp    %r10d,%eax
   f4ef8:	0f 46 d0             	cmovbe %eax,%edx
   f4efb:	48 c1 e2 20          	shl    $0x20,%rdx
   f4eff:	44 39 d0             	cmp    %r10d,%eax
   f4f02:	41 0f 42 c2          	cmovb  %r10d,%eax
   f4f06:	48 83 c6 01          	add    $0x1,%rsi
   f4f0a:	48 09 c2             	or     %rax,%rdx
   f4f0d:	48 89 d0             	mov    %rdx,%rax
   f4f10:	48 c1 e8 1e          	shr    $0x1e,%rax
   f4f14:	48 31 d0             	xor    %rdx,%rax
   f4f17:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f4f21:	48 0f af c2          	imul   %rdx,%rax
   f4f25:	48 89 c2             	mov    %rax,%rdx
   f4f28:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f4f2c:	48 31 c2             	xor    %rax,%rdx
   f4f2f:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f4f39:	48 0f af d0          	imul   %rax,%rdx
   f4f3d:	48 89 d0             	mov    %rdx,%rax
   f4f40:	48 c1 e8 1f          	shr    $0x1f,%rax
   f4f44:	48 31 d0             	xor    %rdx,%rax
   f4f47:	48 01 c7             	add    %rax,%rdi
   f4f4a:	48 39 ee             	cmp    %rbp,%rsi
   f4f4d:	72 81                	jb     f4ed0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x890>
   f4f4f:	48 8d 45 ff          	lea    -0x1(%rbp),%rax
   f4f53:	48 83 c1 02          	add    $0x2,%rcx
   f4f57:	31 d2                	xor    %edx,%edx
   f4f59:	4c 29 e8             	sub    %r13,%rax
   f4f5c:	48 39 cd             	cmp    %rcx,%rbp
   f4f5f:	48 0f 42 c2          	cmovb  %rdx,%rax
   f4f63:	4d 8d 64 04 01       	lea    0x1(%r12,%rax,1),%r12
   f4f68:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f4f6d:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f4f71:	4c 89 20             	mov    %r12,(%rax)
   f4f74:	e9 ec fd ff ff       	jmp    f4d65 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f4f79:	48 83 fd 01          	cmp    $0x1,%rbp
   f4f7d:	0f 86 d3 00 00 00    	jbe    f5056 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa16>
   f4f83:	48 89 e8             	mov    %rbp,%rax
   f4f86:	31 c9                	xor    %ecx,%ecx
   f4f88:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f4f90:	48 d1 e8             	shr    $1,%rax
   f4f93:	83 c1 02             	add    $0x2,%ecx
   f4f96:	48 83 f8 01          	cmp    $0x1,%rax
   f4f9a:	75 f4                	jne    f4f90 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x950>
   f4f9c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f4fa1:	48 89 ee             	mov    %rbp,%rsi
   f4fa4:	48 89 df             	mov    %rbx,%rdi
   f4fa7:	e8 54 ef 05 00       	call   153f00 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f4fac:	e9 b0 fc ff ff       	jmp    f4c61 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x621>
   f4fb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f4fb8:	c6 84 24 90 00 00 00 0b 	movb   $0xb,0x90(%rsp)
   f4fc0:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f4fc5:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f4fcd:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f4fd5:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f4fdd:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f4fe5:	e9 bb fd ff ff       	jmp    f4da5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f4fea:	e8 51 4d 00 00       	call   f9d40 <_ZN8QuadTree15defaultResourceEv>
   f4fef:	41 8b b7 d0 00 00 00 	mov    0xd0(%r15),%esi
   f4ff6:	48 89 f1             	mov    %rsi,%rcx
   f4ff9:	e9 26 f7 ff ff       	jmp    f4724 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xe4>
   f4ffe:	31 c9                	xor    %ecx,%ecx
   f5000:	e9 57 fa ff ff       	jmp    f4a5c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x41c>
   f5005:	31 c0                	xor    %eax,%eax
   f5007:	e9 0f f9 ff ff       	jmp    f491b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2db>
   f500c:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f5014:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f501c:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f5024:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f502c:	e8 2f 22 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f5031:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f5039:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f5041:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f5049:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f5051:	e8 aa 53 00 00       	call   fa400 <_ZN8QuadTree6detail15activeWorkspaceEv>
   f5056:	31 c9                	xor    %ecx,%ecx
   f5058:	e9 3f ff ff ff       	jmp    f4f9c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x95c>
