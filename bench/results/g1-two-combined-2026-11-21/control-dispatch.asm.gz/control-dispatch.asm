
# control unordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, false>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-combined.ARqsxS/control-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f0a40 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f0a40:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f0a47:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f0a4b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f0a53:	48 8b 2a             	mov    (%rdx),%rbp
   f0a56:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f0a5e:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f0a62:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f0a6a:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f0a72:	49 89 ff             	mov    %rdi,%r15
   f0a75:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f0a7d:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f0a84:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f0a89:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f0a92:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f0a9a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f0a9e:	0f 11 07             	movups %xmm0,(%rdi)
   f0aa1:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f0aa5:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f0aa9:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f0aad:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f0ab1:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f0ab5:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f0ab9:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f0abd:	48 89 14 24          	mov    %rdx,(%rsp)
   f0ac1:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f0ac5:	e8 f6 25 06 00       	call   1530c0 <_ZN5bench6memory11allocationsEv>
   f0aca:	80 3d a7 27 08 00 00 	cmpb   $0x0,0x827a7(%rip)        # 173278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f0ad1:	4c 8b 1c 24          	mov    (%rsp),%r11
   f0ad5:	49 89 c6             	mov    %rax,%r14
   f0ad8:	0f 84 41 0e 00 00    	je     f191f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xedf>
   f0ade:	0f 31                	rdtsc
   f0ae0:	48 c1 e2 20          	shl    $0x20,%rdx
   f0ae4:	48 09 d0             	or     %rdx,%rax
   f0ae7:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f0aef:	49 8b 13             	mov    (%r11),%rdx
   f0af2:	49 3b 53 08          	cmp    0x8(%r11),%rdx
   f0af6:	0f 84 0f 09 00 00    	je     f140b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9cb>
   f0afc:	49 29 ec             	sub    %rbp,%r12
   f0aff:	48 c7 04 24 00 00 00 00 	movq   $0x0,(%rsp)
   f0b07:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f0b0b:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f0b13:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f0b1b:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f0b24:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f0b2d:	c7 44 24 1c 00 00 00 00 	movl   $0x0,0x1c(%rsp)
   f0b35:	4c 89 9c 24 88 00 00 00 	mov    %r11,0x88(%rsp)
   f0b3d:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f0b45:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f0b4d:	45 31 ed             	xor    %r13d,%r13d
   f0b50:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   f0b58:	45 31 f6             	xor    %r14d,%r14d
   f0b5b:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f0b60:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f0b65:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0b70:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   f0b75:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f0b79:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f0b7d:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f0b85:	48 8b 28             	mov    (%rax),%rbp
   f0b88:	4c 8b 60 08          	mov    0x8(%rax),%r12
   f0b8c:	49 29 ec             	sub    %rbp,%r12
   f0b8f:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
   f0b94:	49 c1 fc 04          	sar    $0x4,%r12
   f0b98:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   f0b9f:	74 13                	je     f0bb4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x174>
   f0ba1:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f0ba8:	3b 83 b8 02 00 00    	cmp    0x2b8(%rbx),%eax
   f0bae:	0f 84 b8 05 00 00    	je     f116c <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x72c>
   f0bb4:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f0bbc:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f0bc0:	31 f6                	xor    %esi,%esi
   f0bc2:	66 0f 6f 3d f6 bc 06 00 	movdqa 0x6bcf6(%rip),%xmm7        # 15c8c0 <C.66.5+0x2a0>
   f0bca:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f0bd2:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f0bda:	ba 88 01 00 00       	mov    $0x188,%edx
   f0bdf:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f0be6:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f0beb:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f0bf3:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f0bfb:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f0c00:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f0c08:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f0c0c:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f0c15:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f0c1d:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f0c26:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f0c2e:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f0c37:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f0c3f:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f0c47:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f0c4c:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f0c54:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f0c59:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f0c61:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f0c66:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f0c6e:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f0c7a:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f0c86:	e8 85 64 f1 ff       	call   7110 <memset@plt>
   f0c8b:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f0c91:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f0c95:	66 0f 6f 05 33 bc 06 00 	movdqa 0x6bc33(%rip),%xmm0        # 15c8d0 <C.66.5+0x2b0>
   f0c9d:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f0ca3:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f0ca9:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f0cad:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f0cb4:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f0cbc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f0cc1:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f0cc9:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f0cd1:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f0cd9:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f0ce5:	48 89 9c 24 d8 01 00 00 	mov    %rbx,0x1d8(%rsp)
   f0ced:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f0cf9:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f0d05:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f0d11:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f0d1d:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f0d29:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f0d34:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f0d3c:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f0d47:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f0d53:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f0d5b:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f0d67:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f0d72:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f0d7a:	48 89 9c 24 78 02 00 00 	mov    %rbx,0x278(%rsp)
   f0d82:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f0d8e:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f0d9a:	48 89 9c 24 90 02 00 00 	mov    %rbx,0x290(%rsp)
   f0da2:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f0dae:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f0db6:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f0dbe:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f0dc6:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f0dce:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f0dd6:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f0de2:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f0dea:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f0df3:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f0dfb:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f0e03:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f0e0c:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f0e14:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f0e1c:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f0e25:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f0e2d:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f0e34:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f0e3c:	48 89 9c 24 a8 02 00 00 	mov    %rbx,0x2a8(%rsp)
   f0e44:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f0e50:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f0e5c:	48 89 9c 24 c0 02 00 00 	mov    %rbx,0x2c0(%rsp)
   f0e64:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f0e70:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f0e7c:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f0e88:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f0e93:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f0e9f:	48 89 9c 24 60 03 00 00 	mov    %rbx,0x360(%rsp)
   f0ea7:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f0eb2:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f0ebd:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f0ec9:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f0ed1:	48 89 9c 24 00 04 00 00 	mov    %rbx,0x400(%rsp)
   f0ed9:	48 89 9c 24 18 04 00 00 	mov    %rbx,0x418(%rsp)
   f0ee1:	48 89 9c 24 30 04 00 00 	mov    %rbx,0x430(%rsp)
   f0ee9:	48 89 9c 24 48 04 00 00 	mov    %rbx,0x448(%rsp)
   f0ef1:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f0ef9:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f0f01:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f0f09:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f0f11:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f0f19:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f0f20:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f0f29:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f0f34:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f0f3b:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f0f42:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f0f4d:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f0f54:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f0f5c:	e8 9f 08 01 00       	call   101800 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f0f61:	80 bb 80 01 00 00 00 	cmpb   $0x0,0x180(%rbx)
   f0f68:	0f 85 82 06 00 00    	jne    f15f0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbb0>
   f0f6e:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f0f77:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f0f7f:	48 89 5b 50          	mov    %rbx,0x50(%rbx)
   f0f83:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f0f8b:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f0f94:	c6 83 ec 00 00 00 00 	movb   $0x0,0xec(%rbx)
   f0f9b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
   f0f9f:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f0fa8:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f0fb0:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   f0fb4:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f0fbd:	48 89 43 48          	mov    %rax,0x48(%rbx)
   f0fc1:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f0fc8:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
   f0fcc:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f0fd5:	48 89 83 98 00 00 00 	mov    %rax,0x98(%rbx)
   f0fdc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f0fe1:	0f 11 43 38          	movups %xmm0,0x38(%rbx)
   f0fe5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f0fe9:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
   f0ff0:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f0ff9:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
   f1000:	0f 11 83 a8 00 00 00 	movups %xmm0,0xa8(%rbx)
   f1007:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f100f:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f1018:	48 c7 43 58 00 00 00 00 	movq   $0x0,0x58(%rbx)
   f1020:	0f 11 83 b1 00 00 00 	movups %xmm0,0xb1(%rbx)
   f1027:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f102b:	0f 11 83 d0 00 00 00 	movups %xmm0,0xd0(%rbx)
   f1032:	48 c7 43 60 00 00 00 00 	movq   $0x0,0x60(%rbx)
   f103a:	48 c7 43 68 00 00 00 00 	movq   $0x0,0x68(%rbx)
   f1042:	48 c7 43 70 00 00 00 00 	movq   $0x0,0x70(%rbx)
   f104a:	48 c7 43 78 00 00 00 00 	movq   $0x0,0x78(%rbx)
   f1052:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   f105c:	c6 83 94 00 00 00 00 	movb   $0x0,0x94(%rbx)
   f1063:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   f106d:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   f1078:	c7 83 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%rbx)
   f1082:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f1089:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f1092:	48 89 9b f0 00 00 00 	mov    %rbx,0xf0(%rbx)
   f1099:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
   f109f:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f10a6:	48 c7 83 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rbx)
   f10b1:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f10b8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f10bd:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   f10c4:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f10cb:	48 c7 83 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rbx)
   f10d6:	48 89 9b 08 01 00 00 	mov    %rbx,0x108(%rbx)
   f10dd:	48 c7 83 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rbx)
   f10e8:	48 c7 83 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rbx)
   f10f3:	48 89 9b 20 01 00 00 	mov    %rbx,0x120(%rbx)
   f10fa:	48 c7 83 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rbx)
   f1105:	48 c7 83 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rbx)
   f1110:	48 89 9b 38 01 00 00 	mov    %rbx,0x138(%rbx)
   f1117:	48 c7 83 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rbx)
   f1122:	48 c7 83 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rbx)
   f112d:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   f1138:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   f1142:	c6 83 80 01 00 00 01 	movb   $0x1,0x180(%rbx)
   f1149:	89 83 b8 02 00 00    	mov    %eax,0x2b8(%rbx)
   f114f:	0f 11 83 50 01 00 00 	movups %xmm0,0x150(%rbx)
   f1156:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f115f:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f1167:	e8 94 06 01 00       	call   101800 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f116c:	4c 39 a3 c0 02 00 00 	cmp    %r12,0x2c0(%rbx)
   f1173:	0f 82 37 04 00 00    	jb     f15b0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb70>
   f1179:	48 8b 93 78 02 00 00 	mov    0x278(%rbx),%rdx
   f1180:	4c 8b 93 70 02 00 00 	mov    0x270(%rbx),%r10
   f1187:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   f1191:	48 89 d1             	mov    %rdx,%rcx
   f1194:	4c 29 d1             	sub    %r10,%rcx
   f1197:	48 89 c8             	mov    %rcx,%rax
   f119a:	48 c1 f8 03          	sar    $0x3,%rax
   f119e:	48 0f af c7          	imul   %rdi,%rax
   f11a2:	4c 39 e0             	cmp    %r12,%rax
   f11a5:	0f 82 95 03 00 00    	jb     f1540 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb00>
   f11ab:	49 39 c4             	cmp    %rax,%r12
   f11ae:	73 16                	jae    f11c6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   f11b0:	49 6b c4 38          	imul   $0x38,%r12,%rax
   f11b4:	49 01 c2             	add    %rax,%r10
   f11b7:	4c 39 d2             	cmp    %r10,%rdx
   f11ba:	74 07                	je     f11c3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x783>
   f11bc:	4c 89 93 78 02 00 00 	mov    %r10,0x278(%rbx)
   f11c3:	4c 89 d2             	mov    %r10,%rdx
   f11c6:	48 8b b3 70 02 00 00 	mov    0x270(%rbx),%rsi
   f11cd:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   f11d3:	74 5c                	je     f1231 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7f1>
   f11d5:	48 89 f0             	mov    %rsi,%rax
   f11d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f11dc:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   f11e0:	31 c9                	xor    %ecx,%ecx
   f11e2:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f11ea:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f11f5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1200:	f3 0f 6f 4d 00       	movdqu 0x0(%rbp),%xmm1
   f1205:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f1209:	48 83 c5 10          	add    $0x10,%rbp
   f120d:	48 83 c0 38          	add    $0x38,%rax
   f1211:	89 48 d8             	mov    %ecx,-0x28(%rax)
   f1214:	48 83 c1 01          	add    $0x1,%rcx
   f1218:	0f 11 40 e8          	movups %xmm0,-0x18(%rax)
   f121c:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f1224:	0f 11 48 c8          	movups %xmm1,-0x38(%rax)
   f1228:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
   f122c:	4c 39 e1             	cmp    %r12,%rcx
   f122f:	72 cf                	jb     f1200 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f1231:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f123d:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1241:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f1249:	48 39 d6             	cmp    %rdx,%rsi
   f124c:	0f 84 b6 03 00 00    	je     f1608 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbc8>
   f1252:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f125c:	48 29 f2             	sub    %rsi,%rdx
   f125f:	48 c1 fa 03          	sar    $0x3,%rdx
   f1263:	48 0f af d0          	imul   %rax,%rdx
   f1267:	48 39 53 38          	cmp    %rdx,0x38(%rbx)
   f126b:	0f 82 1f 04 00 00    	jb     f1690 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc50>
   f1271:	48 83 ec 20          	sub    $0x20,%rsp
   f1275:	48 8d 8b 88 01 00 00 	lea    0x188(%rbx),%rcx
   f127c:	48 8d b3 70 02 00 00 	lea    0x270(%rbx),%rsi
   f1283:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f128c:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   f1290:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f1299:	0f 11 04 24          	movups %xmm0,(%rsp)
   f129d:	e8 de 37 fe ff       	call   d4a80 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f12a2:	48 83 c4 20          	add    $0x20,%rsp
   f12a6:	84 c0                	test   %al,%al
   f12a8:	0f 85 bc 06 00 00    	jne    f196a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf2a>
   f12ae:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f12b7:	0f 84 e3 01 00 00    	je     f14a0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa60>
   f12bd:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f12c2:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f12ca:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f12d2:	48 89 de             	mov    %rbx,%rsi
   f12d5:	e8 e6 f0 ff ff       	call   f03c0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f12da:	8b 74 24 1c          	mov    0x1c(%rsp),%esi
   f12de:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f12e5:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f12ef:	48 8b bc 24 38 03 00 00 	mov    0x338(%rsp),%rdi
   f12f7:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f12fd:	39 c6                	cmp    %eax,%esi
   f12ff:	48 8b 94 24 c8 00 00 00 	mov    0xc8(%rsp),%rdx
   f1307:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f1310:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f1319:	0f 43 c6             	cmovae %esi,%eax
   f131c:	48 01 3c 24          	add    %rdi,(%rsp)
   f1320:	48 8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%rdi
   f1328:	48 01 7c 24 08       	add    %rdi,0x8(%rsp)
   f132d:	4c 01 ea             	add    %r13,%rdx
   f1330:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   f1334:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f1338:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f1341:	41 89 47 38          	mov    %eax,0x38(%r15)
   f1345:	48 8b 04 24          	mov    (%rsp),%rax
   f1349:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f134d:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f1353:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f1358:	49 89 47 40          	mov    %rax,0x40(%r15)
   f135c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f1361:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f1366:	49 89 47 48          	mov    %rax,0x48(%r15)
   f136a:	48 89 d0             	mov    %rdx,%rax
   f136d:	48 c1 e8 1e          	shr    $0x1e,%rax
   f1371:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f1376:	48 31 d0             	xor    %rdx,%rax
   f1379:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f137e:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f1388:	48 0f af c2          	imul   %rdx,%rax
   f138c:	48 89 c2             	mov    %rax,%rdx
   f138f:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f1393:	48 31 d0             	xor    %rdx,%rax
   f1396:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f13a0:	48 0f af c2          	imul   %rdx,%rax
   f13a4:	48 89 c2             	mov    %rax,%rdx
   f13a7:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f13ab:	48 31 d0             	xor    %rdx,%rax
   f13ae:	48 01 44 24 10       	add    %rax,0x10(%rsp)
   f13b3:	45 84 f6             	test   %r14b,%r14b
   f13b6:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   f13bb:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f13c3:	49 89 77 50          	mov    %rsi,0x50(%r15)
   f13c7:	44 0f 44 f0          	cmove  %eax,%r14d
   f13cb:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f13d3:	49 83 c5 01          	add    $0x1,%r13
   f13d7:	48 8b 10             	mov    (%rax),%rdx
   f13da:	45 88 77 68          	mov    %r14b,0x68(%r15)
   f13de:	48 8b 40 08          	mov    0x8(%rax),%rax
   f13e2:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   f13e7:	48 29 d0             	sub    %rdx,%rax
   f13ea:	48 c1 f8 03          	sar    $0x3,%rax
   f13ee:	48 0f af c1          	imul   %rcx,%rax
   f13f2:	49 39 c5             	cmp    %rax,%r13
   f13f5:	0f 82 75 f7 ff ff    	jb     f0b70 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f13fb:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   f1403:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f140b:	80 3d 66 1e 08 00 00 	cmpb   $0x0,0x81e66(%rip)        # 173278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1412:	0f 84 21 05 00 00    	je     f1939 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xef9>
   f1418:	0f 31                	rdtsc
   f141a:	48 c1 e2 20          	shl    $0x20,%rdx
   f141e:	48 09 d0             	or     %rdx,%rax
   f1421:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f1429:	0f 88 d2 04 00 00    	js     f1901 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xec1>
   f142f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1433:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f1438:	f2 0f 59 05 f0 1d 08 00 	mulsd  0x81df0(%rip),%xmm0        # 173230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f1440:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1445:	49 89 07             	mov    %rax,(%r15)
   f1448:	e8 73 1c 06 00       	call   1530c0 <_ZN5bench6memory11allocationsEv>
   f144d:	4c 29 f0             	sub    %r14,%rax
   f1450:	49 89 47 58          	mov    %rax,0x58(%r15)
   f1454:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f145c:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f1465:	0f 85 f2 04 00 00    	jne    f195d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf1d>
   f146b:	4c 89 f8             	mov    %r15,%rax
   f146e:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f1476:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f147e:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f1486:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f148e:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f1496:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f149d:	c3                   	ret
   f149e:	66 90                	xchg   %ax,%ax
   f14a0:	80 3d d1 1d 08 00 00 	cmpb   $0x0,0x81dd1(%rip)        # 173278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f14a7:	0f 84 db 03 00 00    	je     f1888 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe48>
   f14ad:	0f 31                	rdtsc
   f14af:	48 c1 e2 20          	shl    $0x20,%rdx
   f14b3:	48 09 d0             	or     %rdx,%rax
   f14b6:	48 89 c5             	mov    %rax,%rbp
   f14b9:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f14be:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f14c6:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f14ce:	48 89 de             	mov    %rbx,%rsi
   f14d1:	e8 ea ee ff ff       	call   f03c0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f14d6:	f2 0f 10 0d 52 1d 08 00 	movsd  0x81d52(%rip),%xmm1        # 173230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f14de:	48 89 e8             	mov    %rbp,%rax
   f14e1:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f14e9:	0f 88 61 03 00 00    	js     f1850 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe10>
   f14ef:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f14f3:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f14f8:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f14fc:	80 3d 75 1d 08 00 00 	cmpb   $0x0,0x81d75(%rip)        # 173278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f1503:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1508:	49 89 47 08          	mov    %rax,0x8(%r15)
   f150c:	0f 84 5e 03 00 00    	je     f1870 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe30>
   f1512:	0f 31                	rdtsc
   f1514:	48 c1 e2 20          	shl    $0x20,%rdx
   f1518:	48 09 d0             	or     %rdx,%rax
   f151b:	48 29 e8             	sub    %rbp,%rax
   f151e:	0f 88 0c 03 00 00    	js     f1830 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdf0>
   f1524:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1528:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f152d:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f1531:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f1536:	49 89 47 10          	mov    %rax,0x10(%r15)
   f153a:	e9 9b fd ff ff       	jmp    f12da <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x89a>
   f153f:	90                   	nop
   f1540:	48 8b b3 80 02 00 00 	mov    0x280(%rbx),%rsi
   f1547:	4d 89 e3             	mov    %r12,%r11
   f154a:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   f1554:	49 29 c3             	sub    %rax,%r11
   f1557:	48 89 f7             	mov    %rsi,%rdi
   f155a:	48 29 d7             	sub    %rdx,%rdi
   f155d:	48 c1 ff 03          	sar    $0x3,%rdi
   f1561:	49 0f af f9          	imul   %r9,%rdi
   f1565:	4c 39 df             	cmp    %r11,%rdi
   f1568:	0f 82 42 01 00 00    	jb     f16b0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc70>
   f156e:	4c 89 d9             	mov    %r11,%rcx
   f1571:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1575:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f1579:	48 89 d0             	mov    %rdx,%rax
   f157c:	0f 1f 40 00          	nopl   0x0(%rax)
   f1580:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f1584:	48 83 c0 38          	add    $0x38,%rax
   f1588:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f158c:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f1590:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f1594:	48 83 e9 01          	sub    $0x1,%rcx
   f1598:	75 e6                	jne    f1580 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb40>
   f159a:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f159e:	4c 01 da             	add    %r11,%rdx
   f15a1:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   f15a8:	e9 19 fc ff ff       	jmp    f11c6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   f15ad:	0f 1f 00             	nopl   (%rax)
   f15b0:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f15b4:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f15bc:	48 8d bb 88 01 00 00 	lea    0x188(%rbx),%rdi
   f15c3:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   f15cb:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f15d3:	e8 a8 52 02 00       	call   116880 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f15d8:	84 c0                	test   %al,%al
   f15da:	0f 85 8a 03 00 00    	jne    f196a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf2a>
   f15e0:	4c 89 a3 c0 02 00 00 	mov    %r12,0x2c0(%rbx)
   f15e7:	e9 8d fb ff ff       	jmp    f1179 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x739>
   f15ec:	0f 1f 40 00          	nopl   0x0(%rax)
   f15f0:	c6 83 80 01 00 00 00 	movb   $0x0,0x180(%rbx)
   f15f7:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   f15fb:	e8 00 02 01 00       	call   101800 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f1600:	e9 69 f9 ff ff       	jmp    f0f6e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x52e>
   f1605:	0f 1f 00             	nopl   (%rax)
   f1608:	48 83 bb c8 00 00 00 00 	cmpq   $0x0,0xc8(%rbx)
   f1610:	74 55                	je     f1667 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc27>
   f1612:	48 8b 93 80 00 00 00 	mov    0x80(%rbx),%rdx
   f1619:	48 85 d2             	test   %rdx,%rdx
   f161c:	0f 85 73 02 00 00    	jne    f1895 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe55>
   f1622:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f1627:	66 0f 6f 05 51 b2 06 00 	movdqa 0x6b251(%rip),%xmm0        # 15c880 <C.66.5+0x260>
   f162f:	c7 83 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%rbx)
   f1639:	48 c7 83 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%rbx)
   f1644:	48 89 83 64 01 00 00 	mov    %rax,0x164(%rbx)
   f164b:	48 c7 83 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rbx)
   f1656:	c7 83 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%rbx)
   f1660:	0f 11 83 dc 00 00 00 	movups %xmm0,0xdc(%rbx)
   f1667:	80 7b 08 00          	cmpb   $0x0,0x8(%rbx)
   f166b:	0f 84 3d fc ff ff    	je     f12ae <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x86e>
   f1671:	80 bb 60 01 00 00 00 	cmpb   $0x0,0x160(%rbx)
   f1678:	0f 84 30 fc ff ff    	je     f12ae <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x86e>
   f167e:	c6 83 60 01 00 00 00 	movb   $0x0,0x160(%rbx)
   f1685:	e9 24 fc ff ff       	jmp    f12ae <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x86e>
   f168a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1690:	ba 10 00 00 00       	mov    $0x10,%edx
   f1695:	48 8b 3d c4 1b 08 00 	mov    0x81bc4(%rip),%rdi        # 173260 <stderr@GLIBC_2.2.5>
   f169c:	48 8d 35 fd 92 06 00 	lea    0x692fd(%rip),%rsi        # 15a9a0 <_IO_stdin_used+0x19a0>
   f16a3:	31 c0                	xor    %eax,%eax
   f16a5:	e8 96 5c f1 ff       	call   7340 <fprintf@plt>
   f16aa:	e8 71 5a f1 ff       	call   7120 <abort@plt>
   f16af:	90                   	nop
   f16b0:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f16ba:	48 29 c7             	sub    %rax,%rdi
   f16bd:	4c 39 df             	cmp    %r11,%rdi
   f16c0:	0f 82 a0 b6 f1 ff    	jb     cd66 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f16c6:	4c 39 d8             	cmp    %r11,%rax
   f16c9:	4c 89 df             	mov    %r11,%rdi
   f16cc:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f16d4:	48 0f 43 f8          	cmovae %rax,%rdi
   f16d8:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   f16e0:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f16e8:	48 01 c7             	add    %rax,%rdi
   f16eb:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   f16f0:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f16fa:	48 39 c7             	cmp    %rax,%rdi
   f16fd:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f1702:	48 0f 47 f8          	cmova  %rax,%rdi
   f1706:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   f170a:	48 89 c7             	mov    %rax,%rdi
   f170d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f1712:	e8 69 1b 06 00       	call   153280 <_Znwm>
   f1717:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f171d:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   f1725:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f1729:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   f172e:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f1736:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f173a:	48 01 c1             	add    %rax,%rcx
   f173d:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f1745:	49 01 cb             	add    %rcx,%r11
   f1748:	66 90                	xchg   %ax,%ax
   f174a:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1755:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1760:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   f1764:	48 83 c1 38          	add    $0x38,%rcx
   f1768:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f176c:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f1770:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   f1774:	4c 39 d9             	cmp    %r11,%rcx
   f1777:	75 e7                	jne    f1760 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd20>
   f1779:	4c 39 d2             	cmp    %r10,%rdx
   f177c:	74 71                	je     f17ef <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdaf>
   f177e:	4c 89 d1             	mov    %r10,%rcx
   f1781:	48 89 c7             	mov    %rax,%rdi
   f1784:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f1789:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f1794:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f179f:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f17aa:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f17b5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f17c0:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   f17c4:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   f17c8:	48 83 c1 38          	add    $0x38,%rcx
   f17cc:	48 83 c7 38          	add    $0x38,%rdi
   f17d0:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f17d4:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   f17d9:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   f17dd:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f17e1:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   f17e6:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f17ea:	48 39 ca             	cmp    %rcx,%rdx
   f17ed:	75 d1                	jne    f17c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f17ef:	4d 85 d2             	test   %r10,%r10
   f17f2:	74 15                	je     f1809 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdc9>
   f17f4:	4c 29 d6             	sub    %r10,%rsi
   f17f7:	4c 89 d7             	mov    %r10,%rdi
   f17fa:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f17ff:	e8 fc 1b 06 00       	call   153400 <_ZdlPvm>
   f1804:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f1809:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   f180d:	48 89 83 70 02 00 00 	mov    %rax,0x270(%rbx)
   f1814:	48 01 c2             	add    %rax,%rdx
   f1817:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f181c:	48 89 93 78 02 00 00 	mov    %rdx,0x278(%rbx)
   f1823:	48 89 83 80 02 00 00 	mov    %rax,0x280(%rbx)
   f182a:	e9 97 f9 ff ff       	jmp    f11c6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x786>
   f182f:	90                   	nop
   f1830:	48 89 c2             	mov    %rax,%rdx
   f1833:	83 e0 01             	and    $0x1,%eax
   f1836:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f183a:	48 d1 ea             	shr    $1,%rdx
   f183d:	48 09 c2             	or     %rax,%rdx
   f1840:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1845:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1849:	e9 df fc ff ff       	jmp    f152d <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaed>
   f184e:	66 90                	xchg   %ax,%ax
   f1850:	48 89 c2             	mov    %rax,%rdx
   f1853:	83 e0 01             	and    $0x1,%eax
   f1856:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f185a:	48 d1 ea             	shr    $1,%rdx
   f185d:	48 09 c2             	or     %rax,%rdx
   f1860:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1865:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f1869:	e9 8a fc ff ff       	jmp    f14f8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab8>
   f186e:	66 90                	xchg   %ax,%ax
   f1870:	e8 5b 5a f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f1875:	f2 0f 10 0d b3 19 08 00 	movsd  0x819b3(%rip),%xmm1        # 173230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f187d:	e9 99 fc ff ff       	jmp    f151b <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xadb>
   f1882:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f1888:	e8 43 5a f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f188d:	48 89 c5             	mov    %rax,%rbp
   f1890:	e9 24 fc ff ff       	jmp    f14b9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa79>
   f1895:	48 c7 83 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%rbx)
   f18a0:	80 bb 94 00 00 00 00 	cmpb   $0x0,0x94(%rbx)
   f18a7:	0f 85 96 00 00 00    	jne    f1943 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf03>
   f18ad:	8b 83 90 00 00 00    	mov    0x90(%rbx),%eax
   f18b3:	83 c0 01             	add    $0x1,%eax
   f18b6:	89 83 90 00 00 00    	mov    %eax,0x90(%rbx)
   f18bc:	83 f8 ff             	cmp    $0xffffffff,%eax
   f18bf:	0f 85 5d fd ff ff    	jne    f1622 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbe2>
   f18c5:	48 8b 43 78          	mov    0x78(%rbx),%rax
   f18c9:	48 89 d1             	mov    %rdx,%rcx
   f18cc:	48 c1 e1 04          	shl    $0x4,%rcx
   f18d0:	48 01 c1             	add    %rax,%rcx
   f18d3:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f18da:	48 83 c0 10          	add    $0x10,%rax
   f18de:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f18e6:	48 39 c8             	cmp    %rcx,%rax
   f18e9:	75 e8                	jne    f18d3 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe93>
   f18eb:	48 01 93 b0 00 00 00 	add    %rdx,0xb0(%rbx)
   f18f2:	c7 83 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%rbx)
   f18fc:	e9 21 fd ff ff       	jmp    f1622 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbe2>
   f1901:	48 89 c2             	mov    %rax,%rdx
   f1904:	83 e0 01             	and    $0x1,%eax
   f1907:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f190b:	48 d1 ea             	shr    $1,%rdx
   f190e:	48 09 c2             	or     %rax,%rdx
   f1911:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f1916:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f191a:	e9 19 fb ff ff       	jmp    f1438 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9f8>
   f191f:	4c 89 1c 24          	mov    %r11,(%rsp)
   f1923:	e8 d8 03 f2 ff       	call   11d00 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f1928:	4c 8b 1c 24          	mov    (%rsp),%r11
   f192c:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f1934:	e9 b6 f1 ff ff       	jmp    f0aef <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaf>
   f1939:	e8 c2 03 f2 ff       	call   11d00 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f193e:	e9 de fa ff ff       	jmp    f1421 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x9e1>
   f1943:	48 c7 83 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rbx)
   f194e:	c7 83 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%rbx)
   f1958:	e9 c5 fc ff ff       	jmp    f1622 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbe2>
   f195d:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f1965:	e8 f6 58 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f196a:	0f b6 d0             	movzbl %al,%edx
   f196d:	e9 23 fd ff ff       	jmp    f1695 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb0EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc55>

# control ordered_step (anonymous namespace)::Runner<bench::LibraryIndex<int, true>, int>::step((anonymous namespace)::Fixture<int> const&, bench::Boundary, unsigned long)

/home/dima/.cache/quadtree-g1-combined.ARqsxS/control-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f4940 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm>:
   f4940:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
   f4947:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f494b:	48 89 ac 24 b0 04 00 00 	mov    %rbp,0x4b0(%rsp)
   f4953:	48 8b 2a             	mov    (%rdx),%rbp
   f4956:	4c 89 a4 24 b8 04 00 00 	mov    %r12,0x4b8(%rsp)
   f495e:	4c 8b 62 08          	mov    0x8(%rdx),%r12
   f4962:	4c 89 b4 24 c8 04 00 00 	mov    %r14,0x4c8(%rsp)
   f496a:	4c 89 bc 24 d0 04 00 00 	mov    %r15,0x4d0(%rsp)
   f4972:	49 89 ff             	mov    %rdi,%r15
   f4975:	48 89 9c 24 a8 04 00 00 	mov    %rbx,0x4a8(%rsp)
   f497d:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   f4984:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
   f4989:	64 48 8b 1c 25 28 00 00 00 	mov    %fs:0x28,%rbx
   f4992:	48 89 9c 24 98 04 00 00 	mov    %rbx,0x498(%rsp)
   f499a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   f499e:	0f 11 07             	movups %xmm0,(%rdi)
   f49a1:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
   f49a5:	0f 11 47 20          	movups %xmm0,0x20(%rdi)
   f49a9:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
   f49ad:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
   f49b1:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
   f49b5:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
   f49b9:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   f49bd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   f49c2:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
   f49c6:	e8 f5 e6 05 00       	call   1530c0 <_ZN5bench6memory11allocationsEv>
   f49cb:	80 3d a6 e8 07 00 00 	cmpb   $0x0,0x7e8a6(%rip)        # 173278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f49d2:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f49d7:	49 89 c6             	mov    %rax,%r14
   f49da:	0f 84 83 0e 00 00    	je     f5863 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf23>
   f49e0:	0f 31                	rdtsc
   f49e2:	48 c1 e2 20          	shl    $0x20,%rdx
   f49e6:	48 09 d0             	or     %rdx,%rax
   f49e9:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f49f1:	49 8b 11             	mov    (%r9),%rdx
   f49f4:	49 3b 51 08          	cmp    0x8(%r9),%rdx
   f49f8:	0f 84 4b 09 00 00    	je     f5349 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa09>
   f49fe:	49 29 ec             	sub    %rbp,%r12
   f4a01:	c6 44 24 77 00       	movb   $0x0,0x77(%rsp)
   f4a06:	83 bc 24 90 00 00 00 01 	cmpl   $0x1,0x90(%rsp)
   f4a0e:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f4a12:	4c 89 a4 24 80 00 00 00 	mov    %r12,0x80(%rsp)
   f4a1a:	48 c7 44 24 18 00 00 00 00 	movq   $0x0,0x18(%rsp)
   f4a23:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f4a2c:	48 c7 44 24 08 00 00 00 00 	movq   $0x0,0x8(%rsp)
   f4a35:	c7 44 24 70 00 00 00 00 	movl   $0x0,0x70(%rsp)
   f4a3d:	4c 89 8c 24 88 00 00 00 	mov    %r9,0x88(%rsp)
   f4a45:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f4a4d:	4c 89 b4 24 b8 00 00 00 	mov    %r14,0xb8(%rsp)
   f4a55:	49 89 de             	mov    %rbx,%r14
   f4a58:	0f 94 84 24 97 00 00 00 	sete   0x97(%rsp)
   f4a60:	45 31 ed             	xor    %r13d,%r13d
   f4a63:	0f 29 6c 24 20       	movaps %xmm5,0x20(%rsp)
   f4a68:	0f 29 6c 24 30       	movaps %xmm5,0x30(%rsp)
   f4a6d:	0f 1f 00             	nopl   (%rax)
   f4a70:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
   f4a75:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
   f4a79:	48 8b 28             	mov    (%rax),%rbp
   f4a7c:	48 8b 58 08          	mov    0x8(%rax),%rbx
   f4a80:	48 29 eb             	sub    %rbp,%rbx
   f4a83:	49 89 dc             	mov    %rbx,%r12
   f4a86:	49 c1 fc 04          	sar    $0x4,%r12
   f4a8a:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f4a92:	74 14                	je     f4aa8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x168>
   f4a94:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f4a9b:	41 3b 86 b8 02 00 00 	cmp    0x2b8(%r14),%eax
   f4aa2:	0f 84 cb 05 00 00    	je     f5073 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x733>
   f4aa8:	0f b6 84 24 97 00 00 00 	movzbl 0x97(%rsp),%eax
   f4ab0:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f4ab4:	31 f6                	xor    %esi,%esi
   f4ab6:	66 0f 6f 3d 02 7e 06 00 	movdqa 0x67e02(%rip),%xmm7        # 15c8c0 <C.66.5+0x2a0>
   f4abe:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f4ac6:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f4ace:	ba 88 01 00 00       	mov    $0x188,%edx
   f4ad3:	88 84 24 09 01 00 00 	mov    %al,0x109(%rsp)
   f4ada:	b8 fd ff ff ff       	mov    $0xfffffffd,%eax
   f4adf:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f4ae7:	0f 29 84 24 10 01 00 00 	movaps %xmm0,0x110(%rsp)
   f4aef:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f4af4:	0f 11 bc 24 0c 01 00 00 	movups %xmm7,0x10c(%rsp)
   f4afc:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   f4b00:	66 0f 6f 94 24 10 01 00 00 	movdqa 0x110(%rsp),%xmm2
   f4b09:	c6 84 24 f0 00 00 00 02 	movb   $0x2,0xf0(%rsp)
   f4b11:	66 0f 6f a4 24 f0 00 00 00 	movdqa 0xf0(%rsp),%xmm4
   f4b1a:	c6 84 24 08 01 00 00 01 	movb   $0x1,0x108(%rsp)
   f4b22:	66 0f 6f 9c 24 00 01 00 00 	movdqa 0x100(%rsp),%xmm3
   f4b2b:	0f 29 84 24 20 01 00 00 	movaps %xmm0,0x120(%rsp)
   f4b33:	0f 29 a4 24 40 01 00 00 	movaps %xmm4,0x140(%rsp)
   f4b3b:	0f 29 64 24 60       	movaps %xmm4,0x60(%rsp)
   f4b40:	0f 29 9c 24 50 01 00 00 	movaps %xmm3,0x150(%rsp)
   f4b48:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   f4b4d:	0f 29 94 24 60 01 00 00 	movaps %xmm2,0x160(%rsp)
   f4b55:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
   f4b5a:	0f 29 84 24 70 01 00 00 	movaps %xmm0,0x170(%rsp)
   f4b62:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f4b6e:	48 c7 84 24 80 01 00 00 00 00 00 00 	movq   $0x0,0x180(%rsp)
   f4b7a:	e8 91 25 f1 ff       	call   7110 <memset@plt>
   f4b7f:	66 0f 6f 64 24 60    	movdqa 0x60(%rsp),%xmm4
   f4b85:	66 0f ef c9          	pxor   %xmm1,%xmm1
   f4b89:	66 0f 6f 05 3f 7d 06 00 	movdqa 0x67d3f(%rip),%xmm0        # 15c8d0 <C.66.5+0x2b0>
   f4b91:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
   f4b97:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
   f4b9d:	66 0f ef ed          	pxor   %xmm5,%xmm5
   f4ba1:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f4ba8:	48 89 84 24 20 02 00 00 	mov    %rax,0x220(%rsp)
   f4bb0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f4bb5:	48 8d bc 24 90 01 00 00 	lea    0x190(%rsp),%rdi
   f4bbd:	48 89 84 24 68 02 00 00 	mov    %rax,0x268(%rsp)
   f4bc5:	0f 29 84 24 c0 01 00 00 	movaps %xmm0,0x1c0(%rsp)
   f4bcd:	48 c7 84 24 d0 01 00 00 00 00 00 00 	movq   $0x0,0x1d0(%rsp)
   f4bd9:	4c 89 b4 24 d8 01 00 00 	mov    %r14,0x1d8(%rsp)
   f4be1:	48 c7 84 24 e0 01 00 00 00 00 00 00 	movq   $0x0,0x1e0(%rsp)
   f4bed:	48 c7 84 24 e8 01 00 00 00 00 00 00 	movq   $0x0,0x1e8(%rsp)
   f4bf9:	48 c7 84 24 f0 01 00 00 00 00 00 00 	movq   $0x0,0x1f0(%rsp)
   f4c05:	48 c7 84 24 f8 01 00 00 00 00 00 00 	movq   $0x0,0x1f8(%rsp)
   f4c11:	48 c7 84 24 00 02 00 00 00 00 00 00 	movq   $0x0,0x200(%rsp)
   f4c1d:	c7 84 24 18 02 00 00 01 00 00 00 	movl   $0x1,0x218(%rsp)
   f4c28:	c6 84 24 1c 02 00 00 00 	movb   $0x0,0x21c(%rsp)
   f4c30:	c7 84 24 28 02 00 00 00 00 00 00 	movl   $0x0,0x228(%rsp)
   f4c3b:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f4c47:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f4c4f:	48 c7 84 24 50 02 00 00 00 00 00 00 	movq   $0x0,0x250(%rsp)
   f4c5b:	c7 84 24 70 02 00 00 00 00 00 00 	movl   $0x0,0x270(%rsp)
   f4c66:	c6 84 24 74 02 00 00 00 	movb   $0x0,0x274(%rsp)
   f4c6e:	4c 89 b4 24 78 02 00 00 	mov    %r14,0x278(%rsp)
   f4c76:	48 c7 84 24 80 02 00 00 00 00 00 00 	movq   $0x0,0x280(%rsp)
   f4c82:	48 c7 84 24 88 02 00 00 00 00 00 00 	movq   $0x0,0x288(%rsp)
   f4c8e:	4c 89 b4 24 90 02 00 00 	mov    %r14,0x290(%rsp)
   f4c96:	48 c7 84 24 98 02 00 00 00 00 00 00 	movq   $0x0,0x298(%rsp)
   f4ca2:	0f 29 a4 24 90 01 00 00 	movaps %xmm4,0x190(%rsp)
   f4caa:	0f 29 9c 24 a0 01 00 00 	movaps %xmm3,0x1a0(%rsp)
   f4cb2:	0f 29 94 24 b0 01 00 00 	movaps %xmm2,0x1b0(%rsp)
   f4cba:	0f 11 8c 24 08 02 00 00 	movups %xmm1,0x208(%rsp)
   f4cc2:	0f 11 ac 24 58 02 00 00 	movups %xmm5,0x258(%rsp)
   f4cca:	48 c7 84 24 a0 02 00 00 00 00 00 00 	movq   $0x0,0x2a0(%rsp)
   f4cd6:	0f 11 84 24 48 03 00 00 	movups %xmm0,0x348(%rsp)
   f4cde:	66 0f 6f 84 24 40 02 00 00 	movdqa 0x240(%rsp),%xmm0
   f4ce7:	0f 29 8c 24 d0 00 00 00 	movaps %xmm1,0xd0(%rsp)
   f4cef:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f4cf7:	f3 0f 6f 84 24 d9 00 00 00 	movdqu 0xd9(%rsp),%xmm0
   f4d00:	0f 11 8c 24 b8 03 00 00 	movups %xmm1,0x3b8(%rsp)
   f4d08:	0f 11 84 24 c1 03 00 00 	movups %xmm0,0x3c1(%rsp)
   f4d10:	f3 0f 6f 84 24 44 01 00 00 	movdqu 0x144(%rsp),%xmm0
   f4d19:	48 89 84 24 ec 02 00 00 	mov    %rax,0x2ec(%rsp)
   f4d21:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f4d28:	48 89 84 24 a8 03 00 00 	mov    %rax,0x3a8(%rsp)
   f4d30:	4c 89 b4 24 a8 02 00 00 	mov    %r14,0x2a8(%rsp)
   f4d38:	48 c7 84 24 b0 02 00 00 00 00 00 00 	movq   $0x0,0x2b0(%rsp)
   f4d44:	48 c7 84 24 b8 02 00 00 00 00 00 00 	movq   $0x0,0x2b8(%rsp)
   f4d50:	4c 89 b4 24 c0 02 00 00 	mov    %r14,0x2c0(%rsp)
   f4d58:	48 c7 84 24 c8 02 00 00 00 00 00 00 	movq   $0x0,0x2c8(%rsp)
   f4d64:	48 c7 84 24 d0 02 00 00 00 00 00 00 	movq   $0x0,0x2d0(%rsp)
   f4d70:	48 c7 84 24 f8 02 00 00 00 00 00 00 	movq   $0x0,0x2f8(%rsp)
   f4d7c:	c7 84 24 00 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x300(%rsp)
   f4d87:	48 c7 84 24 58 03 00 00 00 00 00 00 	movq   $0x0,0x358(%rsp)
   f4d93:	4c 89 b4 24 60 03 00 00 	mov    %r14,0x360(%rsp)
   f4d9b:	c7 84 24 a0 03 00 00 01 00 00 00 	movl   $0x1,0x3a0(%rsp)
   f4da6:	c7 84 24 f0 03 00 00 ff ff ff ff 	movl   $0xffffffff,0x3f0(%rsp)
   f4db1:	48 c7 84 24 40 02 00 00 00 00 00 00 	movq   $0x0,0x240(%rsp)
   f4dbd:	c6 84 24 48 02 00 00 00 	movb   $0x0,0x248(%rsp)
   f4dc5:	4c 89 b4 24 00 04 00 00 	mov    %r14,0x400(%rsp)
   f4dcd:	4c 89 b4 24 18 04 00 00 	mov    %r14,0x418(%rsp)
   f4dd5:	4c 89 b4 24 30 04 00 00 	mov    %r14,0x430(%rsp)
   f4ddd:	4c 89 b4 24 48 04 00 00 	mov    %r14,0x448(%rsp)
   f4de5:	0f 11 a4 24 18 03 00 00 	movups %xmm4,0x318(%rsp)
   f4ded:	0f 11 9c 24 28 03 00 00 	movups %xmm3,0x328(%rsp)
   f4df5:	0f 11 94 24 38 03 00 00 	movups %xmm2,0x338(%rsp)
   f4dfd:	0f 29 8c 24 30 02 00 00 	movaps %xmm1,0x230(%rsp)
   f4e05:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f4e0d:	8b 84 24 54 01 00 00 	mov    0x154(%rsp),%eax
   f4e14:	f3 0f 6f 84 24 94 01 00 00 	movdqu 0x194(%rsp),%xmm0
   f4e1d:	c7 84 24 74 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x474(%rsp)
   f4e28:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f4e2f:	8b 84 24 a4 01 00 00 	mov    0x1a4(%rsp),%eax
   f4e36:	c7 84 24 88 04 00 00 ff ff ff ff 	movl   $0xffffffff,0x488(%rsp)
   f4e41:	89 84 24 e8 02 00 00 	mov    %eax,0x2e8(%rsp)
   f4e48:	0f 11 84 24 d8 02 00 00 	movups %xmm0,0x2d8(%rsp)
   f4e50:	e8 ab c9 00 00       	call   101800 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f4e55:	41 80 be 80 01 00 00 00 	cmpb   $0x0,0x180(%r14)
   f4e5d:	0f 85 f5 06 00 00    	jne    f5558 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc18>
   f4e63:	f3 0f 6f 84 24 18 03 00 00 	movdqu 0x318(%rsp),%xmm0
   f4e6c:	48 8b 84 24 58 03 00 00 	mov    0x358(%rsp),%rax
   f4e74:	4d 89 76 50          	mov    %r14,0x50(%r14)
   f4e78:	48 8d bc 24 18 03 00 00 	lea    0x318(%rsp),%rdi
   f4e80:	f3 0f 6f 8c 24 c8 03 00 00 	movdqu 0x3c8(%rsp),%xmm1
   f4e89:	41 c6 86 ec 00 00 00 00 	movb   $0x0,0xec(%r14)
   f4e91:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   f4e96:	f3 0f 6f 84 24 28 03 00 00 	movdqu 0x328(%rsp),%xmm0
   f4e9f:	0f 29 8c 24 a0 01 00 00 	movaps %xmm1,0x1a0(%rsp)
   f4ea7:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
   f4eac:	f3 0f 6f 84 24 38 03 00 00 	movdqu 0x338(%rsp),%xmm0
   f4eb5:	49 89 46 48          	mov    %rax,0x48(%r14)
   f4eb9:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f4ec0:	41 0f 11 46 28       	movups %xmm0,0x28(%r14)
   f4ec5:	f3 0f 6f 84 24 48 03 00 00 	movdqu 0x348(%rsp),%xmm0
   f4ece:	49 89 86 98 00 00 00 	mov    %rax,0x98(%r14)
   f4ed5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f4eda:	41 0f 11 46 38       	movups %xmm0,0x38(%r14)
   f4edf:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f4ee3:	41 0f 11 86 80 00 00 00 	movups %xmm0,0x80(%r14)
   f4eeb:	f3 0f 6f 84 24 b8 03 00 00 	movdqu 0x3b8(%rsp),%xmm0
   f4ef4:	49 89 86 e0 00 00 00 	mov    %rax,0xe0(%r14)
   f4efb:	41 0f 11 86 a8 00 00 00 	movups %xmm0,0xa8(%r14)
   f4f03:	0f 29 84 24 90 01 00 00 	movaps %xmm0,0x190(%rsp)
   f4f0b:	f3 0f 6f 84 24 99 01 00 00 	movdqu 0x199(%rsp),%xmm0
   f4f14:	49 c7 46 58 00 00 00 00 	movq   $0x0,0x58(%r14)
   f4f1c:	41 0f 11 86 b1 00 00 00 	movups %xmm0,0xb1(%r14)
   f4f24:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f4f28:	41 0f 11 86 d0 00 00 00 	movups %xmm0,0xd0(%r14)
   f4f30:	49 c7 46 60 00 00 00 00 	movq   $0x0,0x60(%r14)
   f4f38:	49 c7 46 68 00 00 00 00 	movq   $0x0,0x68(%r14)
   f4f40:	49 c7 46 70 00 00 00 00 	movq   $0x0,0x70(%r14)
   f4f48:	49 c7 46 78 00 00 00 00 	movq   $0x0,0x78(%r14)
   f4f50:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f4f5b:	41 c6 86 94 00 00 00 00 	movb   $0x0,0x94(%r14)
   f4f63:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f4f6e:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f4f79:	41 c7 86 e8 00 00 00 00 00 00 00 	movl   $0x0,0xe8(%r14)
   f4f84:	8b 84 24 70 04 00 00 	mov    0x470(%rsp),%eax
   f4f8b:	66 0f 6f 84 24 60 04 00 00 	movdqa 0x460(%rsp),%xmm0
   f4f94:	4d 89 b6 f0 00 00 00 	mov    %r14,0xf0(%r14)
   f4f9b:	41 89 86 60 01 00 00 	mov    %eax,0x160(%r14)
   f4fa2:	8b 84 24 2c 03 00 00 	mov    0x32c(%rsp),%eax
   f4fa9:	49 c7 86 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%r14)
   f4fb4:	89 84 24 70 04 00 00 	mov    %eax,0x470(%rsp)
   f4fbb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f4fc0:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f4fc7:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   f4fce:	49 c7 86 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%r14)
   f4fd9:	4d 89 b6 08 01 00 00 	mov    %r14,0x108(%r14)
   f4fe0:	49 c7 86 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%r14)
   f4feb:	49 c7 86 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%r14)
   f4ff6:	4d 89 b6 20 01 00 00 	mov    %r14,0x120(%r14)
   f4ffd:	49 c7 86 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%r14)
   f5008:	49 c7 86 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%r14)
   f5013:	4d 89 b6 38 01 00 00 	mov    %r14,0x138(%r14)
   f501a:	49 c7 86 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%r14)
   f5025:	49 c7 86 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%r14)
   f5030:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f503b:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f5046:	41 c6 86 80 01 00 00 01 	movb   $0x1,0x180(%r14)
   f504e:	41 89 86 b8 02 00 00 	mov    %eax,0x2b8(%r14)
   f5055:	41 0f 11 86 50 01 00 00 	movups %xmm0,0x150(%r14)
   f505d:	f3 0f 6f 84 24 1c 03 00 00 	movdqu 0x31c(%rsp),%xmm0
   f5066:	0f 29 84 24 60 04 00 00 	movaps %xmm0,0x460(%rsp)
   f506e:	e8 8d c7 00 00       	call   101800 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f5073:	4d 39 a6 c0 02 00 00 	cmp    %r12,0x2c0(%r14)
   f507a:	0f 82 90 04 00 00    	jb     f5510 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xbd0>
   f5080:	49 8b 96 78 02 00 00 	mov    0x278(%r14),%rdx
   f5087:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f508e:	48 bf b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rdi
   f5098:	48 89 d1             	mov    %rdx,%rcx
   f509b:	4c 29 d1             	sub    %r10,%rcx
   f509e:	48 89 c8             	mov    %rcx,%rax
   f50a1:	48 c1 f8 03          	sar    $0x3,%rax
   f50a5:	48 0f af c7          	imul   %rdi,%rax
   f50a9:	4c 39 e0             	cmp    %r12,%rax
   f50ac:	0f 82 ee 03 00 00    	jb     f54a0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb60>
   f50b2:	49 39 c4             	cmp    %rax,%r12
   f50b5:	73 16                	jae    f50cd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f50b7:	49 6b c4 38          	imul   $0x38,%r12,%rax
   f50bb:	49 01 c2             	add    %rax,%r10
   f50be:	4c 39 d2             	cmp    %r10,%rdx
   f50c1:	74 07                	je     f50ca <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78a>
   f50c3:	4d 89 96 78 02 00 00 	mov    %r10,0x278(%r14)
   f50ca:	4c 89 d2             	mov    %r10,%rdx
   f50cd:	4d 8b 96 70 02 00 00 	mov    0x270(%r14),%r10
   f50d4:	48 85 db             	test   %rbx,%rbx
   f50d7:	0f 84 7c 00 00 00    	je     f5159 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x819>
   f50dd:	4c 89 d1             	mov    %r10,%rcx
   f50e0:	31 f6                	xor    %esi,%esi
   f50e2:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f50e6:	49 bb b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%r11
   f50f0:	48 bf eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdi
   f50fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f5100:	41 89 f0             	mov    %esi,%r8d
   f5103:	f3 0f 6f 45 00       	movdqu 0x0(%rbp),%xmm0
   f5108:	89 71 10             	mov    %esi,0x10(%rcx)
   f510b:	48 83 c6 01          	add    $0x1,%rsi
   f510f:	41 81 f0 6b 6e 61 72 	xor    $0x72616e6b,%r8d
   f5116:	c6 41 30 01          	movb   $0x1,0x30(%rcx)
   f511a:	48 83 c5 10          	add    $0x10,%rbp
   f511e:	48 83 c1 38          	add    $0x38,%rcx
   f5122:	4c 89 c0             	mov    %r8,%rax
   f5125:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f5129:	48 c1 e8 1e          	shr    $0x1e,%rax
   f512d:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f5131:	4c 31 c0             	xor    %r8,%rax
   f5134:	49 0f af c3          	imul   %r11,%rax
   f5138:	49 89 c0             	mov    %rax,%r8
   f513b:	49 c1 e8 1b          	shr    $0x1b,%r8
   f513f:	4c 31 c0             	xor    %r8,%rax
   f5142:	48 0f af c7          	imul   %rdi,%rax
   f5146:	49 89 c0             	mov    %rax,%r8
   f5149:	49 c1 e8 1f          	shr    $0x1f,%r8
   f514d:	4c 31 c0             	xor    %r8,%rax
   f5150:	48 89 41 f0          	mov    %rax,-0x10(%rcx)
   f5154:	4c 39 e6             	cmp    %r12,%rsi
   f5157:	72 a7                	jb     f5100 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x7c0>
   f5159:	48 c7 84 24 20 03 00 00 00 00 00 00 	movq   $0x0,0x320(%rsp)
   f5165:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5169:	0f 29 84 24 10 03 00 00 	movaps %xmm0,0x310(%rsp)
   f5171:	4c 39 d2             	cmp    %r10,%rdx
   f5174:	0f 84 f6 03 00 00    	je     f5570 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc30>
   f517a:	48 b8 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%rax
   f5184:	4c 29 d2             	sub    %r10,%rdx
   f5187:	48 c1 fa 03          	sar    $0x3,%rdx
   f518b:	48 0f af d0          	imul   %rax,%rdx
   f518f:	49 39 56 38          	cmp    %rdx,0x38(%r14)
   f5193:	0f 82 67 04 00 00    	jb     f5600 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc0>
   f5199:	48 83 ec 20          	sub    $0x20,%rsp
   f519d:	49 8d 8e 88 01 00 00 	lea    0x188(%r14),%rcx
   f51a4:	49 8d b6 70 02 00 00 	lea    0x270(%r14),%rsi
   f51ab:	66 0f 6f 84 24 30 03 00 00 	movdqa 0x330(%rsp),%xmm0
   f51b4:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f51b8:	48 c7 44 24 10 00 00 00 00 	movq   $0x0,0x10(%rsp)
   f51c1:	0f 11 04 24          	movups %xmm0,(%rsp)
   f51c5:	e8 b6 f8 fd ff       	call   d4a80 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EE13buildPreparedILb0ELb0ESt6vectorINS_10BuildEntryIjiNS_3BoxIiEEEESaIS8_EENS_6detail9AcceptAllEEENS_6StatusERT1_RT2_St8optionalISt4spanINS_6HandleINSB_10EntryStoreIijS1_S2_EEEELm18446744073709551615EEEmRNS_9WorkspaceIiEE.isra.0>
   f51ca:	48 83 c4 20          	add    $0x20,%rsp
   f51ce:	84 c0                	test   %al,%al
   f51d0:	0f 85 db 06 00 00    	jne    f58b1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf71>
   f51d6:	48 83 bc 24 80 00 00 00 18 	cmpq   $0x18,0x80(%rsp)
   f51df:	0f 84 fb 01 00 00    	je     f53e0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xaa0>
   f51e5:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f51ea:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f51ee:	4c 89 f6             	mov    %r14,%rsi
   f51f1:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f51f9:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f5201:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f5209:	e8 f2 ec ff ff       	call   f3f00 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f520e:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f5216:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f521e:	8b 7c 24 70          	mov    0x70(%rsp),%edi
   f5222:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
   f5229:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   f522d:	48 b9 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   f5237:	48 8b b4 24 38 03 00 00 	mov    0x338(%rsp),%rsi
   f523f:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
   f5245:	66 0f 6f 84 24 20 03 00 00 	movdqa 0x320(%rsp),%xmm0
   f524e:	39 c7                	cmp    %eax,%edi
   f5250:	66 0f 6f 94 24 10 03 00 00 	movdqa 0x310(%rsp),%xmm2
   f5259:	0f 43 c7             	cmovae %edi,%eax
   f525c:	48 01 74 24 08       	add    %rsi,0x8(%rsp)
   f5261:	4c 01 64 24 10       	add    %r12,0x10(%rsp)
   f5266:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   f526a:	89 44 24 70          	mov    %eax,0x70(%rsp)
   f526e:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   f5272:	66 0f 6d 84 24 10 03 00 00 	punpckhqdq 0x310(%rsp),%xmm0
   f527b:	41 89 47 38          	mov    %eax,0x38(%r15)
   f527f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   f5284:	66 0f d4 44 24 20    	paddq  0x20(%rsp),%xmm0
   f528a:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
   f528f:	49 89 47 40          	mov    %rax,0x40(%r15)
   f5293:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f5298:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   f529d:	49 89 47 48          	mov    %rax,0x48(%r15)
   f52a1:	48 89 d0             	mov    %rdx,%rax
   f52a4:	48 c1 e8 1e          	shr    $0x1e,%rax
   f52a8:	41 0f 11 77 18       	movups %xmm6,0x18(%r15)
   f52ad:	48 31 d0             	xor    %rdx,%rax
   f52b0:	41 0f 11 47 28       	movups %xmm0,0x28(%r15)
   f52b5:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f52bf:	48 0f af c2          	imul   %rdx,%rax
   f52c3:	48 89 c2             	mov    %rax,%rdx
   f52c6:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f52ca:	48 31 d0             	xor    %rdx,%rax
   f52cd:	48 ba eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rdx
   f52d7:	48 0f af c2          	imul   %rdx,%rax
   f52db:	48 89 c2             	mov    %rax,%rdx
   f52de:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f52e2:	48 31 d0             	xor    %rdx,%rax
   f52e5:	48 01 44 24 18       	add    %rax,0x18(%rsp)
   f52ea:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   f52ef:	0f b6 84 24 40 03 00 00 	movzbl 0x340(%rsp),%eax
   f52f7:	49 89 5f 50          	mov    %rbx,0x50(%r15)
   f52fb:	0f b6 5c 24 77       	movzbl 0x77(%rsp),%ebx
   f5300:	84 db                	test   %bl,%bl
   f5302:	0f 44 d8             	cmove  %eax,%ebx
   f5305:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f530d:	49 83 c5 01          	add    $0x1,%r13
   f5311:	48 8b 10             	mov    (%rax),%rdx
   f5314:	88 5c 24 77          	mov    %bl,0x77(%rsp)
   f5318:	41 88 5f 68          	mov    %bl,0x68(%r15)
   f531c:	48 8b 40 08          	mov    0x8(%rax),%rax
   f5320:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f5325:	48 29 d0             	sub    %rdx,%rax
   f5328:	48 c1 f8 03          	sar    $0x3,%rax
   f532c:	48 0f af c1          	imul   %rcx,%rax
   f5330:	49 39 c5             	cmp    %rax,%r13
   f5333:	0f 82 37 f7 ff ff    	jb     f4a70 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x130>
   f5339:	4c 8b b4 24 b8 00 00 00 	mov    0xb8(%rsp),%r14
   f5341:	4c 8b ac 24 c0 04 00 00 	mov    0x4c0(%rsp),%r13
   f5349:	80 3d 28 df 07 00 00 	cmpb   $0x0,0x7df28(%rip)        # 173278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f5350:	0f 84 29 05 00 00    	je     f587f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf3f>
   f5356:	0f 31                	rdtsc
   f5358:	48 c1 e2 20          	shl    $0x20,%rdx
   f535c:	48 09 d0             	or     %rdx,%rax
   f535f:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f5367:	0f 88 d8 04 00 00    	js     f5845 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf05>
   f536d:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5371:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f5376:	f2 0f 59 05 b2 de 07 00 	mulsd  0x7deb2(%rip),%xmm0        # 173230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f537e:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f5383:	49 89 07             	mov    %rax,(%r15)
   f5386:	e8 35 dd 05 00       	call   1530c0 <_ZN5bench6memory11allocationsEv>
   f538b:	4c 29 f0             	sub    %r14,%rax
   f538e:	49 89 47 58          	mov    %rax,0x58(%r15)
   f5392:	48 8b 84 24 98 04 00 00 	mov    0x498(%rsp),%rax
   f539a:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f53a3:	0f 85 fb 04 00 00    	jne    f58a4 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf64>
   f53a9:	4c 89 f8             	mov    %r15,%rax
   f53ac:	48 8b 9c 24 a8 04 00 00 	mov    0x4a8(%rsp),%rbx
   f53b4:	48 8b ac 24 b0 04 00 00 	mov    0x4b0(%rsp),%rbp
   f53bc:	4c 8b a4 24 b8 04 00 00 	mov    0x4b8(%rsp),%r12
   f53c4:	4c 8b b4 24 c8 04 00 00 	mov    0x4c8(%rsp),%r14
   f53cc:	4c 8b bc 24 d0 04 00 00 	mov    0x4d0(%rsp),%r15
   f53d4:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
   f53db:	c3                   	ret
   f53dc:	0f 1f 40 00          	nopl   0x0(%rax)
   f53e0:	80 3d 91 de 07 00 00 	cmpb   $0x0,0x7de91(%rip)        # 173278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f53e7:	0f 84 db 03 00 00    	je     f57c8 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe88>
   f53ed:	0f 31                	rdtsc
   f53ef:	48 c1 e2 20          	shl    $0x20,%rdx
   f53f3:	48 09 d0             	or     %rdx,%rax
   f53f6:	48 89 c5             	mov    %rax,%rbp
   f53f9:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   f53fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5402:	4c 89 f6             	mov    %r14,%rsi
   f5405:	48 8d bc 24 10 03 00 00 	lea    0x310(%rsp),%rdi
   f540d:	48 8d 94 24 c0 00 00 00 	lea    0xc0(%rsp),%rdx
   f5415:	0f 29 84 24 c0 00 00 00 	movaps %xmm0,0xc0(%rsp)
   f541d:	e8 de ea ff ff       	call   f3f00 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>
   f5422:	4c 8b a4 24 c0 00 00 00 	mov    0xc0(%rsp),%r12
   f542a:	48 8b 9c 24 c8 00 00 00 	mov    0xc8(%rsp),%rbx
   f5432:	48 89 e8             	mov    %rbp,%rax
   f5435:	f2 0f 10 0d f3 dd 07 00 	movsd  0x7ddf3(%rip),%xmm1        # 173230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f543d:	48 2b 84 24 98 00 00 00 	sub    0x98(%rsp),%rax
   f5445:	0f 88 45 03 00 00    	js     f5790 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe50>
   f544b:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f544f:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f5454:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f5458:	80 3d 19 de 07 00 00 	cmpb   $0x0,0x7de19(%rip)        # 173278 <_ZN12_GLOBAL__N_15timerL4gTscE>
   f545f:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f5464:	49 89 47 08          	mov    %rax,0x8(%r15)
   f5468:	0f 84 42 03 00 00    	je     f57b0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe70>
   f546e:	0f 31                	rdtsc
   f5470:	48 c1 e2 20          	shl    $0x20,%rdx
   f5474:	48 09 d0             	or     %rdx,%rax
   f5477:	48 29 e8             	sub    %rbp,%rax
   f547a:	0f 88 f0 02 00 00    	js     f5770 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe30>
   f5480:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5484:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
   f5489:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   f548d:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
   f5492:	49 89 47 10          	mov    %rax,0x10(%r15)
   f5496:	e9 83 fd ff ff       	jmp    f521e <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x8de>
   f549b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f54a0:	49 8b b6 80 02 00 00 	mov    0x280(%r14),%rsi
   f54a7:	4d 89 e3             	mov    %r12,%r11
   f54aa:	49 b9 b7 6d db b6 6d db b6 6d 	movabs $0x6db6db6db6db6db7,%r9
   f54b4:	49 29 c3             	sub    %rax,%r11
   f54b7:	48 89 f7             	mov    %rsi,%rdi
   f54ba:	48 29 d7             	sub    %rdx,%rdi
   f54bd:	48 c1 ff 03          	sar    $0x3,%rdi
   f54c1:	49 0f af f9          	imul   %r9,%rdi
   f54c5:	4c 39 df             	cmp    %r11,%rdi
   f54c8:	0f 82 52 01 00 00    	jb     f5620 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xce0>
   f54ce:	4c 89 d9             	mov    %r11,%rcx
   f54d1:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f54d5:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f54d9:	48 89 d0             	mov    %rdx,%rax
   f54dc:	0f 1f 40 00          	nopl   0x0(%rax)
   f54e0:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   f54e4:	48 83 c0 38          	add    $0x38,%rax
   f54e8:	0f 11 40 c8          	movups %xmm0,-0x38(%rax)
   f54ec:	0f 11 48 e0          	movups %xmm1,-0x20(%rax)
   f54f0:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
   f54f4:	48 83 e9 01          	sub    $0x1,%rcx
   f54f8:	75 e6                	jne    f54e0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xba0>
   f54fa:	4d 6b db 38          	imul   $0x38,%r11,%r11
   f54fe:	4c 01 da             	add    %r11,%rdx
   f5501:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f5508:	e9 c0 fb ff ff       	jmp    f50cd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f550d:	0f 1f 00             	nopl   (%rax)
   f5510:	48 8d b4 24 10 03 00 00 	lea    0x310(%rsp),%rsi
   f5518:	49 8d be 88 01 00 00 	lea    0x188(%r14),%rdi
   f551f:	4c 89 a4 24 10 03 00 00 	mov    %r12,0x310(%rsp)
   f5527:	48 c7 84 24 18 03 00 00 00 00 00 00 	movq   $0x0,0x318(%rsp)
   f5533:	4c 89 a4 24 20 03 00 00 	mov    %r12,0x320(%rsp)
   f553b:	e8 40 13 02 00       	call   116880 <_ZN8QuadTree9WorkspaceIiE7reserveERKNS_20WorkspaceReservationE>
   f5540:	84 c0                	test   %al,%al
   f5542:	0f 85 69 03 00 00    	jne    f58b1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf71>
   f5548:	4d 89 a6 c0 02 00 00 	mov    %r12,0x2c0(%r14)
   f554f:	e9 2c fb ff ff       	jmp    f5080 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x740>
   f5554:	0f 1f 40 00          	nopl   0x0(%rax)
   f5558:	41 c6 86 80 01 00 00 00 	movb   $0x0,0x180(%r14)
   f5560:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   f5564:	e8 97 c2 00 00       	call   101800 <_ZN8QuadTree5IndexIjiNS_9UncheckedELb1EED1Ev>
   f5569:	e9 f5 f8 ff ff       	jmp    f4e63 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x523>
   f556e:	66 90                	xchg   %ax,%ax
   f5570:	49 83 be c8 00 00 00 00 	cmpq   $0x0,0xc8(%r14)
   f5578:	74 58                	je     f55d2 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc92>
   f557a:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
   f5581:	48 85 d2             	test   %rdx,%rdx
   f5584:	0f 85 4b 02 00 00    	jne    f57d5 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe95>
   f558a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   f558f:	66 0f 6f 05 e9 72 06 00 	movdqa 0x672e9(%rip),%xmm0        # 15c880 <C.66.5+0x260>
   f5597:	41 c7 86 d0 00 00 00 00 00 00 00 	movl   $0x0,0xd0(%r14)
   f55a2:	49 c7 86 c8 00 00 00 00 00 00 00 	movq   $0x0,0xc8(%r14)
   f55ad:	49 89 86 64 01 00 00 	mov    %rax,0x164(%r14)
   f55b4:	49 c7 86 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%r14)
   f55bf:	41 c7 86 78 01 00 00 ff ff ff ff 	movl   $0xffffffff,0x178(%r14)
   f55ca:	41 0f 11 86 dc 00 00 00 	movups %xmm0,0xdc(%r14)
   f55d2:	41 80 7e 08 00       	cmpb   $0x0,0x8(%r14)
   f55d7:	0f 84 f9 fb ff ff    	je     f51d6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f55dd:	41 80 be 60 01 00 00 00 	cmpb   $0x0,0x160(%r14)
   f55e5:	0f 84 eb fb ff ff    	je     f51d6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f55eb:	41 c6 86 60 01 00 00 00 	movb   $0x0,0x160(%r14)
   f55f3:	e9 de fb ff ff       	jmp    f51d6 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x896>
   f55f8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f5600:	ba 10 00 00 00       	mov    $0x10,%edx
   f5605:	48 8b 3d 54 dc 07 00 	mov    0x7dc54(%rip),%rdi        # 173260 <stderr@GLIBC_2.2.5>
   f560c:	48 8d 35 8d 53 06 00 	lea    0x6538d(%rip),%rsi        # 15a9a0 <_IO_stdin_used+0x19a0>
   f5613:	31 c0                	xor    %eax,%eax
   f5615:	e8 26 1d f1 ff       	call   7340 <fprintf@plt>
   f561a:	e8 01 1b f1 ff       	call   7120 <abort@plt>
   f561f:	90                   	nop
   f5620:	48 bf 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rdi
   f562a:	48 29 c7             	sub    %rax,%rdi
   f562d:	4c 39 df             	cmp    %r11,%rdi
   f5630:	0f 82 30 78 f1 ff    	jb     ce66 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm.cold>
   f5636:	4c 39 d8             	cmp    %r11,%rax
   f5639:	4c 89 df             	mov    %r11,%rdi
   f563c:	48 89 b4 24 b0 00 00 00 	mov    %rsi,0xb0(%rsp)
   f5644:	48 0f 43 f8          	cmovae %rax,%rdi
   f5648:	48 89 8c 24 a8 00 00 00 	mov    %rcx,0xa8(%rsp)
   f5650:	4c 89 94 24 a0 00 00 00 	mov    %r10,0xa0(%rsp)
   f5658:	48 01 c7             	add    %rax,%rdi
   f565b:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   f5660:	48 b8 49 92 24 49 92 24 49 02 	movabs $0x249249249249249,%rax
   f566a:	48 39 c7             	cmp    %rax,%rdi
   f566d:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
   f5672:	48 0f 47 f8          	cmova  %rax,%rdi
   f5676:	48 6b c7 38          	imul   $0x38,%rdi,%rax
   f567a:	48 89 c7             	mov    %rax,%rdi
   f567d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   f5682:	e8 f9 db 05 00       	call   153280 <_Znwm>
   f5687:	4c 6b 5c 24 50 38    	imul   $0x38,0x50(%rsp),%r11
   f568d:	48 8b 8c 24 a8 00 00 00 	mov    0xa8(%rsp),%rcx
   f5695:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f5699:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   f569e:	4c 8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%r10
   f56a6:	66 0f 76 c9          	pcmpeqd %xmm1,%xmm1
   f56aa:	48 01 c1             	add    %rax,%rcx
   f56ad:	48 8b b4 24 b0 00 00 00 	mov    0xb0(%rsp),%rsi
   f56b5:	49 01 cb             	add    %rcx,%r11
   f56b8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f56c0:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   f56c4:	48 83 c1 38          	add    $0x38,%rcx
   f56c8:	0f 11 41 c8          	movups %xmm0,-0x38(%rcx)
   f56cc:	0f 11 49 e0          	movups %xmm1,-0x20(%rcx)
   f56d0:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   f56d4:	4c 39 d9             	cmp    %r11,%rcx
   f56d7:	75 e7                	jne    f56c0 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xd80>
   f56d9:	4c 39 d2             	cmp    %r10,%rdx
   f56dc:	74 51                	je     f572f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdef>
   f56de:	4c 89 d1             	mov    %r10,%rcx
   f56e1:	48 89 c7             	mov    %rax,%rdi
   f56e4:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f56ea:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f56f5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f5700:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   f5704:	4c 8b 41 30          	mov    0x30(%rcx),%r8
   f5708:	48 83 c1 38          	add    $0x38,%rcx
   f570c:	48 83 c7 38          	add    $0x38,%rdi
   f5710:	0f 11 47 c8          	movups %xmm0,-0x38(%rdi)
   f5714:	f3 0f 6f 41 d8       	movdqu -0x28(%rcx),%xmm0
   f5719:	4c 89 47 f8          	mov    %r8,-0x8(%rdi)
   f571d:	0f 11 47 d8          	movups %xmm0,-0x28(%rdi)
   f5721:	f3 0f 6f 41 e8       	movdqu -0x18(%rcx),%xmm0
   f5726:	0f 11 47 e8          	movups %xmm0,-0x18(%rdi)
   f572a:	48 39 ca             	cmp    %rcx,%rdx
   f572d:	75 d1                	jne    f5700 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xdc0>
   f572f:	4d 85 d2             	test   %r10,%r10
   f5732:	74 15                	je     f5749 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xe09>
   f5734:	4c 29 d6             	sub    %r10,%rsi
   f5737:	4c 89 d7             	mov    %r10,%rdi
   f573a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   f573f:	e8 bc dc 05 00       	call   153400 <_ZdlPvm>
   f5744:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   f5749:	49 6b d4 38          	imul   $0x38,%r12,%rdx
   f574d:	49 89 86 70 02 00 00 	mov    %rax,0x270(%r14)
   f5754:	48 01 c2             	add    %rax,%rdx
   f5757:	48 03 44 24 40       	add    0x40(%rsp),%rax
   f575c:	49 89 96 78 02 00 00 	mov    %rdx,0x278(%r14)
   f5763:	49 89 86 80 02 00 00 	mov    %rax,0x280(%r14)
   f576a:	e9 5e f9 ff ff       	jmp    f50cd <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0x78d>
   f576f:	90                   	nop
   f5770:	48 89 c2             	mov    %rax,%rdx
   f5773:	83 e0 01             	and    $0x1,%eax
   f5776:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f577a:	48 d1 ea             	shr    $1,%rdx
   f577d:	48 09 c2             	or     %rax,%rdx
   f5780:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f5785:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f5789:	e9 fb fc ff ff       	jmp    f5489 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb49>
   f578e:	66 90                	xchg   %ax,%ax
   f5790:	48 89 c2             	mov    %rax,%rdx
   f5793:	83 e0 01             	and    $0x1,%eax
   f5796:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f579a:	48 d1 ea             	shr    $1,%rdx
   f579d:	48 09 c2             	or     %rax,%rdx
   f57a0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f57a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f57a9:	e9 a6 fc ff ff       	jmp    f5454 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb14>
   f57ae:	66 90                	xchg   %ax,%ax
   f57b0:	e8 1b 1b f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f57b5:	f2 0f 10 0d 73 da 07 00 	movsd  0x7da73(%rip),%xmm1        # 173230 <_ZN12_GLOBAL__N_15timerL10gNsPerTickE>
   f57bd:	e9 b5 fc ff ff       	jmp    f5477 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb37>
   f57c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f57c8:	e8 03 1b f1 ff       	call   72d0 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
   f57cd:	48 89 c5             	mov    %rax,%rbp
   f57d0:	e9 24 fc ff ff       	jmp    f53f9 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xab9>
   f57d5:	49 c7 86 88 00 00 00 00 00 00 00 	movq   $0x0,0x88(%r14)
   f57e0:	41 80 be 94 00 00 00 00 	cmpb   $0x0,0x94(%r14)
   f57e8:	0f 85 9b 00 00 00    	jne    f5889 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xf49>
   f57ee:	41 8b 86 90 00 00 00 	mov    0x90(%r14),%eax
   f57f5:	83 c0 01             	add    $0x1,%eax
   f57f8:	41 89 86 90 00 00 00 	mov    %eax,0x90(%r14)
   f57ff:	83 f8 ff             	cmp    $0xffffffff,%eax
   f5802:	0f 85 82 fd ff ff    	jne    f558a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f5808:	49 8b 46 78          	mov    0x78(%r14),%rax
   f580c:	48 89 d1             	mov    %rdx,%rcx
   f580f:	48 c1 e1 04          	shl    $0x4,%rcx
   f5813:	48 01 c1             	add    %rax,%rcx
   f5816:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   f581d:	48 83 c0 10          	add    $0x10,%rax
   f5821:	48 c7 40 f8 00 00 00 00 	movq   $0x0,-0x8(%rax)
   f5829:	48 39 c8             	cmp    %rcx,%rax
   f582c:	75 e8                	jne    f5816 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xed6>
   f582e:	49 01 96 b0 00 00 00 	add    %rdx,0xb0(%r14)
   f5835:	41 c7 86 90 00 00 00 01 00 00 00 	movl   $0x1,0x90(%r14)
   f5840:	e9 45 fd ff ff       	jmp    f558a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f5845:	48 89 c2             	mov    %rax,%rdx
   f5848:	83 e0 01             	and    $0x1,%eax
   f584b:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f584f:	48 d1 ea             	shr    $1,%rdx
   f5852:	48 09 c2             	or     %rax,%rdx
   f5855:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
   f585a:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   f585e:	e9 13 fb ff ff       	jmp    f5376 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa36>
   f5863:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
   f5868:	e8 93 c4 f1 ff       	call   11d00 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f586d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   f5872:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f587a:	e9 72 f1 ff ff       	jmp    f49f1 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xb1>
   f587f:	e8 7c c4 f1 ff       	call   11d00 <_ZN12_GLOBAL__N_15timerL3nowEv.part.0>
   f5884:	e9 d6 fa ff ff       	jmp    f535f <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xa1f>
   f5889:	49 c7 86 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%r14)
   f5894:	41 c7 86 a0 00 00 00 00 00 00 00 	movl   $0x0,0xa0(%r14)
   f589f:	e9 e6 fc ff ff       	jmp    f558a <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xc4a>
   f58a4:	4c 89 ac 24 c0 04 00 00 	mov    %r13,0x4c0(%rsp)
   f58ac:	e8 af 19 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f58b1:	0f b6 d0             	movzbl %al,%edx
   f58b4:	e9 4c fd ff ff       	jmp    f5605 <_ZN12_GLOBAL__N_16RunnerIN5bench12LibraryIndexIiLb1EEEiE4stepERKNS_7FixtureIiEENS1_8BoundaryEm+0xcc5>

# control unordered_pairs bench::Counters bench::LibraryIndex<int, false>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-combined.ARqsxS/control-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f03c0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f03c0:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
   f03c7:	44 8b 8e d0 00 00 00 	mov    0xd0(%rsi),%r9d
   f03ce:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f03d2:	48 89 9c 24 38 01 00 00 	mov    %rbx,0x138(%rsp)
   f03da:	48 89 fb             	mov    %rdi,%rbx
   f03dd:	48 89 ac 24 40 01 00 00 	mov    %rbp,0x140(%rsp)
   f03e5:	4c 89 cd             	mov    %r9,%rbp
   f03e8:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   f03ed:	64 48 8b 04 25 28 00 00 00 	mov    %fs:0x28,%rax
   f03f6:	48 89 84 24 28 01 00 00 	mov    %rax,0x128(%rsp)
   f03fe:	31 c0                	xor    %eax,%eax
   f0400:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   f0405:	41 83 f9 01          	cmp    $0x1,%r9d
   f0409:	0f 86 09 03 00 00    	jbe    f0718 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x358>
   f040f:	4c 89 b4 24 58 01 00 00 	mov    %r14,0x158(%rsp)
   f0417:	66 48 0f 6e c9       	movq   %rcx,%xmm1
   f041c:	4c 8d 76 08          	lea    0x8(%rsi),%r14
   f0420:	8b b6 64 01 00 00    	mov    0x164(%rsi),%esi
   f0426:	0f 11 44 24 68       	movups %xmm0,0x68(%rsp)
   f042b:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
   f0430:	66 48 0f 6e c0       	movq   %rax,%xmm0
   f0435:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
   f0439:	c6 44 24 60 00       	movb   $0x0,0x60(%rsp)
   f043e:	48 c7 84 24 98 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0x98(%rsp)
   f044a:	0f 11 84 24 88 00 00 00 	movups %xmm0,0x88(%rsp)
   f0452:	83 fe ff             	cmp    $0xffffffff,%esi
   f0455:	0f 85 d5 01 00 00    	jne    f0630 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x270>
   f045b:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   f0463:	49 89 d7             	mov    %rdx,%r15
   f0466:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   f046e:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   f0476:	49 83 f9 04          	cmp    $0x4,%r9
   f047a:	0f 86 a5 02 00 00    	jbe    f0725 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x365>
   f0480:	8d 45 ff             	lea    -0x1(%rbp),%eax
   f0483:	89 6c 24 24          	mov    %ebp,0x24(%rsp)
   f0487:	45 31 ed             	xor    %r13d,%r13d
   f048a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f048f:	31 c0                	xor    %eax,%eax
   f0491:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   f0496:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   f049b:	84 c0                	test   %al,%al
   f049d:	0f 85 63 01 00 00    	jne    f0606 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x246>
   f04a3:	66 90                	xchg   %ax,%ax
   f04a5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f04b0:	4c 39 6c 24 28       	cmp    %r13,0x28(%rsp)
   f04b5:	0f 84 4b 01 00 00    	je     f0606 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x246>
   f04bb:	4c 89 ef             	mov    %r13,%rdi
   f04be:	41 8d 6d 01          	lea    0x1(%r13),%ebp
   f04c2:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   f04c7:	45 89 ec             	mov    %r13d,%r12d
   f04ca:	48 c1 e7 05          	shl    $0x5,%rdi
   f04ce:	41 89 ed             	mov    %ebp,%r13d
   f04d1:	8b 6c 24 24          	mov    0x24(%rsp),%ebp
   f04d5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   f04da:	48 8d 5f 20          	lea    0x20(%rdi),%rbx
   f04de:	eb 1c                	jmp    f04fc <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x13c>
   f04e0:	41 83 c5 01          	add    $0x1,%r13d
   f04e4:	41 39 ed             	cmp    %ebp,%r13d
   f04e7:	0f 83 03 01 00 00    	jae    f05f0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x230>
   f04ed:	48 83 c3 20          	add    $0x20,%rbx
   f04f1:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
   f04f6:	0f 85 f4 00 00 00    	jne    f05f0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x230>
   f04fc:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
   f0501:	44 89 ea             	mov    %r13d,%edx
   f0504:	44 89 e6             	mov    %r12d,%esi
   f0507:	4c 89 f7             	mov    %r14,%rdi
   f050a:	e8 f1 22 f2 ff       	call   12800 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_7ContextERT0_.isra.0>
   f050f:	84 c0                	test   %al,%al
   f0511:	74 cd                	je     f04e0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x120>
   f0513:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f0518:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   f051d:	48 8b 40 68          	mov    0x68(%rax),%rax
   f0521:	8b 7c 30 18          	mov    0x18(%rax,%rsi,1),%edi
   f0525:	39 7c 18 18          	cmp    %edi,0x18(%rax,%rbx,1)
   f0529:	0f 82 d9 01 00 00    	jb     f0708 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x348>
   f052f:	44 89 2c 24          	mov    %r13d,(%rsp)
   f0533:	44 89 e2             	mov    %r12d,%edx
   f0536:	4c 89 f6             	mov    %r14,%rsi
   f0539:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
   f0541:	e8 3a 76 04 00       	call   137b80 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f0546:	8b 14 24             	mov    (%rsp),%edx
   f0549:	4c 89 f6             	mov    %r14,%rsi
   f054c:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   f0554:	e8 27 76 04 00       	call   137b80 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f0559:	48 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%rdx
   f0561:	48 8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%rax
   f0569:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   f0573:	8b 00                	mov    (%rax),%eax
   f0575:	8b 0a                	mov    (%rdx),%ecx
   f0577:	49 83 07 01          	addq   $0x1,(%r15)
   f057b:	89 ca                	mov    %ecx,%edx
   f057d:	39 c8                	cmp    %ecx,%eax
   f057f:	0f 46 d0             	cmovbe %eax,%edx
   f0582:	48 c1 e2 20          	shl    $0x20,%rdx
   f0586:	39 c8                	cmp    %ecx,%eax
   f0588:	0f 42 c1             	cmovb  %ecx,%eax
   f058b:	48 09 c2             	or     %rax,%rdx
   f058e:	48 89 d0             	mov    %rdx,%rax
   f0591:	48 c1 e8 1e          	shr    $0x1e,%rax
   f0595:	48 31 d0             	xor    %rdx,%rax
   f0598:	48 0f af c6          	imul   %rsi,%rax
   f059c:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   f05a6:	48 89 c2             	mov    %rax,%rdx
   f05a9:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f05ad:	48 31 d0             	xor    %rdx,%rax
   f05b0:	48 0f af c6          	imul   %rsi,%rax
   f05b4:	48 89 c2             	mov    %rax,%rdx
   f05b7:	48 c1 ea 1f          	shr    $0x1f,%rdx
   f05bb:	48 31 d0             	xor    %rdx,%rax
   f05be:	49 01 47 08          	add    %rax,0x8(%r15)
   f05c2:	48 8b 84 24 88 00 00 00 	mov    0x88(%rsp),%rax
   f05ca:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f05ce:	0f 84 0c ff ff ff    	je     f04e0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x120>
   f05d4:	48 83 c0 01          	add    $0x1,%rax
   f05d8:	41 83 c5 01          	add    $0x1,%r13d
   f05dc:	48 89 84 24 88 00 00 00 	mov    %rax,0x88(%rsp)
   f05e4:	41 39 ed             	cmp    %ebp,%r13d
   f05e7:	0f 82 00 ff ff ff    	jb     f04ed <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x12d>
   f05ed:	0f 1f 00             	nopl   (%rax)
   f05f0:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
   f05f5:	0f b6 44 24 60       	movzbl 0x60(%rsp),%eax
   f05fa:	49 83 c5 01          	add    $0x1,%r13
   f05fe:	84 c0                	test   %al,%al
   f0600:	0f 84 aa fe ff ff    	je     f04b0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xf0>
   f0606:	8b 6c 24 24          	mov    0x24(%rsp),%ebp
   f060a:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   f060f:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f0614:	4c 8b a4 24 48 01 00 00 	mov    0x148(%rsp),%r12
   f061c:	4c 8b ac 24 50 01 00 00 	mov    0x150(%rsp),%r13
   f0624:	4c 8b bc 24 60 01 00 00 	mov    0x160(%rsp),%r15
   f062c:	eb 24                	jmp    f0652 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x292>
   f062e:	66 90                	xchg   %ax,%ax
   f0630:	48 8d 4c 24 58       	lea    0x58(%rsp),%rcx
   f0635:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
   f063a:	4c 89 f7             	mov    %r14,%rdi
   f063d:	4c 89 0c 24          	mov    %r9,(%rsp)
   f0641:	4c 8d 84 24 a0 00 00 00 	lea    0xa0(%rsp),%r8
   f0649:	e8 b2 be fa ff       	call   9c500 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE9selfPairsIZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS4_8CountersERT_mEUlRKSB_RKT0_E_NS_6detail9AcceptAllEEEvjRNS2_7ContextESC_RSF_>
   f064e:	4c 8b 0c 24          	mov    (%rsp),%r9
   f0652:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   f0658:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
   f065e:	0f b6 44 24 60       	movzbl 0x60(%rsp),%eax
   f0663:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f066b:	66 0f 6f 84 24 80 00 00 00 	movdqa 0x80(%rsp),%xmm0
   f0674:	0f 29 94 24 e0 00 00 00 	movaps %xmm2,0xe0(%rsp)
   f067c:	0f 29 84 24 00 01 00 00 	movaps %xmm0,0x100(%rsp)
   f0684:	84 c0                	test   %al,%al
   f0686:	74 08                	je     f0690 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2d0>
   f0688:	3c 0b                	cmp    $0xb,%al
   f068a:	0f 85 4e 03 00 00    	jne    f09de <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x61e>
   f0690:	4c 8b b4 24 58 01 00 00 	mov    0x158(%rsp),%r14
   f0698:	48 8b 94 24 f0 00 00 00 	mov    0xf0(%rsp),%rdx
   f06a0:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   f06a8:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   f06b0:	48 89 13             	mov    %rdx,(%rbx)
   f06b3:	48 8b 94 24 e8 00 00 00 	mov    0xe8(%rsp),%rdx
   f06bb:	4c 89 4b 08          	mov    %r9,0x8(%rbx)
   f06bf:	48 89 53 10          	mov    %rdx,0x10(%rbx)
   f06c3:	31 d2                	xor    %edx,%edx
   f06c5:	85 ed                	test   %ebp,%ebp
   f06c7:	0f 95 c2             	setne  %dl
   f06ca:	3c 0b                	cmp    $0xb,%al
   f06cc:	89 53 20             	mov    %edx,0x20(%rbx)
   f06cf:	0f 94 43 30          	sete   0x30(%rbx)
   f06d3:	48 8b 84 24 28 01 00 00 	mov    0x128(%rsp),%rax
   f06db:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f06e4:	0f 85 29 03 00 00    	jne    f0a13 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x653>
   f06ea:	48 89 d8             	mov    %rbx,%rax
   f06ed:	48 8b ac 24 40 01 00 00 	mov    0x140(%rsp),%rbp
   f06f5:	48 8b 9c 24 38 01 00 00 	mov    0x138(%rsp),%rbx
   f06fd:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
   f0704:	c3                   	ret
   f0705:	0f 1f 00             	nopl   (%rax)
   f0708:	44 89 24 24          	mov    %r12d,(%rsp)
   f070c:	44 89 ea             	mov    %r13d,%edx
   f070f:	e9 22 fe ff ff       	jmp    f0536 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x176>
   f0714:	0f 1f 40 00          	nopl   0x0(%rax)
   f0718:	0f 11 84 24 e8 00 00 00 	movups %xmm0,0xe8(%rsp)
   f0720:	e9 73 ff ff ff       	jmp    f0698 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2d8>
   f0725:	49 8d 41 ff          	lea    -0x1(%r9),%rax
   f0729:	49 0f af c1          	imul   %r9,%rax
   f072d:	48 d1 e8             	shr    $1,%rax
   f0730:	48 39 c1             	cmp    %rax,%rcx
   f0733:	0f 82 47 fd ff ff    	jb     f0480 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xc0>
   f0739:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   f073e:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   f0743:	45 31 ff             	xor    %r15d,%r15d
   f0746:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   f074b:	48 8b 70 68          	mov    0x68(%rax),%rsi
   f074f:	48 8b 40 58          	mov    0x58(%rax),%rax
   f0753:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
   f0758:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   f075d:	4c 8d 66 20          	lea    0x20(%rsi),%r12
   f0761:	41 8d 71 ff          	lea    -0x1(%r9),%esi
   f0765:	48 89 04 24          	mov    %rax,(%rsp)
   f0769:	48 83 c0 10          	add    $0x10,%rax
   f076d:	89 74 24 18          	mov    %esi,0x18(%rsp)
   f0771:	0f 1f 40 00          	nopl   0x0(%rax)
   f0775:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f0780:	44 89 7c 24 08       	mov    %r15d,0x8(%rsp)
   f0785:	41 83 c7 01          	add    $0x1,%r15d
   f0789:	49 89 c6             	mov    %rax,%r14
   f078c:	4c 89 e3             	mov    %r12,%rbx
   f078f:	44 89 3c 24          	mov    %r15d,(%rsp)
   f0793:	45 89 fd             	mov    %r15d,%r13d
   f0796:	eb 4d                	jmp    f07e5 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x425>
   f0798:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f07a0:	49 8b 54 24 e8       	mov    -0x18(%r12),%rdx
   f07a5:	48 85 13             	test   %rdx,(%rbx)
   f07a8:	74 46                	je     f07f0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x430>
   f07aa:	8b 50 f0             	mov    -0x10(%rax),%edx
   f07ad:	41 8b 4e 08          	mov    0x8(%r14),%ecx
   f07b1:	48 83 44 24 70 01    	addq   $0x1,0x70(%rsp)
   f07b7:	39 ca                	cmp    %ecx,%edx
   f07b9:	7c 55                	jl     f0810 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x450>
   f07bb:	0f 84 54 01 00 00    	je     f0915 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x555>
   f07c1:	0f 1f 40 00          	nopl   0x0(%rax)
   f07c5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f07d0:	41 83 c5 01          	add    $0x1,%r13d
   f07d4:	48 83 c3 20          	add    $0x20,%rbx
   f07d8:	49 83 c6 10          	add    $0x10,%r14
   f07dc:	41 39 ed             	cmp    %ebp,%r13d
   f07df:	0f 83 ab 01 00 00    	jae    f0990 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5d0>
   f07e5:	49 8b 54 24 e0       	mov    -0x20(%r12),%rdx
   f07ea:	48 85 53 08          	test   %rdx,0x8(%rbx)
   f07ee:	75 b0                	jne    f07a0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f07f0:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   f07f5:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
   f07f9:	74 d5                	je     f07d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f07fb:	48 83 c2 01          	add    $0x1,%rdx
   f07ff:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
   f0804:	eb ca                	jmp    f07d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f0806:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f0810:	41 8b 3e             	mov    (%r14),%edi
   f0813:	8b 70 f8             	mov    -0x8(%rax),%esi
   f0816:	39 f7                	cmp    %esi,%edi
   f0818:	0f 8d 02 01 00 00    	jge    f0920 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x560>
   f081e:	44 8b 40 f4          	mov    -0xc(%rax),%r8d
   f0822:	45 3b 46 0c          	cmp    0xc(%r14),%r8d
   f0826:	0f 8d 00 01 00 00    	jge    f092c <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x56c>
   f082c:	44 8b 50 fc          	mov    -0x4(%rax),%r10d
   f0830:	45 39 56 04          	cmp    %r10d,0x4(%r14)
   f0834:	0f 8d f2 00 00 00    	jge    f092c <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x56c>
   f083a:	41 8b 7c 24 f8       	mov    -0x8(%r12),%edi
   f083f:	39 7b 18             	cmp    %edi,0x18(%rbx)
   f0842:	0f 82 86 01 00 00    	jb     f09ce <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x60e>
   f0848:	44 89 6c 24 24       	mov    %r13d,0x24(%rsp)
   f084d:	8b 54 24 08          	mov    0x8(%rsp),%edx
   f0851:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   f0856:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
   f085e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f0863:	4c 89 fe             	mov    %r15,%rsi
   f0866:	e8 15 73 04 00       	call   137b80 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f086b:	8b 54 24 24          	mov    0x24(%rsp),%edx
   f086f:	4c 89 fe             	mov    %r15,%rsi
   f0872:	48 8d bc 24 e0 00 00 00 	lea    0xe0(%rsp),%rdi
   f087a:	e8 01 73 04 00       	call   137b80 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE4viewEj>
   f087f:	48 8b 8c 24 b8 00 00 00 	mov    0xb8(%rsp),%rcx
   f0887:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   f088c:	48 8b 94 24 f8 00 00 00 	mov    0xf8(%rsp),%rdx
   f0894:	8b 31                	mov    (%rcx),%esi
   f0896:	8b 12                	mov    (%rdx),%edx
   f0898:	48 83 00 01          	addq   $0x1,(%rax)
   f089c:	89 f1                	mov    %esi,%ecx
   f089e:	39 f2                	cmp    %esi,%edx
   f08a0:	0f 46 ca             	cmovbe %edx,%ecx
   f08a3:	48 c1 e1 20          	shl    $0x20,%rcx
   f08a7:	39 f2                	cmp    %esi,%edx
   f08a9:	0f 42 d6             	cmovb  %esi,%edx
   f08ac:	48 be b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rsi
   f08b6:	48 09 d1             	or     %rdx,%rcx
   f08b9:	48 89 ca             	mov    %rcx,%rdx
   f08bc:	48 c1 ea 1e          	shr    $0x1e,%rdx
   f08c0:	48 31 ca             	xor    %rcx,%rdx
   f08c3:	48 0f af d6          	imul   %rsi,%rdx
   f08c7:	48 be eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rsi
   f08d1:	48 89 d1             	mov    %rdx,%rcx
   f08d4:	48 c1 e9 1b          	shr    $0x1b,%rcx
   f08d8:	48 31 ca             	xor    %rcx,%rdx
   f08db:	48 0f af d6          	imul   %rsi,%rdx
   f08df:	48 89 d1             	mov    %rdx,%rcx
   f08e2:	48 c1 e9 1f          	shr    $0x1f,%rcx
   f08e6:	48 31 ca             	xor    %rcx,%rdx
   f08e9:	48 01 50 08          	add    %rdx,0x8(%rax)
   f08ed:	48 8b 94 24 88 00 00 00 	mov    0x88(%rsp),%rdx
   f08f5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   f08fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
   f08fe:	0f 84 cc fe ff ff    	je     f07d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f0904:	48 83 c2 01          	add    $0x1,%rdx
   f0908:	48 89 94 24 88 00 00 00 	mov    %rdx,0x88(%rsp)
   f0910:	e9 bb fe ff ff       	jmp    f07d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f0915:	41 8b 3e             	mov    (%r14),%edi
   f0918:	8b 70 f8             	mov    -0x8(%rax),%esi
   f091b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f0920:	39 f7                	cmp    %esi,%edi
   f0922:	0f 8f a8 fe ff ff    	jg     f07d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f0928:	44 8b 40 f4          	mov    -0xc(%rax),%r8d
   f092c:	45 8b 4e 0c          	mov    0xc(%r14),%r9d
   f0930:	45 39 c8             	cmp    %r9d,%r8d
   f0933:	0f 8f 97 fe ff ff    	jg     f07d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f0939:	45 8b 56 04          	mov    0x4(%r14),%r10d
   f093d:	44 8b 58 fc          	mov    -0x4(%rax),%r11d
   f0941:	45 39 da             	cmp    %r11d,%r10d
   f0944:	0f 8f 86 fe ff ff    	jg     f07d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f094a:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
   f094f:	41 80 7f 21 01       	cmpb   $0x1,0x21(%r15)
   f0954:	0f 95 44 24 24       	setne  0x24(%rsp)
   f0959:	45 39 d8             	cmp    %r11d,%r8d
   f095c:	41 0f 95 c0          	setne  %r8b
   f0960:	44 22 44 24 24       	and    0x24(%rsp),%r8b
   f0965:	45 39 d1             	cmp    %r10d,%r9d
   f0968:	41 0f 95 c1          	setne  %r9b
   f096c:	45 21 c8             	and    %r9d,%r8d
   f096f:	39 f2                	cmp    %esi,%edx
   f0971:	0f 95 c2             	setne  %dl
   f0974:	41 84 d0             	test   %dl,%r8b
   f0977:	0f 84 bd fe ff ff    	je     f083a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x47a>
   f097d:	39 f9                	cmp    %edi,%ecx
   f097f:	0f 84 b5 fe ff ff    	je     f083a <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x47a>
   f0985:	e9 46 fe ff ff       	jmp    f07d0 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f098a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f0990:	44 8b 3c 24          	mov    (%rsp),%r15d
   f0994:	49 83 c4 20          	add    $0x20,%r12
   f0998:	48 83 c0 10          	add    $0x10,%rax
   f099c:	44 39 7c 24 18       	cmp    %r15d,0x18(%rsp)
   f09a1:	0f 85 d9 fd ff ff    	jne    f0780 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3c0>
   f09a7:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
   f09ac:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
   f09b1:	4c 8b a4 24 48 01 00 00 	mov    0x148(%rsp),%r12
   f09b9:	4c 8b ac 24 50 01 00 00 	mov    0x150(%rsp),%r13
   f09c1:	4c 8b bc 24 60 01 00 00 	mov    0x160(%rsp),%r15
   f09c9:	e9 84 fc ff ff       	jmp    f0652 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x292>
   f09ce:	8b 74 24 08          	mov    0x8(%rsp),%esi
   f09d2:	44 89 ea             	mov    %r13d,%edx
   f09d5:	89 74 24 24          	mov    %esi,0x24(%rsp)
   f09d9:	e9 73 fe ff ff       	jmp    f0851 <_ZNK5bench12LibraryIndexIiLb0EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x491>
   f09de:	48 8b 3d 7b 28 08 00 	mov    0x8287b(%rip),%rdi        # 173260 <stderr@GLIBC_2.2.5>
   f09e5:	0f b6 d0             	movzbl %al,%edx
   f09e8:	48 8d 35 b1 9f 06 00 	lea    0x69fb1(%rip),%rsi        # 15a9a0 <_IO_stdin_used+0x19a0>
   f09ef:	31 c0                	xor    %eax,%eax
   f09f1:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   f09f9:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   f0a01:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   f0a09:	e8 32 69 f1 ff       	call   7340 <fprintf@plt>
   f0a0e:	e8 0d 67 f1 ff       	call   7120 <abort@plt>
   f0a13:	4c 89 a4 24 48 01 00 00 	mov    %r12,0x148(%rsp)
   f0a1b:	4c 89 ac 24 50 01 00 00 	mov    %r13,0x150(%rsp)
   f0a23:	4c 89 b4 24 58 01 00 00 	mov    %r14,0x158(%rsp)
   f0a2b:	4c 89 bc 24 60 01 00 00 	mov    %r15,0x160(%rsp)
   f0a33:	e8 28 68 f1 ff       	call   7260 <__stack_chk_fail@plt>

# control ordered_pairs bench::Counters bench::LibraryIndex<int, true>::pairs<(anonymous namespace)::PairSink>((anonymous namespace)::PairSink&, unsigned long) const

/home/dima/.cache/quadtree-g1-combined.ARqsxS/control-build/bench/quadtree-bench:     file format elf64-x86-64


Disassembly of section .text:

00000000000f3f00 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m>:
   f3f00:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
   f3f07:	66 0f ef c0          	pxor   %xmm0,%xmm0
   f3f0b:	48 89 9c 24 c8 01 00 00 	mov    %rbx,0x1c8(%rsp)
   f3f13:	48 89 fb             	mov    %rdi,%rbx
   f3f16:	4c 89 bc 24 f0 01 00 00 	mov    %r15,0x1f0(%rsp)
   f3f1e:	49 89 f7             	mov    %rsi,%r15
   f3f21:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   f3f26:	8b 96 d0 00 00 00    	mov    0xd0(%rsi),%edx
   f3f2c:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
   f3f33:	64 48 8b 3c 25 28 00 00 00 	mov    %fs:0x28,%rdi
   f3f3c:	48 89 bc 24 b8 01 00 00 	mov    %rdi,0x1b8(%rsp)
   f3f44:	31 ff                	xor    %edi,%edi
   f3f46:	83 fa 01             	cmp    $0x1,%edx
   f3f49:	0f 86 01 03 00 00    	jbe    f4250 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x350>
   f3f4f:	48 39 f2             	cmp    %rsi,%rdx
   f3f52:	74 44                	je     f3f98 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x98>
   f3f54:	ba 07 00 00 00       	mov    $0x7,%edx
   f3f59:	48 8b 3d 00 f3 07 00 	mov    0x7f300(%rip),%rdi        # 173260 <stderr@GLIBC_2.2.5>
   f3f60:	48 8d 35 39 6a 06 00 	lea    0x66a39(%rip),%rsi        # 15a9a0 <_IO_stdin_used+0x19a0>
   f3f67:	31 c0                	xor    %eax,%eax
   f3f69:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f3f71:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f3f79:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f3f81:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f3f89:	e8 b2 33 f1 ff       	call   7340 <fprintf@plt>
   f3f8e:	e8 8d 31 f1 ff       	call   7120 <abort@plt>
   f3f93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f3f98:	49 89 c8             	mov    %rcx,%r8
   f3f9b:	0f 11 84 24 98 00 00 00 	movups %xmm0,0x98(%rsp)
   f3fa3:	49 8b 47 50          	mov    0x50(%r15),%rax
   f3fa7:	89 d1                	mov    %edx,%ecx
   f3fa9:	0f 11 84 24 a8 00 00 00 	movups %xmm0,0xa8(%rsp)
   f3fb1:	66 49 0f 6e d0       	movq   %r8,%xmm2
   f3fb6:	66 48 0f 6e c7       	movq   %rdi,%xmm0
   f3fbb:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
   f3fbf:	c6 84 24 90 00 00 00 00 	movb   $0x0,0x90(%rsp)
   f3fc7:	48 c7 84 24 c8 00 00 00 ff ff ff ff 	movq   $0xffffffffffffffff,0xc8(%rsp)
   f3fd3:	0f 11 84 24 b8 00 00 00 	movups %xmm0,0xb8(%rsp)
   f3fdb:	48 85 c0             	test   %rax,%rax
   f3fde:	0f 84 c6 08 00 00    	je     f48aa <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9aa>
   f3fe4:	48 89 84 24 d0 00 00 00 	mov    %rax,0xd0(%rsp)
   f3fec:	48 89 84 24 d8 00 00 00 	mov    %rax,0xd8(%rsp)
   f3ff4:	48 c7 84 24 e0 00 00 00 00 00 00 00 	movq   $0x0,0xe0(%rsp)
   f4000:	48 c7 84 24 e8 00 00 00 00 00 00 00 	movq   $0x0,0xe8(%rsp)
   f400c:	48 89 84 24 f0 00 00 00 	mov    %rax,0xf0(%rsp)
   f4014:	48 c7 84 24 f8 00 00 00 00 00 00 00 	movq   $0x0,0xf8(%rsp)
   f4020:	48 c7 84 24 00 01 00 00 00 00 00 00 	movq   $0x0,0x100(%rsp)
   f402c:	48 89 84 24 08 01 00 00 	mov    %rax,0x108(%rsp)
   f4034:	48 c7 84 24 10 01 00 00 00 00 00 00 	movq   $0x0,0x110(%rsp)
   f4040:	48 c7 84 24 18 01 00 00 00 00 00 00 	movq   $0x0,0x118(%rsp)
   f404c:	48 89 84 24 20 01 00 00 	mov    %rax,0x120(%rsp)
   f4054:	48 c7 84 24 28 01 00 00 00 00 00 00 	movq   $0x0,0x128(%rsp)
   f4060:	48 c7 84 24 30 01 00 00 00 00 00 00 	movq   $0x0,0x130(%rsp)
   f406c:	48 89 84 24 38 01 00 00 	mov    %rax,0x138(%rsp)
   f4074:	48 c7 84 24 40 01 00 00 00 00 00 00 	movq   $0x0,0x140(%rsp)
   f4080:	48 c7 84 24 48 01 00 00 00 00 00 00 	movq   $0x0,0x148(%rsp)
   f408c:	48 89 84 24 50 01 00 00 	mov    %rax,0x150(%rsp)
   f4094:	48 c7 84 24 58 01 00 00 00 00 00 00 	movq   $0x0,0x158(%rsp)
   f40a0:	48 c7 84 24 60 01 00 00 00 00 00 00 	movq   $0x0,0x160(%rsp)
   f40ac:	48 89 84 24 68 01 00 00 	mov    %rax,0x168(%rsp)
   f40b4:	48 c7 84 24 70 01 00 00 00 00 00 00 	movq   $0x0,0x170(%rsp)
   f40c0:	48 c7 84 24 78 01 00 00 00 00 00 00 	movq   $0x0,0x178(%rsp)
   f40cc:	48 89 84 24 80 01 00 00 	mov    %rax,0x180(%rsp)
   f40d4:	48 c7 84 24 88 01 00 00 00 00 00 00 	movq   $0x0,0x188(%rsp)
   f40e0:	48 c7 84 24 90 01 00 00 00 00 00 00 	movq   $0x0,0x190(%rsp)
   f40ec:	48 89 84 24 98 01 00 00 	mov    %rax,0x198(%rsp)
   f40f4:	48 c7 84 24 a0 01 00 00 00 00 00 00 	movq   $0x0,0x1a0(%rsp)
   f4100:	48 c7 84 24 a8 01 00 00 00 00 00 00 	movq   $0x0,0x1a8(%rsp)
   f410c:	c7 84 24 b0 01 00 00 00 00 00 00 	movl   $0x0,0x1b0(%rsp)
   f4117:	c6 84 24 b4 01 00 00 00 	movb   $0x0,0x1b4(%rsp)
   f411f:	49 39 b7 a0 01 00 00 	cmp    %rsi,0x1a0(%r15)
   f4126:	0f 82 b4 01 00 00    	jb     f42e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f412c:	49 39 b7 b8 01 00 00 	cmp    %rsi,0x1b8(%r15)
   f4133:	0f 82 a7 01 00 00    	jb     f42e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3e0>
   f4139:	41 80 bf 6c 02 00 00 00 	cmpb   $0x0,0x26c(%r15)
   f4141:	0f 85 aa 07 00 00    	jne    f48f1 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9f1>
   f4147:	49 8d 47 08          	lea    0x8(%r15),%rax
   f414b:	4d 8b 9f 98 01 00 00 	mov    0x198(%r15),%r11
   f4152:	c6 44 24 43 00       	movb   $0x0,0x43(%rsp)
   f4157:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   f415c:	49 8d 87 88 01 00 00 	lea    0x188(%r15),%rax
   f4163:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   f4168:	41 c6 87 6c 02 00 00 01 	movb   $0x1,0x26c(%r15)
   f4170:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
   f4175:	85 c9                	test   %ecx,%ecx
   f4177:	0f 84 7a 01 00 00    	je     f42f7 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f417d:	8d 41 ff             	lea    -0x1(%rcx),%eax
   f4180:	83 f8 02             	cmp    $0x2,%eax
   f4183:	0f 86 3c 07 00 00    	jbe    f48c5 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9c5>
   f4189:	89 cf                	mov    %ecx,%edi
   f418b:	4c 89 d8             	mov    %r11,%rax
   f418e:	66 0f 6f 05 fa 86 06 00 	movdqa 0x686fa(%rip),%xmm0        # 15c890 <C.66.5+0x270>
   f4196:	c1 ef 02             	shr    $0x2,%edi
   f4199:	89 fa                	mov    %edi,%edx
   f419b:	48 c1 e2 04          	shl    $0x4,%rdx
   f419f:	4c 01 da             	add    %r11,%rdx
   f41a2:	41 bb 04 00 00 00    	mov    $0x4,%r11d
   f41a8:	66 41 0f 6e cb       	movd   %r11d,%xmm1
   f41ad:	66 0f 70 c9 00       	pshufd $0x0,%xmm1,%xmm1
   f41b2:	0f 1f 00             	nopl   (%rax)
   f41b5:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f41c0:	0f 11 00             	movups %xmm0,(%rax)
   f41c3:	48 83 c0 10          	add    $0x10,%rax
   f41c7:	66 0f fe c1          	paddd  %xmm1,%xmm0
   f41cb:	48 39 d0             	cmp    %rdx,%rax
   f41ce:	75 f0                	jne    f41c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2c0>
   f41d0:	8d 04 bd 00 00 00 00 	lea    0x0(,%rdi,4),%eax
   f41d7:	39 c8                	cmp    %ecx,%eax
   f41d9:	74 25                	je     f4200 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f41db:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
   f41e0:	89 c2                	mov    %eax,%edx
   f41e2:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f41e6:	8d 50 01             	lea    0x1(%rax),%edx
   f41e9:	39 ca                	cmp    %ecx,%edx
   f41eb:	73 13                	jae    f4200 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f41ed:	89 d7                	mov    %edx,%edi
   f41ef:	83 c0 02             	add    $0x2,%eax
   f41f2:	41 89 14 bb          	mov    %edx,(%r11,%rdi,4)
   f41f6:	39 c8                	cmp    %ecx,%eax
   f41f8:	73 06                	jae    f4200 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x300>
   f41fa:	89 c2                	mov    %eax,%edx
   f41fc:	41 89 04 93          	mov    %eax,(%r11,%rdx,4)
   f4200:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
   f4207:	0f 86 ea 00 00 00    	jbe    f42f7 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x3f7>
   f420d:	49 39 b7 48 02 00 00 	cmp    %rsi,0x248(%r15)
   f4214:	0f 82 e7 00 00 00    	jb     f4301 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f421a:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f4224:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f422b:	48 c1 ea 04          	shr    $0x4,%rdx
   f422f:	48 39 f2             	cmp    %rsi,%rdx
   f4232:	0f 82 c9 00 00 00    	jb     f4301 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x401>
   f4238:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f423c:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   f4241:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f4246:	e8 75 f0 f1 ff       	call   132c0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f424b:	e9 db 00 00 00       	jmp    f432b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x42b>
   f4250:	48 39 f2             	cmp    %rsi,%rdx
   f4253:	0f 85 fb fc ff ff    	jne    f3f54 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54>
   f4259:	48 89 d0             	mov    %rdx,%rax
   f425c:	0f 11 84 24 d8 00 00 00 	movups %xmm0,0xd8(%rsp)
   f4264:	31 d2                	xor    %edx,%edx
   f4266:	48 8b 8c 24 e0 00 00 00 	mov    0xe0(%rsp),%rcx
   f426e:	85 c0                	test   %eax,%eax
   f4270:	89 c7                	mov    %eax,%edi
   f4272:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   f427a:	0f 95 c0             	setne  %al
   f427d:	48 c7 43 28 00 00 00 00 	movq   $0x0,0x28(%rbx)
   f4285:	80 fa 0b             	cmp    $0xb,%dl
   f4288:	48 89 0b             	mov    %rcx,(%rbx)
   f428b:	48 8b 8c 24 d8 00 00 00 	mov    0xd8(%rsp),%rcx
   f4293:	0f b6 c0             	movzbl %al,%eax
   f4296:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
   f429a:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
   f429e:	89 43 20             	mov    %eax,0x20(%rbx)
   f42a1:	0f 94 43 30          	sete   0x30(%rbx)
   f42a5:	48 8b 84 24 b8 01 00 00 	mov    0x1b8(%rsp),%rax
   f42ad:	64 48 2b 04 25 28 00 00 00 	sub    %fs:0x28,%rax
   f42b6:	0f 85 10 06 00 00    	jne    f48cc <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9cc>
   f42bc:	48 89 d8             	mov    %rbx,%rax
   f42bf:	4c 8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%r15
   f42c7:	48 8b 9c 24 c8 01 00 00 	mov    0x1c8(%rsp),%rbx
   f42cf:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
   f42d6:	c3                   	ret
   f42d7:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
   f42e0:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f42e8:	e8 13 c7 00 00       	call   100a00 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f42ed:	ba 05 00 00 00       	mov    $0x5,%edx
   f42f2:	e9 62 fc ff ff       	jmp    f3f59 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f42f7:	48 83 fe 01          	cmp    $0x1,%rsi
   f42fb:	0f 86 bd 05 00 00    	jbe    f48be <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x9be>
   f4301:	48 89 f0             	mov    %rsi,%rax
   f4304:	31 c9                	xor    %ecx,%ecx
   f4306:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   f4310:	48 d1 e8             	shr    $1,%rax
   f4313:	83 c1 02             	add    $0x2,%ecx
   f4316:	48 83 f8 01          	cmp    $0x1,%rax
   f431a:	75 f4                	jne    f4310 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x410>
   f431c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f4321:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f4326:	e8 55 e9 05 00       	call   152c80 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f432b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f4332:	83 fa 01             	cmp    $0x1,%edx
   f4335:	0f 86 2a 03 00 00    	jbe    f4665 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f433b:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f4343:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f434b:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f4353:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f435b:	48 c7 44 24 08 01 00 00 00 	movq   $0x1,0x8(%rsp)
   f4364:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   f4369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f4370:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f4378:	84 c0                	test   %al,%al
   f437a:	0f 85 c0 02 00 00    	jne    f4640 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f4380:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   f4385:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f438a:	48 8d 4c 24 43       	lea    0x43(%rsp),%rcx
   f438f:	4c 8d ac 24 90 00 00 00 	lea    0x90(%rsp),%r13
   f4397:	8b 7c 9f fc          	mov    -0x4(%rdi,%rbx,4),%edi
   f439b:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   f43a0:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   f43a5:	48 8d 4c 24 42       	lea    0x42(%rsp),%rcx
   f43aa:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   f43af:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   f43b4:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   f43b9:	48 8d 5c 24 44       	lea    0x44(%rsp),%rbx
   f43be:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   f43c3:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
   f43c8:	48 89 8c 24 80 00 00 00 	mov    %rcx,0x80(%rsp)
   f43d0:	41 8b 8f 64 01 00 00 	mov    0x164(%r15),%ecx
   f43d7:	89 7c 24 44          	mov    %edi,0x44(%rsp)
   f43db:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
   f43e4:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
   f43e9:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   f43ee:	83 f9 ff             	cmp    $0xffffffff,%ecx
   f43f1:	0f 84 d9 02 00 00    	je     f46d0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7d0>
   f43f7:	89 ce                	mov    %ecx,%esi
   f43f9:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   f43fd:	49 03 b7 f8 00 00 00 	add    0xf8(%r15),%rsi
   f4404:	44 8b 46 64          	mov    0x64(%rsi),%r8d
   f4408:	45 85 c0             	test   %r8d,%r8d
   f440b:	0f 84 ff 01 00 00    	je     f4610 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4411:	48 8b 84 24 c8 00 00 00 	mov    0xc8(%rsp),%rax
   f4419:	48 85 c0             	test   %rax,%rax
   f441c:	0f 84 56 04 00 00    	je     f4878 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x978>
   f4422:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f4426:	74 0c                	je     f4434 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x534>
   f4428:	48 83 e8 01          	sub    $0x1,%rax
   f442c:	48 89 84 24 c8 00 00 00 	mov    %rax,0xc8(%rsp)
   f4434:	48 8b 84 24 98 00 00 00 	mov    0x98(%rsp),%rax
   f443c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   f4440:	74 0c                	je     f444e <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x54e>
   f4442:	48 83 c0 01          	add    $0x1,%rax
   f4446:	48 89 84 24 98 00 00 00 	mov    %rax,0x98(%rsp)
   f444e:	48 89 fa             	mov    %rdi,%rdx
   f4451:	8b 46 1c             	mov    0x1c(%rsi),%eax
   f4454:	48 c1 e2 04          	shl    $0x4,%rdx
   f4458:	49 03 57 58          	add    0x58(%r15),%rdx
   f445c:	39 02                	cmp    %eax,(%rdx)
   f445e:	0f 8f ac 01 00 00    	jg     f4610 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4464:	8b 42 08             	mov    0x8(%rdx),%eax
   f4467:	39 46 14             	cmp    %eax,0x14(%rsi)
   f446a:	0f 8f a0 01 00 00    	jg     f4610 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4470:	8b 46 20             	mov    0x20(%rsi),%eax
   f4473:	39 42 04             	cmp    %eax,0x4(%rdx)
   f4476:	0f 8f 94 01 00 00    	jg     f4610 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f447c:	8b 42 0c             	mov    0xc(%rdx),%eax
   f447f:	39 46 18             	cmp    %eax,0x18(%rsi)
   f4482:	0f 8f 88 01 00 00    	jg     f4610 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x710>
   f4488:	49 8b 47 68          	mov    0x68(%r15),%rax
   f448c:	48 c1 e7 05          	shl    $0x5,%rdi
   f4490:	48 83 ec 08          	sub    $0x8,%rsp
   f4494:	4d 89 e9             	mov    %r13,%r9
   f4497:	48 01 f8             	add    %rdi,%rax
   f449a:	48 8b 08             	mov    (%rax),%rcx
   f449d:	4c 8b 40 08          	mov    0x8(%rax),%r8
   f44a1:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   f44a6:	50                   	push   %rax
   f44a7:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   f44ac:	e8 0f aa f2 ff       	call   1eec0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE11walkOrderedIZNKS2_11orderedSelfIZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS5_8CountersERT_mEUlRKSC_RKT0_E_NS_6detail9AcceptAllEEEvRNS_9WorkspaceIiEEbRNS2_7ContextESD_RSG_EUljE_EEvRKNS2_4NodeERKNS_3BoxIiEENS_6FilterESQ_SD_>
   f44b1:	0f b6 84 24 a0 00 00 00 	movzbl 0xa0(%rsp),%eax
   f44b9:	5a                   	pop    %rdx
   f44ba:	59                   	pop    %rcx
   f44bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   f44c0:	84 c0                	test   %al,%al
   f44c2:	0f 85 78 01 00 00    	jne    f4640 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f44c8:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f44cd:	49 8b 9f b0 01 00 00 	mov    0x1b0(%r15),%rbx
   f44d4:	48 83 fd 7f          	cmp    $0x7f,%rbp
   f44d8:	0f 86 5b 03 00 00    	jbe    f4839 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x939>
   f44de:	49 39 af 48 02 00 00 	cmp    %rbp,0x248(%r15)
   f44e5:	0f 82 58 03 00 00    	jb     f4843 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f44eb:	48 b8 ab aa aa aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   f44f5:	49 f7 a7 60 02 00 00 	mulq   0x260(%r15)
   f44fc:	48 c1 ea 04          	shr    $0x4,%rdx
   f4500:	48 39 ea             	cmp    %rbp,%rdx
   f4503:	0f 82 3a 03 00 00    	jb     f4843 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x943>
   f4509:	49 8b 7f 68          	mov    0x68(%r15),%rdi
   f450d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   f4512:	89 e9                	mov    %ebp,%ecx
   f4514:	48 89 da             	mov    %rbx,%rdx
   f4517:	e8 a4 ed f1 ff       	call   132c0 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE14radixRankOrderERNS_9WorkspaceIiEEPjj.isra.0>
   f451c:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   f4521:	48 85 ed             	test   %rbp,%rbp
   f4524:	0f 84 fb 00 00 00    	je     f4625 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f452a:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
   f452f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   f4534:	31 c9                	xor    %ecx,%ecx
   f4536:	4d 8b 5f 68          	mov    0x68(%r15),%r11
   f453a:	4d 8b 4f 60          	mov    0x60(%r15),%r9
   f453e:	4c 89 c2             	mov    %r8,%rdx
   f4541:	48 8b 07             	mov    (%rdi),%rax
   f4544:	4c 8b 94 24 b8 00 00 00 	mov    0xb8(%rsp),%r10
   f454c:	48 c1 e2 05          	shl    $0x5,%rdx
   f4550:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
   f4554:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   f4559:	4d 8d 34 13          	lea    (%r11,%rdx,1),%r14
   f455d:	4c 8d 68 01          	lea    0x1(%rax),%r13
   f4561:	8b 14 8b             	mov    (%rbx,%rcx,4),%edx
   f4564:	49 8b 76 10          	mov    0x10(%r14),%rsi
   f4568:	4d 8d 64 0d 00       	lea    0x0(%r13,%rcx,1),%r12
   f456d:	48 89 d0             	mov    %rdx,%rax
   f4570:	48 c1 e0 05          	shl    $0x5,%rax
   f4574:	49 39 74 03 10       	cmp    %rsi,0x10(%r11,%rax,1)
   f4579:	48 89 d0             	mov    %rdx,%rax
   f457c:	49 0f 42 c0          	cmovb  %r8,%rax
   f4580:	49 0f 43 d0          	cmovae %r8,%rdx
   f4584:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f4588:	41 8b 34 91          	mov    (%r9,%rdx,4),%esi
   f458c:	39 f0                	cmp    %esi,%eax
   f458e:	89 f2                	mov    %esi,%edx
   f4590:	0f 46 d0             	cmovbe %eax,%edx
   f4593:	48 c1 e2 20          	shl    $0x20,%rdx
   f4597:	39 f0                	cmp    %esi,%eax
   f4599:	0f 42 c6             	cmovb  %esi,%eax
   f459c:	48 09 d0             	or     %rdx,%rax
   f459f:	48 89 c2             	mov    %rax,%rdx
   f45a2:	48 c1 ea 1e          	shr    $0x1e,%rdx
   f45a6:	48 31 c2             	xor    %rax,%rdx
   f45a9:	48 b8 b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rax
   f45b3:	48 0f af d0          	imul   %rax,%rdx
   f45b7:	48 89 d0             	mov    %rdx,%rax
   f45ba:	48 c1 e8 1b          	shr    $0x1b,%rax
   f45be:	48 31 c2             	xor    %rax,%rdx
   f45c1:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f45cb:	48 0f af d0          	imul   %rax,%rdx
   f45cf:	48 89 d0             	mov    %rdx,%rax
   f45d2:	48 c1 e8 1f          	shr    $0x1f,%rax
   f45d6:	48 31 c2             	xor    %rax,%rdx
   f45d9:	48 01 d7             	add    %rdx,%rdi
   f45dc:	49 83 fa ff          	cmp    $0xffffffffffffffff,%r10
   f45e0:	0f 84 82 01 00 00    	je     f4768 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x868>
   f45e6:	49 83 c2 01          	add    $0x1,%r10
   f45ea:	48 83 c1 01          	add    $0x1,%rcx
   f45ee:	4c 89 94 24 b8 00 00 00 	mov    %r10,0xb8(%rsp)
   f45f6:	48 39 cd             	cmp    %rcx,%rbp
   f45f9:	0f 85 62 ff ff ff    	jne    f4561 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x661>
   f45ff:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f4604:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f4608:	4c 89 20             	mov    %r12,(%rax)
   f460b:	eb 18                	jmp    f4625 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f460d:	0f 1f 00             	nopl   (%rax)
   f4610:	49 8b bf b0 01 00 00 	mov    0x1b0(%r15),%rdi
   f4617:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f461c:	31 c9                	xor    %ecx,%ecx
   f461e:	31 f6                	xor    %esi,%esi
   f4620:	e8 5b e6 05 00       	call   152c80 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f4625:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f462c:	48 83 44 24 08 01    	addq   $0x1,0x8(%rsp)
   f4632:	48 89 c2             	mov    %rax,%rdx
   f4635:	48 39 44 24 08       	cmp    %rax,0x8(%rsp)
   f463a:	0f 82 30 fd ff ff    	jb     f4370 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x470>
   f4640:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f4645:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f464d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f4655:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f465d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f4665:	41 c6 87 6c 02 00 00 00 	movb   $0x0,0x26c(%r15)
   f466d:	48 8d bc 24 d0 00 00 00 	lea    0xd0(%rsp),%rdi
   f4675:	e8 86 c3 00 00       	call   100a00 <_ZN8QuadTree9WorkspaceIiED1Ev>
   f467a:	0f b6 94 24 90 00 00 00 	movzbl 0x90(%rsp),%edx
   f4682:	66 0f 6f 84 24 a0 00 00 00 	movdqa 0xa0(%rsp),%xmm0
   f468b:	66 0f 6f 9c 24 90 00 00 00 	movdqa 0x90(%rsp),%xmm3
   f4694:	0f 29 84 24 e0 00 00 00 	movaps %xmm0,0xe0(%rsp)
   f469c:	66 0f 6f 84 24 b0 00 00 00 	movdqa 0xb0(%rsp),%xmm0
   f46a5:	0f 29 9c 24 d0 00 00 00 	movaps %xmm3,0xd0(%rsp)
   f46ad:	0f 29 84 24 f0 00 00 00 	movaps %xmm0,0xf0(%rsp)
   f46b5:	80 fa 0b             	cmp    $0xb,%dl
   f46b8:	74 08                	je     f46c2 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7c2>
   f46ba:	84 d2                	test   %dl,%dl
   f46bc:	0f 85 97 f8 ff ff    	jne    f3f59 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x59>
   f46c2:	41 8b 87 d0 00 00 00 	mov    0xd0(%r15),%eax
   f46c9:	e9 98 fb ff ff       	jmp    f4266 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x366>
   f46ce:	66 90                	xchg   %ax,%ax
   f46d0:	49 8b 6f 68          	mov    0x68(%r15),%rbp
   f46d4:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
   f46d9:	31 db                	xor    %ebx,%ebx
   f46db:	eb 49                	jmp    f4726 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x826>
   f46dd:	0f 1f 00             	nopl   (%rax)
   f46e0:	4c 89 e9             	mov    %r13,%rcx
   f46e3:	44 89 f2             	mov    %r14d,%edx
   f46e6:	4c 89 e7             	mov    %r12,%rdi
   f46e9:	e8 12 e1 f1 ff       	call   12800 <_ZNK8QuadTree5IndexIjiNS_9UncheckedELb1EE13pairQualifiesILb0ENS_6detail9AcceptAllEEEbjjbRNS2_7ContextERT0_.isra.0>
   f46ee:	84 c0                	test   %al,%al
   f46f0:	74 19                	je     f470b <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x80b>
   f46f2:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   f46f7:	48 8d 50 01          	lea    0x1(%rax),%rdx
   f46fb:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   f4700:	49 8b 97 b0 01 00 00 	mov    0x1b0(%r15),%rdx
   f4707:	44 89 34 82          	mov    %r14d,(%rdx,%rax,4)
   f470b:	41 8b 97 d0 00 00 00 	mov    0xd0(%r15),%edx
   f4712:	48 83 c3 01          	add    $0x1,%rbx
   f4716:	0f b6 84 24 90 00 00 00 	movzbl 0x90(%rsp),%eax
   f471e:	39 d3                	cmp    %edx,%ebx
   f4720:	0f 83 9a fd ff ff    	jae    f44c0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c0>
   f4726:	84 c0                	test   %al,%al
   f4728:	0f 85 12 ff ff ff    	jne    f4640 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x740>
   f472e:	8b 44 24 44          	mov    0x44(%rsp),%eax
   f4732:	41 89 de             	mov    %ebx,%r14d
   f4735:	48 89 c6             	mov    %rax,%rsi
   f4738:	48 c1 e0 05          	shl    $0x5,%rax
   f473c:	48 01 e8             	add    %rbp,%rax
   f473f:	48 89 d9             	mov    %rbx,%rcx
   f4742:	48 c1 e1 05          	shl    $0x5,%rcx
   f4746:	48 8b 7c 0d 10       	mov    0x10(%rbp,%rcx,1),%rdi
   f474b:	48 39 78 10          	cmp    %rdi,0x10(%rax)
   f474f:	72 8f                	jb     f46e0 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x7e0>
   f4751:	48 83 c3 01          	add    $0x1,%rbx
   f4755:	39 d3                	cmp    %edx,%ebx
   f4757:	0f 83 6b fd ff ff    	jae    f44c8 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x5c8>
   f475d:	41 89 de             	mov    %ebx,%r14d
   f4760:	eb dd                	jmp    f473f <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x83f>
   f4762:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   f4768:	4c 8d 69 01          	lea    0x1(%rcx),%r13
   f476c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   f4771:	4c 39 ed             	cmp    %r13,%rbp
   f4774:	0f 84 85 fe ff ff    	je     f45ff <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x6ff>
   f477a:	4d 8b 74 13 10       	mov    0x10(%r11,%rdx,1),%r14
   f477f:	4c 89 ee             	mov    %r13,%rsi
   f4782:	0f 1f 00             	nopl   (%rax)
   f4785:	66 66 2e 0f 1f 84 00 00 00 00 00 	data16 cs nopw 0x0(%rax,%rax,1)
   f4790:	8b 04 b3             	mov    (%rbx,%rsi,4),%eax
   f4793:	48 89 c2             	mov    %rax,%rdx
   f4796:	48 c1 e2 05          	shl    $0x5,%rdx
   f479a:	4d 39 74 13 10       	cmp    %r14,0x10(%r11,%rdx,1)
   f479f:	48 89 c2             	mov    %rax,%rdx
   f47a2:	49 0f 42 d0          	cmovb  %r8,%rdx
   f47a6:	49 0f 43 c0          	cmovae %r8,%rax
   f47aa:	45 8b 14 91          	mov    (%r9,%rdx,4),%r10d
   f47ae:	41 8b 04 81          	mov    (%r9,%rax,4),%eax
   f47b2:	44 89 d2             	mov    %r10d,%edx
   f47b5:	44 39 d0             	cmp    %r10d,%eax
   f47b8:	0f 46 d0             	cmovbe %eax,%edx
   f47bb:	48 c1 e2 20          	shl    $0x20,%rdx
   f47bf:	44 39 d0             	cmp    %r10d,%eax
   f47c2:	41 0f 42 c2          	cmovb  %r10d,%eax
   f47c6:	48 83 c6 01          	add    $0x1,%rsi
   f47ca:	48 09 c2             	or     %rax,%rdx
   f47cd:	48 89 d0             	mov    %rdx,%rax
   f47d0:	48 c1 e8 1e          	shr    $0x1e,%rax
   f47d4:	48 31 d0             	xor    %rdx,%rax
   f47d7:	48 ba b9 e5 e4 1c 6d 47 58 bf 	movabs $0xbf58476d1ce4e5b9,%rdx
   f47e1:	48 0f af c2          	imul   %rdx,%rax
   f47e5:	48 89 c2             	mov    %rax,%rdx
   f47e8:	48 c1 ea 1b          	shr    $0x1b,%rdx
   f47ec:	48 31 c2             	xor    %rax,%rdx
   f47ef:	48 b8 eb 11 31 13 bb 49 d0 94 	movabs $0x94d049bb133111eb,%rax
   f47f9:	48 0f af d0          	imul   %rax,%rdx
   f47fd:	48 89 d0             	mov    %rdx,%rax
   f4800:	48 c1 e8 1f          	shr    $0x1f,%rax
   f4804:	48 31 d0             	xor    %rdx,%rax
   f4807:	48 01 c7             	add    %rax,%rdi
   f480a:	48 39 ee             	cmp    %rbp,%rsi
   f480d:	72 81                	jb     f4790 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x890>
   f480f:	48 8d 45 ff          	lea    -0x1(%rbp),%rax
   f4813:	48 83 c1 02          	add    $0x2,%rcx
   f4817:	31 d2                	xor    %edx,%edx
   f4819:	4c 29 e8             	sub    %r13,%rax
   f481c:	48 39 cd             	cmp    %rcx,%rbp
   f481f:	48 0f 42 c2          	cmovb  %rdx,%rax
   f4823:	4d 8d 64 04 01       	lea    0x1(%r12,%rax,1),%r12
   f4828:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f482d:	48 89 78 08          	mov    %rdi,0x8(%rax)
   f4831:	4c 89 20             	mov    %r12,(%rax)
   f4834:	e9 ec fd ff ff       	jmp    f4625 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x725>
   f4839:	48 83 fd 01          	cmp    $0x1,%rbp
   f483d:	0f 86 d3 00 00 00    	jbe    f4916 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xa16>
   f4843:	48 89 e8             	mov    %rbp,%rax
   f4846:	31 c9                	xor    %ecx,%ecx
   f4848:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   f4850:	48 d1 e8             	shr    $1,%rax
   f4853:	83 c1 02             	add    $0x2,%ecx
   f4856:	48 83 f8 01          	cmp    $0x1,%rax
   f485a:	75 f4                	jne    f4850 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x950>
   f485c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   f4861:	48 89 ee             	mov    %rbp,%rsi
   f4864:	48 89 df             	mov    %rbx,%rdi
   f4867:	e8 14 e4 05 00       	call   152c80 <_ZN8QuadTree6detail14introPartitionIjZNKS_5IndexIjiNS_9UncheckedELb1EE9sortRanksEPjmEUljjE_EEvPT_mT0_j>
   f486c:	e9 b0 fc ff ff       	jmp    f4521 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x621>
   f4871:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   f4878:	c6 84 24 90 00 00 00 0b 	movb   $0xb,0x90(%rsp)
   f4880:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   f4885:	48 8b ac 24 d0 01 00 00 	mov    0x1d0(%rsp),%rbp
   f488d:	4c 8b a4 24 d8 01 00 00 	mov    0x1d8(%rsp),%r12
   f4895:	4c 8b ac 24 e0 01 00 00 	mov    0x1e0(%rsp),%r13
   f489d:	4c 8b b4 24 e8 01 00 00 	mov    0x1e8(%rsp),%r14
   f48a5:	e9 bb fd ff ff       	jmp    f4665 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x765>
   f48aa:	e8 91 49 00 00       	call   f9240 <_ZN8QuadTree15defaultResourceEv>
   f48af:	41 8b b7 d0 00 00 00 	mov    0xd0(%r15),%esi
   f48b6:	48 89 f1             	mov    %rsi,%rcx
   f48b9:	e9 26 f7 ff ff       	jmp    f3fe4 <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0xe4>
   f48be:	31 c9                	xor    %ecx,%ecx
   f48c0:	e9 57 fa ff ff       	jmp    f431c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x41c>
   f48c5:	31 c0                	xor    %eax,%eax
   f48c7:	e9 0f f9 ff ff       	jmp    f41db <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x2db>
   f48cc:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f48d4:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f48dc:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f48e4:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f48ec:	e8 6f 29 f1 ff       	call   7260 <__stack_chk_fail@plt>
   f48f1:	48 89 ac 24 d0 01 00 00 	mov    %rbp,0x1d0(%rsp)
   f48f9:	4c 89 a4 24 d8 01 00 00 	mov    %r12,0x1d8(%rsp)
   f4901:	4c 89 ac 24 e0 01 00 00 	mov    %r13,0x1e0(%rsp)
   f4909:	4c 89 b4 24 e8 01 00 00 	mov    %r14,0x1e8(%rsp)
   f4911:	e8 ea 4f 00 00       	call   f9900 <_ZN8QuadTree6detail15activeWorkspaceEv>
   f4916:	31 c9                	xor    %ecx,%ecx
   f4918:	e9 3f ff ff ff       	jmp    f485c <_ZNK5bench12LibraryIndexIiLb1EE5pairsIN12_GLOBAL__N_18PairSinkEEENS_8CountersERT_m+0x95c>
